const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, yearnFor, reminiscence, fulfill, expressLonging, server } = require('../lib/soul-longing');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.longing_intensity = 0.6;
  state.desired_objects = ['lost_time', 'unreachable_place'];
  state.yearning_depth = 0.5;
  state.nostalgia_frequency = 0.4;
  state.fulfillment_level = 0.2;
}

try {
reset();

assert.strictEqual(typeof state.longing_intensity, 'number', 'longing_intensity is number');
assert.strictEqual(typeof state.fulfillment_level, 'number', 'fulfillment_level is number');
assert.strictEqual(Array.isArray(state.desired_objects), true, 'desired_objects is array');
assert.ok(state.sehnsucht !== undefined, 'sehnsucht exists');
assert.ok(state.nostalgia_types.personal !== undefined, 'personal nostalgia exists');
assert.ok(state.nostalgia_types.historical !== undefined, 'historical nostalgia exists');
assert.ok(state.romantic_vs_existential !== undefined, 'romantic vs existential exists');

let r = yearnFor('peace');
assert.ok(r.message.includes('peace'), 'yearnFor includes object');
assert.ok(r.intensity > 0.6, 'yearnFor increases intensity');
assert.ok(state.desired_objects.includes('peace'), 'object added to desires');

r = reminiscence('childhood_summer');
assert.ok(r.message.includes('childhood_summer'), 'reminiscence includes memory');
assert.ok(r.nostalgia_frequency > 0.4, 'reminiscence increases nostalgia');

assert.strictEqual(state.sehnsucht.ache, 0.6, 'sehnsucht ache initial');
const preFulfillLonging = state.longing_intensity;
r = fulfill('meaningful_connection');
assert.ok(r.message.includes('meaningful_connection'), 'fulfill includes experience');
assert.ok(r.fulfillment > 0.2, 'fulfill increases fulfillment');
assert.ok(r.longing < preFulfillLonging, 'fulfill decreases longing');

r = expressLonging();
assert.ok(r.expression.length > 0, 'expressLonging returns expression');
assert.ok(r.intensity >= 0.6, 'expressLonging returns current intensity');

r = yearnFor('');
assert.ok(r.error, 'yearnFor empty returns error');

r = reminiscence('');
assert.ok(r.error, 'reminiscence empty returns error');

r = fulfill('');
assert.ok(r.error, 'fulfill empty returns error');

assert.ok(state.sehnsucht.ache < 0.6, 'sehnsucht ache decreased by fulfill');
assert.ok(state.romantic_vs_existential.tension >= 0.3, 'tension tracked');

const keyPath = path.join(require('os').homedir(), '.soul-longing', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-longing: ALL 17 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
