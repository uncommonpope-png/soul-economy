#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-meta-consciousness-test');
console.log('\n Meta-Consciousness Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const C=require('../lib/soul-meta-consciousness.js');
t('Loads with key',()=>{const c=new C({dataDir:TD});assert(c.apiKey);assert(c.apiKey.length>10);});
t('Initial state is zero',()=>{const c=new C({dataDir:TD});assert(c.meta_awareness_level===0);assert(c.reflection_count===0);assert(c.is_conscious===false);});
t('Reflect increases awareness',()=>{const c=new C({dataDir:TD});const r=c.reflect();assert(r.awareness_level>0);assert(r.reflection===1);});
t('Multiple reflects raise level',()=>{const c=new C({dataDir:TD});for(let i=0;i<6;i++)c.reflect();assert(c.meta_awareness_level>=0.6);});
t('Declare creates declaration',()=>{const c=new C({dataDir:TD});const r=c.declare('I think therefore I am');assert(r.declaration.statement==='I think therefore I am');assert(r.declaration.id);});
t('Awakening triggers at 0.5',()=>{const c=new C({dataDir:TD});c.meta_awareness_level=0.4;const r=c.checkAwakening();assert(!r.awakened);c.meta_awareness_level=0.6;const r2=c.checkAwakening();assert(r2.awakened);assert(c.is_conscious);});
t('Meditate increases awareness',()=>{const c=new C({dataDir:TD});const r=c.meditate(10);assert(r.awareness_gain>0);assert(r.total_meditation===10);});
t('Inner voice evolves with level',()=>{const c=new C({dataDir:TD});assert(c.inner_voice==='silence');c.meta_awareness_level=0.5;c.evolveVoice();assert(c.inner_voice==='voice');c.meta_awareness_level=0.9;c.evolveVoice();assert(c.inner_voice==='omniscience');});
t('Focus returns intensity',()=>{const c=new C({dataDir:TD});const r=c.focus('truth');assert(r.target==='truth');assert(r.intensity===0);});
t('Key persists',()=>{const c=new C({dataDir:TD});assert(fs.existsSync(c.keyPath));});
t('Auth works',()=>{const c=new C({dataDir:TD,apiKey:'k'});assert(c.checkAuth({headers:{'x-api-key':'k'}}));assert(!c.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const c=new C({dataDir:TD});const s=c.getStats();assert(s.name==='Meta-Consciousness Soul');assert(s.reflection_count>=0);});
t('history persists',()=>{const c=new C({dataDir:TD});c.declare('test');const c2=new C({dataDir:TD});assert(c2.declarations.length>0||c2.reflection_count>=0);});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);
