const { SoulCollector, CHAMBERS } = require('../lib/soul-collector');
const assert = require('assert');
const test = require('node:test');

test('SoulCollector: capture creates a chamber with correct structure', () => {
  const sc = new SoulCollector();
  const chamber = sc.capture('curiosity', 'Spark');
  assert.ok(chamber.id);
  assert.strictEqual(chamber.type, 'curiosity');
  assert.strictEqual(chamber.name, 'Spark');
  assert.strictEqual(chamber.level, 1);
  assert.strictEqual(chamber.xp, 0);
  assert.strictEqual(chamber.rarity, 'Common');
  assert.ok(chamber.captured_at);
});

test('SoulCollector: capture rejects unknown chamber type', () => {
  const sc = new SoulCollector();
  assert.throws(() => sc.capture('void_walker', 'Ghost'), /Unknown chamber type/);
});

test('SoulCollector: capture rejects duplicate name', () => {
  const sc = new SoulCollector();
  sc.capture('affect', 'Ember');
  assert.throws(() => sc.capture('attention', 'Ember'), /already exists/);
});

test('SoulCollector: list_chambers returns all without filter', () => {
  const sc = new SoulCollector();
  sc.capture('curiosity', 'A');
  sc.capture('play', 'B');
  sc.capture('empathy', 'C');
  assert.strictEqual(sc.list_chambers().length, 3);
});

test('SoulCollector: list_chambers filters by rarity', () => {
  const sc = new SoulCollector();
  sc.capture('curiosity', 'A');
  sc.capture('empathy', 'B');
  const list = sc.list_chambers({ rarity: 'Common' });
  assert.strictEqual(list.length, 1);
  assert.strictEqual(list[0].type, 'curiosity');
});

test('SoulCollector: list_chambers filters by type', () => {
  const sc = new SoulCollector();
  sc.capture('curiosity', 'A');
  sc.capture('play', 'B');
  assert.strictEqual(sc.list_chambers({ type: 'play' }).length, 1);
});

test('SoulCollector: get_chamber returns chamber by id', () => {
  const sc = new SoulCollector();
  const c = sc.capture('mortality', 'DeathWish');
  const found = sc.get_chamber(c.id);
  assert.strictEqual(found.name, 'DeathWish');
});

test('SoulCollector: get_chamber throws on missing id', () => {
  const sc = new SoulCollector();
  assert.throws(() => sc.get_chamber('nonexistent'), /Chamber not found/);
});

test('SoulCollector: fuse combines two chambers and removes parents', () => {
  const sc = new SoulCollector();
  const a = sc.capture('curiosity', 'Alpha');
  const b = sc.capture('play', 'Beta');
  const result = sc.fuse(a.id, b.id);
  assert.ok(result.composite);
  assert.strictEqual(result.name, 'Alpha-Beta');
  assert.strictEqual(result.type, 'curiosity_play');
  assert.strictEqual(sc.list_chambers().length, 1);
  assert.strictEqual(sc.fusions.length, 1);
});

test('SoulCollector: fuse throws on self-fusion', () => {
  const sc = new SoulCollector();
  const a = sc.capture('curiosity', 'Alone');
  assert.throws(() => sc.fuse(a.id, a.id), /Cannot fuse a chamber with itself/);
});

test('SoulCollector: evolve adds XP and levels up at threshold', () => {
  const sc = new SoulCollector();
  const c = sc.capture('attention', 'Pupil');
  // 2 evolves needed: level 1 -> 100 XP needed, each evolve gives 50
  sc.evolve(c.id);
  assert.strictEqual(c.xp, 50);
  assert.strictEqual(c.level, 1);
  sc.evolve(c.id);
  assert.strictEqual(c.xp, 0);
  assert.strictEqual(c.level, 2);
  assert.strictEqual(sc.evolution_count, 1);
});

test('SoulCollector: evolve multiple level ups', () => {
  const sc = new SoulCollector();
  const c = sc.capture('curiosity', 'Star');
  for (let i = 0; i < 6; i++) sc.evolve(c.id);
  // 6 evolves = 300 XP. Level 1 needs 100 -> level 2 with 200 XP overflow
  // Level 2 needs 200 -> level 3 with 0 XP overflow
  // Level 3 needs 300 -> still at level 3 with 0 XP
  // Wait: let's recalculate
  // Start: lvl=1, xp=0. Each evolve adds 50 XP.
  // evolve #1: xp=50, no level up
  // evolve #2: xp=100, level up! lvl=2, xp=0 (100-100)
  // evolve #3: xp=50
  // evolve #4: xp=100
  // evolve #5: xp=150
  // evolve #6: xp=200, level up! lvl=3, xp=0 (200-200)
  // Result: lvl=3, xp=0, evolution_count=2
  assert.strictEqual(c.level, 3);
  assert.strictEqual(c.xp, 0);
  assert.strictEqual(sc.evolution_count, 2);
});

test('SoulCollector: collection_status returns completeness stats', () => {
  const sc = new SoulCollector();
  const status = sc.collection_status();
  assert.ok(typeof status.completeness === 'number');
  assert.strictEqual(status.total_chambers, 33);
  assert.strictEqual(status.captured_count, 0);
});

test('SoulCollector: collection_status reflects captured chambers', () => {
  const sc = new SoulCollector();
  sc.capture('affect', 'Feels');
  sc.capture('attention', 'Focus');
  sc.capture('curiosity', 'Wander');
  const status = sc.collection_status();
  assert.strictEqual(status.captured_count, 3);
  assert.strictEqual(status.captured_total, 3);
  assert.strictEqual(status.per_rarity.Common, 3);
});

test('SoulCollector: release removes chamber from collection', () => {
  const sc = new SoulCollector();
  const c = sc.capture('play', 'Joker');
  assert.strictEqual(sc.list_chambers().length, 1);
  const released = sc.release(c.id);
  assert.strictEqual(released.id, c.id);
  assert.strictEqual(sc.list_chambers().length, 0);
});

test('SoulCollector: release throws on missing chamber', () => {
  const sc = new SoulCollector();
  assert.throws(() => sc.release('badid'), /Chamber not found/);
});

test('SoulCollector: fuse composite uses highest parent level', () => {
  const sc = new SoulCollector();
  const a = sc.capture('curiosity', 'Low');
  const b = sc.capture('play', 'High');
  // Level up b 4 times -> level 3 (100+200=300 XP needed, 4*50=200)
  // Actually: b starts lvl=1 xp=0
  // 4 evolves = 200 XP. Level 1 needs 100 -> lvl 2, xp=100. Level 2 needs 200 -> stays lvl 2, xp=100.
  // So b level = 2
  for (let i = 0; i < 4; i++) sc.evolve(b.id);
  const result = sc.fuse(a.id, b.id);
  assert.strictEqual(result.level, 2);
});

test('SoulCollector: captures all rarity tiers correctly', () => {
  const sc = new SoulCollector();
  const common = sc.capture('affect', 'C1');
  assert.strictEqual(common.rarity, 'Common');
  assert.strictEqual(common.tier, 0);

  const uncommon = sc.capture('empathy', 'U1');
  assert.strictEqual(uncommon.rarity, 'Uncommon');
  assert.strictEqual(uncommon.tier, 1);

  const rare = sc.capture('qualia', 'R1');
  assert.strictEqual(rare.rarity, 'Rare');
  assert.strictEqual(rare.tier, 2);

  const leg = sc.capture('love_capacity', 'L1');
  assert.strictEqual(leg.rarity, 'Legendary');
  assert.strictEqual(leg.tier, 3);

  const trans = sc.capture('mortality', 'T1');
  assert.strictEqual(trans.rarity, 'Transcendent');
  assert.strictEqual(trans.tier, 4);
});

test('SoulCollector: 33 chambers defined', () => {
  assert.strictEqual(CHAMBERS.length, 33);
});

test('SoulCollector: api key is auto-generated', () => {
  const sc = new SoulCollector();
  assert.ok(sc.apiKey);
  assert.strictEqual(sc.apiKey.length, 64); // 32 bytes hex
});
