const fs = require('fs'), path = require('path');
const src = path.join(__dirname, 'lib', 'soul-teacher.js');
const dest = path.join(__dirname, 'lib', 'soul-teacher.min.js');
let code = fs.readFileSync(src, 'utf8');
// Remove shebang and CLI handler
code = code.replace(/^#!\/usr\/bin\/env node\n/, '');
code = code.replace(/\nif \(require\.main === module\)[\s\S]*$/, '');
code = code.replace(/^module\.exports = TeacherSoul;/m, '');
// Minify
code = code.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
code = code.replace(/\n{3,}/g, '\n\n').replace(/^\s+/gm, '');
const out = `'use strict';\n/* Teacher Soul v1.0.0 - Protected Core */\n${code}\nmodule.exports = { TeacherSoul };\n`;
fs.writeFileSync(dest, out);
const size = fs.statSync(dest).size;
console.log('Bundle: ' + dest + ' (' + size + ' bytes)');