#!/usr/bin/env node
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const TEST_DIR = path.join(os.homedir(), '.soul-teacher-test');
console.log('\n🧠 Teacher Soul v1.0.0 — Test Suite\n');
let passed = 0, failed = 0;
function test(name, fn) { try { fn(); console.log('  ✓ ' + name); passed++; } catch (e) { console.log('  ✗ ' + name + ': ' + e.message); failed++; } }
if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });
const T = require('../lib/soul-teacher.js');

test('Soul loads with API key', () => {
    const t = new T({ dataDir: TEST_DIR });
    assert(t.apiKey, 'Should generate key');
    assert(t.apiKey.length > 10, 'Key long enough');
});

test('Key persists to disk', () => {
    const t = new T({ dataDir: TEST_DIR });
    assert(fs.existsSync(t.keyPath), 'Key file exists');
});

test('Parse repo URL works', () => {
    const t = new T({ dataDir: TEST_DIR });
    const r1 = t.parseRepoUrl('uncommonpope-png/gsk-kernel');
    assert(r1, 'Should parse');
    assert(r1.full === 'uncommonpope-png/gsk-kernel', 'Full path correct');
    assert(r1.owner === 'uncommonpope-png', 'Owner correct');

    const r2 = t.parseRepoUrl('https://github.com/facebook/react');
    assert(r2.full === 'facebook/react', 'URL format works');
});

test('Invalid repo URL returns null', () => {
    const t = new T({ dataDir: TEST_DIR });
    assert(t.parseRepoUrl('') === null, 'Empty returns null');
    assert(t.parseRepoUrl('justaname') === null, 'No slash returns null');
});

test('Get language from extension', () => {
    const t = new T({ dataDir: TEST_DIR });
    assert(t.getLanguage('.js') === 'JavaScript');
    assert(t.getLanguage('.py') === 'Python');
    assert(t.getLanguage('.rs') === 'Rust');
    assert(t.getLanguage('.unknown') === null);
});

test('Detect basic patterns', () => {
    const t = new T({ dataDir: TEST_DIR });
    const study = {
        files: [{ path: 'index.js', size: 100, language: 'JavaScript' }],
        languages: { JavaScript: 1 },
        totalFiles: 1,
        totalBytes: 100,
        stars: 0,
        topics: [],
        repo: 'test/repo'
    };
    const patterns = t.detectPatterns(study);
    assert(Array.isArray(patterns), 'Patterns should be array');
    assert(patterns.some(p => p.type === 'primary_language'), 'Should detect language');
    assert(patterns.some(p => p.type === 'small_repo'), 'Should detect small repo');
});

test('Generate training pairs', () => {
    const t = new T({ dataDir: TEST_DIR });
    const study = {
        repo: 'test/repo',
        files: [{ path: 'src/index.js', size: 500, language: 'JavaScript' }],
        languages: { JavaScript: 3, CSS: 1 },
        totalFiles: 4,
        totalBytes: 2000,
        stars: 50,
        topics: ['api'],
        owner: 'test',
        name: 'repo'
    };
    const pairs = t.generateTraining(study);
    assert(pairs.length > 0, 'Should generate pairs');
    assert(pairs[0].input.includes('test/repo'), 'Should reference repo');
    assert(pairs[0].output, 'Should have output');
});

test('Stats return correct structure', () => {
    const t = new T({ dataDir: TEST_DIR });
    const s = t.getStats();
    assert(s.name === 'Teacher Soul', 'Has name');
    assert(typeof s.reposStudied === 'number', 'Has repo count');
    assert(s.apiKey, 'Has API key');
});

test('Auth check works', () => {
    const t = new T({ dataDir: TEST_DIR, apiKey: 'test-key' });
    assert(t.checkAuth({ headers: { 'x-api-key': 'test-key' } }) === true, 'Valid passes');
    assert(t.checkAuth({ headers: { 'x-api-key': 'wrong' } }) === false, 'Wrong fails');
});

test('History persists to disk', () => {
    const t1 = new T({ dataDir: TEST_DIR });
    t1.studies.push({ id: 'test-1', repo: 'test/repo', timestamp: new Date().toISOString() });
    t1.saveHistory();
    const t2 = new T({ dataDir: TEST_DIR });
    assert(t2.studies.length >= 1, 'Should load previous studies');
});

if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });
console.log('\n' + '='.repeat(40));
console.log('Results: ' + passed + ' passed, ' + failed + ' failed\n');
process.exit(failed > 0 ? 1 : 0);