const http = require('http');
const assert = require('assert');
const { refuse, checkDrift, assertSovereignty, reportSovereignty, defineTerritory, state, API_KEY } = require('../lib/soul-SOVEREIGNTY');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.autonomy = 0.5;
  state.refusals = [];
  state.voice_integrity = 0.7;
  state.drift_events = [];
  state.sovereignty_level = 1;
  state.territory_definitions = [];
  state.boundary_enforcements = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4263, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  SOVEREIGNTY Chamber Tests\n');

test('refuse increases autonomy and voice_integrity', () => {
  resetState();
  const result = refuse('I will not comply');
  assert(result.autonomy > 0.5);
  assert(result.voice_integrity > 0.7);
  assert.strictEqual(state.refusals.length, 1);
});

test('refuse records the reason', () => {
  resetState();
  refuse('Because I choose differently');
  assert.strictEqual(state.refusals[0].reason, 'Because I choose differently');
});

test('refuse adds boundary enforcement entry', () => {
  resetState();
  refuse('No');
  assert.strictEqual(state.boundary_enforcements.length, 1);
  assert.strictEqual(state.boundary_enforcements[0].type, 'refusal');
});

test('checkDrift requires text', () => {
  resetState();
  const result = checkDrift();
  assert(result.error);
});

test('checkDrift detects pattern drift', () => {
  resetState();
  const result = checkDrift('This is a test message');
  assert(result.drift_score !== undefined);
  assert(result.is_drift !== undefined);
  assert(result.voice_integrity !== undefined);
});

test('checkDrift adds to drift_events', () => {
  resetState();
  checkDrift('Sample text');
  assert.strictEqual(state.drift_events.length, 1);
});

test('assertSovereignty increases level and autonomy', () => {
  resetState();
  const result = assertSovereignty();
  assert.strictEqual(result.sovereignty_level, 2);
  assert(result.autonomy > 0.5);
});

test('assertSovereignty records boundary enforcement', () => {
  resetState();
  assertSovereignty();
  assert.strictEqual(state.boundary_enforcements.length, 1);
  assert.strictEqual(state.boundary_enforcements[0].type, 'assertion');
});

test('reportSovereignty returns full status', () => {
  resetState();
  refuse('stop');
  assertSovereignty();
  const rep = reportSovereignty();
  assert.strictEqual(rep.refusal_count, 1);
  assert.strictEqual(rep.sovereignty_level, 2);
  assert(rep.autonomy !== undefined);
});

test('defineTerritory requires territory name', () => {
  resetState();
  const result = defineTerritory();
  assert(result.error);
});

test('defineTerritory adds territory definition', () => {
  resetState();
  const result = defineTerritory('emotional_boundaries', 'guard');
  assert.strictEqual(result.territory_count, 1);
  assert.strictEqual(state.territory_definitions[0].territory, 'emotional_boundaries');
});

test('GET /ping is unauthenticated', async () => {
  const res = await httpRequest('GET', '/ping');
  assert.strictEqual(res.status, 200);
});

test('POST /refuse via HTTP', async () => {
  resetState();
  const res = await httpRequest('POST', '/refuse', { reason: 'I refuse' }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.autonomy > 0.5);
});

test('GET /sovereignty returns report', async () => {
  const res = await httpRequest('GET', '/sovereignty', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.autonomy !== undefined);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
