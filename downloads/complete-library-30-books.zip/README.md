# The Soul Economy — Complete Library (30 Books)

**What this is:** the complete Soul Library in one download — all 30 books by
Craig Jones (several under his pen name Little Bunny, PLT Press), in the Soul
Library JSON text edition.

**Contents:** 30 `book-*.json` files plus `manifest.json` — the full shelf:
non-fiction Books I–VI (the PLT framework), fiction Books VII–XIII (the Albany
Ave universe), the Scorer Series, the Ledger Series, and the Shorts.
~309,000 words total.

**Provenance:** built from the verified local Soul Library sources
(`workspace/books/library-json/`, from github.com/uncommonpope-png/soul-library)
and catalogued in `workspace/books/CATALOG.md`. Fifteen titles exist only in
this library edition.

**Rebuilt-equivalent notice:** this ZIP is a REBUILT equivalent of the
Gumroad draft bundle (which was 1011.5 KB), not a byte-identical copy — the
Gumroad draft's inner files were never published or exported. The fuller
.docx editions of 16 titles are NOT included here; they live in the author's
manuscript set and a future edition may add them.

**Reading:** any JSON file opens in a text editor or browser. Start with
`book-the-calculation.json` (Book II, the guide's recommended entry point)
or `book-the-first-calculation.json` (Book I).
