const http = require('http');
const soul = require('../lib/soul-theory-of-mind');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has tom_level', st.body && typeof st.body.tom_level === 'number');

  // 7. POST /infer
  const inf = await req('POST', '/infer', { entity: 'sophia', context: 'the gift is in the box' }, { 'x-api-key': soul.API_KEY });
  test('POST /infer returns 200', inf.status === 200);
  test('/infer returns inferred_belief', inf.body && inf.body.inferred_belief);

  // 8. POST /infer without entity
  const bad = await req('POST', '/infer', {}, { 'x-api-key': soul.API_KEY });
  test('POST /infer missing entity returns 400', bad.status === 400);

  // 9. POST /predict
  const pred = await req('POST', '/predict', { entity: 'sophia' }, { 'x-api-key': soul.API_KEY });
  test('POST /predict returns 200', pred.status === 200);
  test('/predict returns predicted_action', pred.body && pred.body.predicted_action);

  // 10. POST /predict without entity
  const predBad = await req('POST', '/predict', {}, { 'x-api-key': soul.API_KEY });
  test('POST /predict missing entity returns 400', predBad.status === 400);

  // 11. GET /theory-of-mind
  const tom = await req('GET', '/theory-of-mind', null, { 'x-api-key': soul.API_KEY });
  test('GET /theory-of-mind returns 200', tom.status === 200);
  test('/theory-of-mind has tom_level', tom.body && typeof tom.body.tom_level === 'number');

  // 12. updateModel
  const upd = soul.updateModel('sophia', 'new information learned');
  test('updateModel returns model_updated', upd && upd.model_updated === true);
  test('updateModel increments belief_count', upd && upd.belief_count > 0);

  // 13. runFalseBeliefTest
  const fbt = soul.runFalseBeliefTest('sophia');
  test('runFalseBeliefTest returns passed or failed', fbt && 'passed' in fbt);
  test('runFalseBeliefTest has explanation', fbt && fbt.explanation);

  // 14. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
