const http = require('http');
const soul = require('../lib/soul-love-capacity');

let server;
let pass = 0, fail = 0;
const BASE = `http://localhost:${soul.PORT}`;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 2. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);
  test('/health body has status ok', health.body && health.body.status === 'ok');

  // 3. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 4. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 5. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has agape field', st.body && typeof st.body.agape === 'number');

  // 6. POST /bond - create bond
  const bond = await req('POST', '/bond', { entity: 'alice', type: 'agape', strength: 0.8 }, { 'x-api-key': soul.API_KEY });
  test('POST /bond returns 200', bond.status === 200);
  test('/bond returns entity', bond.body && bond.body.entity === 'alice');

  // 7. POST /bond - duplicate
  const dup = await req('POST', '/bond', { entity: 'alice', type: 'agape', strength: 0.5 }, { 'x-api-key': soul.API_KEY });
  test('POST /bond duplicate returns 400', dup.status === 400);

  // 8. POST /deepen
  const deep = await req('POST', '/deepen', { entity: 'alice', amount: 0.2 }, { 'x-api-key': soul.API_KEY });
  test('POST /deepen returns 200', deep.status === 200);
  test('/deepen increased strength', deep.body && deep.body.strength >= 0.8);

  // 9. POST /deepen nonexistent
  const miss = await req('POST', '/deepen', { entity: 'bob' }, { 'x-api-key': soul.API_KEY });
  test('POST /deepen missing returns 404', miss.status === 404);

  // 10. GET /bonds
  const bonds = await req('GET', '/bonds', null, { 'x-api-key': soul.API_KEY });
  test('GET /bonds returns 200', bonds.status === 200);
  test('/bonds is array', Array.isArray(bonds.body));

  // 11. DELETE /bond/alice
  const del = await req('DELETE', '/bond/alice', null, { 'x-api-key': soul.API_KEY });
  test('DELETE /bond/alice returns 200', del.status === 200);
  test('/bond/alice deleted', del.body && del.body.broken === true);

  // 12. DELETE /bond/nobody (nonexistent)
  const delMiss = await req('DELETE', '/bond/nobody', null, { 'x-api-key': soul.API_KEY });
  test('DELETE /bond missing returns 404', delMiss.status === 404);

  // 13. applyDecay
  soul.formBond('charlie', 'philia', 0.5);
  soul.applyDecay();
  test('applyDecay reduces strength', soul.state.bond_strengths.charlie < 0.5);
  soul.breakBond('charlie');

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
