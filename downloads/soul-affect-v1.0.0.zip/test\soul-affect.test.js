#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-affect-test');
console.log('\n Affect Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const AffectSoul=require('../lib/soul-affect.js');
t('Loads with key',()=>{const i=new AffectSoul({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Auth check works',()=>{const i=new AffectSoul({dataDir:TD,apiKey:'testkey'});assert(i.checkAuth({headers:{'x-api-key':'testkey'}}));assert(!i.checkAuth({headers:{'x-api-key':'wrong'}}));});
t('Key persists',()=>{const i=new AffectSoul({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Stimulate positive shifts valence',()=>{const i=new AffectSoul({dataDir:TD});const r=i.stimulate(0.5);assert(r.valence>0);assert(r.mood);});
t('Stimulate negative shifts valence down',()=>{const i=new AffectSoul({dataDir:TD});i.valence=0;const r=i.stimulate(-0.5);assert(r.valence<0);});
t('Suppress dampens emotion',()=>{const i=new AffectSoul({dataDir:TD});i.stimulate(1);const b=i.valence;const r=i.suppress();assert(Math.abs(r.valence)<Math.abs(b));});
t('Express returns emotion',()=>{const i=new AffectSoul({dataDir:TD});const r=i.express();assert(r.emotion);assert(r.expression);});
t('Contagion spreads emotion',()=>{const i=new AffectSoul({dataDir:TD});i.contagion_receptivity=1;const r=i.contagion("happy",1);assert(r.caught);});
t('Mood cycle changes state',()=>{const i=new AffectSoul({dataDir:TD});const b=i.arousal;i.moodCycle();assert(i.mood_cycle_counter>0);});
t('Compute mood returns string',()=>{const i=new AffectSoul({dataDir:TD});const m=i.computeMood();assert(typeof m==="string");assert(i.mood_types[m]);});
t('Emotion history tracks',()=>{const i=new AffectSoul({dataDir:TD});i.stimulate(0.5);i.suppress();i.express();assert(i.emotion_history.length>=3);});
t('Get emotion returns state',()=>{const i=new AffectSoul({dataDir:TD});const r=i.getEmotion();assert(r.dominant_emotion);assert(typeof r.valence==="number");});
t('GetStats returns ok',()=>{const i=new AffectSoul({dataDir:TD});const s=i.getStats();assert(s.name);assert(typeof s.valence==="number");});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);