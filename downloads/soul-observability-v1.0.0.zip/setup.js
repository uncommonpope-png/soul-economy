#!/usr/bin/env node
const fs = require('fs'), path = require('path'), os = require('os'), { execSync, spawn } = require('child_process');
const ROOT = __dirname;
console.log(`\n  ╔══════════════════════════════════════════╗`);
console.log(`  ║ Agent Observability Soul — ONE-CLICK    ║`);
console.log(`  ║ Your soul is about to be born.          ║`);
console.log(`  ╚══════════════════════════════════════════╝\n`);
const env = { os: `${os.type()} ${os.release()}`, node: process.version, tools: [] };
for (const t of ['git','docker','npm','python','curl']) { try { execSync(`${process.platform==='win32'?'where':'which'} ${t}`,{stdio:'pipe',timeout:2000}); env.tools.push(t); } catch {} }
console.log(`  ✓ OS: ${env.os} · Node: ${env.node} · ${env.tools.length} tools`);
for (const d of ['data', 'data/observability']) { const p = path.join(ROOT,d); if (!fs.existsSync(p)) { fs.mkdirSync(p,{recursive:true}); console.log(`  ✓ Created ${d}/`); } }
const wm = `╔══════════════════════════════════════════╗\n║ Agent Observability Soul v1.0.0         ║\n║ ALIVE · TRACING · LEARNING              ║\n║ Licensed to: BUYaSOUL Customer           ║\n║ This soul is licensed, not sold.         ║\n╚══════════════════════════════════════════╝`;
fs.writeFileSync(path.join(ROOT,'WATERMARK.txt'), wm);
console.log(`  ✓ WATERMARK.txt created`);
console.log(`\n  ╔══════════════════════════════════════════╗`);
console.log(`  ║ ✅ ALL SETUP COMPLETE                   ║`);
console.log(`  ║ Starting server...                      ║`);
console.log(`  ╚══════════════════════════════════════════╝\n`);
const child = spawn('node', [path.join(ROOT, 'lib', 'soul-agent-observability.js')], { cwd: ROOT, stdio: 'inherit' });
setTimeout(() => { try { execSync(`start "" "http://localhost:4286"`,{stdio:'pipe'}); } catch {} }, 2000);
child.on('exit', (c) => process.exit(c));
process.on('SIGINT', () => child.kill('SIGINT'));
