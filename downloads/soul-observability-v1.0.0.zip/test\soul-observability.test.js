const {
  sessions,
  spans,
  COST_CONFIG,
  calculateCost,
  traceStart,
  traceSpan,
  traceEnd,
  listSessions,
  getSession,
  aggregateDashboard,
  getCostBreakdown,
  getToolStats,
  exportAllJson,
  uid,
  ensureApiKey,
  getDateKey,
  getWeekKey,
  getMonthKey,
} = require('../lib/soul-observability.js');

// Ensure API key is initialized
ensureApiKey();

let passed = 0;
let failed = 0;
let errors = [];

function assert(condition, msg) {
  if (condition) {
    passed++;
    console.log(`  ✓ ${msg}`);
  } else {
    failed++;
    errors.push(msg);
    console.log(`  ✗ ${msg}`);
  }
}

function assertEqual(actual, expected, msg) {
  const ok = actual === expected;
  if (ok) {
    passed++;
    console.log(`  ✓ ${msg}`);
  } else {
    failed++;
    errors.push(`${msg} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    console.log(`  ✗ ${msg} (expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)})`);
  }
}

function assertApprox(actual, expected, tolerance, msg) {
  const ok = Math.abs(actual - expected) <= tolerance;
  if (ok) {
    passed++;
    console.log(`  ✓ ${msg}`);
  } else {
    failed++;
    errors.push(`${msg} — expected ~${expected}, got ${actual}`);
    console.log(`  ✗ ${msg} (expected ~${expected}, got ${actual})`);
  }
}

function assertNotNull(val, msg) {
  if (val !== null && val !== undefined) {
    passed++;
    console.log(`  ✓ ${msg}`);
  } else {
    failed++;
    errors.push(`${msg} — value was null/undefined`);
    console.log(`  ✗ ${msg} (null/undefined)`);
  }
}

function resetState() {
  sessions.clear();
  spans.length = 0;
}

// Clear before first test
resetState();

console.log('\n--- Test 1: uid generates unique IDs with prefix ---');
(() => {
  const id1 = uid('session');
  const id2 = uid('span');
  assert(id1.startsWith('session_'), 'uid starts with session_ prefix');
  assert(id2.startsWith('span_'), 'uid starts with span_ prefix');
  assert(id1 !== id2, 'uid generates unique ids');
})();

console.log('\n--- Test 2: calculateCost with known model ---');
(() => {
  const cost = calculateCost({ input: 1000, output: 500 }, 'gpt-4o');
  // input: 1000/1000000 * 2.5 = 0.0025, output: 500/1000000 * 10 = 0.005, total = 0.0075
  assertEqual(cost, 0.0075, 'calculateCost gpt-4o 1000in/500out = 0.0075');
})();

console.log('\n--- Test 3: calculateCost with unknown model returns 0 ---');
(() => {
  const cost = calculateCost({ input: 1000, output: 500 }, 'fake-model');
  assertEqual(cost, 0, 'calculateCost unknown model returns 0');
})();

console.log('\n--- Test 4: calculateCost claude-sonnet-4 ---');
(() => {
  const cost = calculateCost({ input: 2000, output: 1000 }, 'claude-sonnet-4');
  // input: 2000/1000000 * 3 = 0.006, output: 1000/1000000 * 15 = 0.015, total = 0.021
  assertEqual(cost, 0.021, 'calculateCost claude-sonnet-4 2000in/1000out = 0.021');
})();

console.log('\n--- Test 5: traceStart creates a session ---');
(() => {
  resetState();
  const result = traceStart({ agentName: 'test-agent' });
  assertNotNull(result.sessionId, 'traceStart returns sessionId');
  assertNotNull(result.session, 'traceStart returns session');
  assertEqual(result.session.agentName, 'test-agent', 'session agentName matches');
  assertEqual(result.session.status, 'active', 'session status is active');
  assertEqual(sessions.size, 1, 'sessions map has 1 entry');
})();

console.log('\n--- Test 6: traceStart with custom sessionId ---');
(() => {
  resetState();
  const customId = 'my-custom-session-id';
  const result = traceStart({ sessionId: customId, agentName: 'custom-agent' });
  assertEqual(result.sessionId, customId, 'traceStart uses custom sessionId');
  assertEqual(sessions.has(customId), true, 'custom sessionId exists in map');
})();

console.log('\n--- Test 7: traceSpan records span in session ---');
(() => {
  resetState();
  const { sessionId, session } = traceStart({ agentName: 'agent-7' });
  const spanResult = traceSpan({
    traceId: sessionId,
    type: 'tool_call',
    name: 'bash_exec',
    input: 'ls -la',
    output: 'file list...',
    duration: 250,
    tokens: { input: 100, output: 50 },
    model: 'gpt-4o',
    status: 'success',
  });
  assertNotNull(spanResult.span, 'traceSpan returns span');
  assertEqual(spanResult.span.type, 'tool_call', 'span type is tool_call');
  assertEqual(session.spans.length, 1, 'session has 1 span');
  assertEqual(spans.length, 1, 'global spans array has 1 entry');
})();

console.log('\n--- Test 8: traceSpan updates session totals ---');
(() => {
  resetState();
  const { sessionId, session } = traceStart({ agentName: 'agent-8' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: '', duration: 100, tokens: { input: 1000, output: 500 }, model: 'gpt-4o', status: 'success' });
  assertEqual(session.totalTokens.input, 1000, 'session totalTokens.input updated');
  assertEqual(session.totalTokens.output, 500, 'session totalTokens.output updated');
  assertApprox(session.totalCost, 0.0075, 0.001, 'session totalCost updated');
  assertEqual(session.modelUsage['gpt-4o'].calls, 1, 'modelUsage calls counted');
})();

console.log('\n--- Test 9: traceEnd completes session ---');
(() => {
  resetState();
  const { sessionId, session } = traceStart({ agentName: 'agent-9' });
  const endResult = traceEnd({ sessionId });
  assertEqual(session.status, 'completed', 'session status is completed after end');
  assertNotNull(session.endTime, 'session endTime is set');
})();

console.log('\n--- Test 10: traceEnd returns error for missing session ---');
(() => {
  resetState();
  const result = traceEnd({ sessionId: 'nonexistent' });
  assertEqual(result.error, 'Session not found', 'traceEnd returns error for missing session');
})();

console.log('\n--- Test 11: listSessions returns all sessions ---');
(() => {
  resetState();
  traceStart({ agentName: 'agent-a' });
  traceStart({ agentName: 'agent-b' });
  traceStart({ agentName: 'agent-c' });
  const list = listSessions();
  assertEqual(list.length, 3, 'listSessions returns 3 sessions');
  assertEqual(list[0].agentName, 'agent-a', 'first session agentName matches');
  assertNotNull(list[0].startTime, 'session has startTime');
})();

console.log('\n--- Test 12: getSession returns session by id ---');
(() => {
  resetState();
  const { sessionId } = traceStart({ agentName: 'find-me' });
  const found = getSession(sessionId);
  assertNotNull(found, 'getSession returns session');
  assertEqual(found.agentName, 'find-me', 'found session agentName matches');
  const missing = getSession('does-not-exist');
  assertEqual(missing, null, 'getSession returns null for missing id');
})();

console.log('\n--- Test 13: aggregateDashboard returns stats ---');
(() => {
  resetState();
  const { sessionId } = traceStart({ agentName: 'dash-test' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: '', duration: 150, tokens: { input: 500, output: 200 }, model: 'claude-sonnet-4', status: 'success' });
  traceSpan({ traceId: sessionId, type: 'decision', name: 'choose_tool', input: '', output: '', duration: 50, tokens: { input: 100, output: 20 }, model: 'claude-sonnet-4', status: 'success' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'read_file', input: '', output: '', duration: 300, tokens: { input: 200, output: 100 }, model: 'gpt-4o-mini', status: 'error', error: 'permission denied' });
  const dash = aggregateDashboard();
  assert(dash.sessionsToday >= 1, 'dashboard has sessionsToday >= 1');
  assert(dash.totalSessions >= 1, 'dashboard has totalSessions >= 1');
  assert(dash.totalSpans >= 3, 'dashboard counts spans');
  assert(dash.errorRate > 0, 'dashboard has error rate > 0');
  assert(dash.topModels.length > 0, 'dashboard has top models');
  assert(dash.topTools.length > 0, 'dashboard has top tools');
  assert(dash.slowestOperations.length > 0, 'dashboard has slowest operations');
})();

console.log('\n--- Test 14: getCostBreakdown returns per-model breakdown ---');
(() => {
  resetState();
  const { sessionId } = traceStart({ agentName: 'cost-test' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: '', duration: 100, tokens: { input: 1000000, output: 500000 }, model: 'gpt-4o', status: 'success' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'python', input: '', output: '', duration: 100, tokens: { input: 2000000, output: 1000000 }, model: 'claude-sonnet-4', status: 'success' });
  const costs = getCostBreakdown();
  assertNotNull(costs['gpt-4o'], 'costs has gpt-4o entry');
  assertNotNull(costs['claude-sonnet-4'], 'costs has claude-sonnet-4 entry');
  assert(costs['gpt-4o'].sessionCosts > 0, 'gpt-4o has costs > 0');
  assert(costs['claude-sonnet-4'].sessionCosts > 0, 'claude-sonnet-4 has costs > 0');
})();

console.log('\n--- Test 15: getToolStats returns tool usage ---');
(() => {
  resetState();
  const { sessionId } = traceStart({ agentName: 'tool-test' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: 'ok', duration: 100, tokens: { input: 10, output: 5 }, model: 'gpt-4o', status: 'success' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: 'ok', duration: 200, tokens: { input: 10, output: 5 }, model: 'gpt-4o', status: 'success' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'read_file', input: '', output: '', duration: 50, tokens: { input: 10, output: 5 }, model: 'gpt-4o', status: 'error', error: 'not found' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'bash', input: '', output: 'err', duration: 300, tokens: { input: 10, output: 5 }, model: 'gpt-4o', status: 'error', error: 'timeout' });
  const stats = getToolStats();
  assertNotNull(stats['bash'], 'toolStats has bash');
  assertNotNull(stats['read_file'], 'toolStats has read_file');
  assertEqual(stats['bash'].calls, 3, 'bash has 3 calls');
  assertEqual(stats['bash'].errors, 1, 'bash has 1 error');
  assertEqual(stats['read_file'].calls, 1, 'read_file has 1 call');
  assertEqual(stats['read_file'].errors, 1, 'read_file has 1 error');
  assertEqual(stats['bash'].avgDuration, 200, 'bash avg duration is 200ms');
})();

console.log('\n--- Test 16: exportAllJson returns full export ---');
(() => {
  resetState();
  traceStart({ agentName: 'export-test' });
  const exported = exportAllJson();
  assertNotNull(exported.sessions, 'export has sessions array');
  assertNotNull(exported.costConfig, 'export has costConfig');
  assertEqual(exported.sessions.length, 1, 'export has 1 session');
})();

console.log('\n--- Test 17: getDateKey, getWeekKey, getMonthKey utilities ---');
(() => {
  const iso = '2026-05-21T12:34:56.000Z';
  assertEqual(getDateKey(iso), '2026-05-21', 'getDateKey extracts date');
  assertEqual(getMonthKey(iso), '2026-05', 'getMonthKey extracts month');
  // May 21, 2026 is a Thursday, week starts on Sunday (May 17)
  assertEqual(getWeekKey(iso), '2026-05-17', 'getWeekKey extracts week start');
})();

console.log('\n--- Test 18: traceSpan caps spans at 10000 ---');
(() => {
  resetState();
  const { sessionId } = traceStart({ agentName: 'overflow' });
  for (let i = 0; i < 10005; i++) {
    traceSpan({ traceId: sessionId, type: 'tool_call', name: 'spam', input: '', output: '', duration: 1, tokens: { input: 1, output: 1 }, model: 'gpt-4o-mini', status: 'success' });
  }
  assert(spans.length <= 10000, 'spans array capped at 10000');
  assertEqual(spans.length, 10000, 'spans array exactly 10000 after overflow');
})();

console.log('\n--- Test 19: traceSpan records tool errors in session toolUsage ---');
(() => {
  resetState();
  const { sessionId, session } = traceStart({ agentName: 'error-test' });
  traceSpan({ traceId: sessionId, type: 'tool_call', name: 'dangerous_tool', input: 'rm -rf /', output: '', duration: 50, tokens: { input: 10, output: 5 }, model: 'gpt-4o-mini', status: 'error', error: 'permission denied' });
  assertEqual(session.toolUsage['dangerous_tool'].calls, 1, 'toolUsage calls incremented');
  assertEqual(session.toolUsage['dangerous_tool'].errors, 1, 'toolUsage errors incremented');
})();

console.log('\n--- Test 20: Empty state edge cases ---');
(() => {
  resetState();
  const dash = aggregateDashboard();
  assertEqual(dash.sessionsToday, 0, 'empty dashboard sessionsToday is 0');
  assertEqual(dash.totalSessions, 0, 'empty dashboard totalSessions is 0');
  assertEqual(dash.totalSpans, 0, 'empty dashboard totalSpans is 0');
  assertEqual(dash.errorRate, 0, 'empty dashboard errorRate is 0');
  const costs = getCostBreakdown();
  assertNotNull(costs['claude-opus-4'], 'costs has claude-opus-4');
  assert(costs['claude-opus-4'].sessionCosts === 0, 'costs all zero for empty state');
  const stats = getToolStats();
  assertEqual(Object.keys(stats).length, 0, 'toolStats empty for empty state');
})();

console.log('\n--- Results ---');
console.log(`  Passed: ${passed}`);
console.log(`  Failed: ${failed}`);
if (failed > 0) {
  console.log('\n  Errors:');
  errors.forEach(e => console.log(`    - ${e}`));
  process.exit(1);
} else {
  console.log('\n  All tests passed!');
}
