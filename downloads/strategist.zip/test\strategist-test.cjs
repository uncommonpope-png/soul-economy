/**
 * Soul-Strategist Test Suite v2.0.0
 * Validates STRATEGIST archetype behavior with v2.0.0 enhancements:
 * - Strategic Repository Analyzer
 * - AI Trend Radar
 * - MCTS Multi-turn Planning
 * - Spice Loop (perception→state→simulation→decision→reflection)
 * - MCP Adapter
 * - Web Dashboard
 */

const SoulStrategist = require('../soul-strategist.cjs');
const StrategistProfile = require('../personality/strategist-profile.cjs');
const StrategistDecisionEngine = require('../personality/strategist-engine.cjs');
const StrategicRepoAnalyzer = require('../personality/strategist-repo-analyzer.cjs');
const StrategistTrendRadar = require('../src/strategist-trend-radar.cjs');
const StrategistMCTSPlanner = require('../src/strategist-mcts-planner.cjs');
const StrategistMCPAdapter = require('../src/strategist-mcp-adapter.cjs');
const StrategistWebDashboard = require('../src/strategist-web-dashboard.cjs');

class StrategistTestSuite {
  constructor() {
    this.results = [];
    this.passed = 0;
    this.failed = 0;
  }

  test(name, fn) {
    try {
      fn();
      this.passed++;
      this.results.push({ name, status: 'PASS' });
      console.log(`✅ ${name}`);
    } catch (error) {
      this.failed++;
      this.results.push({ name, status: 'FAIL', error: error.message });
      console.log(`❌ ${name}`);
      console.log(`   Error: ${error.message}`);
    }
  }

  assertEqual(actual, expected, message) {
    if (actual !== expected) {
      throw new Error(`${message || 'Assertion failed'}: expected ${expected}, got ${actual}`);
    }
  }

  assertTrue(value, message) {
    if (!value) {
      throw new Error(message || 'Expected true, got false');
    }
  }

  assertGreaterThan(actual, expected, message) {
    if (actual <= expected) {
      throw new Error(`${message || 'Assertion failed'}: expected > ${expected}, got ${actual}`);
    }
  }

  run() {
    console.log('🔮 Soul-Strategist Test Suite v2.0.0');
    console.log('');
    console.log('Testing STRATEGIST archetype implementation (v2.0.0)...');
    console.log('');

    // Test 1: Profile integrity
    this.test('Profile has correct ID', () => {
      this.assertEqual(StrategistProfile.id, 'STRATEGIST', 'Archetype ID');
    });

    this.test('Profile has high profit orientation', () => {
      this.assertGreaterThan(StrategistProfile.plt.profit, 0.8, 'Profit should be > 0.8');
    });

    this.test('Profile has low love orientation', () => {
      this.assertEqual(StrategistProfile.plt.love < 0.5, true, 'Love should be < 0.5');
    });

    // Test 2: Multipliers
    this.test('Extension point has high multiplier', () => {
      this.assertEqual(
        StrategistProfile.multipliers.create_extension_point,
        2.0,
        'Extension point multiplier'
      );
    });

    this.test('Quick patch has negative multiplier', () => {
      this.assertEqual(
        StrategistProfile.multipliers.quick_patch < 0,
        true,
        'Quick patch should be negative'
      );
    });

    this.test('v2.0.0 MCTS planning multiplier exists', () => {
      this.assertGreaterThan(
        StrategistProfile.multipliers.mcts_planning,
        1.5,
        'MCTS planning multiplier should be high'
      );
    });

    this.test('v2.0.0 repo analysis multiplier exists', () => {
      this.assertGreaterThan(
        StrategistProfile.multipliers.repo_analysis,
        1.0,
        'Repo analysis multiplier should exist'
      );
    });

    // Test 3: Decision Engine
    this.test('Decision engine creates successfully', () => {
      const engine = new StrategistDecisionEngine();
      this.assertTrue(engine.profile.id === 'STRATEGIST', 'Engine has STRATEGIST profile');
    });

    this.test('Scores strategic action highly', () => {
      const engine = new StrategistDecisionEngine({ phase: 'planning' });
      const result = engine.scoreAction({
        type: 'create_extension_point',
        baseUtility: 0.8,
        metadata: { hasPositioning: true }
      });
      
      this.assertGreaterThan(result.score, 1.0, 'Strategic action should score > 1.0');
    });

    this.test('Scores quick patch negatively', () => {
      const engine = new StrategistDecisionEngine({ phase: 'implementation' });
      const result = engine.scoreAction({
        type: 'quick_patch',
        baseUtility: 0.9,
        metadata: { hasPositioning: false }
      });
      
      this.assertEqual(result.score < 0, true, 'Quick patch should score negatively');
    });

    // Test 4: Decision making
    this.test('Makes strategic decision', () => {
      const engine = new StrategistDecisionEngine({ phase: 'architecture' });
      const decision = engine.decide({
        task: 'Build auth',
        options: [
          { type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } },
          { type: 'quick_patch', baseUtility: 0.9, metadata: { hasPositioning: false } }
        ],
        context: { phase: 'architecture' }
      });
      
      this.assertEqual(decision.choice, 'create_extension_point', 'Should choose strategic option');
      this.assertTrue(decision.alternatives.length > 0, 'Should provide alternatives');
    });

    // Test 5: Spice Loop (v2.0.0 NEW)
    this.test('Spice fullLoop executes all 5 phases', () => {
      const engine = new StrategistDecisionEngine({ phase: 'planning' });
      const result = engine.fullLoop({
        task: 'Build auth system',
        options: [
          { type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } },
          { type: 'quick_patch', baseUtility: 0.9, metadata: { hasPositioning: false } }
        ],
        context: { phase: 'architecture' }
      });
      
      this.assertTrue(result.perception !== undefined, 'Should have perception');
      this.assertTrue(result.state !== undefined, 'Should have state');
      this.assertTrue(result.simulation !== undefined, 'Should have simulation');
      this.assertTrue(result.decision !== undefined, 'Should have decision');
      this.assertTrue(result.reflection !== undefined, 'Should have reflection');
    });

    // Test 6: Soul integration
    this.test('Soul initializes with BUYaSOUL kernel', () => {
      const soul = new SoulStrategist();
      this.assertEqual(soul.name, 'The Strategist', 'Soul name');
      this.assertEqual(soul.version, '2.0.0', 'Soul version');
    });

    this.test('Soul provides status', () => {
      const soul = new SoulStrategist();
      const status = soul.getStatus();
      
      this.assertEqual(status.name, 'The Strategist', 'Status name');
      this.assertEqual(status.archetype, 'STRATEGIST', 'Status archetype');
    });

    this.test('Soul generates decisions', () => {
      const soul = new SoulStrategist();
      const decision = soul.decide(
        'Test task',
        [{ type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } }],
        { phase: 'planning' }
      );
      
      this.assertTrue(decision.choice !== undefined, 'Should make a choice');
      this.assertTrue(decision.reasoning !== undefined, 'Should provide reasoning');
    });

    this.test('Soul generates strategist thinking', () => {
      const soul = new SoulStrategist();
      const thinking = soul.think('How to build API?');
      
      this.assertTrue(thinking.strategistPrompt !== undefined, 'Should provide prompt');
      this.assertTrue(thinking.approach !== undefined, 'Should provide approach');
    });

    // Test 7: Shadow detection
    this.test('Detects over-planning shadow', () => {
      const engine = new StrategistDecisionEngine();
      const result = engine.scoreAction({
        type: 'strategic_abstraction',
        baseUtility: 0.7,
        metadata: { planningTime: 7200000 }
      });
      
      this.assertTrue(
        result.violations && result.violations.length > 0,
        'Should detect shadow violation'
      );
    });

    // Test 8: v2.0.0 Enhancement — Strategic Repository Analyzer
    this.test('Repo analyzer analyzes a repository', () => {
      const analyzer = new StrategicRepoAnalyzer();
      const result = analyzer.analyze('https://github.com/example/ai-tool');
      
      this.assertTrue(result.repo !== undefined, 'Should have repo name');
      this.assertTrue(result.layers.perception !== undefined, 'Should have perception layer');
      this.assertTrue(result.layers.decision.score > 0, 'Should have strategic score');
    });

    // Test 9: v2.0.0 Enhancement — Trend Radar
    this.test('Trend radar scans trends', () => {
      const radar = new StrategistTrendRadar();
      const result = radar.scan({ category: 'ai-devtools', limit: 3 });
      
      this.assertTrue(result.trends.length > 0, 'Should find trends');
      this.assertTrue(result.trends[0].strategicScore > 0, 'Trends should have scores');
    });

    // Test 10: v2.0.0 Enhancement — MCTS Planner
    this.test('MCTS planner generates plan', () => {
      const planner = new StrategistMCTSPlanner();
      const result = planner.plan(
        'Build auth system',
        [
          { name: 'quick_jwt', utility: 0.6, risk: 0.3 },
          { name: 'strategy_pattern', utility: 0.8, risk: 0.2 }
        ],
        { depth: 2, simulations: 50 }
      );
      
      this.assertTrue(result.bestPath.length > 0, 'Should have a path');
      this.assertTrue(result.confidence > 0, 'Should have confidence');
    });

    // Test 11: v2.0.0 Enhancement — MCP Adapter
    this.test('MCP adapter reports correct tools', () => {
      const adapter = new StrategistMCPAdapter();
      const status = adapter.getStatus();
      
      this.assertTrue(status.toolsCount >= 7, 'Should have at least 7 tools');
      this.assertTrue(status.tools[0].name.startsWith('strategist.'), 'Tools should be namespaced');
    });

    // Test 12: v2.0.0 Enhancement — Web Dashboard
    this.test('Web dashboard has correct endpoints', () => {
      const dash = new StrategistWebDashboard();
      const info = dash.getInfo();
      
      this.assertTrue(info.endpoints.status !== undefined, 'Should have status endpoint');
      this.assertTrue(info.endpoints.decisions !== undefined, 'Should have decisions endpoint');
    });

    // Test 13: Soul v2.0.0 has all enhancement modules
    this.test('Soul v2.0.0 has all enhancement modules', () => {
      const soul = new SoulStrategist();
      
      this.assertTrue(typeof soul.repoAnalyzer.analyze === 'function', 'Should have repo analyzer');
      this.assertTrue(typeof soul.trendRadar.scan === 'function', 'Should have trend radar');
      this.assertTrue(typeof soul.mctsPlanner.plan === 'function', 'Should have MCTS planner');
      this.assertTrue(typeof soul.mcpAdapter.getStatus === 'function', 'Should have MCP adapter');
      this.assertTrue(typeof soul.webDashboard.getInfo === 'function', 'Should have web dashboard');
    });

    // Test 14: Soul v2.0.0 strategic analysis
    this.test('Soul strategicAnalysis returns modules', () => {
      const soul = new SoulStrategist();
      const result = soul.strategicAnalysis({
        decision: {
          task: 'Test',
          options: [{ type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } }],
          context: { phase: 'planning' }
        },
        scanTrends: false
      });
      
      this.assertTrue(result.decision !== undefined, 'Should include decision');
    });

    // Summary
    console.log('');
    console.log('═══════════════════════════════════════════');
    console.log('Test Summary:');
    console.log(`  ✅ Passed: ${this.passed}`);
    console.log(`  ❌ Failed: ${this.failed}`);
    console.log(`  📊 Total: ${this.passed + this.failed}`);
    console.log('═══════════════════════════════════════════');
    
    if (this.failed === 0) {
      console.log('');
      console.log('🎉 All tests passed! Soul-Strategist v2.0.0 is operational.');
      console.log('');
      console.log('The Strategist v2.0.0 is ready to:');
      console.log('  ✅ Make strategic decisions three moves ahead');
      console.log('  ✅ Generate code positioned for future change');
      console.log('  ✅ Analyze GitHub repos for strategic patterns');
      console.log('  ✅ Scan AI/tech trends for opportunities');
      console.log('  ✅ Plan multi-turn MCTS lookahead');
      console.log('  ✅ Run Spice perception→state→simulation→decision→reflection loop');
      console.log('  ✅ Serve MCP tools for Claude/Cursor/Cline');
      console.log('  ✅ Visualize strategy via web dashboard');
    }
    
    return this.failed === 0;
  }
}

// Run tests
if (require.main === module) {
  const suite = new StrategistTestSuite();
  const success = suite.run();
  process.exit(success ? 0 : 1);
}

module.exports = StrategistTestSuite;
