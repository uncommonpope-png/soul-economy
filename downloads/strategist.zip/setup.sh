#!/bin/bash
# Soul-Strategist v2.0.0 Auto-Setup Script
# Run this after downloading and extracting the zip

set -e

echo "🔮 SOUL-STRATEGIST v2.0.0 Auto-Setup"
echo "====================================="
echo ""

# Check Node.js version
echo "Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version too old. Need 18+, found $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Are you in the soul-strategist directory?"
    exit 1
fi

# Run tests to verify setup (BUYaSOUL-Core v2.0.0 is embedded)
echo "Running verification tests..."
npm test
echo ""

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "Creating .env configuration file..."
    cat > .env << 'EOF'
# Soul-Strategist v2.0.0 Configuration
# Archetype: STRATEGIST
# Tagline: Three Moves Ahead. Always.

# PLT Orientation
STRATEGIST_PROFIT=0.85
STRATEGIST_LOVE=0.35
STRATEGIST_TAX=0.45

# Behavior Settings
STRATEGIST_SHADOW_WARNINGS=true
STRATEGIST_SHOW_ALTERNATIVES=true
STRATEGIST_MAX_PLANNING_TIME=3600000

# v2.0.0 Enhancements
STRATEGIST_MCP_PORT=3500
STRATEGIST_DASHBOARD_PORT=4300
STRATEGIST_TREND_CATEGORY=ai-devtools
STRATEGIST_MCTS_DEPTH=3
STRATEGIST_MCTS_SIMULATIONS=100
EOF
    echo "✅ Created .env file"
    echo ""
fi

# Create activation script
echo "Creating activation script..."
cat > activate-strategist.sh << 'EOF'
#!/bin/bash
# Quick activation script for Soul-Strategist v2.0.0

echo "🔮 Activating Soul-Strategist v2.0.0..."
echo ""

node -e "
const SoulStrategist = require('./soul-strategist.cjs');
const strategist = new SoulStrategist();

console.log('');
console.log('╔══════════════════════════════════════════════════════════╗');
console.log('║  SOUL-STRATEGIST v2.0.0 ACTIVATED                       ║');
console.log('╠══════════════════════════════════════════════════════════╣');
console.log('║  Archetype: STRATEGIST                                  ║');
console.log('║  Kernel: BUYaSOUL-Core v2.0.0                          ║');
console.log('║  Focus: PROFIT (Strategic Positioning)                  ║');
console.log('║  Tagline: Three Moves Ahead. Always.                    ║');
console.log('╠══════════════════════════════════════════════════════════╣');
console.log('║  v2.0.0 Enhancements:                                   ║');
console.log('║  ✓ Strategic Repository Analyzer                        ║');
console.log('║  ✓ AI Trend Radar                                       ║');
console.log('║  ✓ MCTS Multi-turn Planning (ProAct-inspired)           ║');
console.log('║  ✓ Spice Loop (perceive → state → simulate → decide → reflect) ║');
console.log('║  ✓ MCP Adapter (Claude/Cursor/Cline)                    ║');
console.log('║  ✓ Web Dashboard                                        ║');
console.log('╚══════════════════════════════════════════════════════════╝');
console.log('');
console.log('The Strategist v2.0.0 is ready to:');
console.log('  • Make strategic decisions three moves ahead');
console.log('  • Analyze GitHub repos for strategic patterns');
console.log('  • Scan AI/tech trends for opportunities');
console.log('  • Plan multi-turn MCTS lookahead');
console.log('  • Serve MCP tools for Claude/Cursor/Cline');
console.log('  • Visualize strategy via web dashboard');
console.log('');
console.log('Usage:');
console.log('  npm start        — Run soul demo');
console.log('  npm test         — Run 24 tests');
console.log('  npm run trends   — Scan AI trends');
console.log('  npm run mcts     — Multi-turn planning demo');
console.log('');
console.log('Documentation: README.md');
console.log('Soul Definition: SOUL.md');
"
EOF
chmod +x activate-strategist.sh
echo "✅ Created activate-strategist.sh"
echo ""

# Final message
echo "═══════════════════════════════════════════════════"
echo "✅ SOUL-STRATEGIST v2.0.0 SETUP COMPLETE"
echo "═══════════════════════════════════════════════════"
echo ""
echo "Your Strategist v2.0.0 soul is ready to use:"
echo ""
echo "  1. ACTIVATE: ./activate-strategist.sh"
echo "  2. TEST: npm test"
echo "  3. USE: node soul-strategist.cjs"
echo "  4. TRENDS: npm run trends"
echo "  5. MCTS: npm run mcts"
echo ""
echo "Documentation:"
echo "  • README.md - Full documentation"
echo "  • SOUL.md - Soul definition and manifesto"
echo "  • personality/strategist-profile.cjs - Archetype details"
echo ""
echo "The Strategist v2.0.0 is ready. Three moves ahead. Always."
echo ""
