/**
 * Strategist Decision Engine v2.0.0
 * Scores actions based on STRATEGIST archetype
 * Spice-inspired perception→state→simulation→decision→reflection loop
 * Three Moves Ahead. Always.
 */

const StrategistProfile = require('./strategist-profile.cjs');

class StrategistDecisionEngine {
  constructor(context = {}) {
    this.profile = StrategistProfile;
    this.context = context;
    this.decisionHistory = [];
    this.shadowAlerts = [];
  }

  /**
   * Score a single action using STRATEGIST multipliers
   * @param {Object} action - Action to score
   * @param {string} action.type - Type of action (create_extension_point, quick_patch, etc.)
   * @param {number} action.baseUtility - Base utility score (0-1)
   * @param {Object} action.metadata - Additional context
   * @returns {Object} Scored action with reasoning
   */
  scoreAction(action) {
    const { type, baseUtility = 0.5, metadata = {} } = action;
    
    // Get multiplier for this action type
    const multiplier = this.profile.multipliers[type] || 1.0;
    
    // Calculate weighted score
    let score = baseUtility * multiplier;
    
    // Apply context dominance boost
    const phase = this.context.phase || 'default';
    const dominance = this.profile.dominance[phase] || 0.5;
    score *= (0.5 + dominance); // 0.5x to 1.5x boost
    
    // Check constraints
    const violations = this.checkConstraints(action);
    
    // Apply shadow penalties
    if (violations.length > 0) {
      violations.forEach(v => {
        if (v.type === 'shadow_trigger') {
          score += this.profile.multipliers[v.penalty] || -1.0;
          this.shadowAlerts.push(v.message);
        }
      });
    }
    
    // Generate reasoning
    const reasoning = this.generateReasoning(action, score, multiplier, violations);
    
    return {
      action: type,
      score: Math.round(score * 100) / 100,
      baseUtility,
      multiplier,
      dominanceBoost: dominance,
      violations: violations.length > 0 ? violations : null,
      reasoning,
      confidence: this.calculateConfidence(score, violations),
      shadowWarning: this.shadowAlerts.length > 0 ? this.shadowAlerts[0] : null
    };
  }

  /**
   * Score multiple actions and return ranked list
   * @param {Array} actions - Array of action objects
   * @returns {Array} Ranked actions with scores
   */
  scoreActions(actions) {
    const scored = actions.map(action => this.scoreAction(action));
    
    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);
    
    // Mark primary choice
    if (scored.length > 0) {
      scored[0].isPrimary = true;
      
      // Mark top alternatives
      scored.slice(1, 3).forEach(s => s.isAlternative = true);
    }
    
    return scored;
  }

  /**
   * Make decision from options
   * @param {Object} decision - Decision context
   * @param {string} decision.task - Task description
   * @param {Array} decision.options - Available options
   * @param {Object} decision.context - Current context
   * @returns {Object} Decision result with alternatives
   */
  decide(decision) {
    const { task, options, context = {} } = decision;
    
    // Update context
    this.context = { ...this.context, ...context };
    
    // Score all options
    const scored = this.scoreActions(options);
    
    // Primary choice
    const primary = scored[0];
    
    // Alternatives (top 2 others)
    const alternatives = scored.slice(1, 3).map(s => ({
      action: s.action,
      score: s.score,
      reasoning: s.reasoning
    }));
    
    // Record decision
    const decisionRecord = {
      timestamp: Date.now(),
      task,
      primary: {
        action: primary.action,
        score: primary.score,
        reasoning: primary.reasoning,
        confidence: primary.confidence
      },
      alternatives,
      context: this.context,
      shadowAlerts: this.shadowAlerts
    };
    
    this.decisionHistory.push(decisionRecord);
    
    // Clear alerts for next decision
    this.shadowAlerts = [];
    
    return {
      task,
      choice: primary.action,
      score: primary.score,
      reasoning: primary.reasoning,
      confidence: primary.confidence,
      alternatives,
      shadowWarning: decisionRecord.shadowAlerts.length > 0 
        ? decisionRecord.shadowAlerts[0] 
        : null,
      strategistThinking: this.generateStrategistThinking(task, primary, alternatives)
    };
  }

  /**
   * Check if action violates constraints
   * @param {Object} action - Action to check
   * @returns {Array} Violations
   */
  checkConstraints(action) {
    const violations = [];
    
    this.profile.constraints.forEach(constraint => {
      switch (constraint.type) {
        case 'forbid':
          if (action.type === 'quick_patch' && constraint.condition === 'quick_patch_without_positioning') {
            // Check if action has positioning metadata
            if (!action.metadata || !action.metadata.hasPositioning) {
              violations.push({
                type: 'constraint_violation',
                constraint: constraint.type,
                message: constraint.message,
                severity: constraint.priority
              });
            }
          }
          break;
          
        case 'max':
          if (constraint.condition === 'planning_time' && action.metadata) {
            const planningTime = action.metadata.planningTime || 0;
            if (planningTime > constraint.value) {
              violations.push({
                type: 'shadow_trigger',
                penalty: 'over_plan',
                message: `⚠️ SHADOW ALERT: Planning for ${Math.round(planningTime/60000)}m exceeds ${Math.round(constraint.value/60000)}m limit. Risk of analysis paralysis.`,
                severity: constraint.priority
              });
            }
          }
          break;
          
        case 'min':
          if (constraint.condition === 'confidence_threshold' && action.metadata) {
            const confidence = action.metadata.confidence || 0;
            if (confidence < constraint.value) {
              violations.push({
                type: 'constraint_violation',
                constraint: 'low_confidence',
                message: `Confidence ${Math.round(confidence*100)}% below ${Math.round(constraint.value*100)}% threshold`,
                severity: constraint.priority
              });
            }
          }
          break;
      }
    });
    
    return violations;
  }

  /**
   * Generate reasoning for score
   */
  generateReasoning(action, score, multiplier, violations) {
    const reasons = [];
    
    // Base reasoning
    if (multiplier > 1.5) {
      reasons.push(`${action.type} has high strategic value (${multiplier}x multiplier)`);
    } else if (multiplier < 0) {
      reasons.push(`${action.type} conflicts with strategic positioning (${multiplier}x penalty)`);
    }
    
    // Context reasoning
    const phase = this.context.phase;
    if (this.profile.dominance[phase] > 0.7) {
      reasons.push(`STRATEGIST dominates ${phase} phase (${this.profile.dominance[phase]} boost)`);
    }
    
    // Violation reasoning
    violations.forEach(v => {
      if (v.type === 'shadow_trigger') {
        reasons.push(`⚠️ Shadow risk: ${v.message}`);
      }
    });
    
    // Score-based reasoning
    if (score > 1.5) {
      return `Strong strategic positioning: ${reasons.join('. ')}`;
    } else if (score > 0.8) {
      return `Good strategic value: ${reasons.join('. ')}`;
    } else if (score > 0) {
      return `Moderate value: ${reasons.join('. ')}`;
    } else {
      return `Avoid: ${reasons.join('. ')}`;
    }
  }

  /**
   * Calculate confidence in decision
   */
  calculateConfidence(score, violations) {
    let confidence = Math.min(0.95, Math.max(0.1, score / 2));
    
    // Reduce confidence for violations
    violations.forEach(v => {
      if (v.severity === 'critical') confidence -= 0.3;
      if (v.severity === 'high') confidence -= 0.15;
    });
    
    return Math.max(0, Math.min(0.95, confidence));
  }

  /**
   * Generate "Strategist thinking" narrative
   */
  generateStrategistThinking(task, primary, alternatives) {
    const prompts = this.profile.decisionPrompts;
    const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
    
    return {
      prompt: randomPrompt,
      analysis: `Chose ${primary.action} (score: ${primary.score}) over ${alternatives.map(a => `${a.action} (${a.score})`).join(', ')}.`,
      positioning: this.assessPositioning(task, primary),
      timing: this.assessTiming(task, primary),
      leverage: this.assessLeverage(task, primary)
    };
  }

  /**
   * Assess how well this positions for future
   */
  assessPositioning(task, choice) {
    if (choice.score > 1.5) {
      return `Strong positioning: ${choice.action} creates leverage for future iterations`;
    } else if (choice.score > 0.8) {
      return `Moderate positioning: Acceptable for current needs`;
    } else {
      return `Weak positioning: May create technical debt`;
    }
  }

  /**
   * Assess timing of decision
   */
  assessTiming(task, choice) {
    if (this.context.deadline === 'tight') {
      return choice.action.includes('quick') 
        ? 'Timing: Expedient given deadline'
        : 'Timing: Risky given deadline - may miss window';
    }
    return 'Timing: Adequate time for strategic approach';
  }

  /**
   * Assess leverage created
   */
  assessLeverage(task, choice) {
    const leverageScore = Math.round(choice.score * 100);
    if (leverageScore > 140) {
      return `Asymmetric leverage: ${leverageScore}% payoff relative to effort`;
    } else if (leverageScore > 80) {
      return `Balanced leverage: ${leverageScore}% reasonable return`;
    } else {
      return `Low leverage: ${leverageScore}% may not justify cost`;
    }
  }

  /**
   * Spice-inspired full loop: perception → state → simulation → decision → reflection
   * @param {Object} input - Situational input
   * @param {string} input.task - The task or problem
   * @param {Array} input.options - Available options
   * @param {Object} input.context - Environmental context
   * @returns {Object} Full loop result with all layers
   */
  fullLoop(input) {
    const perception = this._perceive(input);
    const state = this._modelState(perception);
    const simulation = this._simulate(state);
    const decision = this.decide({
      task: input.task,
      options: input.options,
      context: { ...input.context, simulationInsight: simulation }
    });
    const reflection = this._reflect(decision, perception);

    return { perception, state, simulation, decision, reflection };
  }

  _perceive(input) {
    return {
      task: input.task,
      signals: this._extractSignals(input),
      contextFlags: {
        hasDeadline: !!input.context?.deadline,
        phase: input.context?.phase || 'default',
        complexity: input.options?.length > 3 ? 'high' : input.options?.length > 1 ? 'medium' : 'low'
      },
      timestamp: Date.now()
    };
  }

  _extractSignals(input) {
    const signals = [];
    if (input.task?.toLowerCase().includes('auth')) signals.push('security-sensitive');
    if (input.task?.toLowerCase().includes('migrat')) signals.push('high-risk-change');
    if (input.task?.toLowerCase().includes('api')) signals.push('integration-point');
    if (input.options?.some(o => o.type === 'quick_patch')) signals.push('pressure-for-speed');
    if (input.context?.phase === 'architecture') signals.push('foundational-decision');
    return signals;
  }

  _modelState(perception) {
    return {
      current: perception.contextFlags,
      tension: perception.signals.length > 2 ? 'high' : perception.signals.length > 0 ? 'medium' : 'low',
      momentum: this.decisionHistory.length,
      archetypeBias: 'profit-dominant-strategist',
      shadowRisk: perception.contextFlags.phase === 'planning' && perception.contextFlags.complexity === 'high' ? 'analysis-paralysis' : null
    };
  }

  _simulate(state) {
    const scenarios = [];
    if (state.tension === 'high') {
      scenarios.push({ name: 'quick-win', outcome: 'temporary-relief', probability: 0.6 });
      scenarios.push({ name: 'strategic-position', outcome: 'long-term-advantage', probability: 0.4 });
    } else {
      scenarios.push({ name: 'strategic-position', outcome: 'positioned-for-future', probability: 0.7 });
      scenarios.push({ name: 'balanced-approach', outcome: 'reasonable-progress', probability: 0.3 });
    }
    return {
      scenarios,
      shadowWarning: state.shadowRisk,
      recommendedDepth: state.tension === 'high' ? 2 : 3
    };
  }

  _reflect(decision, perception) {
    return {
      accuracy: decision.confidence > 0.8 ? 'high-confidence' : decision.confidence > 0.5 ? 'moderate-confidence' : 'low-confidence',
      biasCheck: this._checkBias(decision, perception),
      wouldRepeat: decision.score > 0.8,
      learning: decision.score > 1.0
        ? 'Strategic positioning pays off — continue prioritizing extension points'
        : 'Consider faster iteration when confidence is marginal'
    };
  }

  _checkBias(decision, perception) {
    const biases = [];
    if (decision.choice?.includes('extension') && perception.contextFlags.phase === 'implementation') {
      biases.push('over-abstraction-bias');
    }
    if (decision.choice?.includes('patch') && perception.contextFlags.phase === 'architecture') {
      biases.push('under-positioning-bias');
    }
    return biases.length > 0 ? biases : ['none-detected'];
  }

  /**
   * Get decision history
   */
  getHistory() {
    return this.decisionHistory;
  }

  /**
   * Get profile info
   */
  getProfile() {
    return {
      id: this.profile.id,
      name: this.profile.name,
      plt: this.profile.plt,
      strength: this.profile.strength.description,
      shadow: this.profile.shadow.description
    };
  }
}

module.exports = StrategistDecisionEngine;

// CLI Demo
if (require.main === module) {
  console.log('🔮 STRATEGIST Decision Engine v2.0.0 — Spice Loop');
  console.log('');
  
  const engine = new StrategistDecisionEngine({ phase: 'planning' });
  
  console.log('=== SPICE LOOP DEMO (perception → state → simulation → decision → reflection) ===');
  const loopResult = engine.fullLoop({
    task: 'Build user authentication system',
    options: [
      { type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } },
      { type: 'quick_patch', baseUtility: 0.9, metadata: { hasPositioning: false } },
      { type: 'over_engineer', baseUtility: 0.5, metadata: { planningTime: 7200000 } },
      { type: 'strategic_abstraction', baseUtility: 0.7, metadata: {} }
    ],
    context: { phase: 'architecture', deadline: '3_days' }
  });
  
  console.log('1. PERCEPTION');
  console.log('   Signals:', loopResult.perception.signals.join(', '));
  console.log('   Flags:', JSON.stringify(loopResult.perception.contextFlags));
  console.log('');
  console.log('2. STATE');
  console.log('   Tension:', loopResult.state.tension);
  console.log('   Shadow Risk:', loopResult.state.shadowRisk || 'none');
  console.log('');
  console.log('3. SIMULATION');
  console.log('   Scenarios:');
  loopResult.simulation.scenarios.forEach(s => {
    console.log(`   - ${s.name}: ${s.outcome} (${Math.round(s.probability * 100)}%)`);
  });
  console.log('');
  console.log('4. DECISION');
  console.log('   Choice:', loopResult.decision.choice);
  console.log('   Score:', loopResult.decision.score);
  console.log('   Confidence:', Math.round(loopResult.decision.confidence * 100) + '%');
  console.log('   Reasoning:', loopResult.decision.reasoning);
  console.log('');
  console.log('5. REFLECTION');
  console.log('   Accuracy:', loopResult.reflection.accuracy);
  console.log('   Biases:', loopResult.reflection.biasCheck.join(', '));
  console.log('   Would Repeat:', loopResult.reflection.wouldRepeat);
  
  if (loopResult.decision.shadowWarning) {
    console.log('');
    console.log('⚠️ SHADOW WARNING:', loopResult.decision.shadowWarning);
  }
}
