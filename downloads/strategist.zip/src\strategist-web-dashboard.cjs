class StrategistWebDashboard {
  constructor(options = {}) {
    this.port = options.dashboardPort || 4300;
    this._dataPoints = [];
  }

  getInfo() {
    return {
      type: 'strategist-dashboard',
      port: this.port,
      endpoints: {
        status: `http://localhost:${this.port}/status`,
        decisions: `http://localhost:${this.port}/decisions`,
        trends: `http://localhost:${this.port}/trends`,
        mcts: `http://localhost:${this.port}/mcts`,
        analysis: `http://localhost:${this.port}/analysis`
      },
      features: [
        'Strategic position visualization',
        'Decision history timeline',
        'Trend radar heatmap',
        'MCTS tree explorer',
        'PLT score tracker'
      ],
      embedHtml: `<iframe src="http://localhost:${this.port}" width="100%" height="600" title="Strategist Dashboard"></iframe>`
    };
  }

  recordDataPoint(type, data) {
    this._dataPoints.push({
      type,
      data,
      timestamp: Date.now()
    });
  }

  getDataPoints(type, limit = 50) {
    const filtered = type
      ? this._dataPoints.filter(d => d.type === type)
      : this._dataPoints;
    return filtered.slice(-limit);
  }

  generateDecisionChart(decisions) {
    return {
      type: 'line',
      data: {
        labels: decisions.map((_, i) => `#${i + 1}`),
        datasets: [{
          label: 'Strategic Score',
          data: decisions.map(d => d.score || 0),
          borderColor: '#7c3aed',
          backgroundColor: 'rgba(124, 58, 237, 0.1)'
        }]
      },
      insights: this._deriveInsights(decisions)
    };
  }

  generateTrendChart(trends) {
    return {
      type: 'bar',
      data: {
        labels: trends.map(t => t.name?.split('/')[1] || t.name),
        datasets: [{
          label: 'Strategic Score',
          data: trends.map(t => t.strategicScore || 0)
        }]
      }
    };
  }

  generateMCTSTree(plan) {
    return {
      type: 'tree',
      root: plan.goal,
      path: plan.bestPath,
      confidence: plan.confidence
    };
  }

  _deriveInsights(decisions) {
    if (decisions.length < 2) return { trend: 'insufficient-data' };
    const scores = decisions.map(d => d.score || 0);
    const avg = scores.reduce((s, v) => s + v, 0) / scores.length;
    const recent = scores.slice(-3);
    const recentAvg = recent.reduce((s, v) => s + v, 0) / recent.length;
    return {
      averageScore: Math.round(avg * 100) / 100,
      recentTrend: recentAvg > avg ? 'improving' : recentAvg < avg ? 'declining' : 'stable',
      totalDecisions: decisions.length
    };
  }
}

module.exports = StrategistWebDashboard;

if (require.main === module) {
  const dash = new StrategistWebDashboard();
  console.log(JSON.stringify(dash.getInfo(), null, 2));
}
