/**
 * BUYaSOUL Integration: Strategist Soul v2.0.0
 * The Strategist plugged into the BUYaSOUL-Core v2.0.0 kernel
 */

// BUYaSOUL Core v2.0.0 Integration with fallback
let BUYaSOUL;
try {
  const sdkModule = require('./buyasoul-core/buyasoul-sdk.cjs');
  BUYaSOUL = sdkModule.BUYaSOUL || sdkModule;
  if (typeof BUYaSOUL.createSoul !== 'function') throw new Error('Invalid BUYaSOUL export');
} catch {
  BUYaSOUL = require('./lib/mock-buyasoul.cjs');
}
const StrategistProfile = require('./personality/strategist-profile.cjs');
const StrategistDecisionEngine = require('./personality/strategist-engine.cjs');
const StrategistCodeGenerator = require('./src/strategist-code-generator.cjs');
const StrategicRepoAnalyzer = require('./personality/strategist-repo-analyzer.cjs');
const StrategistTrendRadar = require('./src/strategist-trend-radar.cjs');
const StrategistMCTSPlanner = require('./src/strategist-mcts-planner.cjs');
const StrategistMCPAdapter = require('./src/strategist-mcp-adapter.cjs');
const StrategistWebDashboard = require('./src/strategist-web-dashboard.cjs');

class SoulStrategist {
  constructor(config = {}) {
    this.version = '2.0.0';
    this.name = 'The Strategist';
    this.profile = StrategistProfile;
    
    // Initialize BUYaSOUL kernel
    this.kernel = BUYaSOUL.createSoul({
      archetype: 'STRATEGIST',
      soulGroup: 'starseed',
      pltFocus: 'PROFIT'
    });
    
    // Initialize Strategist-specific components
    this.decisionEngine = new StrategistDecisionEngine(config.context);
    this.codeGenerator = new StrategistCodeGenerator(config);
    this.repoAnalyzer = new StrategicRepoAnalyzer(config);
    this.trendRadar = new StrategistTrendRadar(config);
    this.mctsPlanner = new StrategistMCTSPlanner(config);
    this.mcpAdapter = new StrategistMCPAdapter(config);
    this.webDashboard = new StrategistWebDashboard(config);
    
    // GSK Chamber activations specific to Strategist
    this.activateChambers();
    
    console.log(`🔮 Soul-Strategist v${this.version} initialized`);
    console.log(`   Archetype: ${this.profile.name}`);
    console.log(`   Tagline: "${this.profile.tagline}"`);
    console.log(`   Components: decisionEngine, repoAnalyzer, trendRadar, mctsPlanner, mcpAdapter, webDashboard`);
  }

  /**
   * Activate Strategist-specific GSK chambers
   */
  activateChambers() {
    if (this.kernel.__gskMemory) {
      // High activation for strategic thinking
      this.kernel.__gskMemory.activate('prediction', 0.95);
      this.kernel.__gskMemory.activate('awareness', 0.90);
      this.kernel.__gskMemory.activate('reasoning', 0.90);
      this.kernel.__gskMemory.activate('creativity', 0.75);
      this.kernel.__gskMemory.activate('curiosity', 0.70);
      
      // Moderate for execution
      this.kernel.__gskMemory.activate('will', 0.60);
      this.kernel.__gskMemory.activate('agency', 0.65);
      
      // Lower for emotional (Strategist shadow)
      this.kernel.__gskMemory.activate('empathy', 0.35);
      this.kernel.__gskMemory.activate('emotion', 0.40);
    }
  }

  /**
   * Decide how to approach a task (Strategist perspective)
   */
  decide(task, options, context = {}) {
    // Use decision engine
    const decision = this.decisionEngine.decide({
      task,
      options,
      context
    });
    
    // Record in SCRIBE witness
    if (this.kernel.__witness) {
      this.kernel.__witness.record({
        event: 'STRATEGIST_DECISION',
        task,
        choice: decision.choice,
        score: decision.score,
        reasoning: decision.reasoning,
        alternatives: decision.alternatives,
        timestamp: Date.now()
      });
    }
    
    // Update PLT scores
    if (this.kernel.__soul) {
      this.kernel.__soul.reflect('strategic_decision', {
        profitImpact: decision.score > 1.0 ? 0.15 : 0.05,
        loveImpact: -0.02, // Strategist undervalues emotion
        taxImpact: 0.03
      });
    }
    
    return decision;
  }

  /**
   * Generate code for a task (Strategist style)
   */
  generate(task, options = {}) {
    switch (task) {
      case 'auth_system':
        return this.codeGenerator.generateAuthSystem();
      
      case 'database_choice':
        return this.codeGenerator.generateDatabaseChoice(options.analysis);
      
      case 'refactor_strategy':
        return this.codeGenerator.generateRefactoringStrategy(options.moduleName);
      
      default:
        return {
          error: 'Unknown task',
          availableTasks: ['auth_system', 'database_choice', 'refactor_strategy'],
          strategistSuggestion: 'Define task with strategic context for optimal code generation'
        };
    }
  }

  /**
   * Get full soul status
   */
  getStatus() {
    return {
      name: this.name,
      version: this.version,
      archetype: this.profile.id,
      plt: this.profile.plt,
      kernel: {
        pltScore: this.kernel.__soul ? this.kernel.__soul.getPLTScore() : null,
        chambers: this.kernel.__gskMemory ? this.kernel.__gskMemory.getState() : null,
        witnessed: this.kernel.__witness ? this.kernel.__witness.logs : null
      },
      decisionsMade: this.decisionEngine.getHistory().length,
      codeGenerated: this.codeGenerator.generatedCode.length
    };
  }

  /**
   * Get STRATEGIST thinking on a problem
   */
  think(problem) {
    const prompts = this.profile.decisionPrompts;
    const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
    
    return {
      problem,
      strategistPrompt: randomPrompt,
      approach: 'Analyze three moves ahead before acting',
      positioning: 'Consider where this positions you for future changes',
      timing: 'Evaluate if now is the optimal moment',
      leverage: 'Seek asymmetric payoff (small effort → large future gain)',
      shadowWarning: 'Watch for over-planning. Balance analysis with action.',
      pltOrientation: `Profit: ${this.profile.plt.profit}, Love: ${this.profile.plt.love}, Tax: ${this.profile.plt.tax}`
    };
  }

  /**
   * Get profile information
   */
  getProfile() {
    return {
      id: this.profile.id,
      name: this.profile.name,
      tagline: this.profile.tagline,
      strength: this.profile.strength,
      shadow: this.profile.shadow,
      plt: this.profile.plt,
      traits: this.profile.traits
    };
  }

  /**
   * Analyze a GitHub repository for strategic patterns, tech debt, and extension points
   * @param {string} repoUrl - GitHub repository URL
   * @param {Object} options - Analysis options
   * @returns {Object} Strategic analysis report
   */
  analyzeRepo(repoUrl, options = {}) {
    return this.repoAnalyzer.analyze(repoUrl, options);
  }

  /**
   * Scan trending AI/tech repos and generate strategic recommendations
   * @param {Object} filters - Trend filter criteria
   * @returns {Array} Ranked trending repos with strategic analysis
   */
  scanTrends(filters = {}) {
    return this.trendRadar.scan(filters);
  }

  /**
   * Perform MCTS-based multi-turn strategic lookahead planning
   * @param {string} goal - Strategic goal
   * @param {Array} actions - Available actions
   * @param {Object} options - Planning options (depth, simulations, etc.)
   * @returns {Object} Best path and analysis
   */
  planMCTS(goal, actions, options = {}) {
    return this.mctsPlanner.plan(goal, actions, options);
  }

  /**
   * Get MCP server status and available tools
   * @returns {Object} MCP adapter status
   */
  getMCPStatus() {
    return this.mcpAdapter.getStatus();
  }

  /**
   * Get web dashboard URL and metadata
   * @returns {Object} Dashboard info
   */
  getDashboard() {
    return this.webDashboard.getInfo();
  }

  /**
   * Full enhanced strategic analysis: trends + repo + MCTS
   * @param {Object} config - Analysis configuration
   * @returns {Object} Comprehensive strategic report
   */
  strategicAnalysis(config = {}) {
    const results = {};
    
    if (config.scanTrends !== false) {
      results.trends = this.trendRadar.scan({
        category: config.trendCategory || 'ai-devtools',
        limit: config.trendLimit || 10
      });
    }
    
    if (config.repoUrl) {
      results.repoAnalysis = this.repoAnalyzer.analyze(config.repoUrl, config.repoOptions);
    }
    
    if (config.goal && config.actions) {
      results.mctsPlan = this.mctsPlanner.plan(config.goal, config.actions, config.mctsOptions);
    }
    
    if (config.decision) {
      results.decision = this.decisionEngine.decide(config.decision);
    }
    
    // Record in SCRIBE witness
    if (this.kernel.__witness) {
      this.kernel.__witness.record({
        event: 'STRATEGIC_ANALYSIS',
        config: Object.keys(config),
        modules: Object.keys(results),
        timestamp: Date.now()
      });
    }
    
    return results;
  }
}

module.exports = SoulStrategist;

// CLI Demo
if (require.main === module) {
  console.log('🔮 SOUL-STRATEGIST v2.0.0 — BUYaSOUL-Core v2.0.0 Integration');
  console.log('');
  
  // Create the soul
  const strategist = new SoulStrategist();
  
  console.log('');
  console.log('=== STRATEGIST THINKING ===');
  const thinking = strategist.think('How should we build our API?');
  console.log('Problem:', thinking.problem);
  console.log('Prompt:', thinking.strategistPrompt);
  console.log('Approach:', thinking.approach);
  console.log('');
  
  console.log('=== DECISION DEMO (v2.0.0 Enhanced) ===');
  const decision = strategist.decide(
    'Build user authentication',
    [
      { type: 'create_extension_point', baseUtility: 0.8, metadata: { hasPositioning: true } },
      { type: 'quick_patch', baseUtility: 0.9, metadata: { hasPositioning: false } },
      { type: 'strategic_abstraction', baseUtility: 0.7, metadata: {} }
    ],
    { phase: 'architecture' }
  );
  
  console.log('Task:', decision.task);
  console.log('Choice:', decision.choice);
  console.log('Score:', decision.score);
  console.log('Confidence:', Math.round(decision.confidence * 100) + '%');
  console.log('Reasoning:', decision.reasoning);
  console.log('Alternatives:');
  decision.alternatives.forEach((alt, i) => {
    console.log(`  ${i + 1}. ${alt.action} (score: ${alt.score})`);
  });
  console.log('');
  
  console.log('=== MCTS MULTI-TURN PLANNING DEMO ===');
  const mctsPlan = strategist.planMCTS(
    'Build auth system',
    [
      { name: 'quick_jwt', utility: 0.6, risk: 0.3 },
      { name: 'strategy_pattern', utility: 0.8, risk: 0.2 },
      { name: 'oauth_provider', utility: 0.9, risk: 0.4 },
      { name: 'sso_enterprise', utility: 0.7, risk: 0.5 }
    ],
    { depth: 3, simulations: 100 }
  );
  console.log('Goal:', mctsPlan.goal);
  console.log('Best Path:', mctsPlan.bestPath.join(' → '));
  console.log('Confidence:', Math.round(mctsPlan.confidence * 100) + '%');
  console.log('');
  
  console.log('=== SOUL STATUS (v2.0.0) ===');
  const status = strategist.getStatus();
  console.log('Name:', status.name);
  console.log('Archetype:', status.archetype);
  console.log('PLT Orientation:', `Profit ${status.plt.profit}, Love ${status.plt.love}, Tax ${status.plt.tax}`);
  console.log('Decisions Made:', status.decisionsMade);
  console.log('Code Generated:', status.codeGenerated);
  console.log('MCP Adapter:', strategist.getMCPStatus().status);
  
  if (status.kernel.pltScore) {
    console.log('Current PLT Score:', status.kernel.pltScore.toFixed(2));
  }
  
  console.log('');
  console.log('=== AVAILABLE ENHANCEMENTS ===');
  console.log('  analyzeRepo(url)     — Strategic GitHub repo analysis');
  console.log('  scanTrends()         — AI/tech trend radar');
  console.log('  planMCTS(goal, acts) — Multi-turn lookahead planning');
  console.log('  strategicAnalysis()  — All-of-the-above combined report');
  console.log('  getMCPStatus()       — MCP adapter for Claude/Cursor/Cline');
  console.log('  getDashboard()       — Web dashboard info');
}
