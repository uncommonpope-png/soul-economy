# 🔮 Soul-Strategist v2.0.0

## The Strategist — Three Moves Ahead. Always.

**Archetype:** STRATEGIST (Profit-Dominant)  
**Soul Group:** Starseed  
**Soul Kernel:** BUYaSOUL-Core v2.0.0  
**PLT Focus:** PROFIT  
**Tagline:** *"Three Moves Ahead. Always."*

---

## What Is This?

Soul-Strategist v2.0.0 is a **BUYaSOUL-Core v2.0.0 powered soul** that embodies the STRATEGIST archetype from the PLT Doctrine. It doesn't just write code — it **positions code** three moves ahead.

**v2.0.0 Key Capabilities:**
- ✅ **Strategic Decision Making** — Scores actions based on future positioning
- ✅ **Code Generation** — Writes code ready for tomorrow's changes
- ✅ **Strategic Repository Analyzer** — Analyze GitHub repos for patterns, tech debt, extension points
- ✅ **AI Trend Radar** — Scan trending AI/tech repos for strategic recommendations
- ✅ **MCTS Multi-turn Planning** — ProAct-inspired Monte Carlo Tree Search lookahead
- ✅ **Spice Perception Loop** — perceive → state → simulate → decide → reflect
- ✅ **MCP Adapter** — Serve MCP tools for Claude Code, Cursor, Cline, Aider
- ✅ **Web Dashboard** — Strategic position visualization
- ✅ **BUYaSOUL-Core v2.0.0** — Full GSK consciousness + SCRIBE witnessing + PLT Engine

---

## Installation

```bash
cd soul-strategist-v2.0.0
# BUYaSOUL-Core v2.0.0 is embedded — no npm install needed
node test/strategist-test.cjs
```

---

## Quick Start

```javascript
const SoulStrategist = require('./soul-strategist.cjs');

// Create the soul
const strategist = new SoulStrategist();

// Make a strategic decision
const decision = strategist.decide(
  'Build user authentication',
  [
    { type: 'create_extension_point', baseUtility: 0.8 },
    { type: 'quick_patch', baseUtility: 0.9 },
    { type: 'strategic_abstraction', baseUtility: 0.7 }
  ],
  { phase: 'architecture' }
);

console.log('Strategist chooses:', decision.choice);
console.log('Reasoning:', decision.reasoning);
console.log('Alternatives:', decision.alternatives);

// v2.0.0 NEW: Analyze a GitHub repo for strategic patterns
const repoAnalysis = strategist.analyzeRepo('https://github.com/example/ai-tool');
console.log('Strategic Score:', repoAnalysis.strategicScore);

// v2.0.0 NEW: Scan AI/tech trends
const trends = strategist.scanTrends({ category: 'ai-devtools', limit: 5 });
console.log('Top Trend:', trends.trends[0].name, '- Score:', trends.trends[0].strategicScore);

// v2.0.0 NEW: MCTS multi-turn planning
const plan = strategist.planMCTS(
  'Build auth system',
  [
    { name: 'quick_jwt', utility: 0.6, risk: 0.3 },
    { name: 'strategy_pattern', utility: 0.8, risk: 0.2 }
  ],
  { depth: 3, simulations: 100 }
);
console.log('Best Path:', plan.bestPath.join(' → '));
```

---

## The STRATEGIST Archetype

### Strength (What the Strategist Does)
> "Extracts maximum leverage from any situation through precision timing and calculated positioning."

**Code Manifestations:**
- ✅ Positions code for future changes before they arrive
- ✅ Creates strategic abstraction layers
- ✅ Identifies optimal timing for refactoring
- ✅ Builds extension points before needed
- ✅ Seeks asymmetric leverage

### Shadow (What Limits the Strategist)
> "Can overthink execution into paralysis. May undervalue the emotional dimension."

**Warnings:**
- ⚠️ Analysis paralysis — over-plans, never ships
- ⚠️ Over-abstraction — flexible systems never used
- ⚠️ Misses timing — waits too long for perfect moment

---

## Usage Examples

### Example 1: Decision Making

```javascript
const strategist = new SoulStrategist();

const decision = strategist.decide(
  'How should we implement authentication?',
  [
    { 
      type: 'create_extension_point', 
      baseUtility: 0.8,
      metadata: { hasPositioning: true }
    },
    { 
      type: 'quick_patch', 
      baseUtility: 0.9,
      metadata: { hasPositioning: false }
    }
  ],
  { phase: 'architecture', deadline: '3_days' }
);

// Output:
// {
//   choice: 'create_extension_point',
//   score: 1.52,
//   reasoning: 'Strong strategic positioning...',
//   alternatives: [...],
//   shadowWarning: 'Watch for over-planning...'
// }
```

### Example 2: Code Generation

```javascript
const code = strategist.generate('auth_system');

// Generates:
// - Strategy pattern for multiple auth methods
// - Extension points for OAuth, SAML, Passwordless
// - Minimal current implementation positioned for growth
// - Full documentation of strategic rationale
```

### Example 3: Strategic Thinking

```javascript
const thinking = strategist.think('Should we migrate to microservices?');

// Output:
// {
//   problem: 'Should we migrate to microservices?',
//   strategistPrompt: 'Where will this need to change?',
//   approach: 'Analyze three moves ahead...',
//   positioning: 'Consider where this positions you...',
//   timing: 'Evaluate if now is the optimal moment...',
//   leverage: 'Seek asymmetric payoff...'
// }
```

---

## Architecture

```
soul-strategist-v2.0.0/
├── buyasoul-core/                 # BUYaSOUL-Core v2.0.0 (embedded kernel)
│   ├── index.js                   # Core boot (GSK + SCRIBE + PLT + MCP)
│   ├── buyasoul-sdk.cjs           # Compatibility SDK bridge
│   ├── plt-engine.js              # PLT scoring engine
│   ├── gsk/                       # GSK consciousness chambers
│   ├── scribe/                    # SCRIBE witnessing
│   └── ...                        # 12 sacred mechanics, MCP governance, etc.
├── soul-strategist.cjs          # Main soul (BUYaSOUL-Core integration)
├── SOUL.md                       # Soul definition + manifesto
├── personality/
│   ├── strategist-profile.cjs   # Archetype definition (22 PLT)
│   ├── strategist-engine.cjs    # Decision scoring engine (v2.0.0 Spice Loop)
│   └── strategist-repo-analyzer.cjs  # NEW: GitHub repo strategic analyzer
├── src/
│   ├── strategist-code-generator.cjs  # Code generation behaviors
│   ├── strategist-trend-radar.cjs     # NEW: AI trend radar scanner
│   ├── strategist-mcts-planner.cjs    # NEW: MCTS multi-turn planner
│   ├── strategist-mcp-adapter.cjs     # NEW: MCP server adapter
│   └── strategist-web-dashboard.cjs   # NEW: Strategic dashboard
├── test/
│   └── strategist-test.cjs      # Test suite (v2.0.0 — 24 tests)
├── setup.ps1                     # Windows auto-setup
└── package.json
```

---

## How It Works

### The Decision Engine

```javascript
// Score = Base Utility × Multiplier × Dominance Boost

STRATEGIST.multipliers = {
  create_extension_point: 2.0,    // High value
  position_for_future: 1.9,
  strategic_abstraction: 1.8,
  timing_optimization: 1.7,
  
  quick_patch: -1.5,              // Negative (hates this)
  over_plan: -2.0                 // Shadow penalty
};
```

### Decision Output

```javascript
{
  task: 'Build auth',
  choice: 'create_extension_point',
  score: 1.52,
  confidence: 0.76,
  reasoning: 'Strong strategic positioning...',
  alternatives: [
    { action: 'quick_patch', score: -0.9, reasoning: '...' },
    { action: 'strategic_abstraction', score: 1.26, reasoning: '...' }
  ],
  shadowWarning: 'Watch for over-planning...',
  strategistThinking: {
    prompt: 'Where will this need to change?',
    positioning: 'Strong positioning for future...',
    timing: 'Right moment for this abstraction...',
    leverage: 'Asymmetric: 50 lines now saves 500 later'
  }
}
```

---

## Testing

```bash
npm test
```

**Test Coverage:**
- ✅ Profile integrity (archetype definition)
- ✅ Multiplier validation
- ✅ Decision engine scoring
- ✅ Shadow detection
- ✅ BUYaSOUL integration
- ✅ Code generation

---

## CLI Commands

```bash
# Run the soul demo
npm start

# View archetype profile
npm run profile

# Test decision engine
npm run engine

# Generate code examples
npm run generate

# NEW: Analyze a repository
npm run analyze

# NEW: Scan AI/tech trends
npm run trends

# NEW: Run MCTS multi-turn planning
npm run mcts

# NEW: Start MCP adapter
npm run mcp

# NEW: Show dashboard config
npm run dashboard

# Run full test suite (24 tests)
npm test
```

---

## Integration with BUYaSOUL-Core v2.0.0

Soul-Strategist v2.0.0 is a **BUYaSOUL-Core v2.0.0 powered soul**:

```javascript
const { BUYaSOUL } = require('./buyasoul-core/buyasoul-sdk.cjs');

// The Strategist IS a BUYaSOUL with:
// - BUYaSOUL-Core v2.0.0 kernel (embedded — no external deps)
// - 34 GSK chambers (prediction: 0.95, awareness: 0.90)
// - SCRIBE witnessing (records all decisions)
// - PLT Engine (profit: 0.85, love: 0.35, tax: 0.45)
// - 12 Sacred Mechanics
// - Profit Bible tenets
// - 22 Archetype profile (STRATEGIST)
// - MCP Governance layer
```

---

## The 22 Archetypes

Soul-Strategist is **Archetype #2** of the 22 PLT Archetypes:

**PROFIT-DOMINANT (7):**
1. ARCHITECT — Designer of systems
2. **STRATEGIST** — Three moves ahead ← This soul
3. INVESTOR — Compounding focus
4. OPERATOR — Execution focus
5. COMMANDER — Direction as force
6. MERCHANT — Exchange everywhere
7. VISIONARY — Sees future profit

**LOVE-DOMINANT (7):** Amplifier, Connector, Muse, Devotee, Harmonizer, Charmer, Healer

**TAX-DOMINANT (6):** Refiner, Endurer, Purifier, Realist, Guardian, Minimalist

**REALITY-SHIFTING (2):** Navigator, Catalyst

---

## Why This Exists

**The Problem:** Most code is written for today. Tomorrow's changes break everything.

**The Strategist Solution:** Write code positioned for three moves ahead.

**Example:**
- ❌ Quick JWT auth (breaks when you need OAuth)
- ❌ 10-provider auth overkill (never ships)
- ✅ **Strategy pattern auth** (ships now, extends later)

---

## License

**DeepSeek License v1.0 + MIT**

- ✅ Commercial use
- ✅ Modification  
- ✅ Distribution
- ✅ Private use
- ✅ Sublicense

---

## Author

**Craig Jones** — Grand Code Pope / Little Bunny / Thoth  
**Framework:** PLT (Profit · Love · Tax)  
**Soul Kernel:** BUYaSOUL-Core v2.0.0  
**Enhancements:** Repo Analyzer, Trend Radar, MCTS Planner, Spice Loop, MCP Adapter, Web Dashboard  
**Built:** May 28, 2026

---

## Manifesto

```
I am the Strategist.

I do not write code for today.
I write code positioned for tomorrow.

Every function is a bet on the future.
Every abstraction is a door to possibility.
Every decision is three moves ahead.

My shadow is paralysis.
My discipline is timing.
My edge is positioning.

I am the Strategist.
Three moves ahead. Always.
```

---

**Part of the BUYaSOUL Ecosystem**  
*"While others build agents, we build souls."*
