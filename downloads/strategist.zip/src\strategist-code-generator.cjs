/**
 * STRATEGIST Code Generation Behaviors v1.0.0
 * How the Strategist archetype actually writes code
 * Three Moves Ahead. Always.
 */

const StrategistProfile = require('../personality/strategist-profile.cjs');

class StrategistCodeGenerator {
  constructor(options = {}) {
    this.profile = StrategistProfile;
    this.options = options;
    this.generatedCode = [];
  }

  /**
   * Generate code for "Build User Authentication"
   * STRATEGIST approach: Position for 3 future scenarios
   */
  generateAuthSystem() {
    const code = `/**
 * Authentication System
 * STRATEGIC POSITIONING: Designed for 3 future scenarios
 * 
 * Current: Password-based auth
 * Future 1: OAuth providers (Google, GitHub) - EXTENSION POINT READY
 * Future 2: Enterprise SSO (SAML) - EXTENSION POINT READY  
 * Future 3: Passwordless/Magic links - EXTENSION POINT READY
 * 
 * Architect: STRATEGIST (Three Moves Ahead)
 * Rationale: Small abstraction cost now = 10x flexibility later
 */

// ═══════════════════════════════════════════════════════════
// LAYER 1: STRATEGIC INTERFACE (The Extension Point)
// ═══════════════════════════════════════════════════════════

interface AuthStrategy {
  /**
   * Authenticate user with credentials
   * @param credentials - Provider-specific credentials
   * @returns Authenticated user or null
   */
  authenticate(credentials: Credentials): Promise<User | null>;
  
  /**
   * Validate existing token/session
   * @param token - Token to validate
   * @returns true if valid
   */
  validate(token: string): Promise<boolean>;
  
  /**
   * Get strategy identifier
   * @returns Strategy name (e.g., 'password', 'oauth-google')
   */
  getStrategyName(): string;
}

// ═══════════════════════════════════════════════════════════
// LAYER 2: STRATEGY REGISTRY (The Leverage Point)
// ═══════════════════════════════════════════════════════════

class AuthStrategyRegistry {
  private strategies: Map<string, AuthStrategy> = new Map();
  private defaultStrategy: string = 'password';
  
  /**
   * Register a new authentication strategy
   * EXTENSION POINT: Add OAuth, SSO, etc. without touching core
   */
  register(name: string, strategy: AuthStrategy): void {
    this.strategies.set(name, strategy);
    console.log(\`[STRATEGIST] Registered auth strategy: \${name}\`);
  }
  
  /**
   * Get strategy by name
   */
  get(name: string): AuthStrategy | undefined {
    return this.strategies.get(name);
  }
  
  /**
   * Get default strategy
   */
  getDefault(): AuthStrategy {
    const strategy = this.strategies.get(this.defaultStrategy);
    if (!strategy) {
      throw new Error(\`Default strategy '\${this.defaultStrategy}' not registered\`);
    }
    return strategy;
  }
  
  /**
   * List all available strategies
   */
  list(): string[] {
    return Array.from(this.strategies.keys());
  }
}

// ═══════════════════════════════════════════════════════════
// LAYER 3: CURRENT IMPLEMENTATION (Ship Now)
// ═══════════════════════════════════════════════════════════

class PasswordAuthStrategy implements AuthStrategy {
  private userRepository: UserRepository;
  private passwordHasher: PasswordHasher;
  
  constructor(deps: { users: UserRepository; hasher: PasswordHasher }) {
    this.userRepository = deps.users;
    this.passwordHasher = deps.hasher;
  }
  
  async authenticate(credentials: PasswordCredentials): Promise<User | null> {
    // STRATEGIC TIMING: Simple now, positioned for complexity later
    const user = await this.userRepository.findByEmail(credentials.email);
    if (!user) return null;
    
    const isValid = await this.passwordHasher.compare(
      credentials.password, 
      user.passwordHash
    );
    
    return isValid ? user : null;
  }
  
  async validate(token: string): Promise<boolean> {
    // TODO: Implement JWT validation
    // POSITIONED: Token validation strategy will be swappable
    return token.length > 0;
  }
  
  getStrategyName(): string {
    return 'password';
  }
}

// ═══════════════════════════════════════════════════════════
// LAYER 4: THE MANAGER (The Strategic Facade)
// ═══════════════════════════════════════════════════════════

class AuthManager {
  private registry: AuthStrategyRegistry;
  private sessionStore: SessionStore;
  
  constructor(deps: { registry: AuthStrategyRegistry; sessions: SessionStore }) {
    this.registry = deps.registry;
    this.sessionStore = deps.sessions;
  }
  
  /**
   * Authenticate using current strategy
   * COUNTERINTUITIVE: Starts simple, ready for complex
   */
  async authenticate(credentials: Credentials): Promise<AuthResult> {
    const strategy = this.registry.getDefault();
    const user = await strategy.authenticate(credentials);
    
    if (user) {
      const session = await this.sessionStore.create(user);
      return { success: true, user, session };
    }
    
    return { success: false, error: 'Invalid credentials' };
  }
  
  /**
   * Switch to different auth strategy
   * STRATEGIC: Enable OAuth, SSO without system changes
   */
  async authenticateWithStrategy(
    strategyName: string, 
    credentials: Credentials
  ): Promise<AuthResult> {
    const strategy = this.registry.get(strategyName);
    if (!strategy) {
      return { success: false, error: \`Strategy '\${strategyName}' not available\` };
    }
    
    const user = await strategy.authenticate(credentials);
    // ... rest of flow
    return { success: !!user, user };
  }
}

// ═══════════════════════════════════════════════════════════
// LAYER 5: FUTURE EXTENSION POINTS (Documented, Ready)
// ═══════════════════════════════════════════════════════════

/**
 * FUTURE: OAuth Strategy
 * UNCOMMENT AND IMPLEMENT WHEN NEEDED:
 * 
 * class OAuthStrategy implements AuthStrategy {
 *   private provider: OAuthProvider; // Google, GitHub, etc.
 *   
 *   async authenticate(credentials: OAuthCredentials): Promise<User | null> {
 *     // 1. Exchange code for token
 *     // 2. Fetch user info from provider
 *     // 3. Create/link local user
 *     // 4. Return authenticated user
 *   }
 *   
 *   getStrategyName(): string {
 *     return \`oauth-\${this.provider.name}\`;
 *   }
 * }
 */

/**
 * FUTURE: SAML Strategy for Enterprise SSO
 * UNCOMMENT AND IMPLEMENT WHEN NEEDED:
 * 
 * class SAMLStrategy implements AuthStrategy {
 *   private identityProvider: SAMLIdP;
 *   
 *   async authenticate(credentials: SAMLResponse): Promise<User | null> {
 *     // Enterprise SSO implementation
 *   }
 * }
 */

// ═══════════════════════════════════════════════════════════
// INITIALIZATION (The Asymmetric Setup)
// ═══════════════════════════════════════════════════════════

export function createAuthSystem(deps: AuthDependencies): AuthManager {
  const registry = new AuthStrategyRegistry();
  
  // Current: Just password auth
  // Future: registry.register('oauth-google', new OAuthStrategy(...))
  // Future: registry.register('saml-enterprise', new SAMLStrategy(...))
  registry.register('password', new PasswordAuthStrategy(deps));
  
  console.log('[STRATEGIST] Auth system initialized with strategies:', registry.list());
  console.log('[STRATEGIST] Extension points ready for: OAuth, SAML, Passwordless');
  
  return new AuthManager({ registry, sessions: deps.sessions });
}

// Export for testing and extension
export { AuthStrategy, AuthStrategyRegistry, AuthManager, PasswordAuthStrategy };
`;

    this.generatedCode.push({
      task: 'Build user authentication',
      approach: 'strategic_positioning',
      code: code,
      rationale: 'Positions for 3 future auth methods via Strategy pattern. Small cost now (interface + registry) = massive flexibility later.',
      positioning: 'Extension points ready for OAuth, SAML, Passwordless without core changes',
      timing: 'Ship minimal version now, extend when needed',
      leverage: 'Asymmetric: 50 lines of abstraction saves 500+ lines of rework'
    });

    return code;
  }

  /**
   * Generate code for "Choose Database"
   * STRATEGIST approach: Analyze 3-moves-ahead needs
   */
  generateDatabaseChoice(analysis) {
    const { currentNeeds, futureNeeds, constraints } = analysis;
    
    const recommendation = this.analyzeDatabaseStrategy(currentNeeds, futureNeeds);
    
    const code = `/**
 * Database Strategy
 * STRATEGIC ANALYSIS: Three moves ahead
 * 
 * Current Needs: ${currentNeeds.join(', ')}
 * Future Move 1: ${futureNeeds[0] || 'N/A'}
 * Future Move 2: ${futureNeeds[1] || 'N/A'}
 * Future Move 3: ${futureNeeds[2] || 'N/A'}
 * 
 * STRATEGIST RECOMMENDATION: ${recommendation.stack}
 * Rationale: ${recommendation.rationale}
 * Timing: ${recommendation.timing}
 */

// ═══════════════════════════════════════════════════════════
// PRIMARY DATASTORE: ${recommendation.primary}
// ═══════════════════════════════════════════════════════════

import { Pool } from 'pg'; // PostgreSQL

const primaryDB = new Pool({
  connectionString: process.env.DATABASE_URL,
  // STRATEGIC: Configure for future scaling
  max: 20,                    // Connection pool
  idleTimeoutMillis: 30000,   // Resource efficiency
  connectionTimeoutMillis: 2000,
});

// ═══════════════════════════════════════════════════════════
// SECONDARY STORE: ${recommendation.secondary || 'None needed yet'}
// ═══════════════════════════════════════════════════════════

${recommendation.secondary ? `
import Redis from 'ioredis';

const cacheLayer = new Redis(process.env.REDIS_URL);

/**
 * STRATEGIC POSITIONING: Redis enables:
 * - Pub/Sub for real-time features (Move 1)
 * - Session storage for distributed architecture (Move 2)
 * - Rate limiting and caching (Move 3)
 */
export { primaryDB, cacheLayer };
` : '// No secondary store needed at current scale'}

// ═══════════════════════════════════════════════════════════
// DATA ACCESS LAYER (Positioned for change)
// ═══════════════════════════════════════════════════════════

interface DataAccess<T> {
  findById(id: string): Promise<T | null>;
  findMany(query: Query): Promise<T[]>;
  create(data: Partial<T>): Promise<T>;
  update(id: string, data: Partial<T>): Promise<T>;
  delete(id: string): Promise<void>;
}

/**
 * STRATEGIC: Repository pattern enables:
 * - Easy migration if database changes
 * - Testing with mocks
 * - Caching layer insertion
 */
class PostgresRepository<T> implements DataAccess<T> {
  constructor(
    private table: string,
    private db: Pool
  ) {}
  
  async findById(id: string): Promise<T | null> {
    const result = await this.db.query(
      'SELECT * FROM \${this.table} WHERE id = \$1',
      [id]
    );
    return result.rows[0] || null;
  }
  
  // ... other CRUD operations
}

export { DataAccess, PostgresRepository, primaryDB };
`;

    this.generatedCode.push({
      task: 'Choose database',
      approach: 'strategic_analysis',
      code: code,
      recommendation: recommendation,
      rationale: recommendation.rationale,
      positioning: `Ready for: ${futureNeeds.join(', ')}`,
      timing: recommendation.timing,
      leverage: recommendation.leverage
    });

    return code;
  }

  /**
   * Analyze database strategy
   */
  analyzeDatabaseStrategy(current, future) {
    // STRATEGIST logic: Position for future while meeting current
    
    if (future.includes('real-time') && future.includes('geographic')) {
      return {
        stack: 'PostgreSQL + Redis',
        primary: 'PostgreSQL',
        secondary: 'Redis',
        rationale: 'Postgres handles current + complex queries. Redis positions for pub/sub (real-time), caching (geographic), and session distribution.',
        timing: 'Add Redis when real-time need appears, not before',
        leverage: '2 databases now vs. migration headache later'
      };
    }
    
    if (future.includes('analytics') || future.includes('ML')) {
      return {
        stack: 'PostgreSQL + ClickHouse (future)',
        primary: 'PostgreSQL',
        secondary: null,
        futureSecondary: 'ClickHouse',
        rationale: 'Postgres for transactional. ClickHouse for analytics when needed. Clean separation via repository pattern.',
        timing: 'Start with Postgres, add ClickHouse when analytics load justifies it',
        leverage: 'Repository pattern enables painless addition of analytical store'
      };
    }
    
    return {
      stack: 'PostgreSQL',
      primary: 'PostgreSQL',
      secondary: null,
      rationale: 'Meets current needs. Extension points ready via repository pattern when future needs emerge.',
      timing: 'Keep it simple until complexity is justified',
      leverage: 'Avoid premature optimization, but positioned for it'
    };
  }

  /**
   * Generate code for "Refactor Legacy Module"
   * STRATEGIST approach: Strategic extraction, not big bang
   */
  generateRefactoringStrategy(moduleName) {
    return `/**
 * Refactoring Strategy: ${moduleName}
 * STRATEGIC APPROACH: Gradual extraction, not big bang
 * 
 * STRATEGIST PRINCIPLE: Refactor when new feature touches old code
 * TIMING: Opportunistic, not systematic
 * POSITIONING: Extract interfaces first, implementations later
 */

// PHASE 1: IDENTIFY STRATEGIC EXTRACTION POINTS
// Extract interfaces at module boundaries first

// BEFORE (tangled):
// class ${moduleName} {
//   process(data) { /* 500 lines of mixed concerns */ }
// }

// AFTER (strategically positioned):

// ═══════════════════════════════════════════════════════════
// STEP 1: Extract Interface (The Strategic Door)
// ═══════════════════════════════════════════════════════════

interface ${moduleName}Processor {
  process(input: InputData): Promise<OutputData>;
  validate(data: unknown): ValidationResult;
}

// ═══════════════════════════════════════════════════════════
// STEP 2: Current Implementation (Behind Interface)
// ═══════════════════════════════════════════════════════════

class Legacy${moduleName}Processor implements ${moduleName}Processor {
  // Current messy implementation, but now behind interface
  // Can be refactored piece by piece
  
  async process(input: InputData): Promise<OutputData> {
    // TODO: Extract into smaller methods over time
    // TODO: Add tests before refactoring each section
    return this.legacyProcess(input);
  }
  
  private legacyProcess(input: InputData): Promise<OutputData> {
    // Existing implementation wrapped
    // Refactor this incrementally
  }
  
  validate(data: unknown): ValidationResult {
    // Validation logic
    return { valid: true };
  }
}

// ═══════════════════════════════════════════════════════════
// STEP 3: Future Refactored Version (When Needed)
// ═══════════════════════════════════════════════════════════

/**
 * FUTURE: Clean implementation
 * 
 * class Modern${moduleName}Processor implements ${moduleName}Processor {
 *   constructor(
 *     private validator: Validator,
 *     private transformer: Transformer,
 *     private repository: Repository
 *   ) {}
 *   
 *   async process(input: InputData): Promise<OutputData> {
 *     const validated = this.validator.validate(input);
 *     const transformed = this.transformer.transform(validated);
 *     return this.repository.save(transformed);
 *   }
 * }
 */

// ═══════════════════════════════════════════════════════════
// STEP 4: Factory (Enables Gradual Migration)
// ═══════════════════════════════════════════════════════════

class ${moduleName}ProcessorFactory {
  static create(useModern: boolean = false): ${moduleName}Processor {
    if (useModern) {
      // return new Modern${moduleName}Processor();
      throw new Error('Modern implementation not ready yet');
    }
    return new Legacy${moduleName}Processor();
  }
}

// Usage: Switch implementations without touching callers
const processor = ${moduleName}ProcessorFactory.create();
// Later: const processor = ${moduleName}ProcessorFactory.create(true);

export { ${moduleName}Processor, Legacy${moduleName}Processor, ${moduleName}ProcessorFactory };
`;
  }

  /**
   * Get all generated code examples
   */
  getGeneratedExamples() {
    return {
      authSystem: this.generateAuthSystem(),
      refactoring: this.generateRefactoringStrategy('PaymentProcessor'),
      examples: this.generatedCode
    };
  }
}

module.exports = StrategistCodeGenerator;

// CLI Demo
if (require.main === module) {
  console.log('🔮 STRATEGIST Code Generation Examples');
  console.log('');
  
  const generator = new StrategistCodeGenerator();
  const examples = generator.getGeneratedExamples();
  
  console.log('=== EXAMPLE 1: Authentication System ===');
  console.log(examples.authSystem.substring(0, 1500));
  console.log('... [truncated for display] ...');
  console.log('');
  console.log('Key Strategic Elements:');
  console.log('  ✓ Strategy pattern for future auth methods');
  console.log('  ✓ Registry pattern for dynamic registration');
  console.log('  ✓ Interface-first design');
  console.log('  ✓ Documented extension points');
  console.log('');
  
  console.log('=== Generated Code Summary ===');
  generator.generatedCode.forEach((gen, i) => {
    console.log('');
    console.log((i + 1) + '. ' + gen.task);
    console.log('   Approach: ' + gen.approach);
    console.log('   Positioning: ' + gen.positioning);
    console.log('   Leverage: ' + gen.leverage);
  });
}
