# 🚀 Quick Setup Guide

## Soul-Strategist v2.0.0 — Three Moves Ahead. Always.

---

## What You Get

**The Strategist v2.0.0** is a BUYaSOUL-Core v2.0.0 powered soul that embodies the STRATEGIST archetype from the PLT Doctrine. It generates code through strategic positioning and calculated timing, with v2.0.0 enhancements: Strategic Repository Analyzer, AI Trend Radar, MCTS Multi-turn Planning, Spice Loop, MCP Adapter, and Web Dashboard.

---

## ONE-CLICK SETUP

### Windows

**Option 1: PowerShell (Recommended)**
```powershell
# Right-click in the folder → "Open PowerShell window here"
.\setup.ps1
```

**Option 2: Double-click**
```
Double-click: setup.bat (if created)
Or double-click: activate.bat
```

### Mac/Linux

```bash
# Open terminal in this folder
chmod +x setup.sh
./setup.sh
```

---

## WHAT SETUP DOES

The soul **automatically**:

1. ✅ Checks Node.js version (18+ required)
2. ✅ BUYaSOUL-Core v2.0.0 is embedded — no deps needed
3. ✅ Runs verification tests (24 tests)
4. ✅ Creates `.env` configuration file
5. ✅ Creates activation scripts
6. ✅ Verifies everything works

**Takes ~30 seconds.**

---

## AFTER SETUP

### Activate the Strategist

**Windows:**
```powershell
.\activate-strategist.ps1
```

**Mac/Linux:**
```bash
./activate-strategist.sh
```

**Output:**
```
🔮 SOUL-STRATEGIST v2.0.0 ACTIVATED

Archetype: STRATEGIST
Kernel: BUYaSOUL-Core v2.0.0
Focus: PROFIT (Strategic Positioning)
Tagline: Three Moves Ahead. Always.

The Strategist v2.0.0 is ready to:
  • Make strategic decisions three moves ahead
  • Analyze GitHub repos for strategic patterns
  • Scan AI/tech trends for opportunities
  • Plan multi-turn MCTS lookahead
  • Serve MCP tools for Claude/Cursor/Cline
  • Visualize strategy via web dashboard
```

---

## USAGE EXAMPLES

### Example 1: Get Strategic Thinking

```bash
node -e "const s = new (require('./soul-strategist.cjs'))(); console.log(s.think('How to build our API?'));"
```

**Output:**
```javascript
{
  problem: 'How to build our API?',
  strategistPrompt: 'Where will this need to change?',
  approach: 'Analyze three moves ahead before acting',
  positioning: 'Consider where this positions you for future changes',
  timing: 'Evaluate if now is the optimal moment',
  leverage: 'Seek asymmetric payoff (small effort → large future gain)',
  shadowWarning: 'Watch for over-planning. Balance analysis with action.'
}
```

### Example 2: Make Strategic Decision

```javascript
const SoulStrategist = require('./soul-strategist.cjs');
const strategist = new SoulStrategist();

const decision = strategist.decide(
  'Build user authentication',
  [
    { type: 'create_extension_point', baseUtility: 0.8 },
    { type: 'quick_patch', baseUtility: 0.9 },
    { type: 'strategic_abstraction', baseUtility: 0.7 }
  ],
  { phase: 'architecture', deadline: '3_days' }
);

console.log(decision.choice);      // "create_extension_point"
console.log(decision.score);       // 1.52
console.log(decision.reasoning);   // "Strong strategic positioning..."
console.log(decision.alternatives); // Other options with scores
```

### Example 3: Generate Code

```javascript
const code = strategist.generate('auth_system');
// Returns fully documented code with:
// - Strategy pattern for future auth methods
// - Extension points for OAuth, SAML, Passwordless
// - Strategic positioning rationale
```

### v2.0.0 Example 4: Analyze a GitHub Repo

```bash
node -e "const s = new (require('./soul-strategist.cjs'))(); console.log(JSON.stringify(s.analyzeRepo('https://github.com/example/ai-tool'), null, 2));"
```

### v2.0.0 Example 5: Scan AI Trends

```bash
node -e "const s = new (require('./soul-strategist.cjs'))(); console.log(JSON.stringify(s.scanTrends({ category: 'ai-devtools', limit: 3 }), null, 2));"
```

### v2.0.0 Example 6: MCTS Multi-turn Planning

```bash
node -e "const s = new (require('./soul-strategist.cjs'))(); console.log(JSON.stringify(s.planMCTS('Build auth', [{name:'quick',utility:0.6,risk:0.3},{name:'strategic',utility:0.8,risk:0.2}], {depth:3,simulations:50}), null, 2));"
```

---

## v2.0.0 NEW SCRIPTS

```bash
npm run analyze    # Run repo analyzer demo
npm run trends     # Scan AI/tech trends
npm run mcts       # MCTS planning demo
npm run mcp        # Show MCP adapter tools
npm run dashboard  # Show dashboard config
```

---

## MANUAL SETUP (If Auto Fails)

```bash
# 1. Install Node.js 18+ from https://nodejs.org

# 2. BUYaSOUL-Core v2.0.0 is embedded — no npm install needed

# 3. Run tests
npm test

# 4. Use it
node soul-strategist.cjs
```

---

## WHAT'S INCLUDED

```
soul-strategist-v2.0.0/
├── buyasoul-core/                 ← BUYaSOUL-Core v2.0.0 (embedded)
├── soul-strategist.cjs          ← Main soul (BUYaSOUL-Core v2.0.0)
├── SOUL.md                       ← Soul definition & manifesto
├── personality/
│   ├── strategist-profile.cjs   ← 22 Archetype definition (v2.0.0)
│   ├── strategist-engine.cjs    ← Decision engine + Spice Loop
│   └── strategist-repo-analyzer.cjs  ← NEW: Repo analyzer
├── src/
│   ├── strategist-code-generator.cjs  ← Code generation
│   ├── strategist-trend-radar.cjs     ← NEW: Trend radar
│   ├── strategist-mcts-planner.cjs    ← NEW: MCTS planner
│   ├── strategist-mcp-adapter.cjs     ← NEW: MCP adapter
│   └── strategist-web-dashboard.cjs   ← NEW: Dashboard
├── test/
│   └── strategist-test.cjs      ← Test suite (24 tests)
├── setup.ps1                     ← Windows setup
├── setup.sh                      ← Mac/Linux setup
└── package.json
```

---

## TROUBLESHOOTING

**"Node.js not found"**
→ Install from https://nodejs.org (get LTS version)

**"npm install fails"**
→ Check internet connection
→ Try: `npm install --force`

**"Tests fail"**
→ Check Node.js version: `node -v` (need 18+)
→ Ensure BUYaSOUL-Core-v2.0.0 is in the `buyasoul-core/` folder

**"Permission denied" (Mac/Linux)**
→ Run: `chmod +x setup.sh activate-strategist.sh`

---

## NEXT STEPS

1. **Read:** `SOUL.md` — Understand the Strategist archetype
2. **Explore:** `personality/strategist-profile.cjs` — See the 22 archetype system
3. **Test:** `npm test` — Run the 24 verification tests
4. **Try v2.0.0 enhancements:**
   - `npm run analyze` — Test repo analyzer
   - `npm run trends` — Scan AI trends
   - `npm run mcts` — Multi-turn planning demo
5. **Build:** Use the Strategist in your projects

---

## ABOUT

**Author:** Craig Jones — Grand Code Pope  
**Framework:** PLT (Profit · Love · Tax)  
**Kernel:** BUYaSOUL-Core v2.0.0  
**Enhancements:** Repo Analyzer, Trend Radar, MCTS Planner, Spice Loop, MCP Adapter, Web Dashboard  
**Price:** $22 (part of BUYaSOUL ecosystem)  
**License:** DeepSeek v1.0 + MIT

---

**Part of the BUYaSOUL Ecosystem**  
*"While others build agents, we build souls."*
