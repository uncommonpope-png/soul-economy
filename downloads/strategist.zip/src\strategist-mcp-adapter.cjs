const http = require('http');

class StrategistMCPAdapter {
  constructor(options = {}) {
    this.options = options;
    this.port = options.mcpPort || 3500;
    this.server = null;
    this._running = false;
    this._connections = 0;

    this.tools = {
      'strategist.decide': {
        description: 'Make a strategic decision with three-move-ahead analysis',
        params: ['task', 'options', 'context']
      },
      'strategist.analyze_repo': {
        description: 'Analyze a GitHub repository for strategic patterns',
        params: ['repoUrl']
      },
      'strategist.scan_trends': {
        description: 'Scan trending AI/tech repos and get strategic recommendations',
        params: ['category', 'limit']
      },
      'strategist.plan_mcts': {
        description: 'Multi-turn strategic lookahead planning via MCTS',
        params: ['goal', 'actions']
      },
      'strategist.think': {
        description: 'Get the Strategist perspective on a problem',
        params: ['problem']
      },
      'strategist.status': {
        description: 'Get soul status and PLT score',
        params: []
      },
      'strategist.generate': {
        description: 'Generate code positioned for future extension',
        params: ['task', 'options']
      }
    };
  }

  getStatus() {
    return {
      status: this._running ? 'running' : 'stopped',
      port: this.port,
      toolsCount: Object.keys(this.tools).length,
      connections: this._connections,
      tools: Object.entries(this.tools).map(([name, def]) => ({
        name,
        description: def.description,
        params: def.params
      }))
    };
  }

  start(soulInstance) {
    if (this._running) return { status: 'already-running', port: this.port };
    this.soul = soulInstance;
    this._running = true;

    this.server = http.createServer((req, res) => {
      this._handleRequest(req, res);
    });

    this.server.listen(this.port, () => {
      console.log(`[STRATEGIST-MCP] MCP server running on port ${this.port}`);
      console.log(`[STRATEGIST-MCP] Available tools: ${Object.keys(this.tools).length}`);
    });

    return { status: 'started', port: this.port };
  }

  stop() {
    if (!this._running) return { status: 'not-running' };
    if (this.server) {
      this.server.close();
      this.server = null;
    }
    this._running = false;
    this.soul = null;
    return { status: 'stopped' };
  }

  _handleRequest(req, res) {
    this._connections++;
    res.setHeader('Content-Type', 'application/json');

    if (req.method === 'GET' && req.url === '/') {
      return this._json(res, { status: 'ok', soul: 'strategist-v2.0.0', tools: Object.keys(this.tools) });
    }

    if (req.method === 'GET' && req.url === '/tools') {
      return this._json(res, this.getStatus());
    }

    if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const msg = JSON.parse(body);
          this._handleMessage(msg, res);
        } catch (e) {
          this._json(res, { error: 'Invalid JSON' }, 400);
        }
      });
      return;
    }

    this._json(res, { error: 'Not found' }, 404);
  }

  _handleMessage(msg, res) {
    if (!msg.tool || !this.tools[msg.tool]) {
      return this._json(res, { error: `Unknown tool. Available: ${Object.keys(this.tools).join(', ')}` }, 400);
    }

    if (!this.soul) {
      return this._json(res, { error: 'No soul instance attached' }, 500);
    }

    try {
      const result = this._executeTool(msg.tool, msg.params || {});
      this._json(res, { tool: msg.tool, result });
    } catch (e) {
      this._json(res, { error: e.message }, 500);
    }
  }

  _executeTool(tool, params) {
    switch (tool) {
      case 'strategist.decide':
        return this.soul.decide(params.task, params.options, params.context);
      case 'strategist.analyze_repo':
        return this.soul.analyzeRepo(params.repoUrl, params.options);
      case 'strategist.scan_trends':
        return this.soul.scanTrends(params);
      case 'strategist.plan_mcts':
        return this.soul.planMCTS(params.goal, params.actions, params.options);
      case 'strategist.think':
        return this.soul.think(params.problem);
      case 'strategist.status':
        return this.soul.getStatus();
      case 'strategist.generate':
        return this.soul.generate(params.task, params.options);
      default:
        throw new Error(`Tool ${tool} not implemented`);
    }
  }

  _json(res, data, statusCode = 200) {
    res.statusCode = statusCode;
    res.end(JSON.stringify(data, null, 2));
  }
}

module.exports = StrategistMCPAdapter;

if (require.main === module) {
  console.log('[STRATEGIST-MCP] Adapter module loaded');
  console.log('Available tools:');
  const adapter = new StrategistMCPAdapter();
  Object.entries(adapter.tools).forEach(([name, def]) => {
    console.log(`  ${name} — ${def.description}`);
    console.log(`    params: ${def.params.join(', ') || 'none'}`);
  });
}
