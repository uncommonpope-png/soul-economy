class StrategistMCTSPlanner {
  constructor(options = {}) {
    this.options = options;
    this.planCache = new Map();
    this.simulationLog = [];
  }

  plan(goal, actions, options = {}) {
    const depth = options.depth || 3;
    const simulations = options.simulations || 100;
    const explorationConstant = options.explorationConstant || 1.41;

    const cacheKey = `${goal}-${depth}-${simulations}`;
    if (this.planCache.has(cacheKey)) {
      return this.planCache.get(cacheKey);
    }

    const tree = this._buildTree(goal, actions, depth, simulations, explorationConstant);

    const bestPath = this._extractBestPath(tree);
    const result = {
      goal,
      depth,
      simulations,
      bestPath,
      confidence: tree.bestScore,
      treeSize: tree.nodeCount,
      exploredPaths: tree.exploredPaths,
      leafEvaluations: tree.leafCount,
      simulationLog: this.simulationLog.slice(-10),
      alternatives: tree.alternatives.slice(0, 3),
      timing: this._assessTiming(bestPath, depth),
      riskAnalysis: this._analyzeRisk(tree)
    };

    this.planCache.set(cacheKey, result);
    return result;
  }

  _buildTree(goal, actions, depth, simulations, explorationConstant) {
    const root = {
      id: 'root',
      action: goal,
      visits: 0,
      value: 0,
      children: [],
      isLeaf: false
    };

    const exploredPaths = [];
    const alternatives = [];

    for (let sim = 0; sim < simulations; sim++) {
      let node = root;
      const path = [goal];

      for (let d = 0; d < depth; d++) {
        if (!node.children || node.children.length === 0) {
          node.children = actions.map(a => ({
            id: `${a.name}-${d}`,
            action: a.name,
            utility: a.utility || 0.5,
            risk: a.risk || 0.3,
            visits: 0,
            value: 0,
            children: [],
            isLeaf: d === depth - 1
          }));
        }

        const selected = this._selectChild(node.children, explorationConstant);
        selected.visits++;

        const rolloutValue = this._simulateRollout(selected, depth - d - 1);
        selected.value += rolloutValue;

        this.simulationLog.push({
          simulation: sim,
          depth: d,
          action: selected.action,
          rolloutValue: Math.round(rolloutValue * 100) / 100
        });

        path.push(selected.action);
        node = selected;
      }

      exploredPaths.push(path);
    }

    const rootChildren = root.children || [];
    const bestChild = rootChildren.reduce((best, c) =>
      (c.visits > 0 && c.value / c.visits > (best?.value / best?.visits || 0)) ? c : best,
      rootChildren[0]
    );

    const bestScore = bestChild ? Math.round((bestChild.value / bestChild.visits) * 100) / 100 : 0.5;

    const sorted = [...rootChildren].sort((a, b) => (b.value / b.visits) - (a.value / a.visits));
    sorted.slice(1, 4).forEach(c => {
      alternatives.push({
        action: c.action,
        score: Math.round((c.value / c.visits) * 100) / 100,
        visits: c.visits
      });
    });

    return {
      root,
      bestScore,
      nodeCount: this._countNodes(root),
      leafCount: rootChildren.filter(c => c.isLeaf).length,
      exploredPaths: exploredPaths.slice(0, 5),
      alternatives
    };
  }

  _selectChild(children, explorationConstant) {
    return children.reduce((best, child) => {
      if (child.visits === 0) return child;
      const exploitation = child.value / child.visits;
      const exploration = explorationConstant * Math.sqrt(Math.log(
        children.reduce((s, c) => s + c.visits, 0)
      ) / child.visits);
      const ucb = exploitation + exploration;
      return ucb > (best._ucb || -Infinity) ? { ...child, _ucb: ucb } : best;
    }, children[0]);
  }

  _simulateRollout(node, remainingDepth) {
    const baseValue = node.utility || 0.5;
    const riskPenalty = (node.risk || 0.3) * 0.5;
    const depthBonus = Math.max(0, 1 - remainingDepth * 0.15);
    const noise = (Math.random() - 0.5) * 0.2;
    return Math.max(0, Math.min(1, baseValue - riskPenalty + depthBonus + noise));
  }

  _extractBestPath(tree) {
    const path = [tree.root.action];
    let node = tree.root;
    while (node.children && node.children.length > 0) {
      const best = node.children.reduce((a, b) => {
        const aScore = a.visits > 0 ? a.value / a.visits : 0;
        const bScore = b.visits > 0 ? b.value / b.visits : 0;
        return aScore > bScore ? a : b;
      });
      path.push(best.action);
      node = best;
    }
    return path;
  }

  _countNodes(node) {
    let count = 1;
    if (node.children) {
      node.children.forEach(c => count += this._countNodes(c));
    }
    return count;
  }

  _assessTiming(path, depth) {
    const actionCount = path.length - 1;
    return {
      totalPhases: actionCount,
      estimatedDuration: `${actionCount * 2}-${actionCount * 5} days`,
      recommendation: actionCount > 3 ? 'parallelize-early-phases' : 'sequential-execution'
    };
  }

  _analyzeRisk(tree) {
    const highRiskCount = (tree.root.children || []).filter(c => (c.risk || 0) > 0.4).length;
    return {
      highRiskActions: highRiskCount,
      overallRisk: highRiskCount > 2 ? 'high' : highRiskCount > 1 ? 'medium' : 'low',
      mitigationSuggestion: highRiskCount > 0 ? 'Add contingency plans for high-risk phases' : 'Risk profile acceptable'
    };
  }
}

module.exports = StrategistMCTSPlanner;

if (require.main === module) {
  const planner = new StrategistMCTSPlanner();
  const result = planner.plan(
    'Deploy microservices architecture',
    [
      { name: 'extract-auth-service', utility: 0.8, risk: 0.2 },
      { name: 'add-api-gateway', utility: 0.9, risk: 0.3 },
      { name: 'migrate-database', utility: 0.6, risk: 0.6 },
      { name: 'setup-monitoring', utility: 0.7, risk: 0.1 }
    ],
    { depth: 4, simulations: 200 }
  );
  console.log(JSON.stringify(result, null, 2));
}
