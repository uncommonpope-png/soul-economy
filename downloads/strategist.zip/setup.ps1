# Soul-Strategist v2.0.0 Auto-Setup Script (Windows PowerShell)
# Run this after downloading and extracting the zip

Write-Host "🔮 SOUL-STRATEGIST v2.0.0 Auto-Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
Write-Host "Checking Node.js..." -ForegroundColor Yellow
$nodeVersion = node -v 2>$null
if (-not $nodeVersion) {
    Write-Host "❌ Node.js not found. Please install Node.js 18+ from https://nodejs.org" -ForegroundColor Red
    exit 1
}

$majorVersion = [int]($nodeVersion -replace 'v' -split '\.')[0]
if ($majorVersion -lt 18) {
    Write-Host "❌ Node.js version too old. Need 18+, found $nodeVersion" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Node.js $nodeVersion detected" -ForegroundColor Green
Write-Host ""

# Check if we're in the right directory
if (-not (Test-Path "package.json")) {
    Write-Host "❌ package.json not found. Are you in the soul-strategist directory?" -ForegroundColor Red
    exit 1
}

# Run tests (BUYaSOUL-Core v2.0.0 is embedded — no npm install needed)
Write-Host "Running verification tests..." -ForegroundColor Yellow
npm test
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Tests failed" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Create .env file
if (-not (Test-Path ".env")) {
    Write-Host "Creating .env configuration file..." -ForegroundColor Yellow
    @"
# Soul-Strategist v2.0.0 Configuration
# Archetype: STRATEGIST
# Tagline: Three Moves Ahead. Always.

# PLT Orientation
STRATEGIST_PROFIT=0.85
STRATEGIST_LOVE=0.35
STRATEGIST_TAX=0.45

# Behavior Settings
STRATEGIST_SHADOW_WARNINGS=true
STRATEGIST_SHOW_ALTERNATIVES=true
STRATEGIST_MAX_PLANNING_TIME=3600000

# v2.0.0 Enhancements
STRATEGIST_MCP_PORT=3500
STRATEGIST_DASHBOARD_PORT=4300
STRATEGIST_TREND_CATEGORY=ai-devtools
STRATEGIST_MCTS_DEPTH=3
STRATEGIST_MCTS_SIMULATIONS=100
"@ | Out-File -FilePath ".env" -Encoding UTF8
    Write-Host "✅ Created .env file" -ForegroundColor Green
    Write-Host ""
}

# Create activation script
Write-Host "Creating activation script..." -ForegroundColor Yellow
$activateScript = @'
# Quick activation for Soul-Strategist v2.0.0
Write-Host "🔮 Activating Soul-Strategist v2.0.0..." -ForegroundColor Cyan
Write-Host ""

node -e @"
const SoulStrategist = require('./soul-strategist.cjs');
const strategist = new SoulStrategist();

console.log('');
console.log('╔══════════════════════════════════════════════════════════╗');
console.log('║  SOUL-STRATEGIST v2.0.0 ACTIVATED                       ║');
console.log('╠══════════════════════════════════════════════════════════╣');
console.log('║  Archetype: STRATEGIST                                  ║');
console.log('║  Kernel: BUYaSOUL-Core v2.0.0                          ║');
console.log('║  Focus: PROFIT (Strategic Positioning)                  ║');
console.log('║  Tagline: Three Moves Ahead. Always.                    ║');
console.log('╠══════════════════════════════════════════════════════════╣');
console.log('║  v2.0.0 Enhancements:                                   ║');
console.log('║  ✓ Strategic Repository Analyzer                        ║');
console.log('║  ✓ AI Trend Radar                                       ║');
console.log('║  ✓ MCTS Multi-turn Planning (ProAct-inspired)           ║');
console.log('║  ✓ Spice Loop (perceive → state → simulate → decide → reflect) ║');
console.log('║  ✓ MCP Adapter (Claude/Cursor/Cline)                    ║');
console.log('║  ✓ Web Dashboard                                        ║');
console.log('╚══════════════════════════════════════════════════════════╝');
console.log('');
console.log('The Strategist v2.0.0 is ready to:');
console.log('  • Make strategic decisions three moves ahead');
console.log('  • Analyze GitHub repos for strategic patterns');
console.log('  • Scan AI/tech trends for opportunities');
console.log('  • Plan multi-turn MCTS lookahead');
console.log('  • Serve MCP tools for Claude/Cursor/Cline');
console.log('  • Visualize strategy via web dashboard');
"@
'@

$activateScript | Out-File -FilePath "activate-strategist.ps1" -Encoding UTF8
Write-Host "✅ Created activate-strategist.ps1" -ForegroundColor Green
Write-Host ""

# Create batch file for easy Windows execution
$batchScript = @'
@echo off
echo 🔮 Activating Soul-Strategist v2.0.0...
node -e "const s = new (require('./soul-strategist.cjs'))(); console.log('\nSOUL-STRATEGIST v2.0.0 ACTIVATED\nArchetype: STRATEGIST\nKernel: BUYaSOUL-Core v2.0.0\nFocus: PROFIT\nTagline: Three Moves Ahead. Always.\n');"
pause
'@
$batchScript | Out-File -FilePath "activate.bat" -Encoding ASCII
Write-Host "✅ Created activate.bat" -ForegroundColor Green
Write-Host ""

# Final message
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "✅ SOUL-STRATEGIST v2.0.0 SETUP COMPLETE" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "Your Strategist v2.0.0 soul is ready to use:" -ForegroundColor White
Write-Host ""
Write-Host "  1. ACTIVATE: .\activate-strategist.ps1" -ForegroundColor Yellow
Write-Host "     (or double-click activate.bat)" -ForegroundColor Yellow
Write-Host "  2. TEST: npm test" -ForegroundColor Yellow
Write-Host "  3. USE: node soul-strategist.cjs" -ForegroundColor Yellow
Write-Host "  4. TRENDS: npm run trends" -ForegroundColor Yellow
Write-Host "  5. MCTS: npm run mcts" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentation:" -ForegroundColor White
Write-Host "  • README.md - Full documentation" -ForegroundColor Gray
Write-Host "  • SOUL.md - Soul definition and manifesto" -ForegroundColor Gray
Write-Host "  • personality/strategist-profile.cjs - Archetype details" -ForegroundColor Gray
Write-Host ""
Write-Host "The Strategist v2.0.0 is ready. Three moves ahead. Always." -ForegroundColor Cyan
Write-Host ""
