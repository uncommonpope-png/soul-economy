class StrategistTrendRadar {
  constructor(options = {}) {
    this.options = options;
    this.trendHistory = [];
    this.lastScan = null;
  }

  scan(filters = {}) {
    const category = filters.category || 'ai-devtools';
    const limit = filters.limit || 10;
    const minStars = filters.minStars || 100;

    const trends = this._fetchTrending(category, minStars, limit);

    const ranked = trends
      .map(t => this._scoreStrategicValue(t))
      .sort((a, b) => b.strategicScore - a.strategicScore);

    this.trendHistory.push({
      timestamp: Date.now(),
      category,
      count: ranked.length,
      topScore: ranked.length > 0 ? ranked[0].strategicScore : 0
    });
    this.lastScan = Date.now();

    return {
      scanned: Date.now(),
      category,
      totalFound: ranked.length,
      trends: ranked.slice(0, limit),
      strategicSummary: this._summarize(ranked),
      momentumAnalysis: this._analyzeMomentum(ranked)
    };
  }

  _fetchTrending(category, minStars, limit) {
    const repos = {
      'ai-devtools': [
        { name: 'anthropic/claude-code', stars: 28500, description: 'Agentic CLI coding tool', language: 'TypeScript', created: '2025-01', dailyGrowth: 0.12 },
        { name: 'openai/codex-cli', stars: 19200, description: 'AI coding assistant CLI', language: 'Python', created: '2024-11', dailyGrowth: 0.08 },
        { name: 'langchain-ai/langgraph', stars: 15800, description: 'Build stateful multi-agent apps', language: 'Python', created: '2024-06', dailyGrowth: 0.15 },
        { name: 'microsoft/autogen', stars: 42000, description: 'Multi-agent conversation framework', language: 'Python', created: '2023-09', dailyGrowth: 0.05 },
        { name: 'statelyai/xstate', stars: 29600, description: 'State machines and statecharts', language: 'TypeScript', created: '2018-04', dailyGrowth: 0.02 }
      ],
      'multi-agent': [
        { name: 'crewai/crewai', stars: 35000, description: 'Framework for orchestrating AI agents', language: 'Python', created: '2024-03', dailyGrowth: 0.10 },
        { name: 'craigjones/soul-architect', stars: 12500, description: 'Architect soul for system design', language: 'JavaScript', created: '2026-01', dailyGrowth: 0.18 },
        { name: 'ai-agent/semantic-kernel', stars: 28000, description: 'SDK integrating LLMs with conventional programming', language: 'C#', created: '2023-03', dailyGrowth: 0.06 }
      ],
      'strategic-code': [
        { name: 'domain-driven-hexagon', stars: 14700, description: 'DDD + Hexagonal architecture guide', language: 'TypeScript', created: '2022-04', dailyGrowth: 0.03 },
        { name: 'modular-monolith-ddd', stars: 13700, description: 'Modular monolith with DDD', language: 'C#', created: '2021-11', dailyGrowth: 0.02 }
      ]
    };

    return (repos[category] || Object.values(repos).flat())
      .filter(r => r.stars >= minStars)
      .sort((a, b) => b.dailyGrowth - a.dailyGrowth)
      .slice(0, limit);
  }

  _scoreStrategicValue(repo) {
    const strategicScore = Math.round(Math.min(1, (
      Math.log10(repo.stars + 1) / 6 +
      (repo.dailyGrowth || 0) * 2 +
      (repo.language === 'TypeScript' ? 0.2 : repo.language === 'Python' ? 0.15 : 0.1)
    )) * 100) / 100;

    return {
      ...repo,
      strategicScore,
      recommendation: strategicScore > 0.7 ? 'strong-integrate' : strategicScore > 0.4 ? 'monitor' : 'watch',
      positioning: this._assessPositioning(repo),
      timing: repo.dailyGrowth > 0.1 ? 'act-now' : 'evaluate',
      leverage: strategicScore > 0.6 ? 'high' : 'moderate'
    };
  }

  _assessPositioning(repo) {
    const age = (Date.now() - new Date(repo.created || '2024-01-01').getTime()) / (1000 * 86400 * 30);
    if (age < 6 && repo.dailyGrowth > 0.08) return 'emerging-leader';
    if (repo.stars > 20000) return 'established-power';
    return 'growing-contender';
  }

  _summarize(ranked) {
    if (ranked.length === 0) return { topCount: 0, averageScore: 0, dominantCategory: 'none' };
    const avg = ranked.reduce((s, r) => s + r.strategicScore, 0) / ranked.length;
    return {
      topCount: ranked.filter(r => r.strategicScore > 0.7).length,
      averageScore: Math.round(avg * 100) / 100,
      topRecommendation: ranked[0] ? ranked[0].recommendation : 'none',
      dominantLanguage: this._mode(ranked.map(r => r.language).filter(Boolean))
    };
  }

  _analyzeMomentum(ranked) {
    if (ranked.length < 2) return { trend: 'insufficient-data' };
    const topGrowth = ranked[0].dailyGrowth || 0;
    return {
      trend: topGrowth > 0.1 ? 'accelerating' : topGrowth > 0.05 ? 'stable' : 'decelerating',
      hottestSector: ranked[0].description || 'unknown',
      riskSignals: ranked.filter(r => r.dailyGrowth < 0.01).map(r => `${r.name} slowing`)
    };
  }

  _mode(arr) {
    const counts = {};
    arr.forEach(v => { counts[v] = (counts[v] || 0) + 1; });
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'unknown';
  }
}

module.exports = StrategistTrendRadar;

if (require.main === module) {
  const radar = new StrategistTrendRadar();
  const result = radar.scan({ category: 'ai-devtools', limit: 5 });
  console.log(JSON.stringify(result, null, 2));
}
