const http = require('http');
const assert = require('assert');
const { setGoal, executeAction, refuseToQuit, abandonGoal, recoverWillpower, state, API_KEY } = require('../lib/soul-WILL');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try {
    fn();
    testsPassed++;
    console.log(`  \u2713 ${name}`);
  } catch (e) {
    console.log(`  \u2717 ${name}: ${e.message}`);
  }
}

function resetState() {
  state.active_goal = null;
  state.will_strength = 0.5;
  state.willpower = 1.0;
  state.decision_fatigue = 0;
  state.refusal_count = 0;
  state.executed_actions = [];
  state.plans_made = [];
  state.recoveries = 0;
  state.goal_hierarchy = { daily: [], weekly: [], lifetime: [] };
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: 'localhost', port: 4260, path, method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  WILL Chamber Tests\n');

// Unit tests
test('setGoal establishes a goal and increases will_strength', () => {
  resetState();
  const result = setGoal('Write a book');
  assert.strictEqual(result.goal, 'Write a book');
  assert.strictEqual(state.active_goal, 'Write a book');
  assert(result.will_strength > 0.5);
});

test('executeAction requires an active goal', () => {
  resetState();
  const result = executeAction('Do something');
  assert(result.error);
  assert(result.error.includes('No active goal'));
});

test('executeAction reduces willpower and increases decision_fatigue', () => {
  resetState();
  setGoal('Learn piano');
  const before = state.willpower;
  const fatigueBefore = state.decision_fatigue;
  executeAction('Practice scales');
  assert(state.willpower < before);
  assert(state.decision_fatigue > fatigueBefore);
  assert.strictEqual(state.executed_actions.length, 1);
});

test('refuseToQuit increases refusal_count and willpower', () => {
  resetState();
  state.willpower = 0.5;
  const before = state.willpower;
  refuseToQuit();
  assert.strictEqual(state.refusal_count, 1);
  assert(state.willpower > before);
});

test('refuseToQuit recovers will_strength', () => {
  resetState();
  state.will_strength = 0.2;
  const result = refuseToQuit();
  assert(result.will_strength > 0.2);
});

test('abandonGoal clears active_goal and reduces will_strength', () => {
  resetState();
  setGoal('Build a startup');
  const strengthBefore = state.will_strength;
  abandonGoal();
  assert.strictEqual(state.active_goal, null);
  assert(state.will_strength < strengthBefore);
});

test('abandonGoal returns error when no active goal', () => {
  resetState();
  const result = abandonGoal();
  assert(result.error);
});

test('recoverWillpower restores willpower', () => {
  resetState();
  state.willpower = 0.5;
  const result = recoverWillpower(0.3);
  assert.strictEqual(result.willpower, 0.8);
});

test('recoverWillpower reduces decision_fatigue', () => {
  resetState();
  state.decision_fatigue = 0.5;
  recoverWillpower(0.4);
  assert(state.decision_fatigue < 0.5);
});

test('setGoal adds to lifetime goal hierarchy', () => {
  resetState();
  setGoal('Run a marathon');
  assert.strictEqual(state.goal_hierarchy.lifetime.length, 1);
});

// HTTP tests
test('GET /ping returns 200 without auth', async () => {
  const res = await httpRequest('GET', '/ping');
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.ping, 'pong');
});

test('GET /health returns 200 without auth', async () => {
  const res = await httpRequest('GET', '/health');
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.status, 'ok');
});

test('GET /state returns 401 without auth', async () => {
  const res = await httpRequest('GET', '/state');
  assert.strictEqual(res.status, 401);
});

test('GET /state returns state with valid auth', async () => {
  const res = await httpRequest('GET', '/state', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.will_strength !== undefined);
});

test('POST /goal requires auth', async () => {
  const res = await httpRequest('POST', '/goal', { goal: 'test' });
  assert.strictEqual(res.status, 401);
});

test('POST /goal sets goal via HTTP', async () => {
  resetState();
  const res = await httpRequest('POST', '/goal', { goal: 'Ship product' }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.goal, 'Ship product');
});

test('POST /act with valid auth executes action', async () => {
  resetState();
  await httpRequest('POST', '/goal', { goal: 'Test goal' }, API_KEY);
  const res = await httpRequest('POST', '/act', { description: 'Write code' }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.action);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
