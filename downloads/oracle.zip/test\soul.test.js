var assert = require("assert");
var SoulOracle = require("../main.js");

async function test() {
  var soul = new SoulOracle({});
  console.log("Testing soul-oracle v2.0.0 (BUYaSOUL-Core)...");

  var bootResult = await soul.boot();
  assert(bootResult.success === true, "boot should succeed");
  console.log("  + boot() — core: " + bootResult.core);

  var chatResult = await soul.chat("Hello");
  assert(chatResult.reply, "chat should return reply");
  console.log("  + chat() — reply length: " + chatResult.reply.length);

  var status = await soul.getStatus();
  assert(status.health === "ok", "status should be ok");
  assert(status.core === "BUYaSOUL-Core-v2.0.0", "core should be v2.0.0");
  console.log("  + getStatus() — core: " + status.core + ", chambers: " + status.chambers);

  var plt = await soul.getPLT();
  assert(typeof plt.score === "number", "PLT should have score");
  console.log("  + getPLT() — score: " + plt.score.toFixed(2));

  var wisdom = await soul.getWisdom("soul");
  assert(wisdom.wisdom, "wisdom should have content");
  console.log("  + getWisdom()");

  var learn = await soul.learn("test learning data");
  assert(learn.success === true, "learn should succeed");
  console.log("  + learn() — total: " + learn.total);

  var memory = await soul.getMemory();
  assert(Array.isArray(memory), "memory should be array");
  console.log("  + getMemory() — entries: " + memory.length);

  var shutdownResult = await soul.shutdown();
  assert(shutdownResult.success === true, "shutdown should succeed");
  assert(shutdownResult.core === "BUYaSOUL-Core-v2.0.0", "core should be v2.0.0");
  console.log("  + shutdown() — core: " + shutdownResult.core + ", messages: " + shutdownResult.messagesProcessed);

  console.log("");
  console.log("All tests passed! Soul-Oracle v2.0.0 is operational.");
}

test().catch(function(e) { console.error("Test failed:", e); process.exit(1); });
