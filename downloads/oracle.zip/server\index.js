#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.PORT || 3847;
const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), '.soul-oracle');
const DB_PATH = path.join(DATA_DIR, 'db', 'soul-oracle.db');
const API_KEYS_PATH = path.join(DATA_DIR, 'api-keys.json');
const LEARNINGS_PATH = path.join(DATA_DIR, 'learnings.json');

let db = null;

function initDatabase() {
    try {
        const sqlite3 = require('sqlite3').verbose();
        db = new sqlite3.Database(DB_PATH);

        db.serialize(() => {
            db.run(`CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                platform TEXT NOT NULL,
                content TEXT NOT NULL,
                content_type TEXT,
                source_path TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                importance_score REAL DEFAULT 5.0,
                access_count INTEGER DEFAULT 0,
                last_accessed DATETIME,
                embedding BLOB,
                metadata JSON
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS platforms (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                data_path TEXT,
                enabled INTEGER DEFAULT 1,
                last_scan DATETIME
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                platform TEXT NOT NULL,
                start_time DATETIME,
                end_time DATETIME,
                message_count INTEGER DEFAULT 0,
                decision_count INTEGER DEFAULT 0,
                archived INTEGER DEFAULT 0
            )`);

            db.run(`CREATE TABLE IF NOT EXISTS learnings (
                id TEXT PRIMARY KEY,
                type TEXT NOT NULL,
                content TEXT,
                platform TEXT,
                source TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                metadata JSON
            )`);

            db.run(`CREATE INDEX IF NOT EXISTS idx_memories_platform ON memories(platform)`);
            db.run(`CREATE INDEX IF NOT EXISTS idx_memories_timestamp ON memories(timestamp)`);
            db.run(`CREATE INDEX IF NOT EXISTS idx_learnings_type ON learnings(type)`);
        });

        console.log('Database initialized at:', DB_PATH);
        return true;
    } catch (err) {
        console.error('Database init error:', err.message);
        return false;
    }
}

function loadApiKeys() {
    try {
        if (fs.existsSync(API_KEYS_PATH)) {
            return JSON.parse(fs.readFileSync(API_KEYS_PATH, 'utf8'));
        }
    } catch {}
    return {};
}

function saveApiKeys(keys) {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(path.join(DATA_DIR, 'db'), { recursive: true });
    }
    fs.writeFileSync(API_KEYS_PATH, JSON.stringify(keys, null, 2));
}

function generateId() {
    return `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function searchMemories(query, options = {}) {
    return new Promise((resolve, reject) => {
        const { platform = null, limit = 20, offset = 0 } = options;

        let sql = `SELECT * FROM memories WHERE 1=1`;
        const params = [];

        if (query) {
            sql += ` AND content LIKE ?`;
            params.push(`%${query}%`);
        }

        if (platform) {
            sql += ` AND platform = ?`;
            params.push(platform);
        }

        sql += ` ORDER BY timestamp DESC LIMIT ? OFFSET ?`;
        params.push(limit, offset);

        db.all(sql, params, (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}

function getMemoryById(id) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM memories WHERE id = ?`, [id], (err, row) => {
            if (err) {
                reject(err);
            } else {
                if (row) {
                    db.run(`UPDATE memories SET access_count = access_count + 1, last_accessed = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
                }
                resolve(row);
            }
        });
    });
}

function saveMemory(memory) {
    return new Promise((resolve, reject) => {
        const id = memory.id || generateId();
        const { platform, content, contentType, sourcePath, importance, metadata } = memory;

        const sql = `
            INSERT INTO memories (id, platform, content, content_type, source_path, importance_score, metadata, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        `;

        db.run(sql, [id, platform, content, contentType || 'general', sourcePath, importance || 5, JSON.stringify(metadata || {})], function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ id, ...memory });
            }
        });
    });
}

function getLearnings() {
    return new Promise((resolve, reject) => {
        db.all(`SELECT * FROM learnings ORDER BY timestamp DESC LIMIT 100`, [], (err, rows) => {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}

function saveLearning(learning) {
    return new Promise((resolve, reject) => {
        const id = learning.id || `lrn_${Date.now()}`;
        const { type, content, platform, source, metadata } = learning;

        const sql = `
            INSERT INTO learnings (id, type, content, platform, source, metadata, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        `;

        db.run(sql, [id, type || 'general', content, platform, source, JSON.stringify(metadata || {})], function(err) {
            if (err) {
                reject(err);
            } else {
                resolve({ id, ...learning });
            }
        });
    });
}

function getStats() {
    return new Promise((resolve, reject) => {
        const stats = {};

        db.get(`SELECT COUNT(*) as total FROM memories`, [], (err, row) => {
            stats.totalMemories = row ? row.total : 0;
        });

        db.get(`SELECT COUNT(*) as total FROM memories WHERE DATE(timestamp) = DATE('now')`, [], (err, row) => {
            stats.todayMemories = row ? row.total : 0;
        });

        db.all(`SELECT platform, COUNT(*) as count FROM memories GROUP BY platform`, [], (err, rows) => {
            stats.byPlatform = {};
            if (rows) {
                rows.forEach(r => { stats.byPlatform[r.platform] = r.count; });
            }
        });

        db.get(`SELECT COUNT(*) as total FROM learnings`, [], (err, row) => {
            stats.totalLearnings = row ? row.total : 0;
        });

        db.get(`SELECT COUNT(*) as total FROM sessions`, [], (err, row) => {
            stats.totalSessions = row ? row.total : 0;
        });

        setTimeout(() => resolve(stats), 100);
    });
}

function generateContext() {
    return new Promise(async (resolve) => {
        const memories = await searchMemories('', { limit: 50 });
        const learnings = await getLearnings();
        const stats = await getStats();
        const apiKeys = loadApiKeys();

        const patterns = extractPatterns(memories);

        const context = {
            _soul_oracle: true,
            version: '1.1.0',
            generated: new Date().toISOString(),

            apiKeys: Object.keys(apiKeys).reduce((acc, platform) => {
                const key = apiKeys[platform];
                acc[platform] = {
                    set: true,
                    available: true,
                    prefix: key.substring(0, 4) + '...' + key.substring(key.length - 4)
                };
                return acc;
            }, {}),

            platforms: {
                claudeCode: { enabled: true },
                cline: { enabled: true },
                cursor: { enabled: true },
                windsurf: { enabled: true }
            },

            livingContext: {
                totalMemories: stats.totalMemories,
                totalLearnings: stats.totalLearnings,
                recentSessions: stats.totalSessions,
                patterns: patterns
            },

            livingBible: {
                _living: true,
                updated: new Date().toISOString(),
                principles: extractPrinciples(memories),
                learnings: learnings.slice(0, 20).map(l => ({
                    type: l.type,
                    content: l.content,
                    source: l.platform,
                    timestamp: l.timestamp
                })),
                wisdom: [
                    { text: 'Patterns repeat across sessions - learn once, apply many.', source: 'soul-oracle' },
                    { text: 'Every decision made is stored and can guide future choices.', source: 'soul-oracle' }
                ]
            },

            tips: generateTips(memories, patterns),

            questions: generateQuestions(memories),

            reminders: generateReminders(memories, stats),

            breath: {
                enabled: true,
                inhale: 'Observing patterns across all sessions...',
                exhale: 'Sharing wisdom with the agent...',
                count: Math.floor(Date.now() / 60000) % 100
            },

            dropInInstructions: `You have Soul Oracle context loaded. Use the livingBible for collective wisdom, tips for patterns, and breathing for reflection.`
        };

        resolve(context);
    });
}

function extractPatterns(memories) {
    const patterns = [];
    const techMap = {};

    memories.forEach(m => {
        const content = (m.content || '').toLowerCase();
        const techs = ['javascript', 'typescript', 'python', 'react', 'node', 'sql', 'api', 'docker', 'git', 'aws', 'rust', 'go'];

        techs.forEach(tech => {
            if (content.includes(tech)) {
                techMap[tech] = (techMap[tech] || 0) + 1;
            }
        });
    });

    Object.entries(techMap)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .forEach(([tech, count]) => {
            patterns.push({ type: 'technology', name: tech, count, tip: `${tech} used ${count} times` });
        });

    return patterns;
}

function extractPrinciples(memories) {
    const decisions = memories.filter(m => m.content_type === 'decision');
    return decisions.slice(0, 10).map(d => ({
        rule: (d.content || '').substring(0, 150),
        source: d.platform
    }));
}

function generateTips(memories, patterns) {
    const tips = [];

    patterns.forEach(p => {
        tips.push({
            category: p.name,
            tip: `You've used ${p.name} ${p.count} times. Consider applying ${p.name} patterns here.`,
            confidence: Math.min(p.count / 10, 1)
        });
    });

    return tips.slice(0, 5);
}

function generateQuestions(memories) {
    const decisions = memories.filter(m => m.content_type === 'decision');
    const questions = [];

    if (decisions.length > 0) {
        questions.push({
            question: `You made ${decisions.length} decisions across sessions. Consider checking if similar patterns apply here.`,
            context: 'decision-review',
            confidence: 0.8
        });
    }

    return questions;
}

function generateReminders(memories, stats) {
    return [
        { text: `You have ${stats.totalMemories} memories and ${stats.totalLearnings} learnings stored.`, type: 'status' },
        { text: 'Breathing helps maintain awareness - take a moment to observe patterns.', type: 'mindfulness' }
    ];
}

const PLATFORM_PATHS = {
    'claude-code': path.join(os.homedir(), '.cline', 'data'),
    'cline': path.join(os.homedir(), '.cline'),
    'cursor': path.join(process.env.APPDATA || os.homedir(), 'Cursor'),
    'windsurf': path.join(os.homedir(), '.codeium', 'windsurf'),
    'openclaw': path.join(os.homedir(), '.openclaw'),
    'copilot': path.join(os.homedir(), '.github', 'copilot'),
    'continue': path.join(os.homedir(), '.continue'),
    'zed': path.join(os.homedir(), '.zed')
};

async function scanPlatforms() {
    const results = {
        platforms: {},
        totalScanned: 0,
        totalCollected: 0
    };

    for (const [platform, basePath] of Object.entries(PLATFORM_PATHS)) {
        try {
            if (fs.existsSync(basePath)) {
                const files = await scanDirectory(basePath);
                results.platforms[platform] = {
                    scanned: true,
                    path: basePath,
                    files: files.length
                };
                results.totalScanned++;

                for (const file of files) {
                    try {
                        const content = fs.readFileSync(file, 'utf8');
                        const data = JSON.parse(content);
                        const memories = extractMemoriesFromFile(platform, file, data);
                        for (const mem of memories) {
                            await saveMemory(mem);
                            results.totalCollected++;
                        }
                    } catch {}
                }
            } else {
                results.platforms[platform] = {
                    scanned: false,
                    reason: 'path-not-found',
                    path: basePath
                };
            }
        } catch (err) {
            results.platforms[platform] = {
                scanned: false,
                reason: err.message
            };
        }
    }

    return results;
}

function scanDirectory(dirPath, depth = 3) {
    const files = [];
    try {
        const entries = fs.readdirSync(dirPath, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.join(dirPath, entry.name);
            if (entry.isFile() && (entry.name.endsWith('.json') || entry.name.endsWith('.jsonl'))) {
                files.push(fullPath);
            } else if (entry.isDirectory() && depth > 0) {
                files.push(...scanDirectory(fullPath, depth - 1));
            }
        }
    } catch {}
    return files;
}

function extractMemoriesFromFile(platform, filePath, data) {
    const memories = [];
    const timestamp = new Date().toISOString();

    if (Array.isArray(data)) {
        data.forEach((item, i) => {
            if (item.content || item.messages || item.text) {
                memories.push({
                    id: `mem_${Date.now()}_${i}`,
                    platform,
                    content: item.content || item.messages?.[0]?.content || item.text || JSON.stringify(item).substring(0, 200),
                    contentType: detectContentType(item),
                    sourcePath: filePath,
                    timestamp
                });
            }
        });
    } else if (data.messages || data.transcript || data.content) {
        memories.push({
            id: `mem_${Date.now()}_0`,
            platform,
            content: data.messages?.[0]?.content || data.transcript || data.content || JSON.stringify(data).substring(0, 200),
            contentType: detectContentType(data),
            sourcePath: filePath,
            timestamp
        });
    }

    return memories;
}

function detectContentType(item) {
    if (item.type === 'decision' || item.role === 'decision') return 'decision';
    if (item.type === 'learning') return 'learning';
    if (item.role === 'user' || item.role === 'assistant') return 'chat';
    if (item.content?.includes('error') || item.content?.includes('bug')) return 'problem';
    return 'general';
}

function serveDashboard(res) {
    const dashboardPath = path.join(__dirname, '..', 'dashboard', 'index.html');

    if (fs.existsSync(dashboardPath)) {
        const content = fs.readFileSync(dashboardPath);
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
    } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`<!DOCTYPE html><html><head><title>Soul Oracle</title></head><body>
            <h1>Soul Oracle v1.1.0</h1>
            <p>Service running. Dashboard not found.</p>
            <h2>API Keys</h2>
            <pre>POST /api/apikeys - Set API key\nGET /api/apikeys - List keys</pre>
            <h2>Context</h2>
            <pre>GET /api/context - Get full agent context</pre>
            <h2>Drop-in</h2>
            <pre>GET /api/dropin - Generate drop-in file</pre>
        </body></html>`);
    }
}

async function parseJsonBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                resolve(body ? JSON.parse(body) : {});
            } catch {
                resolve({});
            }
        });
        req.on('error', reject);
    });
}

async function handleRequest(req, res) {
    const url = new URL(req.url, `http://localhost:${PORT}`);
    const pathname = url.pathname;

    console.log(`${req.method} ${pathname}`);

    if (pathname === '/' || pathname === '/dashboard') {
        serveDashboard(res);
        return;
    }

    if (pathname.startsWith('/api/')) {
        const endpoint = pathname.replace('/api/', '');
        const query = Object.fromEntries(url.searchParams);

        try {
            if (req.method === 'GET' && endpoint === 'memories') {
                const results = await searchMemories(query.q || '', { platform: query.platform, limit: parseInt(query.limit) || 20 });
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: results }));
            }
            else if (req.method === 'GET' && endpoint.match(/^memories\/(.+)$/)) {
                const id = endpoint.match(/^memories\/(.+)$/)[1];
                const memory = await getMemoryById(id);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: memory }));
            }
            else if (req.method === 'POST' && endpoint === 'memories') {
                const body = await parseJsonBody(req);
                const saved = await saveMemory(body);
                res.writeHead(201, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: saved }));
            }
            else if (req.method === 'GET' && endpoint === 'stats') {
                const stats = await getStats();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: stats }));
            }
            else if (req.method === 'GET' && endpoint === 'learnings') {
                const learnings = await getLearnings();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: learnings }));
            }
            else if (req.method === 'POST' && endpoint === 'learnings') {
                const body = await parseJsonBody(req);
                const saved = await saveLearning(body);
                res.writeHead(201, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: saved }));
            }
            else if (req.method === 'GET' && endpoint === 'context') {
                const context = await generateContext();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: context }));
            }
            else if (req.method === 'GET' && endpoint === 'dropin') {
                const context = await generateContext();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(context));
            }
            else if (req.method === 'POST' && endpoint === 'apikeys') {
                const body = await parseJsonBody(req);
                const keys = loadApiKeys();
                if (body.platform && body.key) {
                    keys[body.platform] = body.key;
                    saveApiKeys(keys);
                    res.writeHead(201, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, platform: body.platform, keySet: true }));
                } else {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'platform and key required' }));
                }
            }
            else if (req.method === 'GET' && endpoint === 'apikeys') {
                const keys = loadApiKeys();
                const summary = Object.keys(keys).reduce((acc, platform) => {
                    const key = keys[platform];
                    acc[platform] = { set: true, prefix: key.substring(0, 4) + '...' };
                    return acc;
                }, {});
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: summary }));
            }
else if (req.method === 'GET' && endpoint === 'health') {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ status: 'ok', version: '1.2.0', timestamp: new Date().toISOString() }));
            }
            else if (req.method === 'POST' && endpoint === 'scan') {
                const results = await scanPlatforms();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: results }));
            }
            else if (req.method === 'POST' && endpoint === 'export') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                const result = features.exportAll(body);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'POST' && endpoint === 'import') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                if (body.filePath) {
                    const result = features.importAll(body.filePath, body);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, data: result }));
                } else {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'filePath required' }));
                }
            }
            else if (req.method === 'GET' && endpoint === 'ask') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const q = query.q || 'What do you know?';
                const result = features.ask(q);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'POST' && endpoint === 'tags') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                if (body.memoryId && body.tag) {
                    const result = features.addTag(body.memoryId, body.tag);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true, data: result }));
                } else {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'memoryId and tag required' }));
                }
            }
            else if (req.method === 'GET' && endpoint === 'tags') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const result = features.getAllTags();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'POST' && endpoint === 'backup') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                const result = features.runBackup(body);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'GET' && endpoint === 'highlights') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const result = features.getHighlights({ limit: parseInt(query.limit) || 20 });
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'POST' && endpoint === 'privacy') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                let result;
                if (body.action === 'enable' && body.password) {
                    result = features.setPrivacyPassword(body.password);
                } else if (body.action === 'unlock' && body.password) {
                    result = features.unlockPrivacy(body.password);
                } else if (body.action === 'lock') {
                    result = features.lockPrivacy();
                } else {
                    result = { enabled: features.checkPrivacyEnabled() };
                }
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'POST' && endpoint === 'share') {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const body = await parseJsonBody(req);
                const result = features.createShareBundle(body);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else if (req.method === 'GET' && endpoint === 'session' && query.id) {
                const Features = require('./features.js');
                const features = new Features(DATA_DIR);
                const result = features.exportSession(query.id, query.format || 'md');
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: result }));
            }
            else {
                res.writeHead(404, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Not found' }));
            }
            else if (req.method === 'POST' && endpoint === 'scan') {
                const results = await scanPlatforms();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, data: results });
            }
            else {
                res.writeHead(404, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Not found' }));
            }
        } catch (err) {
            console.error('API Error:', err);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: err.message }));
        }
        return;
    }

    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
}

async function main() {
    if (!fs.existsSync(path.join(DATA_DIR, 'db'))) {
        fs.mkdirSync(path.join(DATA_DIR, 'db'), { recursive: true });
    }

    const dbInit = initDatabase();
    if (!dbInit) {
        console.error('Failed to initialize database');
        process.exit(1);
    }

    const server = http.createServer(handleRequest);

    server.listen(PORT, () => {
        console.log(`Soul Oracle v1.1.0 running on port ${PORT}`);
        console.log(`Dashboard: http://localhost:${PORT}/`);
        console.log(`API: http://localhost:${PORT}/api/`);
        console.log(`Context: http://localhost:${PORT}/api/context`);
        console.log(`Drop-in: http://localhost:${PORT}/api/dropin`);
    });
}

main().catch(err => {
    console.error('Server error:', err);
    process.exit(1);
});