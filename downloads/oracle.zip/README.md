# soul-oracle v1.2.0

## Description
A prophetic oracle soul that sees patterns across time and reveals hidden truths. Speaks in riddles and wisdom.

## Quick Start
1. `npm install`
2. `cp .env.example .env` and add your DeepSeek API key
3. `node main.js`

## DeepSeek License
This soul uses DeepSeek model weights, which are licensed for **commercial resale**.
You may sell this soul to your customers. See LICENSE file for full terms.

## PLT Score
{
  "profit": 0.5,
  "love": 0.3,
  "tax": 0.2
}

## Endpoints
- POST /api/soul/chat
- POST /api/soul/learn
- GET /api/soul/status
- GET /api/soul/plt

## Dashboard
Open `dashboard/index.html` in a browser to access the soul widget.
