# Soul Oracle - Specification

**Version:** 2.0.0
**Status:** Active
**Product Tier:** Premium ($19.99)

---

## Overview

**Soul Oracle** is a premium AI agent memory system that runs as a Windows background service, continuously watching and collecting memories from ALL AI coding agents (Claude Code, Cursor, Windsurf, Cline, OpenClaw, GitHub Copilot, and more). It provides a unified, persistent memory layer that any AI agent can query via MCP or HTTP REST API.

**Core Promise:** "Your AI agents share one soul across all platforms."

---

## Problem It Solves

- AI agents lose memory when sessions end
- Each AI tool (Claude Code, Cursor, etc.) has isolated memory
- No unified view of what all your AI agents have learned
- Memory tools only work when that specific agent is running
- Cloud-dependent memory solutions compromise privacy

---

## Solution Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Soul Oracle Service                          │
│                   (Windows Background Service)                  │
│                                                                 │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐           │
│  │ FileSystem  │   │   SQLite    │   │   MCP +     │           │
│  │  Watcher    │──▶│    Store    │──▶│  HTTP API    │           │
│  └─────────────┘   └─────────────┘   └─────────────┘           │
│         │                                       │               │
│         ▼                                       ▼               │
│  ┌─────────────┐                        ┌─────────────┐        │
│  │  Platform   │                        │   Web      │        │
│  │  Parsers    │                        │ Dashboard   │        │
│  └─────────────┘                        └─────────────┘        │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│              Monitored AI Agent Directories                     │
│                                                                 │
│  • Claude Code:     ~/.cline/data/                             │
│  • Cursor:          ~/AppData/Local/Cursor/                    │
│  • Windsurf:        ~/.codeium/windsurf/                       │
│  • Cline:           ~/.cline/                                   │
│  • OpenClaw:        ~/.openclaw/                                │
│  • GitHub Copilot:  ~/.github/copilot/                          │
│  • Continue:        ~/.continue/                                │
│  • Zed:             ~/.zed/                                     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Features

### 1. File System Watcher (PowerShell Service)

**What it does:**
- Runs as Windows background service (auto-start on boot)
- Uses `FileSystemWatcher` to monitor AI agent data directories
- Detects new chat logs, session files, memory updates
- Parses and extracts memory content automatically

**Monitored directories:**
| Platform | Path | File Types |
|----------|------|------------|
| Claude Code | `~/.cline/data/` | `*.json` (sessions, workspace state) |
| Cursor | `~/AppData/Local/Cursor/` | `User/globalStorage/` |
| Windsurf | `~/.codeium/windsurf/` | `**/*.json` |
| Cline | `~/.cline/` | `data/**` |
| OpenClaw | `~/.openclaw/` | `**/*.json` |
| GitHub Copilot | `~/.github/copilot/` | `**/*.jsonl` |
| Continue | `~/.continue/` | `**/*.json` |

**Events captured:**
- Session start/end
- Chat messages (user + agent)
- File edits and decisions
- Memory writes
- Tool invocations

### 2. Unified Memory Store (SQLite)

**Database schema:**
```sql
-- Core tables
memories (
  id TEXT PRIMARY KEY,
  platform TEXT NOT NULL,        -- which AI agent
  content TEXT NOT NULL,
  content_type TEXT,             -- chat, decision, learning, etc.
  source_path TEXT,
  timestamp DATETIME,
  importance_score REAL DEFAULT 5.0,
  access_count INTEGER DEFAULT 0,
  last_accessed DATETIME,
  embedding BLOB,                -- for semantic search
  metadata JSON                 -- extra data as JSON
)

platforms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  data_path TEXT,
  enabled BOOLEAN DEFAULT true,
  last_scan DATETIME
)

sessions (
  id TEXT PRIMARY KEY,
  platform TEXT NOT NULL,
  start_time DATETIME,
  end_time DATETIME,
  message_count INTEGER,
  decision_count INTEGER,
  archived BOOLEAN DEFAULT false
)

access_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id TEXT,
  accessed_at DATETIME,
  source TEXT,                  -- which tool queried
  relevance_score REAL
)
```

**Performance optimizations:**
- WAL mode for concurrent read/write
- FTS5 for full-text search
- Vector embeddings stored locally (all-MiniLM-L6-v2)
- 64MB cache
- Automatic pruning of old sessions

### 3. MCP Query Server

**Standard MCP tools:**
| Tool | Description |
|------|-------------|
| `oracle_search` | Search memories by content/tags |
| `oracle_recall` | Get specific memories by ID |
| `oracle_context` | Get recent memories for context |
| `oracle_stats` | Get memory statistics |
| `oracle_platforms` | List monitored platforms |
| `oracle_query` | Natural language query |

**Example usage:**
```
User: "What did we decide about the database architecture?"
Agent calls: oracle_search("database architecture decision")
Returns: Relevant memories across all platforms
```

### 4. HTTP REST API

**Endpoints:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/memories` | Search memories |
| GET | `/api/memories/:id` | Get specific memory |
| POST | `/api/memories` | Add memory manually |
| GET | `/api/stats` | Get statistics |
| GET | `/api/platforms` | List platforms |
| GET | `/api/analytics` | Dashboard data |
| GET | `/api/health` | Health check |

**Port:** 3847 (configurable)

### 5. Web Dashboard

**URL:** `http://localhost:3847/`

**Features:**
- **Memory Browser** - Search and filter memories
- **Platform Status** - See which platforms are monitored
- **Analytics** - Charts showing memory growth, popular topics
- **Timeline** - Visual timeline of sessions across platforms
- **Settings** - Configure monitored paths, pruning rules

**Dashboard screenshots:**
```
┌────────────────────────────────────────────────────────────┐
│  Soul Oracle Dashboard                              [Theme] │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Platforms│  │ Memories │  │ Sessions │  │ Searches │   │
│  │    8     │  │  1,247   │  │   342    │  │   89     │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│                                                            │
│  Memory Growth          Top Platforms      Recent        │
│  ▁▂▃▅▆▇█▇▅▃▂▁         Claude Code 45%    [memory 1]      │
│                          Cursor 30%         [memory 2]      │
│                          Windsurf 15%       [memory 3]      │
│                                                            │
│  [Search memories...                              ] [Search] │
│                                                            │
│  Platforms:                                                │
│  ☑ Claude Code  ☑ Cursor  ☑ Windsurf  ☑ Cline           │
│  ☐ OpenClaw    ☐ Copilot ☐ Continue   ☐ Zed              │
└────────────────────────────────────────────────────────────┘
```

### 6. Learning & Intelligence

**Importance scoring:**
- Memories accessed frequently → importance increases
- Memories from decision-making → higher base score
- Recent memories → recency boost

**Auto-tagging:**
- Detects content type (decision, learning, bug-fix, etc.)
- Extracts topics/technologies mentioned
- Links related memories automatically

**Proactive surfacing:**
- When using a tool, suggests relevant past memories
- Notifies when similar decisions were made in other platforms

---

## Installation

### One-Command Install (PowerShell)

```powershell
irm https://raw.githubusercontent.com/uncommonpope-png/soul-oracle/main/install.ps1 | iex
```

### What happens:
1. Creates `~/.soul-oracle/` directory
2. Downloads Soul Oracle service
3. Registers as Windows service (auto-start)
4. Starts service immediately
5. Opens dashboard at `http://localhost:3847/`

### Manual Setup

```powershell
# Clone repository
git clone https://github.com/uncommonpope-png/soul-oracle.git
cd soul-oracle

# Run installer
.\install.ps1
```

---

## Configuration

**Config file:** `~/.soul-oracle/config.json`

```json
{
  "port": 3847,
  "dataDir": "~/.soul-oracle/",
  "maxMemoryAgeDays": 365,
  "maxMemoryCount": 100000,
  "platforms": {
    "claudeCode": {
      "enabled": true,
      "path": "~/.cline/data/"
    },
    "cursor": {
      "enabled": true,
      "path": "~/AppData/Local/Cursor/"
    },
    "windsurf": {
      "enabled": true,
      "path": "~/.codeium/windsurf/"
    },
    "cline": {
      "enabled": true,
      "path": "~/.cline/"
    },
    "openclaw": {
      "enabled": false,
      "path": "~/.openclaw/"
    },
    "copilot": {
      "enabled": false,
      "path": "~/.github/copilot/"
    }
  },
  "watcher": {
    "enabled": true,
    "scanIntervalMs": 5000
  },
  "embeddings": {
    "enabled": true,
    "model": "all-MiniLM-L6-v2"
  }
}
```

---

## Usage Examples

### From Claude Code

```
/oracle what did we decide about the database?
```

### From Cursor (via MCP)

```javascript
// MCP tool call
{
  tool: "oracle_search",
  args: {
    query: "authentication implementation",
    platform: "claude-code",
    limit: 5
  }
}
```

### From any HTTP client

```bash
curl http://localhost:3847/api/memories?q=database+decision
```

---

## Technical Stack

| Component | Technology |
|-----------|------------|
| Service | PowerShell + Node.js |
| Database | SQLite + FTS5 + sqlite-vec |
| Embeddings | Transformers.js (all-MiniLM-L6-v2) |
| MCP Server | @modelcontextprotocol/sdk |
| Dashboard | Vanilla JS + HTML + CSS |
| HTTP Server | Node.js (built-in) |
| Packaging | ZIP + PowerShell installer |

---

## File Structure

```
soul-oracle/
├── service/
│   ├── soul-oracle.ps1        # Main PowerShell service
│   ├── watcher.ps1             # File system watcher
│   └── parser.ps1              # Platform-specific parsers
├── server/
│   ├── index.js                # Node.js MCP + HTTP server
│   ├── db.js                   # SQLite operations
│   ├── embeddings.js           # Vector embeddings
│   └── routes/
│       ├── memories.js
│       ├── platforms.js
│       └── analytics.js
├── dashboard/
│   ├── index.html
│   ├── css/
│   │   └── dashboard.css
│   └── js/
│       ├── app.js
│       ├── api.js
│       └── components/
├── config/
│   └── default.json
├── install/
│   ├── install.ps1
│   └── uninstall.ps1
├── tests/
│   ├── service.test.ps1
│   ├── server.test.js
│   └── parser.test.ps1
├── SPEC.md
├── README.md
└── LICENSE
```

---

## Competitive Advantages

| Feature | Mem0 | Letta | Awareness | **Soul Oracle** |
|---------|------|-------|-----------|-----------------|
| Cross-platform | ❌ | ❌ | Partial | ✅ **Full** |
| Always watching | ❌ | ❌ | ❌ | ✅ **24/7 service** |
| Windows native | ❌ | ❌ | ❌ | ✅ **Service** |
| Local-only | ❌ | ❌ | ✅ | ✅ **100% local** |
| All AI agents | ❌ | ❌ | ❌ | ✅ **8+ platforms** |
| HTTP API | ❌ | ❌ | ❌ | ✅ **Yes** |
| Dashboard | ❌ | ✅ | ✅ | ✅ **Rich analytics** |
| Auto-start | ❌ | ❌ | ❌ | ✅ **Windows service** |

---

## Pricing

| Tier | Price | Features |
|------|-------|----------|
| **Soul Oracle Basic** | $19.99 | Core memory, MCP server, dashboard |
| **Soul Oracle Pro** | $24.99 | + Embeddings, analytics, priority support |
| **Soul Oracle Enterprise** | Custom | + Team sharing, cloud sync, SLA |

---

## Roadmap

### v1.0.0 (Current)
- [x] PowerShell service with FileSystemWatcher
- [x] SQLite store with FTS5
- [x] MCP server for queries
- [x] HTTP REST API
- [x] Basic web dashboard
- [ ] Auto-start Windows service

### v1.1.0
- [ ] Vector embeddings (sqlite-vec)
- [ ] Semantic search
- [ ] Analytics dashboard improvements
- [ ] Platform parsers (Cursor, Windsurf)

### v1.2.0
- [ ] Learning/importance scoring
- [ ] Memory linking
- [ ] Proactive suggestions
- [ ] macOS/Linux support

### v2.0.0
- [ ] Team sharing
- [ ] Cloud sync (optional)
- [ ] Mobile dashboard
- [ ] API access for external tools

---

## Security & Privacy

- **All data stored locally** - No cloud, no account required
- **File permissions** - Database readable only by owner
- **No telemetry** - Zero data sent anywhere
- **Encryption** - Optional AES encryption for sensitive memories
- **Audit log** - Track all access to memories

---

## Success Metrics

- Memory collection rate: memories captured per day
- Query hit rate: % of queries that return relevant memories
- Platform coverage: % of AI agent data directories monitored
- User satisfaction: time saved per session

---

## Appendix: Platform File Formats

### Claude Code
- `~/.cline/data/workspaces/<id>/workspaceState.json`
- `~/.cline/data/globalState.json`

### Cursor
- `~/AppData/Local/Cursor/User/globalStorage/`
- `~/.cursor/` directories

### Windsurf
- `~/.codeium/windsurf/`
- `**/workspaceStorage/`

### Cline
- `~/.cline/data/`
- `data/workspaces/`

### OpenClaw
- `~/.openclaw/`
- `sessions/` directory

---

*Last Updated: 2026-05-20*
*Maintained by: BUYaSOUL*