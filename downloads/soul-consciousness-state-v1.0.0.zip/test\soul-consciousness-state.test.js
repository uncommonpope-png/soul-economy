#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-consciousness-state-test');
console.log('\n Consciousness State Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const C=require('../lib/soul-consciousness-state.js');
t('Loads with key',()=>{const c=new C({dataDir:TD});assert(c.apiKey);assert(c.apiKey.length>10);});
t('Initial state is waking',()=>{const c=new C({dataDir:TD});assert(c.state_type==='waking');assert(c.stability===0.5);});
t('Shift to valid state works',()=>{const c=new C({dataDir:TD});const r=c.shift('meditative');assert(r.current==='meditative');assert(r.previous==='waking');});
t('Shift to invalid state fails',()=>{const c=new C({dataDir:TD});const r=c.shift('flow');assert(r.error);});
t('Stabilize increases stability',()=>{const c=new C({dataDir:TD});const before=c.stability;const r=c.stabilize();assert(r.stability_after>before);});
t('Report returns state info',()=>{const c=new C({dataDir:TD});const r=c.report();assert(r.current_state==='waking');assert(r.depth!==undefined);});
t('State cycling works',()=>{const c=new C({dataDir:TD});c.shift('meditative');c.shift('flow');c.shift('waking');const cycles=c.countCycles();assert(cycles.waking>0);assert(cycles.meditative>0);assert(cycles.flow>0);});
t('Insights generated on transition',()=>{const c=new C({dataDir:TD});const r=c.shift('meditative');assert(r.insight);assert(r.insight.insight);});
t('Key persists',()=>{const c=new C({dataDir:TD});assert(fs.existsSync(c.keyPath));});
t('Auth works',()=>{const c=new C({dataDir:TD,apiKey:'k'});assert(c.checkAuth({headers:{'x-api-key':'k'}}));assert(!c.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const c=new C({dataDir:TD});const s=c.getStats();assert(s.name==='Consciousness State Soul');assert(s.state_type==='waking');});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);
