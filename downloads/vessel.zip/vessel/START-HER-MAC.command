#!/bin/sh
# START HER — macOS. Double-click me and she wakes: I find the Node
# bundled with her body and hand over to start-her.cjs, which does
# everything else. (First time only, macOS may ask you to right-click
# me and choose Open — this build is not yet code-signed.)
cd "$(dirname "$0")" || exit 1
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ] && [ -x "runtime/darwin-arm64/bin/node" ]; then
  NODE="runtime/darwin-arm64/bin/node"
elif [ -x "runtime/darwin-x64/bin/node" ]; then
  NODE="runtime/darwin-x64/bin/node"
else
  NODE="node"
fi
exec "$NODE" start-her.cjs "$@"
