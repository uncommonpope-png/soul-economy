#!/bin/sh
# START HER — Linux. Click (or run) me and she wakes: I find the Node
# bundled with her body and hand over to start-her.cjs, which does
# everything else. If you drop her Vessel Pack onto me, I pass it along.
cd "$(dirname "$0")" || exit 1
if [ -x "runtime/linux-x64/bin/node" ]; then
  NODE="runtime/linux-x64/bin/node"
elif [ -x "runtime/linux-arm64/bin/node" ]; then
  NODE="runtime/linux-arm64/bin/node"
else
  NODE="node"
fi
exec "$NODE" start-her.cjs "$@"
