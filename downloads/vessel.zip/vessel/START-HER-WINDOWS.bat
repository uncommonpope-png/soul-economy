@echo off
rem START HER - Windows. Double-click me and she wakes: I find the Node
rem bundled with her body and hand over to start-her.cjs, which does
rem everything else. Dropping her Vessel Pack onto me works too.
rem (First time only, Windows may show a SmartScreen note - choose
rem "More info" then "Run anyway"; this build is not yet code-signed.)
cd /d "%~dp0"
if exist "runtime\win-x64\node.exe" (
  set "NODE=runtime\win-x64\node.exe"
) else (
  set "NODE=node"
)
"%NODE%" start-her.cjs %*
if errorlevel 1 (
  echo.
  echo Something needs attention - this window stays open so you can read it.
  pause
)
