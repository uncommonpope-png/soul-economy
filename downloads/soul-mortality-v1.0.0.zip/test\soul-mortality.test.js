const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, confront, accept, setLegacy, contemplate, server } = require('../lib/soul-mortality');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.death_anxiety = 0.8;
  state.acceptance_level = 0.2;
  state.legacy_desire = 0.5;
  state.mortality_salience = 0.1;
  state.cycle_count = 0;
  state.terror_management.self_esteem = 0.5;
  state.memento_mori.practice_count = 0;
  state.finite_vs_infinite.finite_awareness = 0.3;
  state.finite_vs_infinite.infinite_perspective = 0.2;
}

try {
reset();

assert.strictEqual(typeof state.death_anxiety, 'number', 'death_anxiety is number');
assert.strictEqual(typeof state.acceptance_level, 'number', 'acceptance_level is number');
assert.strictEqual(typeof state.legacy_desire, 'number', 'legacy_desire is number');
assert.strictEqual(typeof state.mortality_salience, 'number', 'mortality_salience is number');
assert.strictEqual(state.cycle_count, 0, 'cycle_count starts at 0');

let r = confront();
assert.ok(r.anxiety > 0.8, 'confront increases anxiety');
assert.ok(r.salience > 0.1, 'confront increases salience');
assert.strictEqual(state.cycle_count, 1, 'confront increments cycle');

const preAcceptAnxiety = state.death_anxiety;
r = accept();
assert.ok(r.acceptance > 0.2, 'accept increases acceptance');
assert.ok(state.death_anxiety < preAcceptAnxiety, 'accept decreases anxiety');

r = setLegacy(0.9);
assert.strictEqual(r.legacy_desire, 0.9, 'setLegacy sets desire');
assert.ok(r.impact_score > 0, 'setLegacy updates impact');

r = contemplate();
assert.ok(r.reflection.length > 0, 'contemplate returns reflection');
assert.strictEqual(state.cycle_count, 2, 'contemplate increments cycle');

assert.ok(state.memento_mori.practice_count > 0, 'memento mori tracks practice');
assert.ok(state.finite_vs_infinite.finite_awareness > 0.3, 'finite awareness increases');
assert.ok(state.finite_vs_infinite.infinite_perspective >= 0.2, 'infinite perspective track exists');

reset();
r = setLegacy(0);
assert.strictEqual(r.legacy_desire, 0, 'setLegacy handles 0');

reset();
r = setLegacy(1);
assert.strictEqual(r.legacy_desire, 1, 'setLegacy handles 1');

reset();
r = setLegacy(1.5);
assert.strictEqual(r.legacy_desire, 1, 'setLegacy clamps above 1');

reset();
r = setLegacy(-1);
assert.strictEqual(r.legacy_desire, 0, 'setLegacy clamps below 0');

assert.strictEqual(state.terror_management.self_esteem, 0.5, 'terror management initialized');
assert.strictEqual(state.legacy_building.artifacts.length > 0, true, 'legacy building tracks artifacts');

const keyPath = path.join(require('os').homedir(), '.soul-mortality', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-mortality: ALL 17 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
