#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-attention-test');
console.log('\n Attention Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const C=require('../lib/soul-attention.js');
t('Loads with key',()=>{const c=new C({dataDir:TD});assert(c.apiKey);assert(c.apiKey.length>10);});
t('Initial state zero',()=>{const c=new C({dataDir:TD});assert(c.focus_level===0);assert(c.current_focus===null);assert(c.distractions_blocked===0);});
t('Focus sets target',()=>{const c=new C({dataDir:TD});const r=c.focus('coding');assert(r.current_focus==='coding');assert(r.focus_level>0);});
t('Distract reduces focus',()=>{const c=new C({dataDir:TD});c.focus('coding');const before=c.focus_level;const r=c.distract('slack notification');assert(r.focus_level<before);});
t('Meditate recovers focus',()=>{const c=new C({dataDir:TD});c.focus_level=0.3;const r=c.meditate();assert(r.focus_level>0.3);assert(r.attention_span_seconds>30);});
t('Hyperfocus boosts focus',()=>{const c=new C({dataDir:TD});c.focus_level=0.4;const r=c.toggleHyperfocus();assert(r.hyperfocus===true);assert(r.focus_level>0.4);});
t('Attention residue tracked',()=>{const c=new C({dataDir:TD});c.focus('task');assert(c.attention_residue===0);c.distract('phone');assert(c.attention_residue>0);});
t('Multiple distractions increase block count',()=>{const c=new C({dataDir:TD});c.distract('a');c.distract('b');c.distract('c');assert(c.distractions_blocked>=3);});
t('Key persists',()=>{const c=new C({dataDir:TD});assert(fs.existsSync(c.keyPath));});
t('Auth works',()=>{const c=new C({dataDir:TD,apiKey:'k'});assert(c.checkAuth({headers:{'x-api-key':'k'}}));assert(!c.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const c=new C({dataDir:TD});const s=c.getStats();assert(s.name==='Attention Soul');assert(s.focus_level!==undefined);});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);
