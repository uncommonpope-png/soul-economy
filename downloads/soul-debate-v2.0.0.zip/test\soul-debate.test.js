#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-debate-test');
console.log('\n Debate Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const D=require('../lib/soul-debate.js');
t('Loads with key',()=>{const d=new D({dataDir:TD});assert(d.apiKey);assert(d.apiKey.length>10);});
t('4 agents exist',()=>{const d=new D({dataDir:TD});const k=Object.keys(d.AGENTS);assert(k.length===4);assert(k.includes('judge'));});
t('Debate returns structure',()=>{const d=new D({dataDir:TD});const r=d.debate('Test topic');assert(r.topic);assert(r.rounds.length===3);assert(r.verdict);});
t('Each round has statements',()=>{const d=new D({dataDir:TD});const r=d.debate('Test',{rounds:2});r.rounds.forEach(rd=>{assert(rd.statements.length>0);});});
t('Key persists',()=>{const d=new D({dataDir:TD});assert(fs.existsSync(d.keyPath));});
t('Auth works',()=>{const d=new D({dataDir:TD,apiKey:'k'});assert(d.checkAuth({headers:{'x-api-key':'k'}}));assert(!d.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const d=new D({dataDir:TD});const s=d.getStats();assert(s.name==='Debate Soul');assert(s.debates>=0);});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);