#!/usr/bin/env node
// Debate Soul v2.0 — Setup Script
const fs = require('fs');
const path = require('path');
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');

console.log(`\n  ╔══════════════════════════════════════╗`);
console.log(`  ║   Debate Soul v2.0                   ║`);
console.log(`  ║   PLT-Powered AI Presidential Debates ║`);
console.log(`  ╚══════════════════════════════════════╝\n`);

// Create data directories
['data', 'data/debate', 'data/souls'].forEach(d => {
  const p = path.join(ROOT, d);
  if (!fs.existsSync(p)) { fs.mkdirSync(p, { recursive: true }); console.log(`  Created ${d}/`); }
});

// Check Node version
console.log(`  Node.js ${process.version} detected`);

// Check if brain modules exist
const brainPath = path.join(ROOT, 'brain-in-a-box', 'lib', 'brain-engine.js');
if (fs.existsSync(brainPath)) {
  console.log(`  Brain in a Box engine: bundled`);
} else {
  console.log(`  Brain in a Box engine: not found (some features limited)`);
}

// Check Profit Bible
const biblePath = path.join(ROOT, 'THE-PROFIT-BIBLE.md');
if (fs.existsSync(biblePath)) {
  const size = fs.statSync(biblePath).size;
  console.log(`  THE-PROFIT-BIBLE.md: bundled (${(size / 1024).toFixed(0)} KB)`);
}

console.log(`\n  Debate Soul is ready.`);
console.log(`  Run: node lib/soul-debate.js`);
console.log(`  Open: http://localhost:4170\n`);
