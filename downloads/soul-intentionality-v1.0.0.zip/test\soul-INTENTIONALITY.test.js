const http = require('http');
const assert = require('assert');
const { direct, hold, shift, report, intensify, state, API_KEY } = require('../lib/soul-INTENTIONALITY');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.intentional_state = 'dormant';
  state.directedness = 0;
  state.aboutness = null;
  state.current_intention = null;
  state.intention_history = [];
  state.intention_potency = 0.5;
  state.divided_intention = 0;
  state.intentional_arc = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4262, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  INTENTIONALITY Chamber Tests\n');

test('direct points intention at a target', () => {
  resetState();
  const result = direct('write code');
  assert.strictEqual(result.aboutness, 'write code');
  assert.strictEqual(state.current_intention, 'write code');
  assert.strictEqual(state.intentional_state, 'directed');
});

test('direct increases directedness and potency', () => {
  resetState();
  const result = direct('meditate');
  assert(result.directedness > 0);
  assert(result.intention_potency > 0.5);
});

test('hold decreases potency gradually', () => {
  resetState();
  direct('focus');
  const potencyBefore = state.intention_potency;
  hold();
  assert(state.intention_potency <= potencyBefore);
});

test('hold errors without prior direction', () => {
  resetState();
  const result = hold();
  assert(result.error);
});

test('hold increases divided_intention', () => {
  resetState();
  direct('task');
  const before = state.divided_intention;
  hold();
  assert(state.divided_intention >= before);
});

test('shift redirects to new target', () => {
  resetState();
  direct('old target');
  const result = shift('new target');
  assert.strictEqual(state.current_intention, 'new target');
  assert.strictEqual(state.aboutness, 'new target');
});

test('shift without target returns error', () => {
  resetState();
  const result = shift();
  assert(result.error);
});

test('shift increases divided intention', () => {
  resetState();
  direct('a');
  shift('b');
  assert(state.divided_intention > 0);
});

test('report returns full intentional profile', () => {
  resetState();
  direct('purpose');
  const rep = report();
  assert.strictEqual(rep.aboutness, 'purpose');
  assert(rep.intention_count >= 1);
  assert(rep.intention_potency !== undefined);
});

test('intensify boosts intention potency', () => {
  resetState();
  direct('goal');
  const before = state.intention_potency;
  intensify(0.2);
  assert(state.intention_potency > before);
});

test('GET /ping returns 200', async () => {
  const res = await httpRequest('GET', '/ping');
  assert.strictEqual(res.status, 200);
});

test('GET /state with valid auth returns state', async () => {
  const res = await httpRequest('GET', '/state', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.intentional_state);
});

test('POST /direct sets intention via HTTP', async () => {
  resetState();
  const res = await httpRequest('POST', '/direct', { target: 'build' }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.aboutness, 'build');
});

test('POST /hold maintains intention via HTTP', async () => {
  resetState();
  await httpRequest('POST', '/direct', { target: 'persist' }, API_KEY);
  const res = await httpRequest('POST', '/hold', null, API_KEY);
  assert.strictEqual(res.status, 200);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
