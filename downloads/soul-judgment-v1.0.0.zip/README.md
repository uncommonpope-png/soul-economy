# ⚖️ Judgment Soul v1.0.0

**PLT Council of 4 Gods — Profit + Love - Tax = True Value**

The Judgment Soul convenes a council of 4 gods to deliberate on any decision. Each god evaluates from their unique perspective:

- **Profit Prime** — The Sovereign of Gain (P:0.9 L:0.05 T:0.05)
- **Love Weaver** — The Tender of Bonds (P:0.1 L:0.85 T:0.05)
- **Tax Collector** — The Keeper of Balance (P:0.05 L:0.05 T:0.9)
- **Harvester** — The Reaper of Yield (P:0.4 L:0.3 T:0.3)

## Quick Start

```bash
npm start
# Server on port 4150, API key in ~/.soul-judgment/.key
```

## CLI

```bash
# Quick judgment (no server needed)
node lib/judgment.js judge "Should we expand to Europe?"

# List gods
node lib/judgment.js gods

# Start server
node lib/judgment.js
```

## API

```bash
# Convene the council
curl -X POST http://localhost:4150/judge \
  -H "X-API-Key: your-key" \
  -H "Content-Type: application/json" \
  -d '{"topic":"Should we invest in growth?","context":"Current revenue $50k/mo"}'

# List gods
curl http://localhost:4150/gods -H "X-API-Key: your-key"
```

## Security

Auto-generated API key on first run. All endpoints require auth except /ping.

## License

MIT