#!/usr/bin/env node
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const TEST_DIR = path.join(os.homedir(), '.soul-judgment-test');
console.log('\n⚖️ Judgment Soul v1.0.0 — Test Suite\n');
let passed = 0, failed = 0;
function test(name, fn) { try { fn(); console.log('  ✓ ' + name); passed++; } catch (e) { console.log('  ✗ ' + name + ': ' + e.message); failed++; } }
if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });
const J = require('../lib/soul-judgment.js');

test('Soul loads with API key', () => {
    const j = new J({ dataDir: TEST_DIR });
    assert(j.apiKey, 'Should generate API key');
    assert(j.apiKey.length > 10, 'Key long enough');
});

test('4 Gods exist', () => {
    const j = new J({ dataDir: TEST_DIR });
    const gods = Object.keys(j.GODS);
    assert(gods.length === 4, 'Should have 4 gods');
    assert(gods.includes('profit'), 'Should have Profit Prime');
    assert(gods.includes('love'), 'Should have Love Weaver');
    assert(gods.includes('tax'), 'Should have Tax Collector');
    assert(gods.includes('harvester'), 'Should have Harvester');
});

test('PLT calculation works', () => {
    const j = new J({ dataDir: TEST_DIR });
    assert(j.calcPLT(1, 0, 0) === 1, 'Pure profit = 1');
    assert(j.calcPLT(0, 1, 0) === 1, 'Pure love = 1');
    assert(j.calcPLT(0, 0, 1) === -1, 'Pure tax = -1');
    assert(j.calcPLT(1, 1, 1) === 1, 'Balanced = 1');
});

test('Judge returns correct structure', () => {
    const j = new J({ dataDir: TEST_DIR });
    const r = j.judge('Should we expand?');
    assert(r.topic === 'Should we expand?', 'Topic preserved');
    assert(r.judgments.length === 4, '4 judgments');
    assert(r.verdict, 'Has verdict');
    assert(r.totalPLT !== undefined, 'Has PLT score');
});

test('Each god has an opinion', () => {
    const j = new J({ dataDir: TEST_DIR });
    const r = j.judge('Should we invest in growth?');
    r.judgments.forEach(g => {
        assert(g.opinion.length > 10, g.name + ' should have opinion');
        assert(g.score !== undefined, g.name + ' should have score');
    });
});

test('Profit-scored topic favors Profit Prime', () => {
    const j = new J({ dataDir: TEST_DIR });
    const r = j.judge('Should we grow revenue and scale?');
    const profit = r.judgments.find(g => g.god === 'profit');
    assert(profit.opinion.includes('growth'), 'Profit sees growth');
});

test('Verdict types are valid', () => {
    const j = new J({ dataDir: TEST_DIR });
    const validTypes = ['strong_consensus', 'consensus', 'divided', 'strong_objection', 'lean'];
    const r = j.judge('Test topic');
    assert(validTypes.includes(r.verdict.type), 'Verdict type should be valid');
    assert(['proceed', 'caution', 'deliberate'].includes(r.verdict.recommendation), 'Valid recommendation');
});

test('History tracks judgments', () => {
    const j = new J({ dataDir: TEST_DIR });
    j.judge('Topic 1');
    j.judge('Topic 2');
    const h = j.history();
    assert(h.length >= 2, 'Should track multiple judgments');
});

test('Judgments persist to disk', () => {
    const dataDir = TEST_DIR + '_persist';
    if (fs.existsSync(dataDir)) fs.rmSync(dataDir, { recursive: true, force: true });
    const j1 = new J({ dataDir });
    j1.judge('Persist test');
    const j2 = new J({ dataDir });
    const result = j2.verdicts.length >= 1;
    if (fs.existsSync(dataDir)) fs.rmSync(dataDir, { recursive: true, force: true });
    assert(result, 'Should load previous judgments');
});

test('Status returns correct stats', () => {
    const j = new J({ dataDir: TEST_DIR });
    const s = j.getStats();
    assert(s.name === 'Judgment Soul', 'Has name');
    assert(s.gods.length === 4, '4 gods');
    assert(s.apiKey, 'Has API key prefix');
});

test('Auth check works', () => {
    const j = new J({ dataDir: TEST_DIR, apiKey: 'test-key' });
    assert(j.checkAuth({ headers: { 'x-api-key': 'test-key' } }) === true, 'Valid key passes');
    assert(j.checkAuth({ headers: { 'x-api-key': 'wrong' } }) === false, 'Wrong key fails');
});

test('Key persists to disk', () => {
    const j = new J({ dataDir: TEST_DIR });
    assert(fs.existsSync(j.keyPath), 'Key file exists');
    const stored = fs.readFileSync(j.keyPath, 'utf8').trim();
    assert(stored === j.apiKey, 'Stored key matches');
});

if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });
console.log('\n' + '='.repeat(40));
console.log('Results: ' + passed + ' passed, ' + failed + ' failed\n');
process.exit(failed > 0 ? 1 : 0);