const http = require('http');
const assert = require('assert');
const { createHabit, execute, trackStreak, breakHabit, reportHabits, stackHabits, markKeystone, state, API_KEY } = require('../lib/soul-HABIT-FORMATION');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.habits = {};
  state.cue_loop_strength = 0.3;
  state.automaticity = 0.2;
  state.habit_count = 0;
  state.streaks = {};
  state.day_rule_tracking = { day21: false, day66: false };
  state.keystone_habits = [];
  state.habit_stacks = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4267, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  HABIT-FORMATION Chamber Tests\n');

test('createHabit requires name, cue, and routine', () => {
  resetState();
  assert(createHabit().error);
  assert(createHabit('name').error);
  assert(createHabit('name', 'cue').error);
  assert(!createHabit('name', 'cue', 'routine').error);
});

test('createHabit adds habit to state', () => {
  resetState();
  createHabit('morning_walk', 'alarm', 'walk 10 min');
  assert(state.habits['morning_walk']);
  assert.strictEqual(state.habits['morning_walk'].cue, 'alarm');
  assert.strictEqual(state.habits['morning_walk'].routine, 'walk 10 min');
});

test('createHabit increments habit_count', () => {
  resetState();
  createHabit('h1', 'c1', 'r1');
  assert.strictEqual(state.habit_count, 1);
});

test('createHabit prevents duplicate names', () => {
  resetState();
  createHabit('unique', 'cue', 'routine');
  const result = createHabit('unique', 'cue2', 'routine2');
  assert(result.error);
});

test('createHabit increases cue_loop_strength', () => {
  resetState();
  const before = state.cue_loop_strength;
  createHabit('new_h', 'cue', 'routine');
  assert(state.cue_loop_strength > before);
});

test('execute requires name', () => {
  resetState();
  const result = execute();
  assert(result.error);
});

test('execute errors for non-existent habit', () => {
  resetState();
  const result = execute('nonexistent');
  assert(result.error);
});

test('execute increases strength and streak', () => {
  resetState();
  createHabit('read', 'bedtime', 'read 20 pages');
  const result = execute('read');
  assert(result.habit.strength > 0.1);
  assert(result.habit.streak >= 1);
  assert(result.habit.executions >= 1);
});

test('execute increases automaticity', () => {
  resetState();
  const before = state.automaticity;
  createHabit('code_daily', 'morning', 'write code');
  execute('code_daily');
  assert(state.automaticity > before);
});

test('trackStreak returns milestone info', () => {
  resetState();
  createHabit('exercise', '6am', 'workout');
  execute('exercise');
  const result = trackStreak('exercise');
  assert.strictEqual(result.name, 'exercise');
  assert(result.streak >= 1);
});

test('breakHabit removes habit', () => {
  resetState();
  createHabit('bad_habit', 'trigger', 'action');
  const result = breakHabit('bad_habit');
  assert(!state.habits['bad_habit']);
  assert.strictEqual(result.habit_count, 0);
});

test('breakHabit reduces automaticity', () => {
  resetState();
  createHabit('temp', 'x', 'y');
  state.automaticity = 0.5;
  breakHabit('temp');
  assert(state.automaticity < 0.5);
});

test('stackHabits links two habits', () => {
  resetState();
  createHabit('anchor_h', 'cue', 'routine');
  createHabit('new_h', 'cue2', 'routine2');
  const result = stackHabits('anchor_h', 'new_h');
  assert(result.stack.anchor === 'anchor_h');
  assert(state.habit_stacks.length === 1);
});

test('markKeystone sets habit as keystone', () => {
  resetState();
  createHabit('key_h', 'cue', 'routine');
  const result = markKeystone('key_h');
  assert(result.is_keystone);
  assert(state.keystone_habits.includes('key_h'));
});

test('reportHabits returns full habit state', () => {
  resetState();
  createHabit('h1', 'c', 'r');
  const rep = reportHabits();
  assert(rep.habit_count === 1);
  assert(rep.automaticity !== undefined);
  assert(rep.cue_loop_strength !== undefined);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
