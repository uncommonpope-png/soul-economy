import type { ComponentType } from "react";
import {
  SlidersHorizontal, Settings2, Terminal, Workflow, ShieldCheck,
  Upload, Key, Users, ShoppingBag, History, Phone, Puzzle
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface PanelProps {
  accentColor: string;
}

export interface TabDefinition {
  id: string;
  label: string;
  icon: LucideIcon;
}

export interface PanelDefinition extends TabDefinition {
  component: ComponentType<PanelProps>;
}

// All tabs shown in the navigation bar
export const TAB_DEFINITIONS: TabDefinition[] = [
  { id: "profile", label: "1. Character Blueprint", icon: SlidersHorizontal },
  { id: "skills", label: "2. Equip Skills Loadout", icon: Settings2 },
  { id: "simulation", label: "3. Test Bench Playground", icon: Terminal },
  { id: "integrations", label: "4. Production Pipelines", icon: Workflow },
  { id: "realism", label: "5. System Dashboard", icon: ShieldCheck },
  { id: "souls", label: "6. Soul Foundry", icon: Upload },
  { id: "vault", label: "6. API & Token Vault", icon: Key },
  { id: "habitat", label: "7. Multi-Agent Habitat", icon: Users },
  { id: "marketplace", label: "8. Social & Live Market", icon: ShoppingBag },
  { id: "transactions", label: "9. Marketplace Transactions", icon: History },
  { id: "telephone", label: "10. Telephone Exchange", icon: Phone },
  { id: "terminal", label: "11. Soul Terminal", icon: Terminal },
];

// Panels that auto-render with just { accentColor } prop.
// Add custom panels here — they appear as tabs and render automatically.
// Core tabs with complex props (profile, skills, etc.) are handled in App.tsx.
export const CUSTOM_PANEL_REGISTRY: PanelDefinition[] = [];

export const DEFAULT_TAB = "profile";
