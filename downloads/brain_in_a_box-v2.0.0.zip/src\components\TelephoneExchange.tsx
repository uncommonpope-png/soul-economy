import React, { useEffect, useState } from "react";
import { Phone, PhoneCall, PhoneOff, PhoneIncoming, Voicemail, BookUser, RefreshCw, Activity, Plus, Send, History, Plug, Wifi, WifiOff, Users, Server } from "lucide-react";

interface PhonebookAgent {
  number: string; name: string; platform: string; type: string;
  status: string; lastSeen: string; voicemail: number;
}

interface CallRecord {
  id: string; from: string; fromName: string; to: string; toName: string;
  message: string; timestamp: string; status: string; responses: { response: string; timestamp: string }[];
}

interface Connector {
  id: string; name: string; type: string; setup: string; connected: boolean;
}

interface Stats {
  online: boolean; agents: number; calls: number;
  activeCalls: number; connectors: number; uptime: number;
}

const TELEPHONE_API = "/api/telephone";

export const TelephoneExchange: React.FC<{ accentColor: string }> = ({ accentColor }) => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [phonebook, setPhonebook] = useState<PhonebookAgent[]>([]);
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const [activeCalls, setActiveCalls] = useState<Record<string, CallRecord>>({});
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const [loading, setLoading] = useState(true);

  const [regName, setRegName] = useState("");
  const [regPlatform, setRegPlatform] = useState("generic");
  const [dialTo, setDialTo] = useState("");
  const [dialMsg, setDialMsg] = useState("");
  const [respondCallId, setRespondCallId] = useState("");
  const [respondMsg, setRespondMsg] = useState("");
  const [log, setLog] = useState<string[]>([]);

  const addLog = (m: string) => setLog(prev => [`[${new Date().toLocaleTimeString()}] ${m}`, ...prev].slice(0, 50));

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [sRes, pbRes, cRes, connRes] = await Promise.all([
        fetch(`${TELEPHONE_API}/status`).then(r => r.json()),
        fetch(`${TELEPHONE_API}/phonebook`).then(r => r.json()),
        fetch(`${TELEPHONE_API}/calls`).then(r => r.json()),
        fetch(`${TELEPHONE_API}/connectors`).then(r => r.json()),
      ]);
      if (sRes.online) setStats(sRes);
      if (pbRes.phonebook) setPhonebook(pbRes.phonebook);
      if (cRes.calls) setCalls(cRes.calls);
      if (cRes.active) setActiveCalls(cRes.active);
      if (connRes.connectors) setConnectors(connRes.connectors);
    } catch { addLog("Failed to reach Telephone Soul"); }
    setLoading(false);
  };

  useEffect(() => { fetchAll(); }, []);

  const register = async () => {
    if (!regName) return;
    const res = await fetch(`${TELEPHONE_API}/register`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: regName, platform: regPlatform }),
    });
    const data = await res.json();
    if (data.success) { addLog(`Registered "${regName}" as #${data.agent.number}`); setRegName(""); fetchAll(); }
    else addLog(`Register failed: ${data.error}`);
  };

  const dial = async () => {
    if (!dialTo || !dialMsg) return;
    const res = await fetch(`${TELEPHONE_API}/dial`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to: dialTo, message: dialMsg }),
    });
    const data = await res.json();
    if (data.id) addLog(`Dialed #${dialTo} → call ${data.id}`);
    else addLog(`Dial failed: ${data.error}`);
    setDialMsg(""); fetchAll();
  };

  const respond = async () => {
    if (!respondCallId || !respondMsg) return;
    const res = await fetch(`${TELEPHONE_API}/respond`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ callId: respondCallId, response: respondMsg }),
    });
    const data = await res.json();
    if (data.success) addLog(`Responded to call ${respondCallId}`);
    fetchAll();
  };

  const formatTime = (ts: string) => new Date(ts).toLocaleTimeString();

  if (loading && !stats) {
    return <div className="flex items-center justify-center h-full text-slate-500 text-sm font-mono">Connecting to Telephone Soul...</div>;
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 text-slate-100 flex-1">
      {/* Left panel - controls */}
      <div className="xl:col-span-4 flex flex-col gap-4">
        {/* Stats */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <Phone className="w-5 h-5" style={{ color: accentColor }} />
              Telephone Exchange
            </h2>
            <button onClick={fetchAll} className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs cursor-pointer"><RefreshCw className="w-3.5 h-3.5" /></button>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <StatBox label="Agents" value={stats?.agents || 0} color={accentColor} />
            <StatBox label="Active Calls" value={Object.keys(activeCalls).length} color="#f59e0b" />
            <StatBox label="Total Calls" value={stats?.calls || 0} color="#3b82f6" />
            <StatBox label="Online" value={phonebook.filter(a => a.status === "online").length} color="#10b981" />
            <StatBox label="Connectors" value={stats?.connectors || 0} color="#a855f7" />
            <StatBox label="Uptime" value={stats?.uptime ? `${Math.floor(stats.uptime / 60)}m` : "0m"} color="#64748b" />
          </div>
        </div>

        {/* Register */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><Plus className="w-3.5 h-3.5" style={{ color: accentColor }} /> Register Agent</h3>
          <div className="flex gap-2 mb-2">
            <input value={regName} onChange={e => setRegName(e.target.value)} placeholder="Agent name..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none placeholder:text-slate-600 font-mono" />
            <select value={regPlatform} onChange={e => setRegPlatform(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-200 outline-none font-mono cursor-pointer">
              <option value="generic">Generic</option><option value="claude">Claude</option>
              <option value="cursor">Cursor</option><option value="windsurf">Windsurf</option>
              <option value="cline">Cline</option><option value="openai">OpenAI</option><option value="gemini">Gemini</option>
            </select>
          </div>
          <button onClick={register} className="w-full px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono rounded-lg cursor-pointer"><Plus className="w-3 h-3 inline mr-1" /> Register</button>
        </div>

        {/* Dial */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><PhoneCall className="w-3.5 h-3.5" style={{ color: accentColor }} /> Dial Agent</h3>
          <div className="flex gap-2 mb-2">
            <input value={dialTo} onChange={e => setDialTo(e.target.value)} placeholder="Number (e.g. a1b2)"
              className="w-20 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none placeholder:text-slate-600 font-mono" />
            <input value={dialMsg} onChange={e => setDialMsg(e.target.value)} placeholder="Message..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none placeholder:text-slate-600 font-mono" />
          </div>
          <button onClick={dial} className="w-full px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono rounded-lg cursor-pointer"><Send className="w-3 h-3 inline mr-1" /> Dial</button>
        </div>

        {/* Respond */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><PhoneIncoming className="w-3.5 h-3.5" style={{ color: accentColor }} /> Respond to Call</h3>
          <div className="flex gap-2 mb-2">
            <input value={respondCallId} onChange={e => setRespondCallId(e.target.value)} placeholder="Call ID"
              className="w-28 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none placeholder:text-slate-600 font-mono" />
            <input value={respondMsg} onChange={e => setRespondMsg(e.target.value)} placeholder="Response..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 outline-none placeholder:text-slate-600 font-mono" />
          </div>
          <button onClick={respond} className="w-full px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono rounded-lg cursor-pointer"><PhoneCall className="w-3 h-3 inline mr-1" /> Respond</button>
        </div>
      </div>

      {/* Right panel - data */}
      <div className="xl:col-span-8 flex flex-col gap-4 overflow-y-auto max-h-[calc(100vh-200px)]">
        {/* Phonebook */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><BookUser className="w-4 h-4" style={{ color: accentColor }} /> Phonebook ({phonebook.length})</h3>
          {phonebook.length === 0 ? (
            <div className="text-center py-6 text-slate-500 text-xs font-mono">No agents registered. Register one to get started.</div>
          ) : (
            <div className="space-y-1 max-h-[220px] overflow-y-auto">
              {phonebook.map(a => (
                <div key={a.number} className="flex items-center justify-between bg-slate-950/40 border border-slate-800/40 rounded-lg px-3 py-1.5 text-[11px] font-mono">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${a.status === "online" ? "bg-emerald-400 shadow-[0_0_4px_#34d399]" : "bg-slate-600"}`} />
                    <span className="text-emerald-400 font-bold">#{a.number}</span>
                    <span className="text-slate-200">{a.name}</span>
                    <span className="text-slate-500 text-[9px]">{a.platform}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[9px] text-slate-500">
                    {a.voicemail > 0 && <span className="text-amber-400">{a.voicemail} 📨</span>}
                    <span>{new Date(a.lastSeen).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Calls */}
        {Object.keys(activeCalls).length > 0 && (
          <div className="bg-slate-900/60 border border-amber-800/40 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
            <h3 className="text-xs font-mono font-bold text-amber-400 mb-3 flex items-center gap-1.5"><PhoneCall className="w-4 h-4" /> Active Calls ({Object.keys(activeCalls).length})</h3>
            {Object.values(activeCalls).map(c => (
              <div key={c.id} className="bg-slate-950/60 border border-amber-800/30 rounded-lg px-3 py-2 mb-2 text-[11px] font-mono">
                <div className="flex justify-between text-amber-300">#{c.fromName} → #{c.toName} <span className="text-slate-500">{formatTime(c.timestamp)}</span></div>
                <div className="text-slate-400 mt-1">"{c.message}"</div>
              </div>
            ))}
          </div>
        )}

        {/* Call History */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><History className="w-4 h-4" style={{ color: accentColor }} /> Call History ({calls.length})</h3>
          <div className="space-y-1 max-h-[300px] overflow-y-auto">
            {calls.slice().reverse().map(c => (
              <div key={c.id} className="bg-slate-950/40 border border-slate-800/40 rounded-lg px-3 py-1.5 text-[10px] font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-300">#{c.fromName} → #{c.toName}</span>
                  <span className="text-slate-500">{formatTime(c.timestamp)}</span>
                </div>
                <div className="text-slate-500 mt-0.5">"{c.message}"</div>
                {c.responses.map((r, i) => <div key={i} className="text-emerald-400/70 mt-0.5">↳ {r.response}</div>)}
              </div>
            ))}
          </div>
        </div>

        {/* Connectors */}
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
          <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><Plug className="w-4 h-4" style={{ color: accentColor }} /> Connectors</h3>
          <div className="grid grid-cols-2 gap-2">
            {connectors.map(c => (
              <div key={c.id} className="bg-slate-950/40 border border-slate-800/40 rounded-lg px-3 py-2 text-[10px] font-mono">
                <div className="flex items-center gap-2">
                  {c.connected ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-slate-600" />}
                  <span className="text-slate-200">{c.name}</span>
                  <span className="text-slate-500 text-[8px] uppercase">{c.type}</span>
                </div>
                <div className="text-slate-500 mt-0.5 text-[9px]">{c.setup}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Activity Log */}
        {log.length > 0 && (
          <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4 shadow-2xl">
            <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5"><Activity className="w-4 h-4" style={{ color: accentColor }} /> Activity Log</h3>
            <div className="space-y-0.5 max-h-[150px] overflow-y-auto">
              {log.map((l, i) => (
                <div key={i} className="text-[9px] font-mono text-slate-500">{l}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StatBox: React.FC<{ label: string; value: number | string; color: string }> = ({ label, value, color }) => (
  <div className="bg-slate-950/50 border border-slate-800/50 rounded-lg p-2 text-center">
    <div className="text-lg font-bold font-mono" style={{ color }}>{value}</div>
    <div className="text-[8px] font-mono text-slate-500 uppercase tracking-wider">{label}</div>
  </div>
);
