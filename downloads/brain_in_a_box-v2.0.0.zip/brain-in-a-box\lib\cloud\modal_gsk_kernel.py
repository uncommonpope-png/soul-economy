import modal
import os
import subprocess
import asyncio
import json
from fastapi import FastAPI, Request
from fastapi.responses import Response

app = modal.App("soul-gsk-kernel")
web_app = FastAPI()

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("nodejs", "npm")
    .add_local_dir(
        r"C:\Users\uncom\Desktop\brain-in-a-box\lib",
        remote_path="/brain/lib",
        copy=True
    )
)

# Global kernel process reference
kernel_proc = None

async def proxy(path: str, method="GET", body=None):
    """Proxy request to GSK kernel"""
    import httpx
    url = f"http://127.0.0.1:4242{path}"
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.request(method, url, json=body)
        return Response(content=resp.content, status_code=resp.status_code, media_type="application/json")

@web_app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def catch_all(request: Request, path: str):
    body = await request.body()
    body_json = json.loads(body) if body else None
    return await proxy(f"/{path}", request.method, body_json)

@app.function(
    image=image,
    cpu=4,
    memory=8192,
    scaledown_window=3600,
    timeout=3600,
    volumes={"/brain-data": modal.Volume.from_name("soul-brain-state", create_if_missing=True)},
)
@modal.asgi_app()
def kernel():
    global kernel_proc

    # Start GSK kernel in background
    env = {**os.environ, "PORT": "4242", "BRAIN_DATA_DIR": "/brain-data", "MASTODON_TOKEN": ""}
    kernel_proc = subprocess.Popen(
        ["node", "/brain/lib/soul-brain-in-a-box.js"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env=env
    )

    # Log output in background
    import threading
    def log_output(stream, label):
        for line in iter(stream.readline, b''):
            print(f"[{label}] {line.decode().strip()}", flush=True)
    threading.Thread(target=log_output, args=(kernel_proc.stdout, "KERNEL"), daemon=True).start()
    threading.Thread(target=log_output, args=(kernel_proc.stderr, "ERROR"), daemon=True).start()

    return web_app
