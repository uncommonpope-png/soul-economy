import React, { useState, useRef, useEffect } from "react";
import { Bot, Send, X, Sparkles, Zap, Lightbulb, ChevronRight, Cpu, ShoppingBag, FileJson, Loader2, Paperclip } from "lucide-react";

type TabContext = string;

interface GSKCopilotProps {
  activeTab: TabContext;
  contextData?: any;
}

interface Message {
  id: string;
  role: "user" | "gsk";
  text: string;
  actions?: { label: string; action: string; data?: any }[];
}

const TAB_LABELS: Record<string, string> = {
  profile: "character builder",
  skills: "skill library",
  simulation: "test bench",
  integrations: "pipelines",
  realism: "system dashboard",
  souls: "soul foundry",
  vault: "api vault",
  habitat: "multi-agent habitat",
  marketplace: "social market",
  transactions: "ledger",
  telephone: "telephone exchange",
  terminal: "soul terminal",
};

const QUICK_ACTIONS: Record<string, { label: string; action: string; data?: any }[]> = {
  profile: [
    { label: "Suggest personality", action: "suggest-personality" },
    { label: "Suggest avatar seed", action: "suggest-seed" },
    { label: "Improve this agent", action: "improve" },
  ],
  skills: [
    { label: "Suggest new skills", action: "ideate" },
    { label: "Improve a skill", action: "improve" },
  ],
  marketplace: [
    { label: "List my agent", action: "list-agent" },
    { label: "List a skill", action: "list-skill" },
    { label: "Pricing tips", action: "advice" },
  ],
  export: [
    { label: "Describe for export", action: "describe" },
  ],
};

export const GSKCopilot: React.FC<GSKCopilotProps> = ({ activeTab, contextData }) => {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Message[]>([
    { id: "welcome", role: "gsk", text: `I'm GSK, your creation copilot. I can help you build, customize, and sell agents and skills. You're in the **${TAB_LABELS[activeTab] || activeTab}** tab — how can I help?` },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const chatEnd = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { chatEnd.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  // Update welcome message when tab changes
  useEffect(() => {
    if (open) {
      setMsgs(prev => {
        const filtered = prev.filter(m => m.id !== "welcome");
        return [{
          id: "welcome", role: "gsk" as const,
          text: `I'm GSK, your creation copilot. You're in the **${TAB_LABELS[activeTab] || activeTab}** tab — what would you like help with?`,
          actions: QUICK_ACTIONS[activeTab] || QUICK_ACTIONS[exportActive(activeTab)],
        }, ...filtered];
      });
    }
  }, [activeTab, open]);

  function exportActive(t: string): string | undefined {
    return t === "profile" || t === "skills" ? "export" : undefined;
  }

  const callGsk = async (context: string, action: string, data?: any) => {
    setLoading(true);
    try {
      const res = await fetch("/api/gsk/copilot", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ context, action, data: data || contextData }),
      });
      const result = await res.json();
      const text = result.reply || result.raw || "GSK is thinking...";

      const actions: { label: string; action: string; data?: any }[] = [];
      if (result.suggestions) actions.push({ label: "Apply suggestion", action: "apply", data: result });
      if (result.ideas) actions.push({ label: "Use these ideas", action: "use-ideas", data: result });

      setMsgs(prev => [...prev, { id: `gsk-${Date.now()}`, role: "gsk", text, actions, }]);
      return result;
    } catch (e: any) {
      setMsgs(prev => [...prev, { id: `gsk-${Date.now()}`, role: "gsk", text: `Error: ${e.message}` }]);
    }
    setLoading(false);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    const userMsg = input;
    setInput("");
    setMsgs(prev => [...prev, { id: `usr-${Date.now()}`, role: "user", text: userMsg }]);
    setLoading(true);

    const context = activeTab === "marketplace" ? "marketplace" : activeTab === "skills" ? "skill" : "character";
    await callGsk(context, userMsg);
    setLoading(false);
  };

  const handleQuickAction = async (action: string, label: string) => {
    const context = activeTab === "marketplace" ? "marketplace" : activeTab === "skills" ? "skill" : "character";
    setMsgs(prev => [...prev, { id: `usr-${Date.now()}`, role: "user", text: `→ ${label}` }]);
    await callGsk(context, action);
    setLoading(false);
  };

  const handleFile = async (file: File) => {
    setLoading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve((reader.result as string).split(",")[1]);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Read the file via the soul
      const readRes = await fetch("/api/soul/read-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: file.name, type: file.type, data: base64 })
      });
      const fileData = await readRes.json();

      // Show file in chat
      let filePreview = `📎 **${file.name}** (${(file.size / 1024).toFixed(1)} KB) — ${fileData.fileType || "file"}`;
      if (fileData.fileType === "image" && fileData.preview) {
        filePreview += `\n\n![${file.name}](${fileData.preview})`;
      }
      setMsgs(prev => [...prev, { id: `file-${Date.now()}`, role: "user", text: filePreview }]);

      // Ask GSK to analyze it
      const context = activeTab === "marketplace" ? "marketplace" : activeTab === "skills" ? "skill" : "character";
      const content = fileData.content || fileData.contents?.join("\n") || JSON.stringify(fileData).slice(0, 3000);
      await callGsk(context, `I uploaded a file: ${file.name} (${fileData.fileType}). Here is its content:\n\n${content.slice(0, 8000)}\n\nPlease analyze this and tell me what you see.`);
    } catch (e: any) {
      setMsgs(prev => [...prev, { id: `err-${Date.now()}`, role: "gsk", text: `File error: ${e.message}` }]);
    }
    setLoading(false);
  };

  const quickActions = QUICK_ACTIONS[activeTab] || [];

  return (
    <>
      {/* Floating button */}
      <button onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 shadow-xl hover:shadow-pink-500/30 hover:scale-105 transition-all flex items-center justify-center cursor-pointer group"
        title="GSK Copilot">
        {open ? <X className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
        {!open && <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-900 animate-pulse" />}
      </button>

      {/* Panel */}
      {open && (
        <div className="fixed bottom-20 right-6 z-50 w-80 sm:w-96 h-[500px] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden backdrop-blur-xl">
          {/* Header */}
          <div className="bg-gradient-to-r from-pink-600/20 to-purple-600/20 border-b border-slate-700/80 px-4 py-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="text-sm font-bold text-white">GSK Copilot</span>
                <span className="text-[10px] text-slate-400 block leading-tight">Creation assistant · {TAB_LABELS[activeTab]}</span>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white cursor-pointer p-1"><X className="w-4 h-4" /></button>
          </div>

          {/* Quick actions */}
          {quickActions.length > 0 && (
            <div className="px-3 py-2 border-b border-slate-800 flex gap-1.5 overflow-x-auto shrink-0">
              {quickActions.map(qa => (
                <button key={qa.action} onClick={() => handleQuickAction(qa.action, qa.label)}
                  className="flex items-center gap-1 px-2 py-1 bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/40 rounded-lg text-[10px] font-mono text-slate-300 whitespace-nowrap cursor-pointer transition shrink-0">
                  <Lightbulb className="w-3 h-3 text-amber-400" />
                  {qa.label}
                </button>
              ))}
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 text-[12px]">
            {msgs.map(m => (
              <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-xl px-3 py-2 leading-relaxed ${
                  m.role === "user"
                    ? "bg-pink-600/20 border border-pink-700/30 text-slate-200"
                    : "bg-slate-800/50 border border-slate-700/30 text-slate-300"
                }`}>
                  <div className="whitespace-pre-wrap text-[12px]" dangerouslySetInnerHTML={{ __html: m.text.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>').replace(/\n/g, "<br/>") }} />
                  {m.actions && m.actions.length > 0 && (
                    <div className="flex gap-1.5 mt-2 pt-2 border-t border-slate-700/30">
                      {m.actions.map(a => (
                        <button key={a.label} onClick={() => handleQuickAction(a.action, a.label)}
                          className="text-[10px] px-2 py-0.5 bg-pink-600/20 hover:bg-pink-600/30 border border-pink-700/30 rounded text-pink-300 font-mono cursor-pointer transition">
                          {a.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <Loader2 className="w-3 h-3 animate-spin text-pink-400" />
                GSK is thinking...
              </div>
            )}
            <div ref={chatEnd} />
          </div>

          {/* Input */}
          <form onSubmit={handleSend} className="p-3 border-t border-slate-800 shrink-0 flex gap-2">
            <input ref={fileInputRef} type="file" multiple={false} onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); if (fileInputRef.current) fileInputRef.current.value = ""; }} className="hidden" />
            <button type="button" onClick={() => fileInputRef.current?.click()} disabled={loading}
              className="p-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded-xl text-slate-400 hover:text-emerald-400 cursor-pointer transition shrink-0">
              <Paperclip className="w-4 h-4" />
            </button>
            <input type="text" value={input} onChange={e => setInput(e.target.value)}
              placeholder={`Ask GSK about ${TAB_LABELS[activeTab]}...`}
              disabled={loading}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none placeholder:text-slate-500 disabled:opacity-50" />
            <button type="submit" disabled={loading || !input.trim()}
              className="p-2 bg-pink-600 hover:bg-pink-500 disabled:opacity-50 rounded-xl text-white cursor-pointer transition shrink-0">
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
