const fs = require('fs');
const path = require('path');
const { BrainEngine } = require('C:\\Users\\uncom\\Desktop\\brain-in-a-box\\lib\\brain-engine.js');
const brain = new BrainEngine();
const docs = JSON.parse(fs.readFileSync(require('os').homedir() + '/.plt-docs.json', 'utf8'));

let total = 0, skipped = 0;
for (const [name, text] of Object.entries(docs)) {
    const title = name.replace(/_/g, ' ').replace('.docx', '').replace('BN', '').trim();
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 40);
    
    for (const sentence of sentences.slice(0, 100)) {
        const clean = sentence.trim().slice(0, 500);
        if (clean.length < 30) { skipped++; continue; }
        const q = 'What does ' + title + ' say — ' + clean.slice(0, 60).replace(/"/g, '');
        brain.learn(q, clean);
        total++;
        if (total % 100 === 0) process.stdout.write('.');
    }
    
    brain.remember(title + ': ' + text.slice(0, 10000), 'plt-doctrine');
}

console.log('\nIngested: ' + total + ' entries');
console.log('Skipped: ' + skipped);
console.log('Total learned: ' + brain.knowledge.learned.length);
console.log('Vector memories: ' + brain.vectorMemory.length);

const statePath = 'C:\\Users\\uncom\\Desktop\\brain-in-a-box\\data\\plt-ingested.json';
try {
    if (!fs.existsSync(path.dirname(statePath))) fs.mkdirSync(path.dirname(statePath), { recursive: true });
    fs.writeFileSync(statePath, JSON.stringify({
        documents: Object.keys(docs),
        totalEntries: total,
        learnedEntries: brain.knowledge.learned.length,
        vectorMemories: brain.vectorMemory.length,
        ingestedAt: new Date().toISOString()
    }, null, 2));
    console.log('State saved to: ' + statePath);
} catch(e) { console.log('Save error: ' + e.message); }
