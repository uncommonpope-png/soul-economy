import modal
import os
import subprocess
import json
import time
from pathlib import Path

app = modal.App("soul-debate-test")

# Node.js image with the debate soul files bundled
debate_soul_path = Path(r"C:\Users\uncom\Desktop\shopify-auto-setup\soul-debate")

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("nodejs", "npm", "curl")
    .run_commands("node --version", "npm --version")
)

@app.cls(
    image=image,
    container_idle_timeout=300,
    cpu=2,
    memory=2048,
    secrets=[modal.Secret.from_name("soul-keys", optional=True)],
)
class DebateSoulTest:
    def __init__(self):
        self.process = None
        self.port = 4170

    @modal.enter()
    def start_soul(self):
        """Boot the debate soul server"""
        # Write the soul files to /soul
        import shutil
        src = debate_soul_path
        dst = Path("/soul")
        shutil.copytree(src, dst, ignore=shutil.ignore_patterns('node_modules', '.git'))
        
        # Start the debate soul
        self.process = subprocess.Popen(
            ["node", "/soul/lib/soul-debate.js"],
            env={**os.environ, "PORT": str(self.port)},
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        # Wait for it to be ready
        time.sleep(3)

    @modal.exit()
    def stop_soul(self):
        if self.process:
            self.process.terminate()

    @modal.method()
    async def run_debate(self, topic: str, rounds: int = 3) -> dict:
        """Run a debate and return the result"""
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"http://127.0.0.1:{self.port}/debate",
                json={"topic": topic, "rounds": rounds},
                timeout=120
            )
            return resp.json()

    @modal.method()
    async def test_brain(self) -> dict:
        """Test the enhanced brain features"""
        import httpx
        results = {}
        async with httpx.AsyncClient() as client:
            # Test 1: Status
            resp = await client.get(f"http://127.0.0.1:{self.port}/status", timeout=10)
            results["status"] = resp.json()
            
            # Test 2: Forge a soul
            resp = await client.post(f"http://127.0.0.1:{self.port}/souls", json={
                "name": "Test Soul",
                "role": "Tester",
                "essence": "A soul for testing AI code and strategies",
                "plt": {"profit": 0.5, "love": 0.3, "tax": 0.2}
            }, timeout=10)
            results["forge"] = resp.json()
            
            # Test 3: Get souls
            resp = await client.get(f"http://127.0.0.1:{self.port}/souls", timeout=10)
            results["souls"] = len(resp.json().get("souls", []))
            
            # Test 4: PLT battle
            resp = await client.post(f"http://127.0.0.1:{self.port}/plt-battle", json={
                "proposerText": "We should invest in growth, build revenue, and scale the business aggressively. Profit drives everything.",
                "opposerText": "We need to balance growth with caution. The risks of over-expansion are real. Let's audit our costs first.",
                "rounds": 3
            }, timeout=10)
            results["plt_battle"] = {
                "winner": resp.json().get("battle", {}).get("winner"),
                "proposer_type": resp.json().get("proposerType"),
                "opposer_type": resp.json().get("opposerType")
            }
            
            # Test 5: PLT rules sync
            resp = await client.get(f"http://127.0.0.1:{self.port}/plt-rules", timeout=10)
            results["plt_rules"] = resp.json()

        return results

@app.local_entrypoint()
def test():
    """Run a quick test of the debate soul"""
    soul = DebateSoulTest()
    soul.start_soul.remote()
    
    print("Testing brain features...")
    brain_results = soul.test_brain.remote()
    print(json.dumps(brain_results, indent=2))
    
    print("\nRunning sample debate...")
    debate = soul.run_debate.remote("Should AI be open source?", 2)
    result = debate.result()
    print(f"Topic: {result.get('topic', 'N/A')}")
    if result.get('pltBattle'):
        b = result['pltBattle']
        print(f"PLT Battle: {b['proposerType']} vs {b['opposerType']} → {b['winner']} wins")
    if result.get('verdict'):
        print(f"Verdict winner: {result['verdict'].get('winner')}")
    print("All tests passed!")
