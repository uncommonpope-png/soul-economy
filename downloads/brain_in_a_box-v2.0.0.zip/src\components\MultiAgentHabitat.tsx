import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Users, Map, Sparkles, Send, Trash2, MessageSquare, Plus, Radio, Upload, Zap, Globe, Cpu, BrainCircuit, MessageCircleOff, History, CheckCircle2, Bot, Plug, Wifi, WifiOff } from "lucide-react";
import { AgentProfile } from "../types";

interface MultiAgentHabitatProps {
  primaryAgent: AgentProfile;
  accentColor: string;
}

interface HabitatAgent {
  id: string; name: string; icon: string; provider: string; model: string;
  color: string; role: string; configured: boolean; available: boolean; type: string;
  fallbackOffer?: boolean;
  x: number; y: number; speed: number;
}

interface HabitatMessage {
  id: string; senderName: string; avatarColor: string; text: string; timestamp: string;
}

interface HabitatSession {
  id: string; title: string; createdAt: string; participants: string[]; logs: HabitatMessage[];
}

const HABITAT_SCENES = [
  { id: "matrix", label: "Grid", color: "emerald" },
  { id: "cyber", label: "Cyber", color: "pink" },
  { id: "zen", label: "Zen", color: "indigo" },
  { id: "command", label: "Command", color: "slate" },
];

const MONOLOGUES: Record<string, string[]> = {
  "Google Gemini": ["Scanning multimodal context layers...", "Indexing visual and text signals...", "Correlating cross-modal patterns..."],
  "Groq": ["Running fast inference pass...", "Low-latency evaluation in progress...", "Llama kernel active..."],
  "OpenRouter Free": ["Routing through available models...", "Querying community endpoint...", "Selecting best path..."],
  "Cerebras": ["Wafer-scale processing...", "CS-2 engine active...", "Accelerating inference..."],
  "local": ["Querying GSK knowledge graph...", "Searching 1193 entries...", "N-gram pattern matching..."],
};

const FALLBACK_MONOLOGUES = [
  "No API key configured for this provider.",
  "Set your key in the API & Token Vault.",
  "Or use GSK Local Brain as fallback.",
];

export const MultiAgentHabitat: React.FC<MultiAgentHabitatProps> = ({ primaryAgent, accentColor }) => {
  const [agents, setAgents] = useState<HabitatAgent[]>([]);
  const [loadingAgents, setLoadingAgents] = useState(true);
  const [activeScene, setActiveScene] = useState("matrix");
  const [customBgUrl, setCustomBgUrl] = useState("");
  const [customBgInput, setCustomBgInput] = useState("");
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  const [sessions, setSessions] = useState<HabitatSession[]>(() => {
    const saved = localStorage.getItem("agent_workbench_multi_agent_sessions_v3");
    if (saved) { try { return JSON.parse(saved); } catch {} }
    return [];
  });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState("");
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [newSessionTitle, setNewSessionTitle] = useState("");
  const [newSessionParticipants, setNewSessionParticipants] = useState<string[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Fetch providers on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/habitat/providers");
        const data = await res.json();
        if (data.success && Array.isArray(data.agents)) {
          const positioned = data.agents.map((a: any, i: number) => ({
            ...a,
            x: 15 + (i % 4) * 22,
            y: 20 + Math.floor(i / 4) * 30,
            speed: 0.8 + Math.random() * 0.6,
          }));
          setAgents(positioned);
          if (!selectedAgentId && positioned.length > 0) setSelectedAgentId(positioned[0].id);
        }
      } catch (e) { console.error("Failed to fetch habitat agents", e); }
      setLoadingAgents(false);
    })();
  }, []);

  // Persist sessions
  useEffect(() => { localStorage.setItem("agent_workbench_multi_agent_sessions_v3", JSON.stringify(sessions)); }, [sessions]);

  // Float animation
  useEffect(() => {
    const interval = setInterval(() => {
      setAgents(prev => prev.map(a => ({
        ...a,
        x: Math.min(85, Math.max(10, a.x + (Math.random() - 0.5) * 2)),
        y: Math.min(85, Math.max(10, a.y + (Math.random() - 0.5) * 1.5)),
      })));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [sessions, activeSessionId]);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isSynthesizing || !activeSession) return;

    const currId = activeSession.id;
    const userMsg: HabitatMessage = {
      id: `m-host-${Date.now()}`,
      senderName: "You",
      avatarColor: "#475569",
      text: inputMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setSessions(prev => prev.map(s => s.id === currId ? { ...s, logs: [...s.logs, userMsg] } : s));
    const msg = inputMessage;
    setInputMessage("");
    setIsSynthesizing(true);

    try {
      const participants = agents.filter(a => activeSession.participants.includes(a.id));
      if (participants.length === 0) { setIsSynthesizing(false); return; }

      for (const agent of participants) {
        await new Promise(r => setTimeout(r, 1500));
        const res = await fetch("/api/habitat/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: msg, agentId: agent.id, profile: primaryAgent }),
        });
        const data = await res.json();
        const reply = data.note ? `⚠️ ${data.note}\n\n${data.reply}` : data.reply || "No response.";
        const agentMsg: HabitatMessage = {
          id: `m-${agent.id}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          senderName: agent.type === "local" ? "🧬 GSK Local Brain" : agent.name,
          avatarColor: agent.color,
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };
        setSessions(prev => prev.map(s => s.id === currId ? { ...s, logs: [...s.logs, agentMsg] } : s));
      }
    } catch (e: any) {
      const errMsg: HabitatMessage = {
        id: `m-err-${Date.now()}`, senderName: "System", avatarColor: "#ef4444",
        text: `Error: ${e.message}`, timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setSessions(prev => prev.map(s => s.id === currId ? { ...s, logs: [...s.logs, errMsg] } : s));
    }
    setIsSynthesizing(false);
  };

  const handleDebate = async () => {
    if (!inputMessage.trim() || isSynthesizing || !activeSession) return;
    const topic = inputMessage;
    setInputMessage("");
    setIsSynthesizing(true);

    const debateMsg: HabitatMessage = {
      id: `m-debate-start-${Date.now()}`,
      senderName: "⚖️ Debate",
      avatarColor: "#ffaa44",
      text: `**Debate started**: "${topic}"\n\n⏳ Debate in progress...`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setSessions(prev => prev.map(s => s.id === activeSession.id ? { ...s, logs: [...s.logs, debateMsg] } : s));

    try {
      const res = await fetch("/api/debate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, rounds: 3 })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      let resultText = `## 🗳️ Debate Results\n\n**Topic**: ${data.topic}\n\n`;
      if (data.pltBattle) {
        resultText += `**PLT Battle**: ${data.pltBattle.proposerType} vs ${data.pltBattle.opposerType} — ${data.pltBattle.winner} wins\n`;
      }
      if (data.verdict?.statement) {
        resultText += `\n**Verdict**: ${data.verdict.statement.slice(0, 500)}`;
      }

      const resultMsg: HabitatMessage = {
        id: `m-debate-result-${Date.now()}`,
        senderName: "⚖️ Debate Result",
        avatarColor: "#ffaa44",
        text: resultText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setSessions(prev => prev.map(s => s.id === activeSession.id ? { ...s, logs: [...s.logs, resultMsg] } : s));
    } catch (e: any) {
      const errMsg: HabitatMessage = {
        id: `m-debate-err-${Date.now()}`, senderName: "⚖️ Debate", avatarColor: "#ff6080",
        text: `Debate failed: ${e.message}`, timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setSessions(prev => prev.map(s => s.id === activeSession.id ? { ...s, logs: [...s.logs, errMsg] } : s));
    }
    setIsSynthesizing(false);
  };

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSessionTitle.trim() || newSessionParticipants.length === 0) return;
    const id = `session-${Date.now()}`;
    const sess: HabitatSession = {
      id, title: newSessionTitle,
      createdAt: new Date().toISOString().replace("T", " ").substring(0, 16),
      participants: [...newSessionParticipants],
      logs: [{
        id: `msg-seed-${Date.now()}`,
        senderName: "System Core",
        avatarColor: "#64748b",
        text: `🌌 Session started with: ${newSessionParticipants.map(id => agents.find(a => a.id === id)?.name || id).join(", ")}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }],
    };
    setSessions(prev => [sess, ...prev]);
    setActiveSessionId(id);
    setNewSessionTitle("");
    setIsCreatingSession(false);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = sessions.filter(s => s.id !== id);
    setSessions(updated);
    if (activeSessionId === id) setActiveSessionId(updated[0]?.id || null);
  };

  const getMonologue = (id: string): string => {
    const ag = agents.find(a => a.id === id);
    if (!ag) return "";
    if (!ag.configured) return FALLBACK_MONOLOGUES[Math.floor(Math.random() * FALLBACK_MONOLOGUES.length)];
    const pool = MONOLOGUES[ag.name] || MONOLOGUES[ag.provider] || ["Processing..."];
    return pool[Math.floor(Math.random() * pool.length)];
  };

  const canvasAgents = activeSession ? agents.filter(a => activeSession.participants.includes(a.id)) : agents.slice(0, 4);

  if (loadingAgents) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm font-mono">
        Loading available agents from provider vault...
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 text-slate-100 items-stretch flex-1">
      {/* Sessions panel */}
      <div className="xl:col-span-3 flex flex-col space-y-4 h-full">
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4.5 shadow-2xl flex flex-col h-[670px] overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-amber-500" />
              <div>
                <h3 className="font-display font-bold text-sm text-white">Sessions</h3>
                <p className="text-[10px] text-slate-450 font-sans">Persistent chat logs</p>
              </div>
            </div>
            <button onClick={() => setIsCreatingSession(!isCreatingSession)}
              className="p-1 px-1.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-xs rounded-lg text-amber-500 flex items-center gap-1 transition cursor-pointer">
              <Plus className="w-3.5 h-3.5" /> New
            </button>
          </div>

          <AnimatePresence mode="wait">
            {isCreatingSession ? (
              <motion.form key="create-session" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onSubmit={handleCreateSession} className="bg-slate-950/80 border border-slate-850 rounded-xl p-3 flex flex-col space-y-3">
                <div className="text-[10px] font-mono text-amber-500 font-bold uppercase">Configure Session</div>
                <input type="text" required value={newSessionTitle} onChange={e => setNewSessionTitle(e.target.value)}
                  placeholder="Session title" className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-2 text-xs outline-none text-slate-200 placeholder:text-slate-650" />
                <div>
                  <label className="block text-[9px] text-slate-500 font-mono uppercase mb-1">Participants</label>
                  <div className="space-y-1 max-h-[160px] overflow-y-auto">
                    {agents.map(ag => {
                      const sel = newSessionParticipants.includes(ag.id);
                      return (
                        <button key={ag.id} type="button" onClick={() => setNewSessionParticipants(prev => sel ? prev.filter(id => id !== ag.id) : [...prev, ag.id])}
                          className={`w-full flex items-center justify-between p-1.5 px-2 rounded-lg border text-left text-xs transition cursor-pointer ${
                            sel ? "bg-amber-950/20 border-amber-500/30 text-slate-200" : "bg-slate-900/40 border-slate-850 text-slate-400"
                          }`}>
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: ag.color }} />
                            <span className="truncate max-w-[120px]">{ag.name}</span>
                          </div>
                          <span className="text-[9px] text-slate-500">{ag.configured ? "online" : "offline"}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <button type="submit" disabled={newSessionParticipants.length === 0 || !newSessionTitle.trim()}
                  className="w-full py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-mono font-bold uppercase rounded-lg transition cursor-pointer">
                  Start Session
                </button>
              </motion.form>
            ) : (
              <motion.div key="sessions-list" initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="flex-1 overflow-y-auto space-y-2 pr-1">
                {sessions.length === 0 && (
                  <div className="text-center py-8 text-slate-500 text-xs font-mono">
                    No sessions. Create one to chat with your agents.
                  </div>
                )}
                {sessions.map(s => {
                  const isActive = s.id === activeSessionId;
                  return (
                    <div key={s.id} onClick={() => { setActiveSessionId(s.id); }}
                      className={`group p-3 rounded-xl border text-left transition relative cursor-pointer ${
                        isActive ? "bg-slate-950 border-amber-500/25 shadow-lg" : "bg-slate-900/30 border-slate-850 hover:bg-slate-900/60"
                      }`}>
                      <div className="flex justify-between items-start gap-2">
                        <span className={`text-[12px] font-semibold ${isActive ? "text-white" : "text-slate-300"}`}>{s.title}</span>
                        <button onClick={e => handleDeleteSession(s.id, e)}
                          className="text-slate-600 hover:text-red-400 p-0.5 opacity-0 group-hover:opacity-100 transition cursor-pointer"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex -space-x-1.5">
                          {s.participants.map(pId => {
                            const p = agents.find(a => a.id === pId);
                            if (!p) return null;
                            return <div key={pId} className="w-4 h-4 rounded-full border border-slate-950 flex items-center justify-center font-bold text-[7px]"
                              style={{ backgroundColor: p.color, color: "#fff" }} title={p.name}>{p.name.substring(0, 1).toUpperCase()}</div>;
                          })}
                        </div>
                        <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                          <MessageSquare className="w-3 h-3 text-amber-500" />{s.logs.length} msgs
                        </span>
                      </div>
                      <span className="text-[8px] text-slate-600 font-mono uppercase">{s.createdAt}</span>
                    </div>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Canvas */}
      <div className="xl:col-span-5 flex flex-col space-y-4 h-full">
        <div className="bg-slate-900/60 border border-slate-800/85 backdrop-blur-md rounded-2xl p-4.5 shadow-2xl relative flex flex-col overflow-hidden h-[465px]">
          {/* Scene backgrounds */}
          {activeScene === "matrix" && <div className="absolute inset-0 bg-[#050512] opacity-80 pointer-events-none"><div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(16,185,129,0.06),transparent_80%)] animate-pulse" /><div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[size:100%_4px]" /></div>}
          {activeScene === "cyber" && <div className="absolute inset-0"><div className="absolute inset-0 bg-gradient-to-tr from-pink-500/10 via-purple-950/20 to-slate-950 opacity-95" /><div className="absolute bottom-0 w-full h-1/3 bg-[linear-gradient(transparent,#ec489918)]" /></div>}
          {activeScene === "zen" && <div className="absolute inset-0 bg-[#070912] opacity-90"><div className="absolute top-1/4 left-1/4 w-60 h-60 bg-teal-500/5 rounded-full blur-3xl animate-pulse" /><div className="absolute bottom-10 right-10 w-82 h-82 bg-purple-500/5 rounded-full blur-3xl animate-pulse" /></div>}
          {activeScene === "command" && <div className="absolute inset-0 bg-slate-950/95"><div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" /><div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(148,163,184,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.02)_1px,transparent_1px)] bg-[size:2rem_2rem]" /></div>}
          {activeScene === "custom" && customBgUrl && <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${customBgUrl})` }}><div className="absolute inset-0 bg-slate-950/70 backdrop-blur-[1px]" /></div>}

          <div className="relative z-10 flex justify-between items-center border-b border-slate-800/60 pb-2.5 mb-1.5">
            <div className="flex items-center gap-2">
              <Radio className="w-3.5 h-3.5 text-pink-400 animate-ping" />
              <span className="font-mono text-[9.5px] font-bold text-slate-200 uppercase">{activeScene} stage</span>
            </div>
            <div className="flex items-center gap-1 font-mono text-[8.5px] bg-slate-950/85 p-1 border border-slate-850 rounded">
              {HABITAT_SCENES.map(s => (
                <button key={s.id} onClick={() => setActiveScene(s.id)}
                  className={`px-1.5 py-0.5 rounded transition cursor-pointer ${
                    activeScene === s.id
                      ? `bg-${s.color}-950 text-${s.color}-400 border border-${s.color}-900/60`
                      : "text-slate-550 hover:text-slate-300"
                  }`}>{s.label}</button>
              ))}
            </div>
          </div>

          <div className="flex-1 relative z-10 min-h-[300px]">
            {canvasAgents.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
                <MessageCircleOff className="w-8 h-8 text-slate-600 mb-2" />
                <p className="font-mono text-xs text-slate-500">No agents in this session.</p>
                <button onClick={() => setIsCreatingSession(true)}
                  className="mt-3 px-3 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10px] font-mono rounded text-amber-500 cursor-pointer">
                  Create a session
                </button>
              </div>
            ) : (
              canvasAgents.map(ag => {
                const isSelected = selectedAgentId === ag.id;
                const isOffline = ag.type === "offline" || !ag.configured;
                return (
                  <motion.div key={ag.id} className="absolute cursor-pointer group"
                    animate={{ x: `${ag.x}%`, y: `${ag.y}%` }}
                    transition={{ type: "spring", stiffness: 35, damping: 14 }}
                    onClick={() => setSelectedAgentId(ag.id)}>
                    <div className={`absolute -inset-3.5 rounded-full filter blur-md opacity-25 group-hover:opacity-60 transition ${
                      isSelected ? "animate-pulse" : "" }`}
                      style={{ backgroundColor: isOffline ? "#64748b" : ag.color,
                        boxShadow: isSelected ? `0 0 16px 6px ${isOffline ? "#64748b" : ag.color}` : "none" }} />
                    <div className={`relative w-11 h-11 rounded-full border flex items-center justify-center font-bold tracking-tight text-white transition-all text-[12px] ${
                      isOffline ? "bg-slate-800/80" : "bg-slate-950/95" }`}
                      style={{ borderColor: isSelected ? (isOffline ? "#64748b" : ag.color) : "#1e293b",
                        transform: isSelected ? "scale(1.15)" : "scale(1)" }}>
                      {ag.name.substring(0, 2).toUpperCase()}
                      <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full border border-slate-950"
                        style={{ backgroundColor: isOffline ? "#64748b" : ag.color }} />
                    </div>
                    <div className="absolute top-12 left-1/2 -translate-x-1/2 bg-slate-950 border border-slate-850 p-1 px-2 rounded pointer-events-none shadow-xl select-none text-center whitespace-nowrap">
                      <p className="text-[9.5px] font-mono font-bold text-slate-200">{ag.name}</p>
                      <p className="text-[7.5px] text-slate-500">{isOffline ? "⚡ Use GSK Brain?" : ag.role}</p>
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>

          <form onSubmit={(e) => { e.preventDefault(); if (customBgInput.trim()) { setCustomBgUrl(customBgInput); setActiveScene("custom"); } }}
            className="relative z-10 mt-2 p-1.5 bg-slate-950/90 border border-slate-850/80 rounded-xl flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <input type="text" placeholder="Custom background URL..." value={customBgInput} onChange={e => setCustomBgInput(e.target.value)}
              className="w-full bg-transparent border-none text-[10px] text-slate-400 outline-none placeholder:text-slate-650" />
            <button type="submit" className="px-2.5 py-1 bg-slate-900 border border-slate-800 text-[9px] font-mono rounded cursor-pointer hover:border-slate-700 transition">Set</button>
          </form>
        </div>

        {/* Monologue trace */}
        <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-4 h-4 text-pink-400" />
            <span className="font-mono text-xs text-slate-300 font-bold uppercase">
              Agent Trace: <span style={{ color: agents.find(a => a.id === selectedAgentId)?.color || "#f97316" }}>
                {agents.find(a => a.id === selectedAgentId)?.name || "Unknown"}
              </span>
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-850 p-3 rounded-lg font-mono text-[10.5px] text-slate-400 min-h-[35px]">
            {getMonologue(selectedAgentId || "")}
          </div>
        </div>
      </div>

      {/* Chat panel */}
      <div className="xl:col-span-4 flex flex-col space-y-4 h-full">
        <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-4.5 shadow-2xl relative flex flex-col h-[670px]">
          <div className="flex items-center gap-2 border-b border-slate-805 pb-3 mb-2.5 shrink-0">
            <Bot className="w-5 h-5 text-amber-500" />
            <div>
              <h3 className="font-display font-bold text-sm text-white">Agent Chat</h3>
              <p className="text-[10px] text-slate-500 font-sans">Real responses from configured providers</p>
            </div>
          </div>

          {/* Participant tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 shrink-0 scrollbar-thin border-b border-slate-900">
            {activeSession ? agents.filter(a => activeSession.participants.includes(a.id)).map(ag => {
              const isSel = selectedAgentId === ag.id;
              return (
                <button key={ag.id} onClick={() => setSelectedAgentId(ag.id)}
                  className={`flex items-center gap-1.5 p-1 px-2.5 border rounded-lg text-[10px] font-mono tracking-wider transition-all cursor-pointer whitespace-nowrap uppercase ${
                    isSel ? "bg-slate-950 text-white font-bold" : "bg-slate-900/30 border-slate-850 text-slate-500 hover:text-slate-350"
                  }`} style={{ borderColor: isSel ? ag.color : "transparent" }}>
                  <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: ag.color }} />
                  {ag.name}
                </button>
              );
            }) : <span className="text-[10px] text-slate-600 font-mono">No active session</span>}
          </div>

          <div className="flex-1 min-h-0 flex flex-col justify-between">
            <div className="flex-1 overflow-y-auto space-y-4 mb-3.5 pr-1 text-left scrollbar-thin">
              {activeSession ? activeSession.logs.map(m => {
                const isHost = m.senderName === "You";
                const isSys = m.senderName === "System Core";
                if (isSys) {
                  return <div key={m.id} className="py-2.5 px-3 border border-slate-850 bg-slate-950/60 rounded-xl text-[11px] text-slate-400 font-mono">{m.text}</div>;
                }
                return (
                  <div key={m.id} className={`flex flex-col ${isHost ? "items-end" : "items-start"}`}>
                    <div className="flex items-center gap-1.5 mb-1 text-[10px] font-mono text-slate-500 font-bold">
                      {!isHost && <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: m.avatarColor }} />}
                      <span>{m.senderName}</span>
                      <span className="text-[8px] text-slate-650 font-medium">{m.timestamp}</span>
                    </div>
                    <div className={`max-w-[92%] text-[11.5px] rounded-xl px-3.5 py-2.5 font-sans leading-relaxed text-slate-300 whitespace-pre-wrap ${
                      isHost ? "bg-slate-800 border border-slate-700/80 rounded-tr-none shadow-md" : "bg-slate-950 border border-slate-850 rounded-tl-none"
                    }`} style={{ borderLeftColor: !isHost ? m.avatarColor : undefined, borderLeftWidth: !isHost ? "2.5px" : "1px" }}>
                      {m.text}
                    </div>
                  </div>
                );
              }) : (
                <div className="text-center py-20 font-mono text-slate-500 text-xs">
                  Select a session or create one to start chatting.
                </div>
              )}
              {isSynthesizing && (
                <div className="flex items-center gap-2 text-[10px] font-mono text-amber-500 p-1.5 bg-amber-950/10 border border-amber-900/35 rounded-lg animate-pulse">
                  <Zap className="w-3.5 h-3.5 animate-spin" />
                  <span>Agents responding...</span>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {activeSession && (
              <form onSubmit={handleSendMessage} className="bg-slate-950 border border-slate-850 rounded-xl p-2 flex items-center gap-2 shrink-0">
                <input type="text" value={inputMessage} onChange={e => setInputMessage(e.target.value)}
                  disabled={isSynthesizing}
                  placeholder={`Message ${agents.find(a => a.id === selectedAgentId)?.name || "agents"}...`}
                  className="w-full bg-transparent border-none py-2 px-3 text-xs text-slate-100 outline-none placeholder:text-slate-650 disabled:opacity-50" />
                <button type="submit" disabled={isSynthesizing || !inputMessage.trim()}
                  className="p-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg cursor-pointer disabled:opacity-50 transition border border-amber-500">
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
