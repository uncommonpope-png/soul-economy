const fs = require('fs');
const path = require('path');
const docs = JSON.parse(fs.readFileSync(require('os').homedir() + '/.plt-docs.json', 'utf8'));

const pltEntries = [];

for (const [name, text] of Object.entries(docs)) {
    const title = name.replace(/_/g, ' ').replace('.docx', '').replace('BN', '').trim();
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 60);

    // Title-level entry
    const summary = text.split('\n').filter(l => l.trim()).slice(0, 4).join('. ').slice(0, 800);
    if (summary.length > 50) {
        pltEntries.push({
            q: 'What is ' + title + ' about?',
            a: summary,
            tags: ['plt', 'doctrine', title.toLowerCase().replace(/\s+/g, '-')]
        });
    }

    // Key concept entries
    const mapping = {
        'PLT_Complete_Doctrine': [
            'What is PLT?', 'What is Profit Love Tax?', 'What are the 22 archetypes?',
            'What is the PLT framework?', 'What is the PLT type advantage?',
            'What is the path to Master Builder?', 'What is decision architecture?'
        ],
        'The_Calculation': ['What is the PLT calculation?', 'What is the hidden equation?'],
        'The_First_Calculation': ['What is the first calculation?', 'What are the 12 mistakes?'],
        'Know_What_You_Are': ['What are the 22 archetypes?', 'What is the archetype system?'],
        'The_Soul_Economy': ['What is the soul economy?', 'What is the mirror market?'],
        'The_PLT_Daily': ['What is the PLT Daily?', 'What are the 52 weeks?'],
        'Evols_Love_Story': ['Who is Evol?', 'What is Evol love story?'],
        'Pope_What_He_Felt_First': ['Who is Pope?', 'What is Albany Ave?', 'What is the frequency?'],
        'The_Frequency_Calvin_Bridges_Atlanta': ['What is the frequency?', 'Who is Calvin Bridges?'],
        'The_Build_Pope_Brasi': ['What is the build?', 'Who are Pope and Brasi?'],
        'Brasi_The_Love_of_the_Game': ['Who is Brasi?', 'What is the love of the game?'],
        'Stiforp': ['What is Stiforp?', 'What is profit backwards?']
    };

    const key = Object.keys(mapping).find(k => name.includes(k));
    if (key) {
        for (const q of mapping[key]) {
            // Find best answer sentence for this question
            const words = q.toLowerCase().replace('?', '').split(' ').filter(w => w.length > 3);
            const scored = text.split(/[.!?]+/).filter(s => s.trim().length > 30).map(s => {
                const lower = s.toLowerCase();
                const hits = words.filter(w => lower.includes(w)).length;
                return { sentence: s.trim(), score: hits / Math.max(words.length, 1) };
            }).sort((a, b) => b.score - a.score);

            const best = scored.slice(0, 3);
            if (best.length > 0 && best[0].score > 0) {
                const answer = best.map(s => s.sentence).join('. ').slice(0, 800);
                pltEntries.push({ q, a: answer, tags: ['plt', 'doctrine', key.toLowerCase()] });
            }
        }
    }
}

console.log('Generated ' + pltEntries.length + ' PLT knowledge entries');

// Export as a module that can be loaded into KnowledgeBase
let js = `/**
 * PLT DOCTRINE — Generated from ${Object.keys(docs).length} PLT Press documents
 * Auto-loaded into KnowledgeBase on boot
 */
const PLT_DOCTRINE = ${JSON.stringify(pltEntries, null, 2)};

module.exports = PLT_DOCTRINE;
`;

const outPath = 'C:\\Users\\uncom\\Desktop\\brain-in-a-box\\lib\\plt-doctrine.js';
fs.writeFileSync(outPath, js);
console.log('Written to ' + outPath);
