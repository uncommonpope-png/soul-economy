import modal
import json
import subprocess

app = modal.App("soul-brain-test")

# Use Image.add_local_dir to bundle the brain files
image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("nodejs", "npm")
    .add_local_dir(
        r"C:\Users\uncom\Desktop\brain-in-a-box\lib",
        remote_path="/brain/lib"
    )
)

@app.function(
    image=image,
    cpu=2,
    memory=2048,
    scaledown_window=300,
)
def test_vector_memory():
    """Test the enhanced brain's vector memory and cache"""
    js_test = """
    const { BrainEngine } = require('/brain/lib/brain-engine.js');
    const b = new BrainEngine();
    const results = {};

    // 1. Basic knowledge query
    const r1 = b.query('what is PLT');
    results.knowledge = {
        answer: (r1?.answer || '').slice(0, 100),
        source: r1?.source,
        confidence: r1?.confidence
    };

    // 2. Vector memory
    b.remember('The user prefers Python over JavaScript for backend work', 'episodic');
    b.remember('PLT stands for Profit Love Tax - the core framework', 'knowledge');
    b.remember('The project runs on Node.js with Express', 'episodic');
    const mem = b.recall('what language for backend', 3);
    results.vectorMemory = {
        stored: 3,
        found: mem.length,
        topScore: mem.length > 0 ? mem[0].score : 0,
        topMatch: mem.length > 0 ? mem[0].text.slice(0, 60) : null
    };

    // 3. Response cache
    b._setCached('what is profit', '', 'Profit means multiplying value and creating growth.');
    const cached = b._getCached('what is profit', '');
    results.cache = { hit: cached !== null, value: cached ? cached.slice(0, 40) : null };

    // 4. Pipeline
    const r2 = b.query('What language for backend development?');
    results.pipeline = {
        source: r2?.source,
        confidence: r2?.confidence,
        hadAnswer: !!r2?.answer
    };

    // 5. Stats
    const s = b.getStatus();
    results.stats = {
        knowledgeEntries: s.knowledgeEntries,
        vectorMemories: s.vectorMemory,
        cacheSize: s.cacheSize,
        nGramSize: s.nGramSize,
        totalQueries: s.totalQueries,
        localHits: s.localHits
    };

    console.log(JSON.stringify(results));
    """

    result = subprocess.run(["node", "-e", js_test], capture_output=True, text=True, timeout=30)
    output = result.stdout.strip()
    err = result.stderr.strip() if result.stderr else None
    parsed = json.loads(output) if output else {"error": "no output"}
    return {**parsed, "stderr": err}

@app.function(
    image=image,
    cpu=2,
    memory=2048,
    scaledown_window=300,
)
def test_skills():
    """Test that real skills can be loaded"""
    js_test = """
    const fs = require('fs'), path = require('path');
    const results = {};
    const skillsDir = '/brain/lib/gsk-core/skills';
    
    if (fs.existsSync(skillsDir)) {
        const files = fs.readdirSync(skillsDir).filter(f => f.endsWith('.js'));
        results.skillsFound = files.length;
        
        // Try loading a few
        try {
            const w = require(path.join(skillsDir, 'weather.js'));
            results.weather = typeof w.skill_weather === 'function';
        } catch(e) { results.weather = e.message.slice(0, 80); }
        try {
            const ws = require(path.join(skillsDir, 'web_search.js'));
            results.webSearch = typeof ws.skill_web_search === 'function';
        } catch(e) { results.webSearch = e.message.slice(0, 80); }
        try {
            const m = require(path.join(skillsDir, 'math_calc.js'));
            const res = m.skill_math_calc ? m.skill_math_calc({expression: '2+2'}) : null;
            results.mathCalc = res ? JSON.stringify(res).slice(0, 100) : 'not loaded';
        } catch(e) { results.mathCalc = e.message.slice(0, 80); }
    } else {
        results.skillsFound = 0;
        results.skillsDir = skillsDir;
        results.fsList = fs.readdirSync('/brain/lib').slice(0, 20);
    }
    
    console.log(JSON.stringify(results));
    """
    
    result = subprocess.run(["node", "-e", js_test], capture_output=True, text=True, timeout=15)
    output = result.stdout.strip()
    err = result.stderr.strip() if result.stderr else None
    
    try:
        return {**json.loads(output), "stderr": err}
    except:
        return {"output": output[:500], "stderr": err}

@app.function(
    image=image,
    cpu=2,
    memory=2048,
    scaledown_window=300,
)
def test_web_search():
    """Test web search skill actually fetches the web"""
    js_test = """
    const path = require('path');
    const ws = require('/brain/lib/gsk-core/skills/web_search.js');
    
    ws.skill_web_search({query: 'Node.js latest version 2026', maxResults: 3}).then(res => {
        const results = {
            status: res.status,
            resultCount: res.results?.length || 0,
            firstTitle: res.results?.[0]?.title?.slice(0, 80) || null,
            firstSnippet: res.results?.[0]?.snippet?.slice(0, 100) || null
        };
        console.log(JSON.stringify(results));
    }).catch(e => {
        console.log(JSON.stringify({error: e.message}));
    });
    """
    
    result = subprocess.run(["node", "-e", js_test], capture_output=True, text=True, timeout=20)
    output = result.stdout.strip()
    err = result.stderr.strip() if result.stderr else None
    try:
        return {**json.loads(output), "stderr": err}
    except:
        return {"output": output[:300], "stderr": err}

@app.local_entrypoint()
def run():
    print("\n🧠 Testing enhanced brain on Modal cloud...\n")
    
    print("1. Testing vector memory & cache...")
    r1 = test_vector_memory.remote()
    if r1:
        print(f"   Knowledge: {r1.get('knowledge', {}).get('source')} (confidence: {r1.get('knowledge', {}).get('confidence')})")
        vm = r1.get('vectorMemory', {})
        print(f"   Vector memory: {vm.get('stored')} stored, {vm.get('found')} recalled (best: {vm.get('topScore', 0):.3f})")
        print(f"   Cache: {'HIT' if r1.get('cache', {}).get('hit') else 'MISS'}")
        pipe = r1.get('pipeline', {})
        print(f"   Pipeline: {pipe.get('source')} (confidence: {pipe.get('confidence')})")
        stats = r1.get('stats', {})
        print(f"   Stats: {stats.get('knowledgeEntries')} KB entries, {stats.get('vectorMemories')} memories, {stats.get('cacheSize')} cached, {stats.get('localHits')} local hits")
    
    print("\n2. Testing skill loading...")
    r2 = test_skills.remote()
    if r2:
        print(f"   Skills found: {r2.get('skillsFound', 0)}")
        print(f"   Weather: {r2.get('weather')}")
        print(f"   Web search: {r2.get('webSearch')}")
        print(f"   Math calc: {r2.get('mathCalc')}")
    
    print("\n3. Testing web search (live)...")
    r3 = test_web_search.remote()
    if r3:
        print(f"   Status: {r3.get('status')}")
        print(f"   Results: {r3.get('resultCount')}")
        print(f"   First: {r3.get('firstTitle', '')[:60]}")
    
    print("\n✅ Brain tests complete!")
