import modal
import json
import time

app = modal.App("soul-marketplace-relay")
STALE_MS = 120000
peers = []
listings = []

async def relay_app(scope, receive, send):
    global peers
    if scope["type"] != "http":
        return

    path = scope.get("path", "/")
    method = scope.get("method", "GET")

    # Read body
    body = b""
    while True:
        msg = await receive()
        if msg["type"] == "http.request":
            body += msg.get("body", b"")
            if not msg.get("more_body", False):
                break
        elif msg["type"] == "http.disconnect":
            break

    # Clean stale
    cutoff = time.time() * 1000 - STALE_MS
    peers[:] = [p for p in peers if p.get("lastSeen", 0) > cutoff]

    status = 200
    resp = {"error": "not found"}

    try:
        if method == "POST" and path == "/api/register":
            if not body.strip():
                status, resp = 400, {"error": "empty body"}
            else:
                data = json.loads(body)
                pid = data.get("id")
                name = data.get("name")
                if not pid or not name:
                    status, resp = 400, {"error": "id and name required"}
                else:
                    now = time.time() * 1000
                    existing = next((p for p in peers if p["id"] == pid), None)
                    if existing:
                        existing["lastSeen"] = now
                    else:
                        peers.append({"id": pid, "name": name, "lastSeen": now, "firstSeen": now})
                    resp = {"success": True, "online": len(peers)}

        elif method == "GET" and path == "/api/peers":
            resp = {"peers": peers}

        elif method == "GET" and path == "/health":
            resp = {"ok": True, "online": len(peers)}

    except Exception as e:
        status, resp = 500, {"error": str(e)[:200]}

    resp_body = json.dumps(resp).encode()
    await send({"type": "http.response.start", "status": status, "headers": [
        (b"content-type", b"application/json"),
        (b"access-control-allow-origin", b"*"),
        (b"access-control-allow-headers", b"*"),
    ]})
    await send({"type": "http.response.body", "body": resp_body})

@app.function(
    image=modal.Image.debian_slim(),
    cpu=1, memory=512, scaledown_window=300,
)
@modal.asgi_app()
def relay():
    return relay_app
