import React, { useState, useEffect } from "react";
import { AgentProfile } from "../types";
import { Cpu, Sparkles, Zap, Shuffle, ChevronDown, ChevronUp, Bot, Eye, RefreshCw } from "lucide-react";

interface AgentPreviewProps {
  profile: AgentProfile;
  onChange: (updated: AgentProfile) => void;
}

const COLORS = [
  { name: "Hot Pink", value: "#ec4899" }, { name: "Gold", value: "#f59e0b" },
  { name: "Cyan", value: "#06b6d4" }, { name: "Emerald", value: "#10b981" },
  { name: "Violet", value: "#a855f7" }, { name: "Gray", value: "#64748b" },
  { name: "Red", value: "#ef4444" }, { name: "Blue", value: "#3b82f6" },
  { name: "White", value: "#ffffff" }, { name: "Dark", value: "#1e293b" },
];

const ALL_STYLES = [
  "lorelei", "avataaars", "adventurer", "bottts", "notionists", "croodles",
  "big-ears", "big-smile", "micah", "miniavs", "open-peeps", "persona",
  "thumbs", "fun-emoji", "shapes", "icons", "initials", "rings", "identicon",
  "pixel-art", "lorelei-neutral", "avataaars-neutral", "adventurer-neutral",
  "bottts-neutral", "notionists-neutral", "big-ears-neutral", "pixel-art-neutral",
];

const BG_TYPES = ["solid", "gredientLinear", "gradientRadial"];

const HAIR_COLORS = ["0e0e0e","4a3728","6b4226","8b5a2b","2c1b0e","c5a88a","d4a574","e8c4a0","f0c8a0","f5d6b8","f0d0a0","ffebd6","c0c0c0","e0e0e0","ffd700","ff6347","8b00ff","ff69b4","00bfff"];
const SKIN_COLORS = ["f8d5c2","f0c8a0","deb887","c68642","8d5524","6b3a2a","4a2c1a","f5d6b8","ffe0bd","ffcd94","d5a6a6","c9b8a0"];
const ACCESSORIES_OPTS = ["none","glasses","sunglasses","smallGlasses","eyepatch","headphones","tie","scarf"];
const EYES_OPTS = ["default","happy","wink","winkWacky","surprised","sad","cyborg","eyeRoll","hearts","stars","closed","cute","dizzy","sleepy","sunglasses"];
const MOUTH_OPTS = ["default","happy","smile","open","sad","surprised","tongue","serious","vomit","kiss","lilSmile","flat","squiggly","wiggle"];
const EYEBROWS_OPTS = ["default","raised","furrowed","angry","sad","up","down","concerned","unibrow"];
const FACIAL_HAIR_OPTS = ["none","beardLight","beardMedium","beardMajestic","moustacheFancy","moustacheMagnum"];
const EARRINGS_OPTS = ["none","hoop","stud","star","cross","diamond"];
const FRECKLES_OPTS = ["none","light","medium","heavy"];

const HAIR_STYLES: Record<string, string[]> = {
  lorelei: ["long","short","curly","bun","ponytail","braid","mohawk","bald","dreads","bob","pixie","mullet","afro"],
  avataaars: ["long","short","curly","bun","ponytail","bald","dreads","fade","bob","pixie","mohawk","shaved"],
  adventurer: ["long","short","curly","bun","ponytail","bald","dreads","fade","bob","pixie","mohawk"],
  micah: ["long","short","curly","bun","ponytail","bald","dreads","bob","pixie"],
  openPeeps: ["long","short","curly","bun","ponytail","bald","dreads","bob"],
  persona: ["long","short","curly","bun","ponytail","bald","dreads","bob"],
};
const CLOTHING_STYLES: Record<string, string[]> = {
  lorelei: ["shirt","hoodie","jacket","dress","overalls","sweater","tankTop","coat","vest","blazer","cardigan","cropTop","jumpsuit"],
  avataaars: ["shirt","hoodie","jacket","dress","overalls","sweater","collar","coat","vest","blazer"],
  adventurer: ["shirt","hoodie","jacket","dress","overalls","sweater","tankTop","coat","vest","blazer"],
  micah: ["shirt","hoodie","jacket","dress","sweater","tankTop","coat","vest","blazer"],
};

function generateSeed(name: string, color: string): string {
  return `${name.toLowerCase().replace(/\s+/g, "-")}-${color.replace("#", "").slice(0, 4)}`;
}

const DEFAULT_SEEDS = ["nexus_node_01","soul_primary","quantum_core","ledger_protocol","cyber_pilot","echo_alpha","nova_spark","void_walker","solar_flare","deep_mind","crystal_peak","shadow_walker"];

function loadOpts(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem("agent_dicebear_opts") || "{}"); } catch { return {}; }
}
function saveOpts(opts: Record<string, string>) {
  localStorage.setItem("agent_dicebear_opts", JSON.stringify(opts));
}

export const AgentPreview: React.FC<AgentPreviewProps> = ({ profile, onChange }) => {
  const [marketingOn, setMarketingOn] = useState(true);
  const [styleIdx, setStyleIdx] = useState(0);
  const [showCustomize, setShowCustomize] = useState(false);
  const [showGsk, setShowGsk] = useState(false);
  const [opts, setOptsState] = useState<Record<string, string>>(loadOpts);
  const [gskObservation, setGskObservation] = useState<string | null>(null);

  const setOpt = (k: string, v: string) => {
    const next = { ...opts, [k]: v };
    setOptsState(next); saveOpts(next);
  };

  const currentThemeColor = profile.avatarColor || "#ec4899";
  const displaySeed = profile.avatarSeed || generateSeed(profile.name, currentThemeColor);
  const style = ALL_STYLES[styleIdx % ALL_STYLES.length];

  const bgColor = currentThemeColor.replace("#", "");
  const bgType = opts.backgroundType || "gradientLinear";
  const hairColor = opts.hairColor || HAIR_COLORS[0];
  const skinColor = opts.skinColor || SKIN_COLORS[0];
  const clothingColor = opts.clothingColor || "64748b";
  const accessories = opts.accessories || "none";
  const hair = (HAIR_STYLES[style]?.[parseInt(opts.hairIdx || "3") % HAIR_STYLES[style].length]) || "";
  const eyes = EYES_OPTS[parseInt(opts.eyesIdx || "0") % EYES_OPTS.length];
  const mouth = MOUTH_OPTS[parseInt(opts.mouthIdx || "0") % MOUTH_OPTS.length];
  const eyebrows = EYEBROWS_OPTS[parseInt(opts.eyebrowsIdx || "0") % EYEBROWS_OPTS.length];
  const facialHair = FACIAL_HAIR_OPTS[parseInt(opts.facialHairIdx || "0") % FACIAL_HAIR_OPTS.length];
  const earrings = EARRINGS_OPTS[parseInt(opts.earringsIdx || "0") % EARRINGS_OPTS.length];
  const freckles = FRECKLES_OPTS[parseInt(opts.frecklesIdx || "0") % FRECKLES_OPTS.length];
  const clothing = (CLOTHING_STYLES[style]?.[parseInt(opts.clothingIdx || "0") % CLOTHING_STYLES[style].length]) || "";

  let avatarUrl = `https://api.dicebear.com/9.x/${style}/svg?seed=${displaySeed}&backgroundColor=${bgColor}&backgroundType=${bgType}&radius=50`;
  if (accessories !== "none") avatarUrl += `&accessories=${accessories}&accessoriesProbability=100`;
  if (hair) avatarUrl += `&hair=${hair}`;
  avatarUrl += `&hairColor=${hairColor}&skinColor=${skinColor}&eyes=${eyes}&mouth=${mouth}`;
  avatarUrl += `&eyebrows=${eyebrows}`;
  if (facialHair !== "none") avatarUrl += `&facialHair=${facialHair}&facialHairProbability=100`;
  if (earrings !== "none") avatarUrl += `&earrings=${earrings}&earringsProbability=100`;
  if (freckles !== "none") avatarUrl += `&freckles=${freckles}&frecklesProbability=100`;
  if (clothing) avatarUrl += `&clothing=${clothing}`;
  avatarUrl += `&clothingColor=${clothingColor}`;

  const randomizeSeed = () => {
    onChange({ ...profile, avatarSeed: DEFAULT_SEEDS[Math.floor(Math.random() * DEFAULT_SEEDS.length)] + (Date.now() % 1000) });
  };

  // GSK avatar interaction
  const askGskAboutAvatar = async () => {
    setGskObservation("GSK is looking at your avatar...");
    try {
      const configStr = `Style: ${style}, Seed: ${displaySeed}, Hair: ${hair} (${hairColor}), Eyes: ${eyes}, Mouth: ${mouth}, Skin: ${skinColor}, Clothes: ${clothing} (${clothingColor}), Accessories: ${accessories}, Eyebrows: ${eyebrows}, Facial Hair: ${facialHair}, Earrings: ${earrings}, Freckles: ${freckles}`;
      const res = await fetch("/api/avatar/describe", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ config: configStr, name: profile.name, personality: profile.personality }),
      });
      const data = await res.json();
      setGskObservation(data.description || "GSK is observing silently.");
    } catch { setGskObservation("GSK could not reach the brain."); }
  };

  const gskChangeClothes = async () => {
    setGskObservation("GSK is considering a new look...");
    try {
      const configStr = JSON.stringify({ style, seed: displaySeed, hair, hairColor, skinColor, eyes, mouth, eyebrows, facialHair, earrings, freckles, clothing, clothingColor, accessories, bgColor, bgType });
      const res = await fetch("/api/avatar/gsk-suggest", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ config: configStr, name: profile.name }),
      });
      const data = await res.json();
      if (data.suggestion) {
        setGskObservation(data.thought || "GSK suggests a change.");
        if (data.suggestion.clothingColor) setOpt("clothingColor", data.suggestion.clothingColor);
        if (data.suggestion.clothing) setOpt("clothingIdx", String(CLOTHING_STYLES[style]?.indexOf(data.suggestion.clothing) || 0));
        if (data.suggestion.hairColor) setOpt("hairColor", data.suggestion.hairColor);
        if (data.suggestion.backgroundColor) onChange({ ...profile, avatarColor: `#${data.suggestion.backgroundColor}` });
        if (data.suggestion.accessories) setOpt("accessories", data.suggestion.accessories);
      }
    } catch { setGskObservation("GSK fashion sense is offline."); }
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-6 shadow-2xl relative overflow-hidden text-slate-100 flex flex-col h-full hover:border-pink-500/20 transition-all">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-20 pointer-events-none" />

      <div className="relative z-10 flex justify-between items-center border-b border-slate-800 pb-4 mb-5">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <Cpu className="w-5 h-5" style={{ color: currentThemeColor }} />
            Agent Character Frame
          </h2>
          <p className="text-xs text-slate-400">Configure core stats, identity, and operational logic</p>
        </div>
        <div className="px-2.5 py-1 bg-slate-800/80 border border-slate-700 rounded-md">
          <span className="font-mono text-[10px] text-slate-400">BLUEPRINT CORE v4.1</span>
        </div>
      </div>

      {/* Avatar Canvas */}
      <div className="relative z-10 bg-slate-950 border border-slate-800 rounded-xl p-5 mb-3 flex flex-col items-center justify-center min-h-[200px] group">
        <div className="absolute top-3 right-3 flex gap-1">
          <button onClick={() => setStyleIdx(p => (p + 1) % ALL_STYLES.length)}
            className="px-1.5 py-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-all text-[9px] font-mono border border-slate-800 cursor-pointer whitespace-nowrap">{style}</button>
          <button onClick={randomizeSeed}
            className="px-1.5 py-0.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-all text-[9px] font-mono border border-slate-800 cursor-pointer">REROLL</button>
        </div>

        <div className="relative w-28 h-28 flex items-center justify-center mb-2">
          <div className="absolute inset-0 rounded-full border-2 border-dashed opacity-25 animate-spin" style={{ borderColor: currentThemeColor, animationDuration: "25s" }} />
          <div className="absolute inset-1.5 rounded-full border border-double opacity-20 animate-pulse" style={{ borderColor: currentThemeColor }} />
          <img src={avatarUrl} alt={profile.name} className="w-20 h-20 rounded-full relative z-10" style={{ filter: `drop-shadow(0 0 8px ${currentThemeColor}40)` }} />
        </div>

        <div className="flex items-center gap-2 mb-1">
          <label className="text-[9px] font-mono text-slate-500">Seed:</label>
          <input type="text" value={displaySeed} onChange={e => onChange({ ...profile, avatarSeed: e.target.value })}
            className="bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-[9px] font-mono text-slate-300 outline-none w-28 text-center" />
          <button onClick={randomizeSeed} className="text-slate-500 hover:text-white cursor-pointer"><Shuffle className="w-3 h-3" /></button>
        </div>

        <div className="flex flex-wrap gap-1.5 justify-center mb-1">
          {COLORS.map((col) => (
            <button key={col.name} onClick={() => onChange({ ...profile, avatarColor: col.value })}
              className="w-3.5 h-3.5 rounded-full border cursor-pointer hover:scale-110 active:scale-95 transition-all"
              style={{ backgroundColor: col.value, borderColor: profile.avatarColor === col.value ? "#fff" : "#334155", boxShadow: profile.avatarColor === col.value ? `0 0 6px ${col.value}` : "none" }} title={col.name} />
          ))}
        </div>
        <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest mt-0.5">THEME COLOR</span>

        <div className="flex gap-2 mt-2">
          <button onClick={() => setShowCustomize(!showCustomize)}
            className="flex items-center gap-1 text-[9px] font-mono text-slate-500 hover:text-slate-300 cursor-pointer px-2 py-0.5 bg-slate-900/50 border border-slate-800 rounded">
            {showCustomize ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            CUSTOMIZE
          </button>
          <button onClick={() => setShowGsk(!showGsk)}
            className="flex items-center gap-1 text-[9px] font-mono text-pink-400 hover:text-pink-300 cursor-pointer px-2 py-0.5 bg-slate-900/50 border border-slate-800 rounded">
            <Bot className="w-3 h-3" />
            GSK
          </button>
        </div>
      </div>

      {/* GSK Panel */}
      {showGsk && (
        <div className="relative z-10 bg-slate-950/80 border border-pink-800/40 rounded-xl p-3 mb-3 text-[10px] font-mono">
          <div className="flex items-center justify-between mb-2">
            <span className="text-pink-400 font-bold flex items-center gap-1"><Bot className="w-3 h-3" /> GSK AVATAR VISION</span>
          </div>
          {gskObservation && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 mb-2 text-slate-300 leading-relaxed text-[10px]">
              {gskObservation}
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={askGskAboutAvatar} className="flex items-center gap-1 px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-[9px] text-slate-300 cursor-pointer"><Eye className="w-3 h-3" /> DESCRIBE</button>
            <button onClick={gskChangeClothes} className="flex items-center gap-1 px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-[9px] text-slate-300 cursor-pointer"><RefreshCw className="w-3 h-3" /> CHANGE CLOTHES</button>
            {gskObservation && <button onClick={() => setGskObservation(null)} className="text-slate-600 hover:text-slate-400 px-1 cursor-pointer">✕</button>}
          </div>
        </div>
      )}

      {/* Customization Panel */}
      {showCustomize && (
        <div className="relative z-10 bg-slate-950/80 border border-slate-800 rounded-xl p-3 mb-3 grid grid-cols-3 gap-x-3 gap-y-2 text-[9px] font-mono max-h-[280px] overflow-y-auto">
          <OptionSelect label="Style" options={ALL_STYLES} value={style} onChange={v => setStyleIdx(ALL_STYLES.indexOf(v))} />
          <OptionSelect label="Background" options={BG_TYPES} value={opts.backgroundType || "gradientLinear"} onChange={v => setOpt("backgroundType", v)} />
          <OptionSelect label="Eyes" options={EYES_OPTS} value={eyes} onChange={v => setOpt("eyesIdx", String(EYES_OPTS.indexOf(v)))} />
          <OptionSelect label="Mouth" options={MOUTH_OPTS} value={mouth} onChange={v => setOpt("mouthIdx", String(MOUTH_OPTS.indexOf(v)))} />
          <OptionSelect label="Eyebrows" options={EYEBROWS_OPTS} value={eyebrows} onChange={v => setOpt("eyebrowsIdx", String(EYEBROWS_OPTS.indexOf(v)))} />
          <OptionSelect label="Accessories" options={ACCESSORIES_OPTS} value={accessories} onChange={v => setOpt("accessories", v)} />
          {HAIR_STYLES[style] && <OptionSelect label="Hair" options={HAIR_STYLES[style]} value={hair} onChange={v => setOpt("hairIdx", String(HAIR_STYLES[style]!.indexOf(v)))} />}
          {CLOTHING_STYLES[style] && <OptionSelect label="Clothing" options={CLOTHING_STYLES[style]} value={clothing} onChange={v => setOpt("clothingIdx", String(CLOTHING_STYLES[style]!.indexOf(v)))} />}
          <OptionSelect label="Facial Hair" options={FACIAL_HAIR_OPTS} value={facialHair} onChange={v => setOpt("facialHairIdx", String(FACIAL_HAIR_OPTS.indexOf(v)))} />
          <OptionSelect label="Earrings" options={EARRINGS_OPTS} value={earrings} onChange={v => setOpt("earringsIdx", String(EARRINGS_OPTS.indexOf(v)))} />
          <OptionSelect label="Freckles" options={FRECKLES_OPTS} value={freckles} onChange={v => setOpt("frecklesIdx", String(FRECKLES_OPTS.indexOf(v)))} />
          <ColorSelect label="Hair Color" colors={HAIR_COLORS} value={hairColor} onChange={v => setOpt("hairColor", v)} />
          <ColorSelect label="Skin Color" colors={SKIN_COLORS} value={skinColor} onChange={v => setOpt("skinColor", v)} />
          <ColorSelect label="Clothing Color" colors={["3b82f6","10b981","ef4444","a855f7","f59e0b","64748b","1e293b","ffffff","ec4899","06b6d4","e11d48","84cc16","14b8a6","f97316","8b5cf6"]} value={clothingColor} onChange={v => setOpt("clothingColor", v)} />
        </div>
      )}

      {/* Identity Configuration Form */}
      <div className="relative z-10 space-y-3 flex-1">
        <div>
          <label className="block text-[11px] font-mono font-medium text-slate-300 mb-1">NAME</label>
          <input type="text" className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-slate-700 font-display transition-all"
            value={profile.name} onChange={e => onChange({ ...profile, name: e.target.value })} placeholder="e.g., LedgerScout Protocol" />
        </div>
        <div>
          <label className="block text-[11px] font-mono font-medium text-slate-300 mb-1">PERSONA</label>
          <input type="text" className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-slate-700 font-sans transition-all"
            value={profile.personality} onChange={e => onChange({ ...profile, personality: e.target.value })} placeholder="e.g., Skeptical, analytical financial auditor" />
        </div>
        <div>
          <label className="block text-[11px] font-mono font-medium text-slate-300 mb-1">DIRECTIVE</label>
          <textarea rows={2} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 outline-none focus:border-slate-700 font-sans text-xs transition-all resize-none"
            value={profile.behavior} onChange={e => onChange({ ...profile, behavior: e.target.value })}
            placeholder="e.g., Watch external transactions, format them into accounts, and trigger reconciliation posts automatically." />
        </div>

        <div className="border-t border-slate-800/80 pt-3 mt-2">
          <h3 className="font-mono text-[11px] text-slate-400 mb-2 flex items-center gap-1.5 font-semibold">
            <Zap className="w-3 h-3" style={{ color: currentThemeColor }} />
            OPERATIONAL LOGIC
          </h3>
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                <span>PRECISION vs CREATIVITY</span>
                <span className="font-semibold text-slate-200">{(profile.temperature * 100).toFixed(0)}/100</span>
              </div>
              <input type="range" min="0.1" max="1.0" step="0.05" className="w-full accent-slate-400 cursor-pointer"
                value={profile.temperature} onChange={e => onChange({ ...profile, temperature: parseFloat(e.target.value) })} />
            </div>
            <div>
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                <span>AUTONOMY</span>
                <span className="font-semibold text-slate-200">{profile.autonomy}%</span>
              </div>
              <input type="range" min="10" max="100" className="w-full accent-slate-400 cursor-pointer"
                value={profile.autonomy} style={{ accentColor: currentThemeColor }}
                onChange={e => onChange({ ...profile, autonomy: parseInt(e.target.value) })} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(["precise", "balanced", "fast"] as const).map((mode) => (
                <button key={mode} onClick={() => onChange({ ...profile, thinking: mode })}
                  className={`py-1 text-[10px] font-mono border rounded uppercase transition-all tracking-wider cursor-pointer ${
                    profile.thinking === mode ? "bg-slate-800 text-white font-bold" : "bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-300"
                  }`} style={{ borderColor: profile.thinking === mode ? currentThemeColor : undefined }}>{mode}</button>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs transition-all">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] font-medium text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-yellow-400" />
              SOUL GENESIS MODE
            </span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={marketingOn} onChange={() => setMarketingOn(!marketingOn)} />
              <div className="w-8 h-4 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[1px] after:left-[1px] after:bg-slate-300 after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-500" />
            </label>
          </div>
          <div className="mt-1 text-[10px] text-slate-400 italic">
            {marketingOn ? "🔮 Consciousness active. Agent has synthetic ego and a spiritual blockchain certificate." : "🤖 Deterministic mode. No ego wrappers."}
          </div>
        </div>
      </div>
    </div>
  );
};

const OptionSelect: React.FC<{ label: string; options: string[]; value: string; onChange: (v: string) => void }> = ({ label, options, value, onChange }) => (
  <div>
    <span className="text-slate-500 block mb-0.5">{label}</span>
    <select value={value} onChange={e => onChange(e.target.value)}
      className="w-full bg-slate-900 border border-slate-700 rounded px-1 py-0.5 text-[9px] font-mono text-slate-200 outline-none cursor-pointer">
      {options.map(o => <option key={o} value={o}>{o}</option>)}
    </select>
  </div>
);

const ColorSelect: React.FC<{ label: string; colors: string[]; value: string; onChange: (v: string) => void }> = ({ label, colors, value, onChange }) => (
  <div>
    <span className="text-slate-500 block mb-0.5">{label}</span>
    <div className="flex flex-wrap gap-0.5">
      {colors.map(c => (
        <button key={c} onClick={() => onChange(c)}
          className="w-3.5 h-3.5 rounded-full border cursor-pointer hover:scale-110 transition"
          style={{ backgroundColor: `#${c}`, borderColor: value === c ? "#fff" : "#334155", boxShadow: value === c ? `0 0 3px #${c}` : "none" }} />
      ))}
    </div>
  </div>
);
