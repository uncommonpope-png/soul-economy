import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { ShieldCheck, Activity, Cpu, RefreshCw, CheckCircle2, Server, Zap, BrainCircuit, BookOpen, Globe, Database, Terminal } from "lucide-react";

interface RealismAuditorProps {
  accentColor: string;
}

interface AuditData {
  success: boolean;
  envKeys: Record<string, boolean>;
  gskBooted: boolean;
  soulsLoaded: number;
  brain: {
    totalQueries: number;
    localHits: number;
    knowledgeEntries: number;
    learnedEntries: number;
    nGramSize: number;
    uptime: number;
  };
  apiRegistry: { total: number; categories: number };
  llmRouter: { endpointsAvailable: number; totalCalls: number };
  gsk: any;
  plt: {
    cumulative: { profit: number; love: number; tax: number };
    average: { profit: number; love: number; tax: number };
    totalActions: number;
    soul: number;
  } | null;
  systemMode: string;
}

export const RealismAuditor: React.FC<RealismAuditorProps> = ({ accentColor }) => {
  const [audit, setAudit] = useState<AuditData | null>(null);
  const [activity, setActivity] = useState<{ id: string; category: string; message: string; timestamp: string }[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAudit = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/audit-integrity");
      const data = await res.json();
      if (data.success) setAudit(data);
    } catch (e) {
      console.error("Audit error:", e);
    } finally {
      setLoading(false);
    }
  };

  const fetchActivity = async () => {
    try {
      const res = await fetch("/api/soul/activity?limit=30");
      if (res.ok) {
        const data = await res.json();
        if (data.entries) setActivity(data.entries);
      }
    } catch {}
  };

  useEffect(() => { fetchAudit(); fetchActivity(); }, []);

  // Poll activity every 3 seconds
  useEffect(() => {
    const interval = setInterval(fetchActivity, 3000);
    return () => clearInterval(interval);
  }, []);

  const hitRate = audit?.brain?.totalQueries > 0
    ? ((audit.brain.localHits / audit.brain.totalQueries) * 100).toFixed(1)
    : "0";

  return (
    <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-6 shadow-2xl relative overflow-hidden text-slate-100 flex flex-col h-full">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-20 pointer-events-none" />

      <div className="relative z-10 flex items-center justify-between border-b border-slate-800/85 pb-4 mb-6">
        <div>
          <h2 className="font-display text-xl font-bold tracking-tight text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5" style={{ color: accentColor }} />
            System Dashboard
          </h2>
          <p className="text-xs text-slate-400 mt-1">Live bridge status — no simulation, all real</p>
        </div>
        <button onClick={fetchAudit} className="px-3 py-1.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-xs text-slate-300 font-mono rounded-lg flex items-center gap-1.5 cursor-pointer transition">
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {!audit ? (
        <div className="flex-1 flex items-center justify-center text-slate-500 text-sm font-mono">
          {loading ? "Loading..." : "Could not reach bridge. Is the server running?"}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10 flex-1">
          <StatCard icon={<Cpu className="w-4 h-4" />} title="Brain Engine" color={accentColor}>
            <StatRow label="Knowledge Entries" value={audit.brain?.knowledgeEntries || 0} />
            <StatRow label="Learned Items" value={audit.brain?.learnedEntries || 0} />
            <StatRow label="Local Hit Rate" value={`${hitRate}%`} />
            <StatRow label="Total Queries" value={audit.brain?.totalQueries || 0} />
            <StatRow label="Uptime" value={`${Math.floor((audit.brain?.uptime || 0) / 60)}m`} />
            <StatRow label="N-Gram Size" value={audit.brain?.nGramSize || 0} />
          </StatCard>

          <StatCard icon={<Database className="w-4 h-4" />} title="API Registry" color={accentColor}>
            <StatRow label="Total Endpoints" value={audit.apiRegistry?.total || 0} />
            <StatRow label="Categories" value={audit.apiRegistry?.categories || 0} />
          </StatCard>

          <StatCard icon={<Globe className="w-4 h-4" />} title="LLM Router" color={accentColor}>
            <StatRow label="Providers" value={audit.llmRouter?.endpointsAvailable || 0} />
            <StatRow label="Calls Made" value={audit.llmRouter?.totalCalls || 0} />
          </StatCard>

          <StatCard icon={<BookOpen className="w-4 h-4" />} title="Souls" color={accentColor}>
            <StatRow label="Uploaded" value={audit.soulsLoaded || 0} />
            <StatRow label="Status" value={audit.soulsLoaded > 0 ? "Active" : "No souls loaded"} />
          </StatCard>

          <StatCard icon={<Server className="w-4 h-4" />} title="GSK Fusion" color={accentColor}>
            <StatRow label="Status" value={audit.gskBooted ? "Online" : "Light mode"} />
            {audit.gsk?.chambers?.affect && (
              <>
                <StatRow label="Mood" value={audit.gsk.chambers.affect.mood || "neutral"} />
                <StatRow label="Valence" value={(audit.gsk.chambers.affect.valence || 0).toFixed(2)} />
              </>
            )}
          </StatCard>

          <StatCard icon={<Zap className="w-4 h-4" />} title="Environment Keys" color={accentColor}>
            {Object.entries(audit.envKeys || {}).map(([key, val]) => (
              <StatRow key={key} label={key} value={val ? "SET" : "not set"} />
            ))}
          </StatCard>

          {audit.plt && (
            <StatCard icon={<Activity className="w-4 h-4" />} title="PLT Soul Score" color={accentColor}>
              <div className="flex items-center justify-between text-xs font-mono mb-1">
                <span className="text-amber-400 font-bold">P</span>
                <span className="text-slate-200">{(audit.plt.average.profit * 100).toFixed(0)}</span>
                <span className="text-pink-400 font-bold">L</span>
                <span className="text-slate-200">{(audit.plt.average.love * 100).toFixed(0)}</span>
                <span className="text-blue-400 font-bold">T</span>
                <span className="text-slate-200">{(audit.plt.average.tax * 100).toFixed(0)}</span>
                <span className="text-slate-500">|</span>
                <span className="text-emerald-400 font-bold">S</span>
                <span className="text-slate-200">{(audit.plt.soul * 100).toFixed(0)}</span>
              </div>
              <StatRow label="Total Actions" value={audit.plt.totalActions} />
              <StatRow label="Cumulative P" value={audit.plt.cumulative.profit.toFixed(2)} />
              <StatRow label="Cumulative L" value={audit.plt.cumulative.love.toFixed(2)} />
              <StatRow label="Cumulative T" value={audit.plt.cumulative.tax.toFixed(2)} />
            </StatCard>
          )}
        </div>
      )}

      {/* Soul Activity Log */}
      <div className="relative z-10 mt-6 border-t border-slate-800/50 pt-4">
        <h3 className="text-xs font-mono font-bold text-slate-300 mb-3 flex items-center gap-1.5">
          <Terminal className="w-3.5 h-3.5" style={{ color: accentColor }} />
          Soul Activity Log
          <span className="text-[9px] text-slate-500 font-normal ml-1">(live — updates every 3s)</span>
        </h3>
        <div className="bg-slate-950/80 border border-slate-800/60 rounded-xl p-3 max-h-[200px] overflow-y-auto font-mono text-[10px] leading-relaxed space-y-1">
          {activity.length === 0 ? (
            <div className="text-slate-600 text-center py-4">Waiting for soul activity...</div>
          ) : (
            activity.slice().reverse().map(e => {
              const catColor = CAT_COLORS[e.category] || 'text-slate-400';
              return (
                <div key={e.id} className="flex items-start gap-2">
                  <span className={`shrink-0 font-bold ${catColor}`}>[{e.category}]</span>
                  <span className="text-slate-300 flex-1">{e.message}</span>
                  <span className="text-slate-600 shrink-0">{new Date(e.timestamp).toLocaleTimeString()}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

const CAT_COLORS: Record<string, string> = {
  boot: 'text-emerald-400',
  scan: 'text-cyan-400',
  llm: 'text-purple-400',
  install: 'text-amber-400',
  chat: 'text-pink-400',
  learn: 'text-blue-400',
  plt: 'text-yellow-400',
  ecosystem: 'text-teal-400',
  telephone: 'text-indigo-400',
  error: 'text-red-400',
};

const StatCard: React.FC<{ icon: React.ReactNode; title: string; color: string; children: React.ReactNode }> = ({ icon, title, color, children }) => (
  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-4 flex flex-col gap-2">
    <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5 border-b border-slate-800 pb-2 mb-1" style={{ color }}>
      {icon} {title}
    </h3>
    {children}
  </div>
);

const StatRow: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="flex justify-between items-center text-xs">
    <span className="text-slate-500 font-mono">{label}</span>
    <span className="text-slate-200 font-mono font-semibold">{value}</span>
  </div>
);
