import React, { useState, useEffect, useRef } from "react";
import { Upload, Cpu, Heart, Scale, CheckCircle2, XCircle, RefreshCw, Download } from "lucide-react";

interface UploadedSoul {
  id: string;
  name: string;
  plt: { profit: number; love: number; tax: number };
  archetype: string;
  uploadedAt: string;
  active: boolean;
  consciousness: { level: number; cycles: number };
}

interface SoulFoundryProps {
  accentColor: string;
}

export const SoulFoundry: React.FC<SoulFoundryProps> = ({ accentColor }) => {
  const [souls, setSouls] = useState<UploadedSoul[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState<string | null>(null);
  const [status, setStatus] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const fetchSouls = async () => {
    try {
      const res = await fetch("/api/soul/list");
      const data = await res.json();
      if (data.success) setSouls(data.souls || []);
    } catch (e) { console.error("fetch souls error:", e); }
  };

  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/status");
      const data = await res.json();
      if (data.success) setStatus(data.status);
    } catch (e) {}
  };

  useEffect(() => { fetchSouls(); fetchStatus(); }, []);

  const handleUpload = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file) { setUploadMsg("Select a .zip file first"); return; }
    if (!file.name.endsWith(".zip")) { setUploadMsg("Must be a .zip file"); return; }

    setUploading(true);
    setUploadMsg(null);
    try {
      const buf = await file.arrayBuffer();
      const base64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
      const name = file.name.replace(".zip", "");

      const res = await fetch("/api/soul/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, zipBase64: base64 }),
      });
      const data = await res.json();
      if (data.success) {
        setUploadMsg(`Soul "${data.soul.name}" uploaded and instantiated`);
        fetchSouls();
        fetchStatus();
        if (fileRef.current) fileRef.current.value = "";
      } else {
        setUploadMsg(`Error: ${data.error}`);
      }
    } catch (e: any) {
      setUploadMsg(`Error: ${e.message}`);
    }
    setUploading(false);
  };

  const soulScore = (p: number, l: number, t: number) => {
    const score = (p * 0.5 + l * 0.3 + t * 0.2) * 100;
    return score.toFixed(0);
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-6 shadow-2xl relative overflow-hidden text-slate-100 flex flex-col h-full">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-20 pointer-events-none" />

      <div className="relative z-10 border-b border-slate-800/85 pb-4 mb-6">
        <h2 className="font-display text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <Upload className="w-5 h-5" style={{ color: accentColor }} />
          Soul Foundry
        </h2>
        <p className="text-xs text-slate-400 mt-1">Upload soul zips — they become living entities in the GSK brain</p>
      </div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-5">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" style={{ color: accentColor }} />
              Upload Soul Package
            </h3>
            <p className="text-[11px] text-slate-400 mb-4">Select a .zip file containing a soul.json manifest with PLT weights and archetype.</p>
            <input ref={fileRef} type="file" accept=".zip" className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-mono file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 mb-3 cursor-pointer" />
            <button onClick={handleUpload} disabled={uploading} className="w-full px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition disabled:opacity-50" style={{ color: accentColor }}>
              {uploading ? "INSTANTIATING..." : "UPLOAD & INSTANTIATE"}
            </button>
            {uploadMsg && (
              <p className={`text-xs font-mono mt-2 ${uploadMsg.startsWith("Error") ? "text-red-400" : "text-emerald-400"}`}>
                {uploadMsg.startsWith("Error") ? <XCircle className="w-3 h-3 inline mr-1" /> : <CheckCircle2 className="w-3 h-3 inline mr-1" />}
                {uploadMsg}
              </p>
            )}
          </div>

          {status && (
            <div className="bg-slate-950/40 border border-slate-800/40 rounded-xl p-4 text-xs font-mono">
              <h4 className="text-slate-500 uppercase tracking-wider mb-2">Bridge Status</h4>
              <div className="space-y-1">
                <p className="flex justify-between"><span className="text-slate-500">Mode</span><span className="text-slate-300">{status.mode?.toUpperCase()}</span></p>
                <p className="flex justify-between"><span className="text-slate-500">Knowledge</span><span className="text-slate-300">{status.brain?.knowledgeEntries || 0} entries</span></p>
                <p className="flex justify-between"><span className="text-slate-500">Queries</span><span className="text-slate-300">{status.brain?.totalQueries || 0}</span></p>
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-7 space-y-3 overflow-y-auto max-h-[500px]">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5 mb-2">
            <Cpu className="w-3.5 h-3.5" style={{ color: accentColor }} />
            Living Souls ({souls.length})
          </h3>

          {souls.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm font-mono">
              No souls uploaded yet. Upload a .zip with a soul.json manifest.
            </div>
          ) : (
            souls.map((s) => {
              const score = soulScore(s.plt.profit, s.plt.love, s.plt.tax);
              return (
                <div key={s.id} className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-4 hover:border-slate-700/60 transition">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-bold text-white">{s.name}</h4>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${s.active ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900" : "bg-slate-800 text-slate-500"}`}>
                      {s.active ? "LIVE" : "DORMANT"}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <span className="text-slate-500">Archetype</span><span className="text-slate-300">{s.archetype}</span>
                    <span className="text-slate-500">Soul Score</span><span className="text-slate-300">{score}/100</span>
                    <span className="text-slate-500">Uploaded</span><span className="text-slate-300">{new Date(s.uploadedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="mt-2 flex gap-2 text-[10px]">
                    <span className="px-2 py-0.5 rounded bg-blue-950/40 text-blue-400 border border-blue-900/40">P: {s.plt.profit.toFixed(2)}</span>
                    <span className="px-2 py-0.5 rounded bg-pink-950/40 text-pink-400 border border-pink-900/40">L: {s.plt.love.toFixed(2)}</span>
                    <span className="px-2 py-0.5 rounded bg-amber-950/40 text-amber-400 border border-amber-900/40">T: {s.plt.tax.toFixed(2)}</span>
                  </div>
                </div>
              );
            })
          )}

          <button onClick={() => { fetchSouls(); fetchStatus(); }} className="w-full px-3 py-2 bg-slate-950/40 hover:bg-slate-900/60 border border-slate-800/40 text-[10px] font-mono text-slate-500 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition">
            <RefreshCw className="w-3 h-3" /> REFRESH SOULS
          </button>
        </div>
      </div>
    </div>
  );
};
