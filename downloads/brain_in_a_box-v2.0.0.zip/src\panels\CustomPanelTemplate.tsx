import React from "react";
import { Puzzle } from "lucide-react";

/**
 * ─────────────────────────────────────────────
 *  CUSTOM PANEL TEMPLATE
 * ─────────────────────────────────────────────
 * 
 * 1. Copy this file as src/panels/MyPanel.tsx
 * 2. Edit src/panels/panel-manifest.ts:
 *      import { MyPanel } from "./MyPanel";
 *      export const CUSTOM_PANEL_REGISTRY: PanelDefinition[] = [
 *        { id: "my-panel", label: "My Tool", icon: Puzzle, component: MyPanel },
 *      ];
 * 
 * That's it — your tab appears in the nav bar and renders automatically.
 * 
 * For backend routes, call fetch() from your panel or register routes in server.ts.
 */

interface MyPanelProps {
  accentColor: string;
}

export const MyPanel: React.FC<MyPanelProps> = ({ accentColor }) => {
  return (
    <div className="bg-slate-900/60 border border-slate-800/80 backdrop-blur-md rounded-2xl p-6 shadow-2xl text-slate-100">
      <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 mb-4">
        <Puzzle className="w-5 h-5" style={{ color: accentColor }} />
        My Custom Panel
      </h2>
      <p className="text-sm text-slate-400 font-mono">
        Build anything here. Fetch from any API, render charts, connect tools.
      </p>
    </div>
  );
};
