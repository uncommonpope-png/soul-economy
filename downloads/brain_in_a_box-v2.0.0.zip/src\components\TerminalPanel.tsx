import React, { useState, useRef, useEffect, useCallback } from "react";
import { Terminal, Send, Trash2, Upload, File, X } from "lucide-react";

interface TerminalLine {
  id: string;
  text?: string;
  html?: string;
  image?: string;
  type: "stdout" | "stderr" | "system" | "input" | "file";
  timestamp: string;
}

export const TerminalPanel: React.FC<{ accentColor: string }> = ({ accentColor }) => {
  const [lines, setLines] = useState<TerminalLine[]>([
    { id: "welcome", text: "╔══════════════════════════════════════════════════╗", type: "system", timestamp: "" },
    { id: "welcome2", text: "║  Soul Terminal — type commands or drop files    ║", type: "system", timestamp: "" },
    { id: "welcome3", text: "║  Drop any file: images, PDFs, zips, code, docs  ║", type: "system", timestamp: "" },
    { id: "welcome4", text: "╚══════════════════════════════════════════════════╝", type: "system", timestamp: "" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [cwd, setCwd] = useState(".");
  const [dragging, setDragging] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [lines]);

  const addLine = (line: TerminalLine) => setLines(prev => [...prev, line]);

  const run = async (cmd: string) => {
    if (!cmd.trim()) return;
    addLine({ id: `in-${Date.now()}`, text: `$ ${cmd}`, type: "input", timestamp: "" });
    setLoading(true);
    try {
      const res = await fetch("/api/terminal/exec", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: cmd, cwd })
      });
      const data = await res.json();
      if (data.stdout) data.stdout.split("\n").filter(Boolean).forEach((t: string) => addLine({ id: `out-${Math.random()}`, text: t, type: "stdout", timestamp: "" }));
      if (data.stderr) data.stderr.split("\n").filter(Boolean).forEach((t: string) => addLine({ id: `err-${Math.random()}`, text: t, type: "stderr", timestamp: "" }));
      if (data.cwd) setCwd(data.cwd);
      if (data.exitCode !== 0 && !data.stdout && !data.stderr) {
        addLine({ id: `sys-${Date.now()}`, text: `Exit code: ${data.exitCode}${data.error ? ` — ${data.error}` : ""}`, type: "system", timestamp: "" });
      }
    } catch (e: any) {
      addLine({ id: `err-${Date.now()}`, text: `Error: ${e.message}`, type: "stderr", timestamp: "" });
    }
    setLoading(false);
  };

  const readFile = async (file: File) => {
    addLine({ id: `file-${Date.now()}`, text: `Reading: ${file.name} (${(file.size / 1024).toFixed(1)} KB)...`, type: "system", timestamp: "" });
    setLoading(true);
    try {
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1]);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const res = await fetch("/api/soul/read-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: file.name, type: file.type, data: base64 })
      });
      const data = await res.json();

      addLine({ id: `filehdr-${Date.now()}`, text: `📄 ${data.name} — ${data.fileType || "unknown"}, ${(data.size / 1024).toFixed(1)} KB`, type: "system", timestamp: "" });

      if (data.fileType === "image" && data.preview) {
        addLine({ id: `img-${Date.now()}`, html: `<img src="${data.preview}" style="max-width:400px;max-height:300px;border-radius:8px;border:1px solid rgba(255,255,255,0.1)" />`, type: "file", timestamp: "" });
        if (data.width > 0 && data.height > 0) addLine({ id: `imgdims-${Date.now()}`, text: `${data.width} × ${data.height} px`, type: "stdout", timestamp: "" });
      }

      if (data.fileType === "document" && data.content) {
        addLine({ id: `pdfinfo-${Date.now()}`, text: `Pages: ${data.pageCount || "?"} | Content: ${data.contentLength} chars`, type: "stdout", timestamp: "" });
        addLine({ id: `pdf-${Date.now()}`, text: data.content.slice(0, 5000), type: "stdout", timestamp: "" });
        if (data.contentLength > 5000) addLine({ id: `pdfmore-${Date.now()}`, text: `... (${data.contentLength - 5000} more chars)`, type: "system", timestamp: "" });
      }

      if (data.fileType === "text" && data.content) {
        addLine({ id: `txt-${Date.now()}`, text: data.lineCount > 200 ? `First 200 of ${data.lineCount} lines:\n` + data.content.split("\n").slice(0, 200).join("\n") + `\n... (${data.lineCount - 200} more lines)` : data.content, type: "stdout", timestamp: "" });
      }

      if (data.fileType === "archive" && data.contents) {
        addLine({ id: `zipinfo-${Date.now()}`, text: `${data.fileCount} files:`, type: "stdout", timestamp: "" });
        data.contents.forEach((f: string) => addLine({ id: `zipf-${Math.random()}`, text: `  ${f}`, type: "stdout", timestamp: "" }));
      }

      if (data.fileType === "binary" && !data.preview) {
        addLine({ id: `bin-${Date.now()}`, text: `Binary file — magic: ${data.magic || "unknown"}`, type: "stdout", timestamp: "" });
      }
    } catch (e: any) {
      addLine({ id: `err-${Date.now()}`, text: `File read error: ${e.message}`, type: "stderr", timestamp: "" });
    }
    setLoading(false);
  };

  // Drag and drop handlers
  const onDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setDragging(true); }, []);
  const onDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setDragging(false); }, []);
  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setDragging(false);
    const files = Array.from(e.dataTransfer.files);
    files.forEach(f => readFile(f));
  }, []);
  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(f => readFile(f));
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); run(input); setInput(""); };

  return (
    <div ref={dropRef}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      className={`bg-slate-950/90 border backdrop-blur-md rounded-2xl shadow-2xl flex flex-col h-full text-slate-100 overflow-hidden transition-all ${dragging ? "border-emerald-400/60 ring-2 ring-emerald-400/20" : "border-slate-800/80"}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-950/50 shrink-0">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4" style={{ color: accentColor }} />
          <span className="text-xs font-mono font-bold text-slate-300">Soul Terminal</span>
          <span className="text-[9px] text-slate-600 font-mono ml-2">{cwd}</span>
        </div>
        <div className="flex items-center gap-2">
          <input ref={fileInputRef} type="file" multiple onChange={onFileSelect} className="hidden" />
          <button onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 text-[10px] font-mono text-slate-400 hover:text-emerald-400 px-2 py-1 rounded border border-slate-800 hover:border-emerald-800/40 cursor-pointer transition">
            <Upload className="w-3 h-3" /> Upload
          </button>
          <button onClick={() => setLines([])}
            className="flex items-center gap-1 text-[10px] font-mono text-slate-500 hover:text-red-400 px-2 py-1 rounded border border-slate-800 hover:border-red-800/40 cursor-pointer transition">
            <Trash2 className="w-3 h-3" /> Clear
          </button>
        </div>
      </div>

      {/* Drop zone overlay */}
      {dragging && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-none rounded-2xl">
          <div className="text-center">
            <Upload className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm font-mono text-emerald-400">Drop files anywhere</p>
            <p className="text-[10px] text-slate-500 mt-1">Images, PDFs, zips, code, anything</p>
          </div>
        </div>
      )}

      {/* Terminal output */}
      <div className="flex-1 overflow-y-auto p-3 font-mono text-[12px] leading-relaxed space-y-0.5 bg-slate-950/30" style={{ minHeight: "200px" }}>
        {lines.map(l => (
          <div key={l.id}>
            {l.image || l.html ? (
              <div className="my-1" dangerouslySetInnerHTML={{ __html: l.html || "" }} />
            ) : (
              <div className={`whitespace-pre-wrap break-all ${
                l.type === "stderr" ? "text-red-400" :
                l.type === "system" ? "text-slate-500" :
                l.type === "input" ? "text-emerald-400 font-bold" :
                "text-slate-200"
              }`}>
                {l.text}
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2 p-3 border-t border-slate-800/80 bg-slate-950/50 shrink-0 relative">
        <span className="text-[11px] font-mono text-emerald-400 shrink-0">$</span>
        <input value={input} onChange={e => setInput(e.target.value)} placeholder="Type a command or drop a file..." disabled={loading}
          className="flex-1 bg-transparent border-none outline-none text-[12px] font-mono text-slate-200 placeholder:text-slate-600 disabled:opacity-50" autoFocus />
        <button type="submit" disabled={loading || !input.trim()}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded-lg cursor-pointer transition">
          <Send className="w-3.5 h-3.5 text-slate-300" />
        </button>
      </form>
    </div>
  );
};
