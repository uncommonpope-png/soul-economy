import modal
import json
import subprocess
import time
import os

app = modal.App("soul-procedural-memory-test")

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("nodejs", "npm", "curl")
    .add_local_dir(
        r"C:\Users\uncom\Desktop\shopify-auto-setup\soul-procedural-memory",
        remote_path="/soul",
        copy=True
    )
)

@app.function(
    image=image,
    cpu=2,
    memory=2048,
    scaledown_window=300,
    timeout=300,
)
def test_procedural_memory():
    """Test the Procedural Memory Soul on Modal"""
    import subprocess, time, json

    # Start the soul
    proc = subprocess.Popen(
        ["node", "/soul/lib/soul-procedural-memory.js"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env={**os.environ, "PORT": "4285"}
    )
    time.sleep(5)

    import urllib.request
    def api(method, path, body=None):
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(f"http://127.0.0.1:4285{path}", data=data, method=method, headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode())
        except Exception as e:
            return {"error": str(e)}

    results = {}

    # 1. Ping / health
    results["ping"] = api("GET", "/ping")
    results["health"] = api("GET", "/health")

    if not results.get("ping", {}).get("alive"):
        return {"error": "Soul not responding", "results": results}

    # 2. Record mistakes
    mistakes = []
    for i in range(4):
        m = api("POST", "/record-mistake", {
            "action": f"invalid_api_call_{i}",
            "context": "fetching_data_from_untrusted_source",
            "consequence": "returned_hallucinated_result",
            "severity": "high",
            "fix": "validate_api_response_before_use"
        })
        mistakes.append(m)
    results["recorded"] = len(mistakes)

    # 3. Check that policy was generated (3+ repeats)
    policies = api("GET", "/policies")
    results["policies_generated"] = policies.get("total", 0)

    # 4. Test action blocking (should be flagged)
    check = api("POST", "/check-action", {
        "action": "invalid_api_call_0",
        "context": "fetching_data_from_untrusted_source"
    })
    results["action_check"] = {
        "allowed": check.get("allowed"),
        "enforced": check.get("enforced"),
        "suggestion": check.get("suggestion")
    }

    # 5. Test chat
    chat = api("POST", "/chat", {"message": "What mistakes have you seen?"})
    results["chat"] = {
        "has_reply": bool(chat.get("reply")),
        "reply_length": len(chat.get("reply", "")),
        "plt": chat.get("plt")
    }

    # 6. Behavior review
    behavior = api("GET", "/behavior")
    results["behavior"] = {
        "total_actions": behavior.get("total_actions"),
        "prevented": behavior.get("prevented"),
        "prevention_rate": behavior.get("prevention_rate"),
        "plt": behavior.get("plt")
    }

    # 7. PLT state
    plt = api("GET", "/plt")
    results["plt"] = plt

    # 8. Status
    status = api("GET", "/status")
    results["status"] = {
        "mistakes": status.get("mistakes"),
        "policies": status.get("policies"),
        "prevention_count": status.get("prevention_count"),
        "uptime": status.get("uptime")
    }

    proc.terminate()
    return results

@app.local_entrypoint()
def run():
    print("\n🧠 Testing Procedural Memory Soul on Modal cloud...\n")
    results = test_procedural_memory.remote()

    if results.get("error"):
        print(f"  FAIL: {results['error']}")
        return

    print(f"  Ping: {'✅' if results['ping'].get('alive') else '❌'}")
    print(f"  Health: {results['health'].get('status', '?')}")
    print(f"\n  Mistakes recorded: {results.get('recorded', 0)}")
    print(f"  Policies generated: {results.get('policies_generated', 0)} (expect 1 from 3+ repeats)")

    ac = results.get("action_check", {})
    print(f"\n  Action check:")
    print(f"    Allowed: {ac.get('allowed')}")
    print(f"    Enforced: {ac.get('enforced')}")
    print(f"    Suggestion: {ac.get('suggestion')}")

    ch = results.get("chat", {})
    print(f"\n  Chat:")
    print(f"    Reply: {'✅' if ch.get('has_reply') else '❌'}")
    print(f"    Length: {ch.get('reply_length')} chars")
    print(f"    PLT: {ch.get('plt')}")

    bh = results.get("behavior", {})
    print(f"\n  Behavior:")
    print(f"    Total: {bh.get('total_actions')}, Prevented: {bh.get('prevented')}, Rate: {bh.get('prevention_rate')}")

    pl = results.get("plt", {})
    if pl:
        print(f"\n  PLT State:")
        print(f"    P: {(pl.get('average', {}).get('profit', 0)*100):.0f}")
        print(f"    L: {(pl.get('average', {}).get('love', 0)*100):.0f}")
        print(f"    T: {(pl.get('average', {}).get('tax', 0)*100):.0f}")
        print(f"    Total actions: {pl.get('totalActions', 0)}")

    st = results.get("status", {})
    print(f"\n  Final Status:")
    print(f"    {st.get('mistakes', 0)} mistakes, {st.get('policies', 0)} policies, {st.get('prevention_count', 0)} prevented")
    print(f"    Uptime: {st.get('uptime', 0)}s")

    print(f"\n  ✅ Test complete!")
