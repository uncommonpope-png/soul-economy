#!/usr/bin/env node

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');

const DATA_DIR = path.join(os.homedir(), '.soul-compress-test');

console.log('\n💰 Token Compression Soul v1.0.0 — Test Suite\n');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        console.log(`  ✓ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ✗ ${name}: ${err.message}`);
        failed++;
    }
}

if (fs.existsSync(DATA_DIR)) fs.rmSync(DATA_DIR, { recursive: true, force: true });

const TokenCompressor = require('../lib/soul-compress');

const LARGE_MEMORY = `# Agent Memory

## Personal Preferences
I prefer concise responses. I like Python for data work.
My name is Alex. I work remotely from Berlin.
I prefer morning standups and async communication.
My timezone is CET (UTC+1).

## Business Context
We run a SaaS company. Monthly revenue is $50k.
Main product is an analytics dashboard for e-commerce.
We have 3 enterprise clients and 200 SMB customers.
Our pricing tiers: Free ($0), Pro ($29/mo), Enterprise ($999/mo).
Sales cycle is typically 2-4 weeks for enterprise.
We use Stripe for billing and HubSpot for CRM.

## Code Architecture
Backend uses Node.js with Express framework.
Database is PostgreSQL with Prisma ORM for type safety.
API follows REST conventions with versioned endpoints.
Frontend is Next.js with React and TypeScript.
Deployment uses Docker containers on Vercel.
CI/CD pipeline runs via GitHub Actions with 3 environments.
Testing stack: Jest for unit, Cypress for e2e.

## Decisions Made
Chose PostgreSQL over MongoDB for relational data integrity.
Decided to use JWT for authentication with refresh tokens.
Selected Vercel for hosting over AWS to reduce ops burden.
Chose Stripe over PayPal for better developer API.
Decided on monorepo with Turborepo for code sharing.
Selected Prisma over TypeORM for better type safety.

## Infrastructure Details
Deployed on Vercel pro plan ($20/mo).
Domain: analytics.example.com via Cloudflare DNS.
SSL cert auto-renewed via Let's Encrypt.
Database hosted on Supabase ($25/mo).
Redis cache via Upstash for session management.
S3-compatible storage via Backblaze B2 for backups.
Monitoring via Sentry for errors and Grafana for metrics.
Backup runs daily at 2 AM UTC, retained for 30 days.

## SEO Strategy
Target keywords: analytics dashboard, e-commerce analytics.
Focus on long-tail keywords for niche markets.
Content marketing via weekly blog posts.
Technical SEO: core web vitals, structured data, sitemaps.

## Team Structure
CTO: Sarah (tech lead, architecture decisions).
2 backend devs (Node.js focus).
1 frontend dev (React/Next.js specialist).
1 designer (UI/UX, Figma).
1 customer success manager.
Weekly sprint planning on Mondays.
Daily standups at 10 AM CET.`;

test('Module loads', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    assert(tc.dataDir === DATA_DIR, 'Should set data dir');
});

test('Token counting works', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    assert(tc.countTokens('hello') === 2, 'Short text');
    assert(tc.countTokens('') === 0, 'Empty text');
    assert(tc.countTokens('a'.repeat(100)) === 25, '100 chars = ~25 tokens');
});

test('Section parsing works', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const sections = tc.parseSections(LARGE_MEMORY);
    assert(sections.length === 7, 'Should find 7 sections');
    assert(sections[0].heading === 'Personal Preferences', 'First section heading');
    assert(sections[1].heading === 'Business Context', 'Second section heading');
});

test('Domain classification works', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    assert(tc.classifySection('Personal Preferences') === 'identity', 'Personal → identity');
    assert(tc.classifySection('Business Context') === 'business', 'Business → business');
    assert(tc.classifySection('Code Architecture') === 'code', 'Code → code');
    assert(tc.classifySection('Decisions Made') === 'decisions', 'Decisions → decisions');
    assert(tc.classifySection('Infrastructure') === 'infra', 'Infra → infra');
});

test('Ingest memory creates domain structure', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const result = tc.ingestMemory(LARGE_MEMORY);
    assert(result.success, 'Ingest should succeed');
    assert(result.domains.length >= 4, 'Should have multiple domains');
    assert(result.totalTokens > 0, 'Should count tokens');
});

test('Domain files are created', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const domains = tc.listDomains();
    assert(domains.includes('identity'), 'Should have identity domain');
    assert(domains.includes('business'), 'Should have business domain');
    assert(domains.includes('code'), 'Should have code domain');
});

test('Trunk index is created', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const trunkPath = path.join(DATA_DIR, 'memory', 'INDEX.md');
    assert(fs.existsSync(trunkPath), 'Trunk index should exist');
    const content = fs.readFileSync(trunkPath, 'utf8');
    assert(content.includes('# Compressed Memory Index'), 'Should have header');
});

test('Compression reduces token count', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const result = tc.compressMemory({ targetTokens: 100 });
    assert(result.success, 'Compress should succeed');
    assert(result.originalTokens > result.compressedTokens, 'Should reduce tokens');
    assert(result.reduction.includes('%'), 'Should report reduction percentage');
});

test('Scheduled review works', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const schedule = tc.getScheduledReview();
    assert(Array.isArray(schedule), 'Should return array');
    assert(schedule.length > 0, 'Should have items');
    assert(schedule[0].retrievability !== undefined, 'Should have retrievability');
});

test('Context reconstruction works', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const result = tc.getOptimizedContext({ query: 'PostgreSQL' });
    assert(result.context, 'Should return context');
    assert(result.tokens > 0, 'Should have tokens');
    assert(result.reduction.includes('%'), 'Should report reduction');
});

test('Query-specific context returns relevant domains', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const result = tc.getOptimizedContext({ query: 'authentication' });
    assert(result.domainsSearched.length > 0, 'Should find relevant domains');
});

test('Stats are tracked', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const stats = tc.getStats();
    assert(stats.totalSectors > 0, 'Should track sectors');
    assert(stats.totalTokens > 0, 'Should track tokens');
    assert(Array.isArray(stats.domains), 'Should list domains');
});

test('Reconstruct produces valid output', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const result = tc.exportReconstructedMemory();
    assert(result.success, 'Should succeed');
    assert(fs.existsSync(result.path), 'File should exist');
    assert(result.tokens > 0, 'Should have tokens');
});

test('FSRS-style retrievability calculation', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const schedule = tc.getScheduledReview();
    schedule.forEach(s => {
        assert(s.retrievability >= 0 && s.retrievability <= 1, 'Retrievability 0-1');
    });
});

test('Domain weights affect token allocation', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const domains = tc.listDomains();
    const allocation = tc.allocateTokenBudget(domains, 1000);
    const keys = Object.keys(allocation);
    assert(keys.length > 0, 'Should allocate to all domains');
    // identity has weight 10, general has weight 1
    if (allocation.identity && allocation.general) {
        assert(allocation.identity > allocation.general, 'Identity should get more than general');
    }
});

test('Backup is created during ingest', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const memoryDir = path.join(DATA_DIR, 'memory');
    const backups = fs.readdirSync(memoryDir).filter(f => f.startsWith('memory-backup-'));
    assert(backups.length > 0, 'Should have backup files');
});

test('Multiple compressions update stats', () => {
    const tc = new TokenCompressor({ dataDir: DATA_DIR });
    const r1 = tc.compressMemory({ targetTokens: 500 });
    const r2 = tc.compressMemory({ targetTokens: 100 });
    assert(r2.compressedTokens <= r1.compressedTokens, 'Second compress should be more aggressive');
});

console.log('\n' + '='.repeat(40));
console.log(`Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(40) + '\n');

if (fs.existsSync(DATA_DIR)) fs.rmSync(DATA_DIR, { recursive: true, force: true });

process.exit(failed > 0 ? 1 : 0);