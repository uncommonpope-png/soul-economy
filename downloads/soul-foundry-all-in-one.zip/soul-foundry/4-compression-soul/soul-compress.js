#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');

const DATA_DIR = path.join(os.homedir(), '.soul-compress');

class TokenCompressor {
    constructor(options = {}) {
        this.dataDir = options.dataDir || DATA_DIR;
        this.memoryDir = path.join(this.dataDir, 'memory');
        this.domainsDir = path.join(this.memoryDir, 'domains');
        this.archiveDir = path.join(this.memoryDir, 'archive');
        this.statsFile = path.join(this.dataDir, 'stats.json');
        this.scheduleFile = path.join(this.dataDir, 'schedule.json');
        this.ensureDirs();
        this.loadStats();
    }

    ensureDirs() {
        [this.dataDir, this.memoryDir, this.domainsDir, this.archiveDir].forEach(d => {
            if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
        });
    }

    loadStats() {
        if (fs.existsSync(this.statsFile)) {
            try { this.stats = JSON.parse(fs.readFileSync(this.statsFile, 'utf8')); return; } catch {}
        }
        this.stats = {
            version: '1.0.0',
            totalSectors: 0,
            totalTokens: 0,
            compressedTokens: 0,
            compressionRatio: 0,
            lastOptimized: null,
            domainStats: {},
            accessLog: []
        };
    }

    saveStats() {
        fs.writeFileSync(this.statsFile, JSON.stringify(this.stats, null, 2));
    }

    now() { return new Date().toISOString(); }

    countTokens(text) {
        if (!text) return 0;
        return Math.ceil(text.length / 4);
    }

    countLines(text) {
        if (!text) return 0;
        return text.split('\n').length;
    }

    // ========== SECTORING ENGINE (Bonsai-style hierarchical memory) ==========

    sectorDomains() {
        return {
            identity: { keywords: ['personal', 'family', 'name', 'profile', 'preferences', 'background', 'about'], weight: 10 },
            business: { keywords: ['business', 'revenue', 'company', 'client', 'product', 'pricing', 'sales', 'marketing', 'seo'], weight: 9 },
            code: { keywords: ['code', 'api', 'function', 'repo', 'git', 'deploy', 'server', 'database', 'frontend', 'backend'], weight: 8 },
            decisions: { keywords: ['decided', 'decision', 'chose', 'selected', 'architecture', 'adr', 'rationale'], weight: 7 },
            infra: { keywords: ['infra', 'config', 'cron', 'service', 'hosting', 'domain', 'ssl', 'cert'], weight: 6 },
            project: { keywords: ['project', 'sprint', 'roadmap', 'milestone', 'deadline', 'task', 'issue'], weight: 5 },
            people: { keywords: ['team', 'colleague', 'manager', 'stakeholder', 'client-name', 'partner'], weight: 4 },
            learnings: { keywords: ['learned', 'discovered', 'insight', 'lesson', 'mistake', 'improvement'], weight: 3 },
            general: { keywords: [], weight: 1 }
        };
    }

    classifySection(heading) {
        const lower = heading.toLowerCase();
        const domains = this.sectorDomains();
        let best = 'general';
        let bestScore = 0;

        for (const [domain, config] of Object.entries(domains)) {
            const score = config.keywords.reduce((sum, kw) =>
                lower.includes(kw) ? sum + config.weight : sum, 0);
            if (score > bestScore) {
                bestScore = score;
                best = domain;
            }
        }
        return best;
    }

    ingestMemory(content, options = {}) {
        const { source = 'imported', skipBackup = false } = options;

        if (!skipBackup) {
            this.backupMemory(content);
        }

        const sections = this.parseSections(content);
        const sectorMap = {};
        let totalTokens = 0;

        sections.forEach(section => {
            const domain = this.classifySection(section.heading);
            if (!sectorMap[domain]) sectorMap[domain] = [];
            sectorMap[domain].push(section);
            totalTokens += this.countTokens(section.content);
        });

        // Write domain files
        Object.entries(sectorMap).forEach(([domain, domainSections]) => {
            const domainPath = path.join(this.domainsDir, domain);
            if (!fs.existsSync(domainPath)) fs.mkdirSync(domainPath, { recursive: true });

            domainSections.forEach(section => {
                const slug = this.slugify(section.heading);
                const filePath = path.join(domainPath, `${slug}.md`);
                fs.writeFileSync(filePath, section.content);
            });

            // Generate domain index
            this.writeDomainIndex(domain, domainSections);
        });

        // Write trunk index
        this.writeTrunkIndex(sectorMap);

        // Update stats
        this.stats.totalSectors = Object.keys(sectorMap).length;
        this.stats.totalTokens = totalTokens;
        this.stats.lastOptimized = this.now();
        this.stats.domainStats = {};
        Object.entries(sectorMap).forEach(([domain, sections]) => {
            const tokens = sections.reduce((sum, s) => sum + this.countTokens(s.content), 0);
            this.stats.domainStats[domain] = {
                sections: sections.length,
                tokens,
                compressedTokens: tokens,
                files: sections.map(s => this.slugify(s.heading))
            };
        });
        this.saveStats();

        return {
            success: true,
            domains: Object.keys(sectorMap),
            sections: sections.length,
            totalTokens,
            sectorMap: Object.fromEntries(
                Object.entries(sectorMap).map(([d, s]) => [d, s.length])
            )
        };
    }

    parseSections(content) {
        const sections = [];
        const lines = content.split('\n');
        let currentHeading = null;
        let currentContent = [];

        lines.forEach(line => {
            if (line.startsWith('## ')) {
                if (currentHeading !== null && currentContent.length > 0) {
                    sections.push({
                        heading: currentHeading,
                        content: currentContent.join('\n').trim()
                    });
                }
                currentHeading = line.replace('## ', '').trim();
                currentContent = [line];
            } else if (currentHeading !== null) {
                currentContent.push(line);
            }
        });

        if (currentHeading !== null && currentContent.length > 0) {
            sections.push({
                heading: currentHeading,
                content: currentContent.join('\n').trim()
            });
        }

        return sections;
    }

    slugify(text) {
        return text.toLowerCase()
            .replace(/[^a-z0-9\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .substring(0, 60);
    }

    writeDomainIndex(domain, sections) {
        const totalTokens = sections.reduce((sum, s) => sum + this.countTokens(s.content), 0);
        const lines = [];
        lines.push(`# ${this.capitalize(domain)} Domain`);
        lines.push(`_Sections: ${sections.length}_`);
        lines.push(`_Estimated tokens: ~${totalTokens}_`);
        lines.push('');

        sections.forEach(section => {
            const firstLine = section.content.split('\n')[1] || '';
            const preview = firstLine.replace(/^#+\s*/, '').substring(0, 80) || '(empty)';
            const tokens = this.countTokens(section.content);
            lines.push(`### ${section.heading} (~${tokens} tokens)`);
            lines.push(preview);
            lines.push('');
        });

        const indexPath = path.join(this.domainsDir, domain, '_index.md');
        fs.writeFileSync(indexPath, lines.join('\n'));
    }

    writeTrunkIndex(sectorMap) {
        const lines = [];
        lines.push('# Compressed Memory Index');
        lines.push(`_Optimized: ${this.now()}_`);
        lines.push(`_Total domains: ${Object.keys(sectorMap).length}_`);

        Object.entries(sectorMap).forEach(([domain, sections]) => {
            const totalTokens = sections.reduce((sum, s) => sum + this.countTokens(s.content), 0);
            const firstLine = (sections[0]?.content?.split('\n')[1] || '').substring(0, 60);
            lines.push('');
            lines.push(`## ${this.capitalize(domain)} (~${totalTokens} tokens)`);
            lines.push(firstLine || `${sections.length} sections`);
            lines.push(`_Sections: ${sections.length}_`);
        });

        const trunkPath = path.join(this.memoryDir, 'INDEX.md');
        fs.writeFileSync(trunkPath, lines.join('\n'));
    }

    capitalize(str) { return str.charAt(0).toUpperCase() + str.slice(1); }

    backupMemory(content) {
        const backupPath = path.join(this.memoryDir, `memory-backup-${Date.now()}.md`);
        fs.writeFileSync(backupPath, content);
    }

    // ========== COMPRESSION ENGINE ==========

    compressMemory(options = {}) {
        const { targetTokens = 2048, preserveRecent = true, recentDays = 7 } = options;
        const domains = this.listDomains();

        const allocation = this.allocateTokenBudget(domains, targetTokens);
        const compressed = [];

        domains.forEach(domain => {
            const sections = this.getDomainSections(domain);
            const budget = allocation[domain] || 100;

            const ranked = this.rankSections(sections, domain, recentDays);
            let used = 0;

            ranked.forEach(section => {
                const filePath = path.join(this.domainsDir, domain, section.file);
                const content = fs.readFileSync(filePath, 'utf8');
                const tokens = this.countTokens(content);

                if (used + tokens <= budget) {
                    compressed.push(content);
                    used += tokens;
                } else if (used < budget) {
                    // Partial - summarize this section
                    const remaining = budget - used;
                    const summary = this.summarizeSection(content, remaining);
                    compressed.push(summary);
                    used += this.countTokens(summary);
                }
            });

            this.stats.domainStats[domain].compressedTokens = used;
        });

        const compressedContent = compressed.join('\n\n---\n\n');
        const compressedPath = path.join(this.memoryDir, 'COMPRESSED.md');
        fs.writeFileSync(compressedPath, compressedContent);

        this.stats.compressedTokens = this.countTokens(compressedContent);
        this.stats.compressionRatio = this.stats.totalTokens > 0
            ? Math.round((1 - this.stats.compressedTokens / this.stats.totalTokens) * 100)
            : 0;
        this.saveStats();

        return {
            success: true,
            originalTokens: this.stats.totalTokens,
            compressedTokens: this.stats.compressedTokens,
            reduction: `${this.stats.compressionRatio}%`,
            targetTokens,
            path: compressedPath
        };
    }

    listDomains() {
        if (!fs.existsSync(this.domainsDir)) return [];
        return fs.readdirSync(this.domainsDir).filter(d =>
            fs.statSync(path.join(this.domainsDir, d)).isDirectory()
        );
    }

    getDomainSections(domain) {
        const domainPath = path.join(this.domainsDir, domain);
        if (!fs.existsSync(domainPath)) return [];
        return fs.readdirSync(domainPath)
            .filter(f => f.endsWith('.md') && f !== '_index.md')
            .map(f => ({ file: f, path: path.join(domainPath, f) }));
    }

    allocateTokenBudget(domains, targetTokens) {
        const allocation = {};
        const domainWeights = this.sectorDomains();
        let totalWeight = 0;

        domains.forEach(d => {
            const weight = domainWeights[d]?.weight || 1;
            totalWeight += weight;
        });

        domains.forEach(d => {
            const weight = domainWeights[d]?.weight || 1;
            allocation[d] = Math.floor((weight / totalWeight) * targetTokens);
        });

        return allocation;
    }

    rankSections(sections, domain, recentDays) {
        const accessLog = this.stats.accessLog || [];
        const cutoff = Date.now() - recentDays * 24 * 60 * 60 * 1000;

        return sections.map(section => {
            const accessCount = accessLog.filter(a =>
                a.file === section.file && a.domain === domain
            ).length;

            const recentAccess = accessLog.filter(a =>
                a.file === section.file &&
                a.domain === domain &&
                new Date(a.timestamp).getTime() > cutoff
            ).length;

            const stat = fs.statSync(section.path);

            return {
                ...section,
                accessCount,
                recentAccess,
                modifiedTime: stat.mtimeMs,
                score: recentAccess * 10 + accessCount * 2 + (stat.mtimeMs / 100000000000)
            };
        }).sort((a, b) => b.score - a.score);
    }

    summarizeSection(content, maxTokens) {
        const lines = content.split('\n');
        const heading = lines[0] || 'Summary';
        const body = lines.slice(1).join('\n');

        // Keep heading + first N tokens of body
        const maxChars = maxTokens * 4;
        const truncatedBody = body.length > maxChars
            ? body.substring(0, maxChars) + '\n\n_... (compressed by Token Compression Soul)_'
            : body;

        return `${heading}\n${truncatedBody}`;
    }

    // ========== FSRS-STYLE SCHEDULING ==========

    logAccess(domain, file) {
        if (!this.stats.accessLog) this.stats.accessLog = [];
        this.stats.accessLog.push({
            domain,
            file,
            timestamp: this.now()
        });

        // Keep only last 1000 entries
        if (this.stats.accessLog.length > 1000) {
            this.stats.accessLog = this.stats.accessLog.slice(-1000);
        }
        this.saveStats();
    }

    getScheduledReview() {
        const domains = this.listDomains();
        const schedule = [];

        domains.forEach(domain => {
            const sections = this.getDomainSections(domain);
            sections.forEach(section => {
                const accessCount = (this.stats.accessLog || [])
                    .filter(a => a.file === section.file && a.domain === domain).length;

                // FSRS-like: prioritize what hasn't been accessed recently
                const lastAccess = [...(this.stats.accessLog || [])]
                    .reverse()
                    .find(a => a.file === section.file && a.domain === domain);

                const daysSinceAccess = lastAccess
                    ? (Date.now() - new Date(lastAccess.timestamp).getTime()) / (24 * 60 * 60 * 1000)
                    : 999;

                schedule.push({
                    domain,
                    file: section.file,
                    accessCount,
                    daysSinceAccess,
                    // Retrievability score (FSRS-inspired): higher = needs review
                    retrievability: Math.min(1, daysSinceAccess / 30)
                });
            });
        });

        return schedule.sort((a, b) => b.retrievability - a.retrievability);
    }

    // ========== CONTEXT RECONSTRUCTION ==========

    getOptimizedContext(options = {}) {
        const { query = '', maxTokens = 4096, includeTrunk = true } = options;

        let context = [];

        // Always include trunk
        if (includeTrunk) {
            const trunkPath = path.join(this.memoryDir, 'INDEX.md');
            if (fs.existsSync(trunkPath)) {
                context.push(fs.readFileSync(trunkPath, 'utf8'));
            }
        }

        // If there's a query, find relevant domains
        if (query) {
            const relevantDomains = this.findRelevantDomains(query);
            relevantDomains.forEach(domain => {
                const indexPath = path.join(this.domainsDir, domain, '_index.md');
                if (fs.existsSync(indexPath)) {
                    context.push(`\n## ${this.capitalize(domain)} Domain\n`);
                    context.push(fs.readFileSync(indexPath, 'utf8'));
                }

                // Include specific matching files
                const sections = this.getDomainSections(domain);
                sections.forEach(section => {
                    const content = fs.readFileSync(section.path, 'utf8');
                    if (content.toLowerCase().includes(query.toLowerCase())) {
                        context.push('\n' + content);
                        this.logAccess(domain, section.file);
                    }
                });
            });
        }

        // If under maxTokens, include compressed memory
        let contextText = context.join('\n');
        if (this.countTokens(contextText) < maxTokens) {
            const compressedPath = path.join(this.memoryDir, 'COMPRESSED.md');
            if (fs.existsSync(compressedPath)) {
                const compressed = fs.readFileSync(compressedPath, 'utf8');
                const remainingTokens = maxTokens - this.countTokens(contextText);
                const compressedLines = compressed.split('\n');
                let compressedBudget = remainingTokens * 4;
                let included = [];
                for (const line of compressedLines) {
                    if (compressedBudget <= 0) break;
                    included.push(line);
                    compressedBudget -= line.length + 1;
                }
                if (included.length > 0) {
                    contextText += '\n\n' + included.join('\n');
                }
            }
        }

        const finalTokens = this.countTokens(contextText);
        const reduction = this.stats.totalTokens > 0
            ? Math.round((1 - finalTokens / this.stats.totalTokens) * 100)
            : 0;

        return {
            context: contextText,
            tokens: finalTokens,
            originalTokens: this.stats.totalTokens,
            reduction: `${reduction}%`,
            domainsSearched: query ? this.findRelevantDomains(query) : []
        };
    }

    findRelevantDomains(query) {
        const lower = query.toLowerCase();
        const domains = this.sectorDomains();
        const scored = [];

        for (const [domain, config] of Object.entries(domains)) {
            const score = config.keywords.reduce((sum, kw) =>
                lower.includes(kw) ? sum + config.weight : sum, 0);
            if (score > 0) scored.push({ domain, score });
        }

        // Also check actual content
        this.listDomains().forEach(domain => {
            if (!scored.find(s => s.domain === domain)) {
                const sections = this.getDomainSections(domain);
                for (const section of sections) {
                    try {
                        const content = fs.readFileSync(section.path, 'utf8');
                        if (content.toLowerCase().includes(lower)) {
                            scored.push({ domain, score: 1 });
                            break;
                        }
                    } catch {}
                }
            }
        });

        return [...new Set(scored.sort((a, b) => b.score - a.score).map(s => s.domain))];
    }

    // ========== UTILITIES ==========

    getStats() {
        return {
            ...this.stats,
            domains: this.listDomains(),
            totalFiles: this.listDomains().reduce((sum, d) =>
                sum + this.getDomainSections(d).length, 0
            ),
            schedulePending: this.getScheduledReview().filter(s => s.retrievability > 0.5).length
        };
    }

    // ========== EXPORT ==========

    exportReconstructedMemory() {
        const domains = this.listDomains();
        const lines = [];

        lines.push('# Reconstructed Memory');
        lines.push(`_Reconstructed: ${this.now()}_`);
        lines.push(`_Compression ratio: ${this.stats.compressionRatio || 0}%_`);
        lines.push('');

        domains.forEach(domain => {
            const sections = this.getDomainSections(domain);
            lines.push(`## ${this.capitalize(domain)}`);
            lines.push('');

            sections.forEach(section => {
                const content = fs.readFileSync(section.path, 'utf8');
                lines.push(content);
                lines.push('');
            });
        });

        const exportPath = path.join(this.memoryDir, 'RECONSTRUCTED.md');
        fs.writeFileSync(exportPath, lines.join('\n'));

        return {
            success: true,
            path: exportPath,
            tokens: this.countTokens(lines.join('\n'))
        };
    }
}

module.exports = TokenCompressor;

if (require.main === module) {
    const compress = new TokenCompressor();
    const cmd = process.argv[2] || 'help';

    switch (cmd) {
        case 'ingest':
            const filePath = process.argv[3];
            if (filePath && fs.existsSync(filePath)) {
                const content = fs.readFileSync(filePath, 'utf8');
                console.log(JSON.stringify(compress.ingestMemory(content), null, 2));
            } else {
                console.log('Usage: node lib/soul-compress.js ingest <file>');
            }
            break;
        case 'compress':
            const target = parseInt(process.argv[3]) || 2048;
            console.log(JSON.stringify(compress.compressMemory({ targetTokens: target }), null, 2));
            break;
        case 'context':
            const query = process.argv.slice(3).join(' ');
            console.log(JSON.stringify(compress.getOptimizedContext({ query }), null, 2));
            break;
        case 'schedule':
            console.log(JSON.stringify(compress.getScheduledReview(), null, 2));
            break;
        case 'stats':
            console.log(JSON.stringify(compress.getStats(), null, 2));
            break;
        case 'reconstruct':
            console.log(JSON.stringify(compress.exportReconstructedMemory(), null, 2));
            break;
        default:
            console.log(`
💰 Token Compression Soul v1.0.0

Commands:
  ingest <file>       - Import and sector a flat memory file
  compress [tokens]   - Compress to target token budget (default: 2048)
  context [query]     - Get optimized context (optionally filtered by query)
  schedule            - Show FSRS-style review schedule
  stats               - Show compression statistics
  reconstruct         - Export full reconstructed memory
  help                - Show this help

Example:
  node lib/soul-compress.js ingest MEMORY.md
  node lib/soul-compress.js compress 1024
  node lib/soul-compress.js context "authentication"
`);
    }
}