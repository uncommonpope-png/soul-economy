# Token Compression Soul v1.0.0

**Reduce your AI agent's memory token usage by 70-95%. Save money. Think faster.**

## The Problem

Every AI session loads the ENTIRE memory file. If your agent has 6,000 tokens of memory, it burns 6,000 tokens before answering a single question. This costs real money and pollutes the agent's reasoning.

## The Solution

Token Compression Soul restructures flat memory into a sectorized hierarchy. On every session, the agent loads only the trunk (index) — typically 300-500 tokens. Specific domains are loaded only when needed.

**Techniques combined:**
- **Bonsai-style sectoring** — B-tree inspired hierarchy: trunk → domain → file
- **FSRS spaced repetition** — Only surfaces what's about to be forgotten
- **Progressive disclosure** — Load what you need, when you need it
- **Token budget allocation** — Weight-based distribution across domains

## Results

| Metric | Flat Memory | Compressed |
|--------|-------------|------------|
| Boot token cost | 6,400 | ~385 (**94% less**) |
| Cost per session | High | Low |
| Context pollution | Yes | No |
| Reasoning quality | Degraded | Focused |

## Quick Start

```bash
# Ingest your memory file
node lib/soul-compress.js ingest MEMORY.md

# Compress to a target token budget
node lib/soul-compress.js compress 1024

# Get optimized context for a specific query
node lib/soul-compress.js context "authentication"

# View compression stats
node lib/soul-compress.js stats

# Reconstruct full memory from sectors
node lib/soul-compress.js reconstruct
```

## API Usage

```javascript
const TokenCompressor = require('@buyasoul/soul-compress');
const compressor = new TokenCompressor();

// Ingest flat memory
compressor.ingestMemory(fs.readFileSync('MEMORY.md', 'utf8'));

// Get optimized context for an agent's query
const ctx = compressor.getOptimizedContext({
    query: 'authentication decisions',
    maxTokens: 2048
});

// Feed ctx.context to your AI agent
```

## Requirements

- Node.js 18+

## License

MIT