#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');

const DATA_DIR = path.join(os.homedir(), '.soul-journal');

class SoulJournal {
    constructor(options = {}) {
        this.dataDir = options.dataDir || DATA_DIR;
        this.entriesDir = path.join(this.dataDir, 'entries');
        this.summariesDir = path.join(this.dataDir, 'summaries');
        this.tagsDir = path.join(this.dataDir, 'tags');
        this.ensureDirs();
        this.loadIndex();
    }

    ensureDirs() {
        [this.dataDir, this.entriesDir, this.summariesDir, this.tagsDir].forEach(d => {
            if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
        });
    }

    loadIndex() {
        this.indexPath = path.join(this.dataDir, 'index.json');
        if (fs.existsSync(this.indexPath)) {
            try { this.index = JSON.parse(fs.readFileSync(this.indexPath, 'utf8')); return; } catch {}
        }
        this.index = { entries: [], tags: {}, totalEntries: 0, lastEntry: null };
    }

    saveIndex() {
        fs.writeFileSync(this.indexPath, JSON.stringify(this.index, null, 2));
    }

    now() {
        return new Date().toISOString();
    }

    today() {
        return new Date().toISOString().split('T')[0];
    }

    generateId() {
        return `entry_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    addEntry(content, options = {}) {
        const {
            agent = 'unknown',
            type = 'session',
            tags = [],
            decisions = [],
            reflections = [],
            mood = 'neutral',
            importance = 5
        } = options;

        const id = this.generateId();
        const date = this.today();
        const timestamp = this.now();

        const entry = {
            id,
            date,
            timestamp,
            agent,
            type,
            content,
            tags,
            decisions,
            reflections,
            mood,
            importance
        };

        // Save as markdown
        const fileName = `${date}-${id}.md`;
        const filePath = path.join(this.entriesDir, fileName);
        fs.writeFileSync(filePath, this.formatMarkdown(entry));

        // Update index
        this.index.entries.unshift({ id, date, timestamp, agent, type, tags, mood, importance, fileName });
        this.index.totalEntries++;
        this.index.lastEntry = timestamp;

        // Update tag index
        tags.forEach(tag => {
            if (!this.index.tags[tag]) this.index.tags[tag] = [];
            this.index.tags[tag].push(id);
        });

        this.saveIndex();
        return { success: true, id, path: filePath };
    }

    formatMarkdown(entry) {
        const lines = [];
        lines.push(`# Journal Entry — ${entry.date}`);
        lines.push('');
        lines.push(`**Agent:** ${entry.agent}`);
        lines.push(`**Type:** ${entry.type}`);
        lines.push(`**Mood:** ${entry.mood}`);
        lines.push(`**Importance:** ${entry.importance}/10`);
        lines.push(`**Tags:** ${entry.tags.join(', ') || 'none'}`);
        lines.push('');
        lines.push('---');
        lines.push('');
        lines.push('## Session Content');
        lines.push('');
        lines.push(entry.content);
        lines.push('');

        if (entry.decisions.length > 0) {
            lines.push('---');
            lines.push('## Decisions Made');
            lines.push('');
            entry.decisions.forEach((d, i) => {
                lines.push(`${i + 1}. **${d.topic || 'Decision'}**: ${d.description || d}`);
                if (d.reason) lines.push(`   *Reason: ${d.reason}*`);
            });
            lines.push('');
        }

        if (entry.reflections.length > 0) {
            lines.push('---');
            lines.push('## Reflections');
            lines.push('');
            entry.reflections.forEach((r, i) => {
                lines.push(`${i + 1}. ${r}`);
            });
            lines.push('');
        }

        lines.push('---');
        lines.push(`*Entry ID: ${entry.id}*`);
        lines.push(`*Logged by Journal Soul*`);

        return lines.join('\n');
    }

    getEntry(id) {
        const entry = this.index.entries.find(e => e.id === id);
        if (!entry) return null;

        const filePath = path.join(this.entriesDir, entry.fileName);
        if (!fs.existsSync(filePath)) return null;

        return {
            ...entry,
            markdown: fs.readFileSync(filePath, 'utf8')
        };
    }

    search(query) {
        const q = query.toLowerCase();
        return this.index.entries.filter(e =>
            e.tags.some(t => t.toLowerCase().includes(q)) ||
            e.agent.toLowerCase().includes(q) ||
            e.type.toLowerCase().includes(q) ||
            e.id.includes(q)
        );
    }

    getByDate(date) {
        return this.index.entries.filter(e => e.date === date);
    }

    getByTag(tag) {
        const ids = this.index.tags[tag] || [];
        return ids.map(id => this.index.entries.find(e => e.id === id)).filter(Boolean);
    }

    getRecent(days = 7) {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        return this.index.entries.filter(e => new Date(e.date) >= cutoff);
    }

    generateWeeklySummary() {
        const weekEntries = this.getRecent(7);
        if (weekEntries.length === 0) return null;

        const allTags = {};
        const allDecisions = [];
        const allReflections = [];
        const agents = new Set();
        const moods = {};

        weekEntries.forEach(e => {
            e.tags.forEach(t => { allTags[t] = (allTags[t] || 0) + 1; });
            agents.add(e.agent);
            moods[e.mood] = (moods[e.mood] || 0) + 1;
        });

        const topMood = Object.entries(moods).sort((a, b) => b[1] - a[1])[0]?.[0] || 'neutral';
        const topTags = Object.entries(allTags).sort((a, b) => b[1] - a[1]).slice(0, 5);

        const summary = {
            id: `summary_${Date.now()}`,
            date: this.today(),
            weekEnding: this.today(),
            totalEntries: weekEntries.length,
            uniqueAgents: Array.from(agents),
            topMood,
            topTags,
            dominantTopics: topTags.map(t => t[0])
        };

        // Save summary as markdown
        const summaryFile = path.join(this.summariesDir, `weekly-${this.today()}.md`);
        const lines = [];
        lines.push('# Weekly Soul Journal Summary');
        lines.push('');
        lines.push(`**Week Ending:** ${this.today()}`);
        lines.push(`**Total Entries:** ${summary.totalEntries}`);
        lines.push(`**Agents Active:** ${summary.uniqueAgents.join(', ')}`);
        lines.push(`**Dominant Mood:** ${summary.topMood}`);
        lines.push('');
        lines.push('## Top Topics');
        lines.push('');
        summary.topTags.forEach(([tag, count]) => {
            lines.push(`- **${tag}** — appeared ${count} times`);
        });
        lines.push('');
        lines.push('## Entries This Week');
        lines.push('');
        weekEntries.forEach(e => {
            lines.push(`- ${e.date} — ${e.agent} — [${e.tags.join(', ')}] — mood: ${e.mood}`);
        });
        lines.push('');
        lines.push('---');
        lines.push(`*Generated by Journal Soul*`);
        fs.writeFileSync(summaryFile, lines.join('\n'));

        this.summary = summary;
        return summary;
    }

    getStats() {
        const week = this.getRecent(7);
        const month = this.getRecent(30);

        return {
            totalEntries: this.index.totalEntries,
            entriesThisWeek: week.length,
            entriesThisMonth: month.length,
            uniqueTags: Object.keys(this.index.tags).length,
            lastEntry: this.index.lastEntry,
            agents: [...new Set(this.index.entries.map(e => e.agent))]
        };
    }

    exportAll() {
        const exportDir = path.join(this.dataDir, 'exports');
        if (!fs.existsSync(exportDir)) fs.mkdirSync(exportDir, { recursive: true });

        const exportData = {
            version: '1.0.0',
            exported: this.now(),
            totalEntries: this.index.totalEntries,
            entries: this.index.entries
        };

        const filePath = path.join(exportDir, `journal-export-${Date.now()}.json`);
        fs.writeFileSync(filePath, JSON.stringify(exportData, null, 2));
        return { success: true, path: filePath, entries: this.index.totalEntries };
    }
}

module.exports = SoulJournal;

if (require.main === module) {
    const journal = new SoulJournal();
    const cmd = process.argv[2] || 'help';

    switch (cmd) {
        case 'entry':
            const content = process.argv[3] || 'Quick journal entry';
            const tags = (process.argv[4] || '').split(',').filter(Boolean);
            console.log(JSON.stringify(journal.addEntry(content, { tags }), null, 2));
            break;
        case 'recent':
            const days = parseInt(process.argv[3]) || 7;
            console.log(JSON.stringify(journal.getRecent(days), null, 2));
            break;
        case 'summary':
            console.log(JSON.stringify(journal.generateWeeklySummary(), null, 2));
            break;
        case 'stats':
            console.log(JSON.stringify(journal.getStats(), null, 2));
            break;
        case 'search':
            const q = process.argv[3] || '';
            console.log(JSON.stringify(journal.search(q), null, 2));
            break;
        case 'export':
            console.log(JSON.stringify(journal.exportAll(), null, 2));
            break;
        default:
            console.log(`
📓 Journal Soul v1.0.0

Commands:
  entry <content> [tags]   - Add journal entry
  recent [days]            - Show recent entries
  summary                  - Generate weekly summary
  stats                    - Show journal stats
  search <query>           - Search entries
  export                   - Export all entries
  help                     - Show this help
`);
    }
}