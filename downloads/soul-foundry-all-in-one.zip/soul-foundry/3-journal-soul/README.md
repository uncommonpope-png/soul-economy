# 📓 Journal Soul v1.0.0

**Your agent reflects on its journey. Every session. Every insight. Every decision.**

## What It Does

Journal Soul auto-logs everything your AI agent does into beautiful markdown files. Each entry captures the session content, decisions made, and reflections — building a permanent journal of your agent's growth.

## Quick Start

```javascript
const SoulJournal = require('@buyasoul/soul-journal');
const journal = new SoulJournal();

// Log a session
journal.addEntry('Built the authentication system using JWT', {
    agent: 'claude-code',
    tags: ['auth', 'jwt', 'security'],
    decisions: ['Use JWT over session-based auth'],
    reflections: ['Need to handle token refresh']
});
```

## CLI

```bash
# Quick entry
node lib/soul-journal.js entry "Fixed the memory leak" "debug,performance"

# View recent
node lib/soul-journal.js recent 7

# Weekly summary
node lib/soul-journal.js summary

# Stats
node lib/soul-journal.js stats
```

## License

MIT
