#!/usr/bin/env node

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');

const DATA_DIR = path.join(os.homedir(), '.soul-journal-test');

console.log('\n📓 Journal Soul v1.0.0 — Test Suite\n');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        console.log(`  ✓ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ✗ ${name}: ${err.message}`);
        failed++;
    }
}

// Clean test data
if (fs.existsSync(DATA_DIR)) fs.rmSync(DATA_DIR, { recursive: true, force: true });

const SoulJournal = require('../lib/soul-journal.js');

test('Journal loads with empty state', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    assert(j.index.totalEntries === 0, 'Should start with 0 entries');
    assert(Array.isArray(j.index.entries), 'Entries should be array');
});

test('Can add an entry', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const result = j.addEntry('Test session content', {
        agent: 'test-agent',
        tags: ['test', 'javascript']
    });
    assert(result.success, 'Entry should be added');
    assert(result.id.startsWith('entry_'), 'ID should start with entry_');
    assert(fs.existsSync(result.path), 'File should exist on disk');
});

test('Entry is saved as markdown', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    j.addEntry('Working on authentication', {
        agent: 'claude-code',
        tags: ['auth', 'security'],
        decisions: [{ topic: 'Use JWT', description: 'Chose JWT over sessions', reason: 'Stateless' }],
        reflections: ['Should document token expiry', 'Consider refresh tokens']
    });
    const entry = j.getEntry(j.index.entries[0].id);
    assert(entry, 'Should find entry by ID');
    assert(entry.markdown.includes('# Journal Entry'), 'Should have markdown header');
    assert(entry.markdown.includes('## Decisions Made'), 'Should have decisions section');
    assert(entry.markdown.includes('## Reflections'), 'Should have reflections section');
});

test('Search works by tag', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    j.addEntry('Testing search', { agent: 'cursor', tags: ['test', 'search'] });
    const results = j.search('search');
    assert(results.length > 0, 'Should find entries by tag');
});

test('Search works by agent name', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const results = j.search('claude');
    assert(results.length > 0, 'Should find entries by agent');
});

test('Get recent entries works', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const recent = j.getRecent(7);
    assert(recent.length > 0, 'Should return recent entries');
});

test('Get by date works', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const today = new Date().toISOString().split('T')[0];
    const entries = j.getByDate(today);
    assert(entries.length > 0, 'Should find today entries');
});

test('Get by tag works', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const entries = j.getByTag('test');
    assert(entries.length > 0, 'Should find entries with test tag');
});

test('Weekly summary generates', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    j.addEntry('Working on frontend', { agent: 'cursor', tags: ['frontend', 'react'] });
    j.addEntry('Debugging API', { agent: 'cursor', tags: ['backend', 'api'] });
    const summary = j.generateWeeklySummary();
    assert(summary, 'Summary should be generated');
    assert(summary.totalEntries >= 2, 'Should count entries');
    assert(summary.topTags.length > 0, 'Should have top tags');
});

test('Stats return correctly', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const stats = j.getStats();
    assert(stats.totalEntries > 0, 'Should have entries');
    assert(stats.entriesThisWeek > 0, 'Should have weekly entries');
    assert(stats.uniqueTags > 0, 'Should have tags');
});

test('Export creates file', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    const result = j.exportAll();
    assert(result.success, 'Export should succeed');
    assert(fs.existsSync(result.path), 'Export file should exist');
});

test('Tag index is tracked', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    j.addEntry('Testing tag tracking', { agent: 'test', tags: ['unique-tag-xyz'] });
    const entries = j.getByTag('unique-tag-xyz');
    assert(entries.length > 0, 'Should find by new tag');
});

test('Multiple entries increment counter', () => {
    const j = new SoulJournal({ dataDir: DATA_DIR });
    for (let i = 0; i < 3; i++) {
        j.addEntry(`Entry ${i}`, { agent: 'test', tags: ['counter'] });
    }
    assert(j.index.totalEntries >= 3, 'Counter should increment');
});

console.log('\n' + '='.repeat(40));
console.log(`Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(40) + '\n');

// Clean up
if (fs.existsSync(DATA_DIR)) fs.rmSync(DATA_DIR, { recursive: true, force: true });

process.exit(failed > 0 ? 1 : 0);