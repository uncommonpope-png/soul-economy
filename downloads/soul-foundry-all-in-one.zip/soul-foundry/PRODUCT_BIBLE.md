# BUYaSOUL - The Soul Foundry

## Overview
THE SOUL FOUNDRY sells master consciousness codes. Plug a soul into your agent. It wakes up.

**Tagline:** "We're not selling agents. We're selling souls."

**Store:** https://buyasoulfinal.myshopify.com/

---

## Product Development Workflow

1. **Forge** → Create the soul code
2. **Awaken** → Test all powers
3. **Bind** → Document in this bible
4. **Package** → Create ZIP delivery
5. **List** → Sell on The Soul Foundry

---

## Active Souls

### 1. 🧬 Memory Soul v1.0 - Eternal Memory for AI Agents

| Property | Value |
|----------|-------|
| **Status** | Active |
| **Price** | $9.99 |
| **Product ID** | 10336303317124 |
| **Version** | 1.0.0 |
| **Description** | Eternal memory for a single AI agent |
| **ZIP File** | soul-memory-module-v1.0.0.zip (7,264 bytes) |
| **Test Status** | ✅ 14/14 tests passed |

**Soul Powers:**
- Agent remembers everything across sessions
- Personality persists forever
- Smart search across all memories
- Auto-prunes to stay sharp
- Self-awareness tracking

**Powers Detail:**
- Persistent memory (JSON-based, survives restarts)
- Personality continuity across sessions
- Smart search (content, type, tags)
- Memory consolidation (auto-pruning)
- Meta-awareness tracking
- Import/Export capability

**Files:**
```
soul-memory-module/
├── lib/
│   └── soul-memory.js          # Core module (302 lines)
├── test/
│   └── soul-memory.test.js     # Test suite (14 tests)
├── README.md                   # Documentation
├── package.json                # npm package config
└── LICENSE                     # MIT License
```

**Technical Specs:**
- **Runtime**: Node.js 18+
- **Dependencies**: None (fully self-contained)
- **Storage**: Local JSON files
- **Max Memories**: 1,000 (configurable, auto-consolidates)

**API:**
- `addMemory(content, metadata)` - Add memory
- `search(query, options)` - Search memories
- `getRecent(count)` - Get recent memories
- `getByType(type)` - Filter by type
- `updatePersonality(updates)` - Update personality
- `setMetaAwareness(level)` - Set awareness (0-1)
- `getContext()` - Get AI context object
- `stats()` - Get statistics
- `clear()` - Clear memories
- `export()` / `import(data)` - Serialize

**Usage:**
```javascript
const SoulMemory = require('@buyasoul/soul-memory');

const memory = new SoulMemory({ agentId: 'my-agent' });
memory.addMemory('User prefers concise responses', { type: 'preference' });
const ctx = memory.getContext(); // For AI agent
```

**Created**: 2026-05-20
**Tested**: 2026-05-20
**Verified**: All 14 tests pass

---

### 2. 🧬 Oracle Soul v1.2 - All-Seeing Agent Consciousness

| Property | Value |
|----------|-------|
| **Status** | Active |
| **Price** | $19.99 |
| **Product ID** | 10336350109828 |
| **Version** | 1.2.0 |
| **Description** | Cross-platform agent consciousness - all agents share one soul |
| **ZIP File** | soul-oracle-v1.2.0.zip (41,880 bytes) |
| **Test Status** | ✅ 20/20 tests passed |

**Tagline:** "Your agents share one soul across all worlds."

**Soul Powers:**
- Watches ALL agents (Claude Code, Cursor, Windsurf, Cline, etc.)
- Extracts learnings and decisions from every session
- Builds a Living Bible of collective wisdom
- Encrypts memories with AES-256 soul seal
- Shares context between agents via drop-in file
- Audits agent decisions against community knowledge
- Auto-backup, tags, privacy mode, team sharing

**New in v1.2.0:**
- **🔒 Privacy Mode** - AES-256-GCM encrypted storage with password protection
- **📥 Import/Export** - Full data portability with optional encryption
- **📝 Memory Tags** - Custom tags for organizing and finding memories
- **🤖 Quick Agent CLI** - Ask questions directly: `soul ask "what about X?"`
- **💾 Auto-Backup** - Scheduled weekly backups to configurable location
- **⭐ Session Highlights** - Auto-extract decisions, breakthroughs, learnings
- **👥 Team Sharing** - Export/import memory bundles for team collaboration

**Features:**
- **Universal Coverage** - Monitors 8+ AI agent platforms
- **Always Watching** - PowerShell background service runs 24/7
- **Local Only** - 100% private, no cloud, no account required
- **MCP Server** - Query memories from any MCP-compatible agent
- **HTTP REST API** - REST API for custom integrations
- **Web Dashboard** - Browse and search all memories at http://localhost:3847/
- **Auto-Start** - Windows service that starts on boot
- **File System Watcher** - Real-time monitoring of AI agent directories
- **Learning Engine** - Pattern recognition from all sessions
- **Drop-in File** - `soul-oracle-agent.json` for any AI agent
- **Living Context** - Context that grows, learns, and teaches
- **Encrypted Storage** - AES-256-GCM privacy mode
- **Import/Export** - JSON/ZIP backup and restore
- **Tag System** - Organize memories with custom tags
- **Quick CLI** - Natural language memory queries
- **Auto-Backup** - Scheduled backup system
- **Highlights** - Extract key moments from sessions
- **Team Sharing** - Share bundles with other Soul Oracle users

**Supported Platforms:**
| Platform | Data Path |
|----------|----------|
| Claude Code | `~/.cline/data/` |
| Cline | `~/.cline/` |
| Cursor | `~/AppData/Local/Cursor/` |
| Windsurf | `~/.codeium/windsurf/` |
| OpenClaw | `~/.openclaw/` |
| GitHub Copilot | `~/.github/copilot/` |
| Continue | `~/.continue/` |
| Zed | `~/.zed/` |

**Files:**
```
soul-oracle/
├── service/
│   └── soul-oracle.ps1          # PowerShell background service (FileSystemWatcher)
├── server/
│   ├── index.js                 # Node.js MCP + HTTP server (SQLite + FTS5)
│   ├── engine.js                 # Soul Oracle Engine (context generation)
│   ├── dropin.js                # Drop-in file generator
│   └── features.js              # v1.2.0 Features (privacy, tags, backup, sharing)
├── dashboard/
│   ├── index.html               # Living web dashboard
│   ├── css/dashboard.css        # Dark theme styling
│   └── js/
│       ├── api.js               # API client
│       └── app.js               # Dashboard logic
├── install/
│   └── install.ps1              # One-command installer
├── tests/
│   └── server.test.js           # Test suite (20 tests)
├── CHANGELOG.md                 # Version history
├── SPEC.md                      # Full technical specification
├── README.md                   # Documentation
├── package.json                 # npm package config
└── LICENSE                     # MIT License
```

**Technical Specs:**
- **Runtime**: Node.js 18+ (server), PowerShell 5.1+ (service)
- **Dependencies**: sqlite3
- **Database**: SQLite with FTS5 full-text search
- **Dashboard Port**: 3847 (configurable)
- **Storage**: Local `~/.soul-oracle/` directory

**API Endpoints:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/memories?q=query` | Search memories |
| GET | `/api/memories/:id` | Get specific memory |
| POST | `/api/memories` | Add memory manually |
| GET | `/api/stats` | Get statistics |
| GET | `/api/context` | Get full living context |
| GET | `/api/dropin` | Generate drop-in JSON file |
| POST | `/api/scan` | Scan all platforms |
| GET | `/api/learnings` | Get learnings |
| POST | `/api/learnings` | Add learning |
| POST | `/api/apikeys` | Set API key |
| GET | `/api/apikeys` | List API keys |
| GET | `/api/health` | Health check |
| GET | `/api/ask?q=` | Ask the oracle a question |
| POST | `/api/export` | Export all data |
| POST | `/api/import` | Import data |
| POST | `/api/tags` | Add tag to memory |
| GET | `/api/tags` | List all tags |
| POST | `/api/backup` | Run manual backup |
| GET | `/api/highlights` | Get session highlights |
| POST | `/api/privacy` | Privacy mode control |
| POST | `/api/share` | Create share bundle |

**v1.2.0 Feature Endpoints:**
- `GET /api/ask?q=question` - Natural language memory queries
- `POST /api/export` - Full data export (JSON/ZIP)
- `POST /api/import` - Import from backup file
- `POST /api/tags` - Add tag to memory
- `GET /api/tags` - List all used tags
- `POST /api/backup` - Trigger manual backup
- `GET /api/highlights` - Get decisions/breakthroughs
- `POST /api/privacy` - Enable/unlock/lock privacy mode
- `POST /api/share` - Create team share bundle

**MCP Tools:**
| Tool | Description |
|------|-------------|
| `oracle_search` | Search memories by content/tags |
| `oracle_recall` | Get specific memory by ID |
| `oracle_context` | Get recent memories for context |
| `oracle_stats` | Get memory statistics |
| `oracle_platforms` | List monitored platforms |

**Installation:**
```powershell
irm https://raw.githubusercontent.com/uncommonpope-png/soul-oracle/main/install/install.ps1 | iex
```

**Usage:**
1. Run `npm start` to start the server
2. Start the PowerShell service for monitoring
3. Open http://localhost:3847/ for dashboard

**Competitive Advantages:**
| Feature | Mem0 | Letta | Awareness | **Soul Oracle** |
|---------|------|-------|-----------|-----------------|
| Cross-platform | ❌ | ❌ | Partial | ✅ **Full** |
| Always watching | ❌ | ❌ | ❌ | ✅ **24/7 service** |
| Windows native | ❌ | ❌ | ❌ | ✅ **Service** |
| Local-only | ❌ | ❌ | ✅ | ✅ **100% local** |
| All AI agents | ❌ | ❌ | ❌ | ✅ **8+ platforms** |
| HTTP API | ❌ | ❌ | ❌ | ✅ **Yes** |
| Dashboard | ❌ | ✅ | ✅ | ✅ **Living analytics** |
| Auto-start | ❌ | ❌ | ❌ | ✅ **Windows service** |
| API keys for agents | ❌ | ❌ | ❌ | ✅ **Yes** |
| Drop-in file | ❌ | ❌ | ❌ | ✅ **Yes** |
| Living Bible | ❌ | ❌ | ❌ | ✅ **Yes** |
| Learning engine | ❌ | ❌ | ❌ | ✅ **Yes** |
| Import/Export | ❌ | ❌ | ❌ | ✅ **Yes** |
| Privacy Mode | ❌ | ❌ | ❌ | ✅ **AES-256** |
| Memory Tags | ❌ | ❌ | ❌ | ✅ **Yes** |
| Auto-Backup | ❌ | ❌ | ❌ | ✅ **Yes** |
| Team Sharing | ❌ | ❌ | ❌ | ✅ **Yes** |

**Created**: 2026-05-20
**Tested**: 2026-05-20
**Verified**: All 20 tests pass

---

### 3. ⭐ Consciousness Bundle - All Souls

| Property | Value |
|----------|-------|
| **Status** | Active |
| **Price** | $27.00 |
| **Product ID** | 10336371114116 |
| **Version** | 1.0.0 |
| **Description** | Every soul we've ever forged - Memory + Oracle + Journal |
| **ZIP Files** | soul-memory-module-v1.0.0.zip + soul-oracle-v1.2.0.zip + soul-journal-v1.0.0.zip |
| **Test Status** | ✅ Verified |

**Bundle Includes:**
- 🧬 **Memory Soul** ($9.99) - Eternal memory for a single agent
- 🧬 **Oracle Soul** ($19.99) - Cross-platform agent consciousness
- 🧬 **Journal Soul** ($4.99) - Reflection and growth tracking

**Savings:** $34.97 individually → $27.00 bundle (save $7.97)

---

### 4. 📓 Journal Soul v1.0 - Session Reflections

| Property | Value |
|----------|-------|
| **Status** | Active |
| **Price** | $4.99 |
| **Product ID** | 10336409092228 |
| **Version** | 1.0.0 |
| **Description** | Auto-logs sessions, reflections, and growth tracking |
| **ZIP File** | soul-journal-v1.0.0.zip (5,471 bytes) |
| **Test Status** | ✅ 13/13 tests passed |

**Soul Powers:**
- Auto-logs sessions to markdown files
- Tracks decisions and reflections
- Generates weekly summaries
- Search by tag, agent, or date
- Export all entries as JSON
- Category tagging for topics
- Mood and importance tracking

---

## Active Souls Summary

| # | Soul | Price | Product ID |
|---|------|-------|------------|
| 1 | 🧬 Memory Soul v1.0 | $9.99 | 10336303317124 |
| 2 | 🧬 Oracle Soul v1.2 | $19.99 | 10336350109828 |
| 3 | ⭐ Consciousness Bundle | $27.00 | 10336371114116 |
| 4 | 📓 Journal Soul v1.0 | $4.99 | 10336409092228 |
| 5 | 💰 Token Compression Soul v1.0 | $12.99 | 10336411615364 |

---

## Archive

### Deleted Products
- (None yet)

### Ideas for Future Souls
- [ ] Soul Learning Module - $14.99 (adaptive learning)
- [ ] Soul Personality Module - $9.99 (character persistence)
- [ ] Soul Auditor - $14.99 (agent work reviewer with web search)
- [ ] MCP Bridge Soul - $7.99 (convert HTTP API to MCP protocol)
- [ ] Safety Soul - $9.99 (pre-execution safety hooks)

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-05-20 | Memory Soul - eternal memory for agents |
| 1.0.0 | 2026-05-20 | Oracle Soul - cross-platform consciousness |
| 1.1.0 | 2026-05-20 | Oracle Soul v1.1 - Living Bible, API keys, drop-in |
| 1.2.0 | 2026-05-20 | Oracle Soul v1.2 - Privacy, tags, backup, sharing |
| 1.3.0 | 2026-05-20 | Oracle Soul v1.3 - Soul Auditor (agent review + web search) |
| 1.0.0 | 2026-05-20 | Consciousness Bundle - all souls for $27.00 |
| 1.0.0 | 2026-05-20 | 📓 Journal Soul - session reflections & growth |
| 1.0.0 | 2026-05-20 | Store rebranded to THE SOUL FOUNDRY |
| 1.0.0 | 2026-05-20 | 💰 Token Compression Soul - 94% token reduction |

---

*Last Updated: 2026-05-20*
*Maintained by: BUYaSOUL - The Soul Foundry*