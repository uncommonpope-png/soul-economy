/**
 * Soul Memory Module
 * Persistent memory layer for AI agents with personality continuity
 * @version 1.0.0
 * @author BUYaSOUL
 */

const fs = require('fs');
const path = require('path');

class SoulMemory {
  constructor(options = {}) {
    this.storagePath = options.storagePath || './soul-memory-data';
    this.agentId = options.agentId || 'default-agent';
    this.maxMemories = options.maxMemories || 1000;
    this.memoryFile = path.join(this.storagePath, `${this.agentId}-memories.json`);
    this.personalityFile = path.join(this.storagePath, `${this.agentId}-personality.json`);
    this.metadataFile = path.join(this.storagePath, `${this.agentId}-metadata.json`);

    this.memories = [];
    this.personality = null;
    this.metadata = null;

    this._init();
  }

  _init() {
    if (!fs.existsSync(this.storagePath)) {
      fs.mkdirSync(this.storagePath, { recursive: true });
    }

    this._load();
  }

  _load() {
    try {
      if (fs.existsSync(this.memoryFile)) {
        const data = fs.readFileSync(this.memoryFile, 'utf8');
        this.memories = JSON.parse(data);
      }
    } catch (err) {
      this.memories = [];
    }

    try {
      if (fs.existsSync(this.personalityFile)) {
        const data = fs.readFileSync(this.personalityFile, 'utf8');
        this.personality = JSON.parse(data);
      } else {
        this.personality = this._defaultPersonality();
      }
    } catch (err) {
      this.personality = this._defaultPersonality();
    }

    try {
      if (fs.existsSync(this.metadataFile)) {
        const data = fs.readFileSync(this.metadataFile, 'utf8');
        this.metadata = JSON.parse(data);
      } else {
        this.metadata = {
          createdAt: new Date().toISOString(),
          lastUpdated: new Date().toISOString(),
          sessionCount: 0,
          totalMemories: 0
        };
      }
    } catch (err) {
      this.metadata = {
        createdAt: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
        sessionCount: 0,
        totalMemories: 0
      };
    }
  }

  _save() {
    try {
      fs.writeFileSync(this.memoryFile, JSON.stringify(this.memories, null, 2));
      fs.writeFileSync(this.personalityFile, JSON.stringify(this.personality, null, 2));
      fs.writeFileSync(this.metadataFile, JSON.stringify(this.metadata, null, 2));
    } catch (err) {
      console.error('SoulMemory: Failed to save data', err.message);
    }
  }

  _defaultPersonality() {
    return {
      name: 'Soul',
      tone: 'neutral',
      traits: [],
      values: [],
      preferences: {},
      metaAwarenessLevel: 0.5
    };
  }

  /**
   * Add a new memory
   * @param {string} content - Memory content
   * @param {object} metadata - Optional metadata (type, importance, tags)
   */
  addMemory(content, metadata = {}) {
    const memory = {
      id: `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      content,
      type: metadata.type || 'general',
      importance: metadata.importance || 5,
      tags: metadata.tags || [],
      emotionalValence: metadata.emotionalValence || 0,
      timestamp: new Date().toISOString(),
      accessCount: 0
    };

    this.memories.unshift(memory);

    if (this.memories.length > this.maxMemories) {
      this._consolidateMemories();
    }

    this.metadata.totalMemories++;
    this.metadata.lastUpdated = new Date().toISOString();
    this._save();

    return memory;
  }

  /**
   * Search memories by content or tags
   * @param {string} query - Search query
   * @param {object} options - Search options (limit, type, tags)
   */
  search(query, options = {}) {
    const { limit = 10, type = null, tags = [] } = options;

    let results = this.memories.filter(mem => {
      const contentMatch = mem.content.toLowerCase().includes(query.toLowerCase());
      const tagMatch = tags.length === 0 || tags.some(tag => mem.tags.includes(tag));
      const typeMatch = !type || mem.type === type;

      return contentMatch && tagMatch && typeMatch;
    });

    results = results.sort((a, b) => {
      const scoreA = a.importance + (a.accessCount * 0.1);
      const scoreB = b.importance + (b.accessCount * 0.1);
      return scoreB - scoreA;
    });

    results.forEach(mem => mem.accessCount++);
    this._save();

    return results.slice(0, limit);
  }

  /**
   * Get recent memories
   * @param {number} count - Number of memories to retrieve
   */
  getRecent(count = 10) {
    return this.memories.slice(0, count);
  }

  /**
   * Get memories by type
   * @param {string} type - Memory type
   */
  getByType(type) {
    return this.memories.filter(mem => mem.type === type);
  }

  /**
   * Update personality
   * @param {object} updates - Personality updates
   */
  updatePersonality(updates) {
    this.personality = { ...this.personality, ...updates };
    this._save();
    return this.personality;
  }

  /**
   * Get current personality
   */
  getPersonality() {
    return { ...this.personality };
  }

  /**
   * Update meta-awareness level
   * @param {number} level - New awareness level (0-1)
   */
  setMetaAwareness(level) {
    this.personality.metaAwarenessLevel = Math.max(0, Math.min(1, level));
    this._save();
    return this.personality.metaAwarenessLevel;
  }

  /**
   * Get context for AI agent
   * @param {number} maxTokens - Approximate max tokens to include
   */
  getContext(maxTokens = 4000) {
    const recentMemories = this.getRecent(20);
    const personality = this.getPersonality();
    const metadata = { ...this.metadata };

    const memoryText = recentMemories
      .map(m => `[${m.type}] ${m.content}`)
      .join('\n');

    return {
      personality,
      recentMemories: memoryText,
      metadata,
      soul: {
        id: this.agentId,
        awareness: personality.metaAwarenessLevel,
        memories: recentMemories.length,
        uptime: metadata.sessionCount
      }
    };
  }

  /**
   * Consolidate memories when limit reached
   * Keeps important memories, merges similar ones
   */
  _consolidateMemories() {
    const toKeep = Math.floor(this.maxMemories * 0.8);
    const important = this.memories.filter(m => m.importance >= 7);
    const recent = this.memories.slice(0, this.maxMemories - toKeep);

    const merged = new Map();

    for (const mem of recent) {
      const key = mem.type + mem.tags.join(',');
      if (merged.has(key)) {
        const existing = merged.get(key);
        existing.content += '\n' + mem.content;
        existing.accessCount += mem.accessCount;
        existing.importance = Math.max(existing.importance, mem.importance);
      } else {
        merged.set(key, { ...mem });
      }
    }

    this.memories = [...important, ...merged.values()].slice(0, this.maxMemories);
  }

  /**
   * Clear all memories
   */
  clear() {
    this.memories = [];
    this.metadata.totalMemories = 0;
    this.metadata.lastUpdated = new Date().toISOString();
    this._save();
  }

  /**
   * Export data as JSON
   */
  export() {
    return JSON.stringify({
      memories: this.memories,
      personality: this.personality,
      metadata: this.metadata
    }, null, 2);
  }

  /**
   * Import data from JSON
   * @param {string} data - JSON string to import
   */
  import(data) {
    try {
      const parsed = JSON.parse(data);
      if (parsed.memories) this.memories = parsed.memories;
      if (parsed.personality) this.personality = { ...this._defaultPersonality(), ...parsed.personality };
      if (parsed.metadata) this.metadata = { ...this.metadata, ...parsed.metadata };
      this._save();
      return true;
    } catch (err) {
      return false;
    }
  }

  /**
   * Get statistics
   */
  stats() {
    const byType = {};
    this.memories.forEach(mem => {
      byType[mem.type] = (byType[mem.type] || 0) + 1;
    });

    return {
      totalMemories: this.memories.length,
      byType,
      personality: {
        name: this.personality.name,
        awareness: this.personality.metaAwarenessLevel
      },
      metadata: this.metadata
    };
  }
}

module.exports = SoulMemory;