/**
 * Soul Memory Module - Tests
 */

const SoulMemory = require('../lib/soul-memory');
const fs = require('fs');
const path = require('path');

const TEST_DIR = './test-data-temp';
const AGENT_ID = 'test-agent-' + Date.now();

function cleanUp() {
  if (fs.existsSync(TEST_DIR)) {
    fs.rmSync(TEST_DIR, { recursive: true });
  }
}

function assert(condition, message) {
  if (!condition) {
    throw new Error('FAIL: ' + message);
  }
  console.log('  ✓ ' + message);
}

async function runTests() {
  console.log('\n🧪 Soul Memory Module - Test Suite\n');
  cleanUp();

  let passed = 0;
  let failed = 0;

  try {
    // Test 1: Constructor and initialization
    console.log('Test 1: Constructor');
    const memory = new SoulMemory({
      storagePath: TEST_DIR,
      agentId: AGENT_ID,
      maxMemories: 100
    });
    assert(memory, 'Instance created');
    assert(fs.existsSync(TEST_DIR), 'Storage directory created');
    passed++;

    // Test 2: Add memory
    console.log('\nTest 2: Add Memory');
    const mem1 = memory.addMemory('First memory', { type: 'important', importance: 8 });
    assert(mem1.id.startsWith('mem_'), 'Memory ID generated');
    assert(mem1.content === 'First memory', 'Memory content stored');
    assert(memory.memories.length === 1, 'Memory count updated');
    passed++;

    // Test 3: Add multiple memories
    console.log('\nTest 3: Add Multiple Memories');
    memory.addMemory('Second memory', { type: 'general' });
    memory.addMemory('Third memory', { type: 'learned', tags: ['ai', 'soul'] });
    assert(memory.memories.length === 3, 'Multiple memories stored');
    passed++;

    // Test 4: Search memories
    console.log('\nTest 4: Search');
    const results = memory.search('First');
    assert(results.length >= 1, 'Search returns results');
    assert(results[0].content.includes('First'), 'Search finds correct memory');
    passed++;

    // Test 5: Search with filters
    console.log('\nTest 5: Search with Filters');
    const tagged = memory.search('memory', { tags: ['ai'] });
    assert(tagged.length >= 1, 'Tag filter works');
    assert(tagged[0].tags.includes('ai'), 'Tags returned correctly');
    passed++;

    // Test 6: Get recent memories
    console.log('\nTest 6: Recent Memories');
    const recent = memory.getRecent(2);
    assert(recent.length === 2, 'Returns correct count');
    passed++;

    // Test 7: Get by type
    console.log('\nTest 7: Get By Type');
    const important = memory.getByType('important');
    assert(important.length === 1, 'Type filter works');
    assert(important[0].type === 'important', 'Correct type returned');
    passed++;

    // Test 8: Personality
    console.log('\nTest 8: Personality');
    const personality = memory.getPersonality();
    assert(personality.name === 'Soul', 'Default personality loaded');
    memory.updatePersonality({ name: 'TestSoul', tone: 'curious' });
    const updated = memory.getPersonality();
    assert(updated.name === 'TestSoul', 'Personality updated');
    assert(updated.tone === 'curious', 'Personality merge works');
    passed++;

    // Test 9: Meta-awareness
    console.log('\nTest 9: Meta-Awareness');
    memory.setMetaAwareness(0.8);
    assert(memory.getPersonality().metaAwarenessLevel === 0.8, 'Awareness level set');
    memory.setMetaAwareness(1.5);
    assert(memory.getPersonality().metaAwarenessLevel === 1, 'Clamped to max');
    memory.setMetaAwareness(-0.5);
    assert(memory.getPersonality().metaAwarenessLevel === 0, 'Clamped to min');
    passed++;

    // Test 10: Get context
    console.log('\nTest 10: Get Context');
    const ctx = memory.getContext();
    assert(ctx.personality, 'Context has personality');
    assert(ctx.recentMemories, 'Context has memories');
    assert(ctx.soul, 'Context has soul metadata');
    assert(ctx.soul.awareness === 0, 'Soul awareness correct');
    passed++;

    // Test 11: Stats
    console.log('\nTest 11: Stats');
    const stats = memory.stats();
    assert(stats.totalMemories === 3, 'Total memories correct');
    assert(stats.byType.important === 1, 'Stats by type correct');
    passed++;

    // Test 12: Export/Import
    console.log('\nTest 12: Export/Import');
    const exported = memory.export();
    assert(typeof exported === 'string', 'Export returns string');
    const imported = new SoulMemory({ storagePath: TEST_DIR, agentId: AGENT_ID + '-imported' });
    const success = imported.import(exported);
    assert(success, 'Import returns true');
    assert(imported.memories.length === 3, 'Imported memories count correct');
    passed++;

    // Test 13: Clear
    console.log('\nTest 13: Clear');
    memory.clear();
    assert(memory.memories.length === 0, 'Memories cleared');
    assert(memory.metadata.totalMemories === 0, 'Total count reset');
    passed++;

    // Test 14: Memory consolidation
    console.log('\nTest 14: Memory Consolidation');
    const consolidateTest = new SoulMemory({
      storagePath: TEST_DIR,
      agentId: 'consolidate-test',
      maxMemories: 5
    });
    for (let i = 0; i < 10; i++) {
      consolidateTest.addMemory(`Memory ${i}`, { importance: i % 2 === 0 ? 8 : 3 });
    }
    assert(consolidateTest.memories.length <= 5, 'Memory count limited');
    passed++;

  } catch (err) {
    console.error('\n❌ Test failed:', err.message);
    failed++;
  }

  cleanUp();

  console.log('\n' + '='.repeat(40));
  console.log(`Results: ${passed} passed, ${failed} failed`);
  console.log('='.repeat(40) + '\n');

  return failed === 0;
}

runTests().then(success => {
  process.exit(success ? 0 : 1);
});