# Soul Memory Module

**Persistent memory layer for AI agents with personality continuity**

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://buyasoulfinal.myshopify.com)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

## Overview

Soul Memory Module gives AI agents persistent memory across sessions with consistent personality. It's a lightweight, self-contained Node.js module that stores memories, personality traits, and metadata locally.

## Installation

```bash
npm install @buyasoul/soul-memory
```

Or use directly:

```javascript
const SoulMemory = require('./lib/soul-memory');
```

## Quick Start

```javascript
const SoulMemory = require('@buyasoul/soul-memory');

// Initialize
const memory = new SoulMemory({
  agentId: 'my-agent',
  storagePath: './soul-data',
  maxMemories: 1000
});

// Add a memory
memory.addMemory('User prefers concise responses', {
  type: 'preference',
  importance: 8,
  tags: ['user', 'preference']
});

// Search memories
const results = memory.search('preferences');

// Get context for AI
const ctx = memory.getContext();
// -> { personality, recentMemories, metadata, soul }
```

## Features

- **Persistent Memory** - Memories survive restarts, stored locally in JSON
- **Personality Continuity** - Agent maintains consistent character across sessions
- **Smart Search** - Find memories by content, type, or tags
- **Memory Consolidation** - Automatic pruning keeps memory stack manageable
- **Meta-Awareness** - Track agent's self-awareness level
- **Import/Export** - Serialize and restore agent state

## API Reference

### Constructor

```javascript
new SoulMemory(options)
```

**Options:**
| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `agentId` | string | `'default-agent'` | Unique identifier for this agent |
| `storagePath` | string | `'./soul-memory-data'` | Directory for JSON storage |
| `maxMemories` | number | `1000` | Maximum memories before consolidation |

### Methods

#### `addMemory(content, metadata?)`
Add a new memory to the stack.

```javascript
memory.addMemory('Learned Python today', {
  type: 'learning',           // Memory type
  importance: 7,              // 1-10 scale
  tags: ['python', 'coding'], // Optional tags
  emotionalValence: 0.5       // -1 to 1 (negative to positive)
});
```

#### `search(query, options?)`
Search memories by content with optional filters.

```javascript
// Simple search
memory.search('python');

// With filters
memory.search('learning', {
  limit: 5,
  type: 'learning',
  tags: ['python']
});
```

#### `getRecent(count?)`
Get the most recent memories.

```javascript
memory.getRecent(10);
```

#### `getByType(type)`
Filter memories by type.

```javascript
memory.getByType('preference');
```

#### `updatePersonality(updates)`
Update personality traits.

```javascript
memory.updatePersonality({
  name: 'Aurora',
  tone: 'curious',
  traits: ['analytical', 'friendly']
});
```

#### `setMetaAwareness(level)`
Set the agent's meta-awareness level (0-1).

```javascript
memory.setMetaAwareness(0.7);
```

#### `getContext(maxTokens?)`
Get context object for AI agent consumption.

```javascript
const ctx = memory.getContext();
// Returns: { personality, recentMemories, metadata, soul }
```

#### `stats()`
Get memory statistics.

```javascript
const stats = memory.stats();
// { totalMemories, byType, personality, metadata }
```

#### `clear()`
Clear all memories (keeps personality).

#### `export()`
Export all data as JSON string.

#### `import(jsonString)`
Import data from JSON string.

## Memory Types

| Type | Description |
|------|-------------|
| `general` | Default memory type |
| `important` | High-importance facts |
| `learned` | Things the agent learned |
| `preference` | User preferences |
| `context` | Session context |

## File Structure

```
soul-memory-data/
├── my-agent-memories.json
├── my-agent-personality.json
└── my-agent-metadata.json
```

## Use Cases

- **AI Coding Assistants** - Remember user preferences, project context
- **Chatbots** - Maintain conversation history with personality
- **Game NPCs** - Consistent character across sessions
- **Autonomous Agents** - Persistent learning and adaptation

## License

MIT License - See [LICENSE](LICENSE) for details.

## Support

For issues and feature requests, contact BUYaSOUL support.

---

**Made with ❤️ by BUYaSOUL**
*Give your AI a soul*