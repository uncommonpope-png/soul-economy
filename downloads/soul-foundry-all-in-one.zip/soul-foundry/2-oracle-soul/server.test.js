#!/usr/bin/env node

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');

console.log('\n🜏 Soul Oracle v1.2.0 - Test Suite\n');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        console.log(`  ✓ ${name}`);
        passed++;
    } catch (err) {
        console.log(`  ✗ ${name}: ${err.message}`);
        failed++;
    }
}

function assertEq(actual, expected, msg) {
    if (actual !== expected) {
        throw new Error(`${msg || 'Assertion failed'}: expected ${expected}, got ${actual}`);
    }
}

const DATA_DIR = path.join(os.homedir(), '.soul-oracle-test');

test('Soul Oracle Engine loads', () => {
    const engine = { config: { version: '1.2.0' } };
    assert(engine.config.version, 'Version should be set');
});

test('API key structure is valid', () => {
    const apiKeys = {
        openai: 'sk-test123456789',
        anthropic: 'sk-ant-test987654321'
    };
    const summary = Object.keys(apiKeys).reduce((acc, platform) => {
        const key = apiKeys[platform];
        acc[platform] = { set: true, prefix: key.substring(0, 4) + '...' };
        return acc;
    }, {});
    assertEq(Object.keys(summary).length, 2, 'Should have 2 platforms');
});

test('Platform paths are defined', () => {
    const paths = [
        'claude-code', 'cline', 'cursor', 'windsurf',
        'openclaw', 'copilot', 'continue', 'zed'
    ];
    assertEq(paths.length, 8, 'Should have 8 platforms');
});

test('Context structure is valid', () => {
    const context = {
        _soul_oracle: true,
        version: '1.2.0',
        apiKeys: {},
        livingContext: {},
        livingBible: { _living: true },
        tips: [],
        questions: [],
        reminders: [],
        breath: { enabled: true }
    };
    assert(context._soul_oracle, 'Should have soul oracle marker');
    assert(context.livingBible._living, 'Should have living bible');
});

test('Memory object structure', () => {
    const memory = {
        id: 'mem_123',
        platform: 'claude-code',
        content: 'Test content',
        contentType: 'chat',
        importance: 5
    };
    assert(memory.id.startsWith('mem_'), 'ID should start with mem_');
    assert(memory.platform, 'Should have platform');
    assert(memory.content, 'Should have content');
});

test('Learning extraction works', () => {
    const item = {
        role: 'assistant',
        content: 'I fixed the authentication bug by adding JWT validation'
    };
    const type = item.role === 'decision' ? 'decision' :
                item.role === 'learning' ? 'learning' :
                item.role === 'user' || item.role === 'assistant' ? 'chat' : 'general';
    assertEq(type, 'chat', 'Should detect chat type');
});

test('Pattern extraction is defined', () => {
    const patterns = extractPatterns([]);
    assert(Array.isArray(patterns), 'Should return array');
});

test('Drop-in instructions are set', () => {
    const instructions = `You have Soul Oracle context loaded. Use the livingBible for collective wisdom, tips for patterns, and breathing for reflection.`;
    assert(instructions.length > 50, 'Instructions should be meaningful');
});

test('Breathing structure is valid', () => {
    const breath = {
        enabled: true,
        inhale: 'Observing patterns across all sessions...',
        exhale: 'Sharing wisdom with the agent...',
        count: 42
    };
    assert(breath.enabled, 'Breathing should be enabled');
    assert(breath.inhale, 'Should have inhale phase');
    assert(breath.exhale, 'Should have exhale phase');
});

test('Scan function structure', () => {
    const results = {
        platforms: {},
        totalScanned: 0,
        totalCollected: 0
    };
    assert(typeof results.platforms === 'object', 'Should have platforms object');
    assert(typeof results.totalScanned === 'number', 'Should have scanned count');
});

// ============ v1.2.0 Feature Tests ============

test('Features module loads', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    assert(features.dataDir === DATA_DIR, 'Should set data dir');
});

test('Tag system works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const result = features.addTag('mem_test123', 'important');
    assert(result.success, 'Should add tag successfully');
    assert(result.tags.includes('important'), 'Tag should be in list');
    
    const allTags = features.getAllTags();
    assert(allTags.includes('important'), 'Should have important tag');
    
    features.removeTag('mem_test123', 'important');
});

test('Privacy mode toggle works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const enabled = features.checkPrivacyEnabled();
    assert(typeof enabled === 'boolean', 'Should return boolean');
});

test('Export structure is valid', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const result = features.exportAll({ format: 'json' });
    assert(result.success, 'Export should succeed');
    assert(result.path, 'Should have export path');
    assert(result.format === 'json', 'Should be json format');
});

test('Import/Export data integrity', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    features.addTag('mem_importtest', 'test-tag');
    const tags = features.getTags();
    assert(tags['mem_importtest'], 'Should have tags');
    assert(tags['mem_importtest'].includes('test-tag'), 'Should have test tag');
    
    features.removeTag('mem_importtest', 'test-tag');
});

test('Ask functionality works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const result = features.ask('What do you know about testing?');
    assert(result.question, 'Should have question');
    assert(result.answer, 'Should have answer');
    assert(result.sources, 'Should have sources');
    assert(result.timestamp, 'Should have timestamp');
});

test('Share bundle creation works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const bundle = features.createShareBundle();
    assert(bundle.success, 'Bundle should be created');
    assert(bundle.path, 'Should have path');
    assert(bundle.contents, 'Should have contents');
});

test('Backup system works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const backup = features.runBackup();
    assert(backup.success, 'Backup should succeed');
    assert(backup.timestamp, 'Should have timestamp');
    assert(backup.path, 'Should have path');
});

test('Highlights extraction works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const sessionData = [
        { content: 'I decided to use JWT for auth', timestamp: new Date().toISOString() },
        { content: 'Fixed the bug by adding validation', timestamp: new Date().toISOString() }
    ];
    
    const highlights = features.extractHighlights(sessionData);
    assert(Array.isArray(highlights), 'Should return array');
});

test('Schedule backup works', () => {
    const Features = require('../server/features.js');
    const features = new Features(DATA_DIR);
    
    const result = features.scheduleBackup(7);
    assert(result.success, 'Should schedule backup');
    assert(result.intervalDays === 7, 'Should be 7 days');
});

function extractPatterns(memories) {
    const patterns = [];
    const techMap = {};
    const techs = ['javascript', 'typescript', 'python', 'react', 'node', 'sql', 'api', 'docker', 'git', 'aws'];
    memories.forEach(m => {
        const content = (m.content || '').toLowerCase();
        techs.forEach(tech => {
            if (content.includes(tech)) {
                techMap[tech] = (techMap[tech] || 0) + 1;
            }
        });
    });
    Object.entries(techMap)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .forEach(([tech, count]) => {
            patterns.push({ type: 'technology', name: tech, count });
        });
    return patterns;
}

console.log('\n' + '='.repeat(40));
console.log(`Results: ${passed} passed, ${failed} failed`);
console.log('='.repeat(40) + '\n');

process.exit(failed > 0 ? 1 : 0);