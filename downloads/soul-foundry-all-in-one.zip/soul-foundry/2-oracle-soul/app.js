document.addEventListener('DOMContentLoaded', () => {
    const stats = {
        totalMemories: document.getElementById('totalMemories'),
        totalLearnings: document.getElementById('totalLearnings'),
        totalPatterns: document.getElementById('totalPatterns'),
        breathCount: document.getElementById('breathCount')
    };
    const searchInput = document.getElementById('searchInput');
    const platformFilter = document.getElementById('platformFilter');
    const searchBtn = document.getElementById('searchBtn');
    const resultsList = document.getElementById('resultsList');
    const platformList = document.getElementById('platformList');
    const apiPlatform = document.getElementById('apiPlatform');
    const apiKeyInput = document.getElementById('apiKeyInput');
    const saveApiKeyBtn = document.getElementById('saveApiKeyBtn');
    const apiKeysList = document.getElementById('apiKeysList');
    const scanBtn = document.getElementById('scanBtn');
    const scanResults = document.getElementById('scanResults');
    const generateJsonBtn = document.getElementById('generateJsonBtn');
    const generateMdBtn = document.getElementById('generateMdBtn');
    const downloadDropinBtn = document.getElementById('downloadDropinBtn');
    const dropinStatus = document.getElementById('dropinStatus');
    const bibleContent = document.getElementById('bibleContent');
    const tipsList = document.getElementById('tipsList');
    const questionsList = document.getElementById('questionsList');
    const remindersList = document.getElementById('remindersList');
    const breathPhase = document.getElementById('breathPhase');

    let breathCycle = 0;

    async function loadStats() {
        const result = await SoulOracleAPI.getStats();
        if (result.success && result.data) {
            stats.totalMemories.textContent = result.data.totalMemories || 0;
            stats.totalLearnings.textContent = result.data.totalLearnings || 0;
            stats.totalPatterns.textContent = Object.keys(result.data.byPlatform || {}).length;
            stats.breathCount.textContent = Math.floor(Date.now() / 60000) % 100;
        }
    }

    async function loadContext() {
        const result = await fetch('/api/context');
        const data = await result.json();

        if (data.success && data.data) {
            const ctx = data.data;

            if (ctx.livingBible) {
                displayBible(ctx.livingBible);
            }

            if (ctx.tips) {
                displayTips(ctx.tips);
            }

            if (ctx.questions) {
                displayQuestions(ctx.questions);
            }

            if (ctx.reminders) {
                displayReminders(ctx.reminders);
            }

            if (ctx.breath) {
                updateBreathing(ctx.breath);
            }

            if (ctx.apiKeys) {
                displayApiKeys(ctx.apiKeys);
            }
        }
    }

    function displayBible(bible) {
        if (bible.principles && bible.principles.length > 0) {
            bibleContent.innerHTML = bible.principles.map(p => `
                <div class="bible-principle">
                    <div class="rule">${escapeHtml(p.rule || p.content || '')}</div>
                    <div class="source">Source: ${p.source || 'unknown'} | ${formatDate(p.timestamp)}</div>
                </div>
            `).join('');
        } else if (bible.wisdom && bible.wisdom.length > 0) {
            bibleContent.innerHTML = bible.wisdom.map(w => `
                <div class="bible-principle">
                    <div class="rule">"${escapeHtml(w.text)}"</div>
                    <div class="source">— ${w.source || 'soul-oracle'}</div>
                </div>
            `).join('');
        } else {
            bibleContent.innerHTML = '<p class="placeholder">Your living bible will grow as you use your AI agents...</p>';
        }
    }

    function displayTips(tips) {
        if (tips.length > 0) {
            tipsList.innerHTML = tips.map(t => `
                <div class="tip-item">
                    <div class="category">${t.category || 'general'}</div>
                    <div class="tip">${escapeHtml(t.tip)}</div>
                    <div class="confidence">Confidence: ${Math.round((t.confidence || 0.5) * 100)}%</div>
                </div>
            `).join('');
        } else {
            tipsList.innerHTML = '<p class="placeholder">Tips will appear as patterns emerge...</p>';
        }
    }

    function displayQuestions(questions) {
        if (questions.length > 0) {
            questionsList.innerHTML = questions.map(q => `
                <div class="question-item">
                    <div class="question">${escapeHtml(q.question)}</div>
                    <div class="context">Context: ${q.context || 'general'}</div>
                </div>
            `).join('');
        } else {
            questionsList.innerHTML = '<p class="placeholder">Questions will be generated from your patterns...</p>';
        }
    }

    function displayReminders(reminders) {
        if (reminders.length > 0) {
            remindersList.innerHTML = reminders.map(r => `
                <div class="reminder-item">
                    <span>${escapeHtml(r.text || r.reminder || '')}</span>
                    <span class="type">${r.type || ''}</span>
                </div>
            `).join('');
        } else {
            remindersList.innerHTML = '<p class="placeholder">Reminders will appear for session awareness...</p>';
        }
    }

    function updateBreathing(breath) {
        setInterval(() => {
            breathCycle++;
            const phases = [
                'Inhaling wisdom...',
                'Observing patterns...',
                'Exhaling knowledge...',
                'Sharing insights...'
            ];
            breathPhase.textContent = phases[breathCycle % phases.length];
        }, 4000);
    }

    async function displayApiKeys(keysData) {
        const keys = Object.entries(keysData);
        if (keys.length > 0) {
            apiKeysList.innerHTML = keys.map(([platform, info]) => `
                <div class="api-key-badge">
                    <span class="platform">${platform}</span>
                    <span class="key">${info.prefix || '••••'}</span>
                </div>
            `).join('');
        }
    }

    async function loadMemories(query = '', platform = '') {
        const result = await SoulOracleAPI.getMemories(query, platform);
        if (result.success && result.data) {
            displayResults(result.data);
        } else {
            resultsList.innerHTML = '<p class="placeholder">No memories found</p>';
        }
    }

    function displayResults(memories) {
        if (!memories || memories.length === 0) {
            resultsList.innerHTML = '<p class="placeholder">No memories yet. Start using your AI agents!</p>';
            return;
        }

        resultsList.innerHTML = memories.map(mem => `
            <div class="result-item" data-id="${mem.id}">
                <span class="platform">${mem.platform || 'unknown'}</span>
                <div class="content">${escapeHtml(mem.content || '')}</div>
                <div class="meta">
                    ${mem.content_type || 'general'} |
                    ${formatDate(mem.timestamp)} |
                    Importance: ${mem.importance_score || 5}
                </div>
            </div>
        `).join('');

        document.querySelectorAll('.result-item').forEach(item => {
            item.addEventListener('click', async () => {
                const id = item.dataset.id;
                const result = await SoulOracleAPI.getMemory(id);
                if (result.success && result.data) {
                    alert(`Memory Details:\n\nPlatform: ${result.data.platform}\nType: ${result.data.content_type}\n\n${result.data.content}`);
                }
            });
        });
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function formatDate(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }

    searchBtn.addEventListener('click', () => {
        const query = searchInput.value;
        const platform = platformFilter.value;
        loadMemories(query, platform);
    });

    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            searchBtn.click();
        }
    });

    saveApiKeyBtn.addEventListener('click', async () => {
        const platform = apiPlatform.value;
        const key = apiKeyInput.value;

        if (!key) {
            alert('Please enter an API key');
            return;
        }

        try {
            const response = await fetch('/api/apikeys', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ platform, key })
            });

            const result = await response.json();

            if (result.success) {
                apiKeyInput.value = '';
                displayApiKeys({ ...{}, [platform]: { set: true, prefix: key.substring(0, 4) + '...' } });
                alert('API key saved!');
                loadContext();
            } else {
                alert('Failed to save API key');
            }
        } catch (err) {
            alert('Error saving API key: ' + err.message);
        }
    });

    scanBtn.addEventListener('click', async () => {
        scanBtn.disabled = true;
        scanBtn.textContent = 'Scanning...';

        try {
            const response = await fetch('/api/scan', { method: 'POST' });
            const result = await response.json();

            if (result.success) {
                scanResults.innerHTML = Object.entries(result.data.platforms || {}).map(([platform, status]) => `
                    <div class="scan-result-item">
                        <span>${platform}</span>
                        <span>${status.scanned ? '✓ Scanned (' + status.files + ' files)' : '✗ ' + (status.reason || 'Not found')}</span>
                    </div>
                `).join('');
            }
        } catch (err) {
            scanResults.innerHTML = '<p>Error scanning: ' + err.message + '</p>';
        }

        scanBtn.disabled = false;
        scanBtn.textContent = 'Scan All Platforms';
        loadStats();
        loadContext();
    });

    generateJsonBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/dropin');
            const data = await response.json();
            dropinStatus.textContent = JSON.stringify(data, null, 2);
        } catch (err) {
            dropinStatus.textContent = 'Error: ' + err.message;
        }
    });

    generateMdBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/dropin?format=markdown');
            const text = await response.text();
            dropinStatus.textContent = text;
        } catch (err) {
            dropinStatus.textContent = 'Error: ' + err.message;
        }
    });

    downloadDropinBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/dropin');
            const data = await response.json();

            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'soul-oracle-agent.json';
            a.click();
            URL.revokeObjectURL(url);
        } catch (err) {
            alert('Error downloading: ' + err.message);
        }
    });

    loadStats();
    loadContext();
    loadMemories();

    setInterval(loadStats, 30000);
    setInterval(loadContext, 60000);
});

document.addEventListener('DOMContentLoaded', () => {
    console.log('Soul Oracle Living Dashboard loaded - v1.1.0');
});