# Soul Oracle

**"Your AI agents share one soul across all platforms."**

Soul Oracle is a premium AI agent memory system that runs as a Windows background service, continuously watching and collecting memories from ALL AI coding agents (Claude Code, Cursor, Windsurf, Cline, OpenClaw, GitHub Copilot, and more). It provides a unified, persistent memory layer that any AI agent can query via MCP or HTTP REST API.

## Features

- **Universal Coverage** - Monitors 8+ AI agent platforms
- **Always Watching** - Runs as Windows service 24/7
- **Local Only** - 100% private, no cloud, no account
- **MCP Server** - Query memories from any MCP-compatible agent
- **HTTP API** - REST API for custom integrations
- **Web Dashboard** - Browse and search all memories
- **Auto-Start** - Windows service that starts on boot
- **Privacy Mode** - AES-256-GCM encrypted storage
- **Import/Export** - Full data portability with encryption
- **Memory Tags** - Organize memories with custom tags
- **Quick CLI** - Ask questions directly: `soul ask "what about X?"`
- **Auto-Backup** - Scheduled weekly backups
- **Session Highlights** - Auto-extract decisions and breakthroughs
- **Team Sharing** - Share memory bundles with others

## Supported Platforms

| Platform | Path |
|----------|------|
| Claude Code | `~/.cline/data/` |
| Cline | `~/.cline/` |
| Cursor | `~/AppData/Local/Cursor/` |
| Windsurf | `~/.codeium/windsurf/` |
| OpenClaw | `~/.openclaw/` |
| GitHub Copilot | `~/.github/copilot/` |
| Continue | `~/.continue/` |
| Zed | `~/.zed/` |

## Quick Start

### Install

```powershell
irm https://raw.githubusercontent.com/uncommonpope-png/soul-oracle/main/install/install.ps1 | iex
```

### Start Server

```powershell
cd ~/.soul-oracle
npm start
```

### Open Dashboard

```
http://localhost:3847/
```

### Ask the Oracle

```powershell
curl "http://localhost:3847/api/ask?q=what%20did%20we%20decide%20about%20auth"
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/memories?q=query` | Search memories |
| POST | `/api/memories` | Add memory |
| GET | `/api/stats` | Get statistics |
| GET | `/api/ask?q=question` | Ask the oracle |
| POST | `/api/export` | Export all data |
| POST | `/api/import` | Import data |
| POST | `/api/tags` | Add tag to memory |
| GET | `/api/tags` | List all tags |
| POST | `/api/backup` | Run backup |
| GET | `/api/highlights` | Get highlights |
| POST | `/api/privacy` | Privacy mode control |
| POST | `/api/share` | Create share bundle |

## Pricing

| Tier | Price | Features |
|------|-------|----------|
| **Soul Oracle** | $19.99 | All features, lifetime updates |

## License

MIT License - See [LICENSE](LICENSE)

---

*Made with 🜏 by BUYaSOUL*