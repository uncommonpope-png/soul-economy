#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');

const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), '.soul-oracle');

class SoulOracleFeatures {
    constructor(dataDir = DATA_DIR) {
        this.dataDir = dataDir;
        this.privacyKey = null;
        this.backupDir = path.join(dataDir, 'backups');
        this.tagsFile = path.join(dataDir, 'tags.json');
        this.highlightsFile = path.join(dataDir, 'highlights.json');
        this.ensureDirs();
    }

    ensureDirs() {
        const dirs = [this.backupDir, path.join(this.dataDir, 'exports')];
        dirs.forEach(d => {
            if (!fs.existsSync(d)) {
                fs.mkdirSync(d, { recursive: true });
            }
        });
    }

    generateId(prefix = 'id') {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    now() {
        return new Date().toISOString();
    }

    // ========== PRIVACY MODE ==========
    setPrivacyPassword(password) {
        const salt = crypto.randomBytes(32);
        const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
        
        const configPath = path.join(this.dataDir, 'privacy.json');
        const config = {
            salt: salt.toString('hex'),
            iv: iv.toString('hex'),
            hash: crypto.createHash('sha256').update(password).digest('hex')
        };
        fs.writeFileSync(configPath, JSON.stringify(config));
        this.privacyKey = key;
        return { success: true, message: 'Privacy mode enabled' };
    }

    checkPrivacyEnabled() {
        const configPath = path.join(this.dataDir, 'privacy.json');
        return fs.existsSync(configPath);
    }

    verifyPassword(password) {
        const configPath = path.join(this.dataDir, 'privacy.json');
        if (!fs.existsSync(configPath)) return false;
        
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        return hash === config.hash;
    }

    unlockPrivacy(password) {
        if (!this.verifyPassword(password)) {
            return { success: false, error: 'Invalid password' };
        }
        
        const configPath = path.join(this.dataDir, 'privacy.json');
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        const salt = Buffer.from(config.salt, 'hex');
        this.privacyKey = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        return { success: true, message: 'Privacy mode unlocked' };
    }

    lockPrivacy() {
        this.privacyKey = null;
        return { success: true, message: 'Privacy mode locked' };
    }

    encryptData(data) {
        if (!this.privacyKey) throw new Error('Privacy not unlocked');
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-gcm', this.privacyKey, iv);
        let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const authTag = cipher.getAuthTag();
        return { iv: iv.toString('hex'), data: encrypted, tag: authTag.toString('hex') };
    }

    decryptData(encryptedObj) {
        if (!this.privacyKey) throw new Error('Privacy not unlocked');
        const iv = Buffer.from(encryptedObj.iv, 'hex');
        const decipher = crypto.createDecipheriv('aes-256-gcm', this.privacyKey, iv);
        decipher.setAuthTag(Buffer.from(encryptedObj.tag, 'hex'));
        let decrypted = decipher.update(encryptedObj.data, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return JSON.parse(decrypted);
    }

    // ========== IMPORT/EXPORT ==========
    exportAll(options = {}) {
        const { format = 'json', includeApiKeys = false, encrypted = false } = options;
        
        const dbDir = path.join(this.dataDir, 'db');
        const exportData = {
            version: '1.2.0',
            exported: this.now(),
            type: 'soul-oracle-full-export',
            data: {}
        };

        if (fs.existsSync(dbDir)) {
            const files = fs.readdirSync(dbDir);
            files.forEach(file => {
                if (file.endsWith('.db') || file.endsWith('.sqlite')) {
                    // Skip binary databases for JSON export
                } else {
                    try {
                        const content = fs.readFileSync(path.join(dbDir, file), 'utf8');
                        const name = file.replace('.json', '');
                        exportData.data[name] = JSON.parse(content);
                    } catch {}
                }
            });
        }

        // Export JSON files
        const jsonFiles = ['api-keys.json', 'learnings.json', 'config.json', 'tags.json', 'highlights.json'];
        jsonFiles.forEach(file => {
            const filePath = path.join(this.dataDir, file);
            if (fs.existsSync(filePath)) {
                try {
                    const name = file.replace('.json', '');
                    if (file === 'api-keys.json' && !includeApiKeys) {
                        exportData.data[name] = { _redacted: true };
                    } else {
                        exportData.data[name] = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                    }
                } catch {}
            }
        });

        if (encrypted && this.privacyKey) {
            exportData.data = this.encryptData(exportData.data);
            exportData.encrypted = true;
        }

        const exportDir = path.join(this.dataDir, 'exports');
        const fileName = `soul-oracle-export-${Date.now()}.${format}`;
        const filePath = path.join(exportDir, fileName);

        if (format === 'json') {
            fs.writeFileSync(filePath, JSON.stringify(exportData, null, 2));
        } else if (format === 'zip') {
            const tempPath = path.join(exportDir, 'temp-' + fileName);
            fs.writeFileSync(tempPath, JSON.stringify(exportData, null, 2));
            try {
                execSync(`cd "${exportDir}" && tar -czf "${fileName}" "temp-${fileName}" && rm "temp-${fileName}"`);
            } catch {
                fs.renameSync(tempPath, filePath);
            }
        }

        return {
            success: true,
            path: filePath,
            size: fs.statSync(filePath).size,
            format,
            encrypted: encrypted && !!this.privacyKey
        };
    }

    importAll(filePath, options = {}) {
        const { password = null, merge = true } = options;
        
        if (!fs.existsSync(filePath)) {
            return { success: false, error: 'File not found' };
        }

        const content = fs.readFileSync(filePath, 'utf8');
        let importData;

        try {
            importData = JSON.parse(content);
        } catch {
            return { success: false, error: 'Invalid JSON file' };
        }

        if (importData.encrypted && password) {
            if (!this.verifyPassword(password)) {
                return { success: false, error: 'Invalid password' };
            }
            const config = JSON.parse(fs.readFileSync(path.join(this.dataDir, 'privacy.json'), 'utf8'));
            const key = crypto.pbkdf2Sync(password, Buffer.from(config.salt, 'hex'), 100000, 32, 'sha256');
            const tempKey = this.privacyKey;
            this.privacyKey = key;
            try {
                importData.data = this.decryptData(importData.data);
            } finally {
                this.privacyKey = tempKey;
            }
        }

        const data = importData.data || importData;

        Object.keys(data).forEach(key => {
            if (key === '_redacted') return;
            const filePath = path.join(this.dataDir, key + '.json');
            
            if (merge && fs.existsSync(filePath)) {
                try {
                    const existing = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                    if (Array.isArray(existing) && Array.isArray(data[key])) {
                        const merged = [...existing, ...data[key]];
                        fs.writeFileSync(filePath, JSON.stringify(merged, null, 2));
                    } else {
                        fs.writeFileSync(filePath, JSON.stringify({ ...existing, ...data[key] }, null, 2));
                    }
                } catch {
                    fs.writeFileSync(filePath, JSON.stringify(data[key], null, 2));
                }
            } else {
                fs.writeFileSync(filePath, JSON.stringify(data[key], null, 2));
            }
        });

        return {
            success: true,
            imported: Object.keys(data).length,
            keys: Object.keys(data)
        };
    }

    // ========== SESSION EXPORT ==========
    exportSession(sessionId, format = 'md') {
        const learningsPath = path.join(this.dataDir, 'learnings.json');
        const memoriesPath = path.join(this.dataDir, 'db', 'memories.json');
        
        let sessionData = { sessionId, learnings: [], memories: [] };

        if (fs.existsSync(learningsPath)) {
            const learnings = JSON.parse(fs.readFileSync(learningsPath, 'utf8'));
            sessionData.learnings = learnings.filter(l => l.sessionId === sessionId || l.id === sessionId);
        }

        if (fs.existsSync(memoriesPath)) {
            try {
                const memories = JSON.parse(fs.readFileSync(memoriesPath, 'utf8'));
                sessionData.memories = memories.filter(m => m.sessionId === sessionId || m.id === sessionId);
            } catch {}
        }

        if (format === 'json') {
            return {
                success: true,
                data: sessionData,
                contentType: 'application/json'
            };
        }

        // Markdown format
        const md = this.generateMarkdownExport(sessionData);
        const exportDir = path.join(this.dataDir, 'exports');
        const fileName = `session-${sessionId}-${Date.now()}.md`;
        const filePath = path.join(exportDir, fileName);
        fs.writeFileSync(filePath, md);

        return {
            success: true,
            path: filePath,
            size: fs.statSync(filePath).size,
            format: 'markdown'
        };
    }

    generateMarkdownExport(data) {
        const formatter = new Intl.DateTimeFormat('en-US', {
            dateStyle: 'full', timeStyle: 'medium'
        });

        let md = `# Soul Oracle Session Report\n\n`;
        md += `**Generated:** ${formatter.format(new Date())}\n`;
        md += `**Session ID:** ${data.sessionId}\n\n`;
        md += `---\n\n`;

        if (data.learnings.length > 0) {
            md += `## Key Learnings\n\n`;
            data.learnings.forEach((l, i) => {
                md += `${i + 1}. **${l.type || 'learning'}**: ${l.content || l.description || 'No content'}\n`;
                if (l.source) md += `   *Source: ${l.source}*\n`;
                md += `\n`;
            });
        }

        if (data.memories.length > 0) {
            md += `## Memories Captured\n\n`;
            data.memories.forEach((m, i) => {
                md += `${i + 1}. ${m.content || m.description || 'No content'}\n`;
                md += `   - Platform: ${m.platform || 'unknown'}\n`;
                md += `   - Type: ${m.contentType || 'general'}\n\n`;
            });
        }

        md += `---\n\n*Generated by Soul Oracle - Your AI agents share one soul*\n`;
        return md;
    }

    // ========== MEMORY TAGS ==========
    addTag(memoryId, tag) {
        const tags = this.getTags();
        
        if (!tags[memoryId]) {
            tags[memoryId] = [];
        }
        
        if (!tags[memoryId].includes(tag)) {
            tags[memoryId].push(tag);
            fs.writeFileSync(this.tagsFile, JSON.stringify(tags, null, 2));
        }
        
        return { success: true, tags: tags[memoryId] };
    }

    removeTag(memoryId, tag) {
        const tags = this.getTags();
        
        if (tags[memoryId]) {
            tags[memoryId] = tags[memoryId].filter(t => t !== tag);
            fs.writeFileSync(this.tagsFile, JSON.stringify(tags, null, 2));
        }
        
        return { success: true, tags: tags[memoryId] || [] };
    }

    getTags() {
        if (!fs.existsSync(this.tagsFile)) {
            return {};
        }
        try {
            return JSON.parse(fs.readFileSync(this.tagsFile, 'utf8'));
        } catch {
            return {};
        }
    }

    getAllTags() {
        const tags = this.getTags();
        const allTags = new Set();
        Object.values(tags).forEach(tagList => {
            tagList.forEach(t => allTags.add(t));
        });
        return Array.from(allTags);
    }

    findByTag(tag) {
        const tags = this.getTags();
        return Object.keys(tags).filter(id => tags[id].includes(tag));
    }

    // ========== QUICK AGENT CLI ==========
    ask(question) {
        const memories = this.searchMemories(question);
        const learnings = this.searchLearnings(question);
        
        return {
            question,
            answer: this.generateAnswer(question, [...memories, ...learnings]),
            sources: {
                memories: memories.length,
                learnings: learnings.length
            },
            timestamp: this.now()
        };
    }

    searchMemories(query) {
        const dbPath = path.join(this.dataDir, 'db', 'soul-oracle.db');
        const results = [];
        
        // Fallback to JSON if no DB
        const memPath = path.join(this.dataDir, 'db', 'memories.json');
        if (fs.existsSync(memPath)) {
            try {
                const memories = JSON.parse(fs.readFileSync(memPath, 'utf8'));
                const q = query.toLowerCase();
                return memories.filter(m => 
                    (m.content && m.content.toLowerCase().includes(q)) ||
                    (m.description && m.description.toLowerCase().includes(q))
                );
            } catch {}
        }
        
        return results;
    }

    searchLearnings(query) {
        const learningsPath = path.join(this.dataDir, 'learnings.json');
        if (!fs.existsSync(learningsPath)) return [];
        
        try {
            const learnings = JSON.parse(fs.readFileSync(learningsPath, 'utf8'));
            const q = query.toLowerCase();
            return learnings.filter(l => 
                (l.content && l.content.toLowerCase().includes(q)) ||
                (l.description && l.description.toLowerCase().includes(q)) ||
                (l.type && l.type.toLowerCase().includes(q))
            );
        } catch {
            return [];
        }
    }

    generateAnswer(question, results) {
        if (results.length === 0) {
            return "I don't have any memories or learnings related to that question yet. Keep working and I'll learn from your sessions.";
        }

        const topResults = results.slice(0, 5);
        const sources = topResults.map(r => r.source || r.platform || 'unknown').filter(s => s !== 'unknown');
        const uniqueSources = [...new Set(sources)];

        return `Based on ${results.length} relevant ${results.length === 1 ? 'memory' : 'memories'}: ` +
            topResults.map(r => r.content || r.description || 'Shared learning').join('. ') +
            (uniqueSources.length > 0 ? ` (from ${uniqueSources.join(', ')})` : '');
    }

    // ========== AUTO-BACKUP ==========
    scheduleBackup(intervalDays = 7) {
        const configPath = path.join(this.dataDir, 'config.json');
        let config = {};
        
        if (fs.existsSync(configPath)) {
            try {
                config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            } catch {}
        }
        
        config.autoBackup = {
            enabled: true,
            intervalDays,
            lastBackup: null,
            backupPath: this.backupDir
        };
        
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
        
        return {
            success: true,
            scheduled: true,
            intervalDays,
            nextBackup: this.calculateNextBackup(intervalDays)
        };
    }

    calculateNextBackup(intervalDays) {
        const next = new Date();
        next.setDate(next.getDate() + intervalDays);
        return next.toISOString();
    }

    runBackup(options = {}) {
        const { destination = null, encrypted = false, password = null } = options;
        
        const targetDir = destination || this.backupDir;
        
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupName = `soul-oracle-backup-${timestamp}`;
        const backupPath = path.join(targetDir, backupName);
        
        fs.mkdirSync(backupPath, { recursive: true });
        
        const backupData = {
            version: '1.2.0',
            timestamp,
            type: 'soul-oracle-backup'
        };
        
        const copyDir = (src, dst) => {
            if (!fs.existsSync(src)) return;
            const items = fs.readdirSync(src);
            items.forEach(item => {
                const srcPath = path.join(src, item);
                const dstPath = path.join(dst, item);
                
                if (fs.statSync(srcPath).isDirectory()) {
                    fs.mkdirSync(dstPath, { recursive: true });
                    copyDir(srcPath, dstPath);
                } else {
                    // Skip large files
                    try {
                        const stat = fs.statSync(srcPath);
                        if (stat.size > 10 * 1024 * 1024) return; // Skip > 10MB
                        fs.copyFileSync(srcPath, dstPath);
                    } catch {}
                }
            });
        };
        
        copyDir(this.dataDir, backupPath);
        
        const manifest = {
            ...backupData,
            paths: ['db', 'learnings.json', 'api-keys.json', 'config.json', 'tags.json'].filter(p => 
                fs.existsSync(path.join(this.dataDir, p))
            )
        };
        
        fs.writeFileSync(path.join(backupPath, 'manifest.json'), JSON.stringify(manifest, null, 2));
        
        return {
            success: true,
            path: backupPath,
            timestamp,
            size: this.getDirSize(backupPath)
        };
    }

    getDirSize(dirPath) {
        let size = 0;
        try {
            const items = fs.readdirSync(dirPath);
            items.forEach(item => {
                const itemPath = path.join(dirPath, item);
                const stat = fs.statSync(itemPath);
                if (stat.isDirectory()) {
                    size += this.getDirSize(itemPath);
                } else {
                    size += stat.size;
                }
            });
        } catch {}
        return size;
    }

    // ========== SESSION HIGHLIGHTS ==========
    extractHighlights(sessionData) {
        const highlights = [];
        
        if (!sessionData) return highlights;
        
        const items = Array.isArray(sessionData) ? sessionData : [sessionData];
        
        items.forEach(item => {
            const content = item.content || item.description || '';
            
            // Extract decisions
            if (content.includes('decided') || content.includes('decision') || content.includes('chose')) {
                highlights.push({
                    type: 'decision',
                    content: content.substring(0, 200),
                    timestamp: item.timestamp || this.now()
                });
            }
            
            // Extract breakthroughs
            if (content.includes('fixed') || content.includes('solved') || content.includes('breakthrough')) {
                highlights.push({
                    type: 'breakthrough',
                    content: content.substring(0, 200),
                    timestamp: item.timestamp || this.now()
                });
            }
            
            // Extract learnings
            if (content.includes('learned') || content.includes('discovered') || content.includes('figured out')) {
                highlights.push({
                    type: 'learning',
                    content: content.substring(0, 200),
                    timestamp: item.timestamp || this.now()
                });
            }
        });
        
        // Save highlights
        const existing = this.getHighlights();
        const updated = [...existing, ...highlights].slice(-100); // Keep last 100
        fs.writeFileSync(this.highlightsFile, JSON.stringify(updated, null, 2));
        
        return highlights;
    }

    getHighlights(options = {}) {
        const { type = null, limit = 20 } = options;
        
        if (!fs.existsSync(this.highlightsFile)) {
            return [];
        }
        
        try {
            let highlights = JSON.parse(fs.readFileSync(this.highlightsFile, 'utf8'));
            
            if (type) {
                highlights = highlights.filter(h => h.type === type);
            }
            
            return highlights.slice(-limit);
        } catch {
            return [];
        }
    }

    // ========== TEAM SHARING ==========
    createShareBundle(options = {}) {
        const { includeMemories = true, includeLearnings = true, includeBible = true, tag = null } = options;
        
        const bundle = {
            version: '1.2.0',
            created: this.now(),
            type: 'soul-oracle-share-bundle',
            contents: {}
        };
        
        if (includeLearnings) {
            const learningsPath = path.join(this.dataDir, 'learnings.json');
            if (fs.existsSync(learningsPath)) {
                try {
                    bundle.contents.learnings = JSON.parse(fs.readFileSync(learningsPath, 'utf8'));
                } catch {}
            }
        }
        
        if (includeBible) {
            const biblePath = path.join(this.dataDir, 'living-bible.json');
            if (fs.existsSync(biblePath)) {
                try {
                    bundle.contents.bible = JSON.parse(fs.readFileSync(biblePath, 'utf8'));
                } catch {}
            }
        }
        
        // Filter by tag if specified
        if (tag && bundle.contents.learnings) {
            const taggedIds = this.findByTag(tag);
            bundle.contents.learnings = bundle.contents.learnings.filter(l => taggedIds.includes(l.id));
            bundle.contents._tagFilter = tag;
        }
        
        const exportDir = path.join(this.dataDir, 'exports');
        const fileName = `soul-oracle-share-${Date.now()}.json`;
        const filePath = path.join(exportDir, fileName);
        
        fs.writeFileSync(filePath, JSON.stringify(bundle, null, 2));
        
        return {
            success: true,
            path: filePath,
            size: fs.statSync(filePath).size,
            contents: Object.keys(bundle.contents),
            itemCount: bundle.contents.learnings?.length || 0
        };
    }

    importShareBundle(filePath) {
        if (!fs.existsSync(filePath)) {
            return { success: false, error: 'File not found' };
        }
        
        try {
            const bundle = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            
            if (bundle.type !== 'soul-oracle-share-bundle') {
                return { success: false, error: 'Invalid bundle format' };
            }
            
            let imported = 0;
            
            if (bundle.contents.learnings) {
                const learningsPath = path.join(this.dataDir, 'learnings.json');
                let existing = [];
                
                if (fs.existsSync(learningsPath)) {
                    try {
                        existing = JSON.parse(fs.readFileSync(learningsPath, 'utf8'));
                    } catch {}
                }
                
                const merged = [...existing, ...bundle.contents.learnings];
                fs.writeFileSync(learningsPath, JSON.stringify(merged, null, 2));
                imported += bundle.contents.learnings.length;
            }
            
            return {
                success: true,
                imported,
                source: bundle.created
            };
        } catch (err) {
            return { success: false, error: err.message };
        }
    }
}

// CLI Interface
if (require.main === module) {
    const args = process.argv.slice(2);
    const command = args[0] || 'help';
    const features = new SoulOracleFeatures();

    switch (command) {
        case 'export':
            console.log(JSON.stringify(features.exportAll({ format: 'json' }), null, 2));
            break;
        case 'import':
            if (args[1]) {
                console.log(JSON.stringify(features.importAll(args[1]), null, 2));
            } else {
                console.log('Usage: node features.js import <file>');
            }
            break;
        case 'ask':
            if (args[1]) {
                console.log(JSON.stringify(features.ask(args.slice(1).join(' ')), null, 2));
            } else {
                console.log('Usage: node features.js ask "your question"');
            }
            break;
        case 'backup':
            console.log(JSON.stringify(features.runBackup(), null, 2));
            break;
        case 'tag':
            if (args[1] && args[2]) {
                console.log(JSON.stringify(features.addTag(args[1], args[2]), null, 2));
            } else {
                console.log('Usage: node features.js tag <memoryId> <tag>');
            }
            break;
        case 'tags':
            console.log(JSON.stringify(features.getAllTags(), null, 2));
            break;
        case 'highlights':
            console.log(JSON.stringify(features.getHighlights({ limit: 10 }), null, 2));
            break;
        case 'privacy':
            if (args[1] === 'enable' && args[2]) {
                console.log(JSON.stringify(features.setPrivacyPassword(args[2]), null, 2));
            } else if (args[1] === 'unlock' && args[2]) {
                console.log(JSON.stringify(features.unlockPrivacy(args[2]), null, 2));
            } else if (args[1] === 'lock') {
                console.log(JSON.stringify(features.lockPrivacy(), null, 2));
            } else {
                console.log('Usage: node features.js privacy enable|unlock|lock <password>');
            }
            break;
        case 'share':
            console.log(JSON.stringify(features.createShareBundle(), null, 2));
            break;
        default:
            console.log(`
Soul Oracle Features v1.2.0

Commands:
  export              - Export all data
  import <file>      - Import data
  ask "question"     - Ask the oracle
  backup             - Run manual backup
  tag <id> <tag>     - Add tag to memory
  tags               - List all tags
  highlights         - Get session highlights
  privacy enable <pass>   - Enable privacy mode
  privacy unlock <pass>    - Unlock privacy
  privacy lock            - Lock privacy
  share              - Create share bundle
  help               - Show this help
`);
    }
}

module.exports = SoulOracleFeatures;