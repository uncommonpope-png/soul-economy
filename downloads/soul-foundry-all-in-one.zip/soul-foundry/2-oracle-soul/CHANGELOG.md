# Soul Oracle Changelog

All notable changes to Soul Oracle will be documented in this file.

## [1.2.0] - 2026-05-20

### Added
- **Import/Export** - Full data portability with encrypted option
- **Session Export** - Export session learnings as JSON or Markdown
- **Memory Tags** - Custom tags for organizing and finding memories
- **Quick Agent CLI** - `soul ask "question"` to query memories
- **Auto-Backup** - Scheduled weekly backups to configurable location
- **Session Highlights** - Auto-extract decisions, breakthroughs, learnings
- **Privacy Mode** - AES-256-GCM encrypted storage with password
- **Team Sharing** - Export/import memory bundles for sharing

### Changed
- Server now supports all new feature endpoints
- Enhanced security for API keys storage
- Improved backup system with manifest tracking

---

## [1.1.0] - 2026-05-20

### Added
- **Living Bible** - Collective wisdom extracted from all sessions that grows over time
- **API Key Management** - Store and manage API keys that become available to all AI agents
- **Drop-in Context Generator** - Generate `soul-oracle-agent.json` to drop into any AI agent
- **Pattern Recognition** - Automatic extraction of technology patterns (JavaScript, Python, etc.)
- **Tips System** - Pattern-based tips generated from accumulated knowledge
- **Questions Engine** - Contextual questions generated from session patterns
- **Reminders System** - Session-based reminders and prompts
- **Breathing Indicator** - Mindful interaction pattern for agents
- **Auto-Scanning** - Automatic platform directory scanning
- **Self-Healing Config** - Auto-creates missing directories and files

### Changed
- Engine now generates rich context with personality and tone
- Enhanced learning extraction from session data
- Improved pattern detection algorithms
- Dashboard now shows Living Bible status

### Fixed
- Platform path detection on Windows
- JSON parsing of large session files
- Database initialization on first install

---

## [1.0.0] - 2026-05-20

### Added
- **Core Memory System** - SQLite-based persistent storage
- **File System Watcher** - Real-time monitoring of AI agent directories
- **8 Platform Support** - Claude Code, Cline, Cursor, Windsurf, OpenClaw, Copilot, Continue, Zed
- **HTTP REST API** - Full API for memories, stats, and search
- **Web Dashboard** - Dark-themed analytics dashboard at http://localhost:3847/
- **PowerShell Service** - Background monitoring service
- **One-Command Install** - PowerShell installer script
- **MCP Server** - Query memories from MCP-compatible agents
- **Auto-Start** - Windows Task Scheduler integration

---

*Format based on [Keep a Changelog](https://keepachangelog.com/)*