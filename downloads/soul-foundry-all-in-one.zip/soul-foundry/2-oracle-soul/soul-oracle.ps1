# Soul Oracle - PowerShell Service
# Monitors AI agent directories and captures memory events
# Version: 1.0.0
# Author: BUYaSOUL

param(
    [string]$DataDir = "$env:USERPROFILE\.soul-oracle",
    [string]$ServerUrl = "http://localhost:3847",
    [int]$ScanIntervalMs = 5000
)

$ErrorActionPreference = "Stop"
$Script:LastProcessed = @{}
$Script:IsRunning = $true

# Platform configurations
$Platforms = @{
    "claude-code" = @{
        Name = "Claude Code"
        Enabled = $true
        BasePaths = @("$env:USERPROFILE\.cline\data")
        FilePatterns = @("*.json")
        Parser = "ParseClaudeCode"
    }
    "cline" = @{
        Name = "Cline"
        Enabled = $true
        BasePaths = @("$env:USERPROFILE\.cline")
        FilePatterns = @("*.json")
        Parser = "ParseCline"
    }
    "cursor" = @{
        Name = "Cursor"
        Enabled = $true
        BasePaths = @("$env:APPDATA\Cursor", "$env:LOCALAPPDATA\Cursor")
        FilePatterns = @("*.json")
        Parser = "ParseCursor"
    }
    "windsurf" = @{
        Name = "Windsurf"
        Enabled = $true
        BasePaths = @("$env:USERPROFILE\.codeium\windsurf")
        FilePatterns = @("*.json")
        Parser = "ParseWindsurf"
    }
    "openclaw" = @{
        Name = "OpenClaw"
        Enabled = $false
        BasePaths = @("$env:USERPROFILE\.openclaw")
        FilePatterns = @("*.json", "*.md")
        Parser = "ParseOpenClaw"
    }
    "copilot" = @{
        Name = "GitHub Copilot"
        Enabled = $false
        BasePaths = @("$env:USERPROFILE\.github\copilot")
        FilePatterns = @("*.jsonl", "*.json")
        Parser = "ParseCopilot"
    }
    "continue" = @{
        Name = "Continue"
        Enabled = $false
        BasePaths = @("$env:USERPROFILE\.continue")
        FilePatterns = @("*.json")
        Parser = "ParseContinue"
    }
    "zed" = @{
        Name = "Zed"
        Enabled = $false
        BasePaths = @("$env:USERPROFILE\.zed")
        FilePatterns = @("*.json")
        Parser = "ParseZed"
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage

    $logFile = Join-Path $DataDir "logs\soul-oracle.log"
    $logDir = Split-Path $logFile -Parent
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }
    Add-Content -Path $logFile -Value $logMessage -Encoding UTF8
}

function Initialize-Service {
    Write-Log "Initializing Soul Oracle Service..."

    if (-not (Test-Path $DataDir)) {
        New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
        Write-Log "Created data directory: $DataDir"
    }

    $dbDir = Join-Path $DataDir "db"
    if (-not (Test-Path $dbDir)) {
        New-Item -ItemType Directory -Path $dbDir -Force | Out-Null
    }

    $configFile = Join-Path $DataDir "config.json"
    if (-not (Test-Path $configFile)) {
        $defaultConfig = @{
            port = 3847
            dataDir = $DataDir
            platforms = @{}
            watcher = @{
                enabled = $true
                scanIntervalMs = $ScanIntervalMs
            }
        } | ConvertTo-Json -Depth 10
        Set-Content -Path $configFile -Value $defaultConfig -Encoding UTF8
        Write-Log "Created default config"
    }

    Write-Log "Service initialized successfully"
}

function Get-FileHashSimple {
    param([string]$Path)
    try {
        $content = Get-Content $Path -Raw -ErrorAction SilentlyContinue
        if ($content) {
            return $content.GetHashCode()
        }
    } catch {
        return 0
    }
    return 0
}

function Scan-Platform {
    param([string]$PlatformId, [hashtable]$PlatformConfig)

    if (-not $PlatformConfig.Enabled) {
        return
    }

    $parserFunc = $PlatformConfig.Parser
    foreach ($basePath in $PlatformConfig.BasePaths) {
        $expandedPath = [System.Environment]::ExpandEnvironmentVariables($basePath)

        if (-not (Test-Path $expandedPath)) {
            continue
        }

        try {
            $files = Get-ChildItem -Path $expandedPath -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in @(".json", ".jsonl", ".md") }

            foreach ($file in $files) {
                $fileHash = Get-FileHashSimple -Path $file.FullName

                if ($Script:LastProcessed[$file.FullName] -ne $fileHash) {
                    $Script:LastProcessed[$file.FullName] = $fileHash

                    $memoryEvent = @{
                        platform = $PlatformId
                        sourcePath = $file.FullName
                        timestamp = (Get-Date).ToString("o")
                        content = ""
                        contentType = "unknown"
                        importance = 5
                    }

                    try {
                        switch ($parserFunc) {
                            "ParseClaudeCode" { $memoryEvent = Parse-ClaudeCode $file }
                            "ParseCline" { $memoryEvent = Parse-Cline $file }
                            "ParseCursor" { $memoryEvent = Parse-Cursor $file }
                            "ParseWindsurf" { $memoryEvent = Parse-Windsurf $file }
                            "ParseOpenClaw" { $memoryEvent = Parse-OpenClaw $file }
                            "ParseCopilot" { $memoryEvent = Parse-Copilot $file }
                            "ParseContinue" { $memoryEvent = Parse-Continue $file }
                            "ParseZed" { $memoryEvent = Parse-Zed $file }
                        }

                        if ($memoryEvent.content) {
                            Send-ToServer $memoryEvent
                        }
                    } catch {
                        Write-Log "Error parsing $($file.FullName): $_" "WARN"
                    }
                }
            }
        } catch {
            Write-Log "Error scanning $expandedPath: $_" "WARN"
        }
    }
}

function Parse-ClaudeCode {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "claude-code"
        contentType = "session"
        importance = 5
    }

    try {
        $content = Get-Content $File.FullName -Raw | ConvertFrom-Json

        if ($File.Name -eq "globalState.json") {
            $memory.content = "Claude Code global state: $(@($content.PSObject.Properties).Count) properties"
            $memory.contentType = "config"
            $memory.importance = 3
        }
        elseif ($File.Name -eq "workspaceState.json") {
            $memory.content = "Workspace state update"
            $memory.contentType = "workspace"
            $memory.importance = 4
        }
        elseif ($content.PSObject.Properties.Name -contains "messages" -or $content.PSObject.Properties.Name -contains "transcript") {
            $memory.content = "Claude Code session with $($content.messages.Count) messages"
            $memory.contentType = "chat"
            $memory.importance = 6
        }
        else {
            $memory.content = "Claude Code data file: $($File.Name)"
            $memory.contentType = "general"
        }

        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")
    } catch {
        return $null
    }

    return $memory
}

function Parse-Cline {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "cline"
        contentType = "general"
        importance = 5
    }

    try {
        $content = Get-Content $File.FullName -Raw | ConvertFrom-Json -ErrorAction SilentlyContinue

        if ($content) {
            $memory.content = "Cline data: $((@($content.PSObject.Properties).Count)) fields"
            $memory.sourcePath = $File.FullName
            $memory.timestamp = (Get-Date).ToString("o")

            if ($File.FullName -match "workspaces?") {
                $memory.contentType = "workspace"
                $memory.importance = 5
            }
        } else {
            return $null
        }
    } catch {
        return $null
    }

    return $memory
}

function Parse-Cursor {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "cursor"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = "Cursor data file: $($File.Name)"
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")

        if ($File.FullName -match "globalStorage") {
            $memory.contentType = "config"
            $memory.importance = 3
        }
    } catch {
        return $null
    }

    return $memory
}

function Parse-Windsurf {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "windsurf"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = "Windsurf data file: $($File.Name)"
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")

        if ($File.FullName -match "workspace") {
            $memory.contentType = "workspace"
            $memory.importance = 5
        }
    } catch {
        return $null
    }

    return $memory
}

function Parse-OpenClaw {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "openclaw"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = Get-Content $File.FullName -Raw -ErrorAction SilentlyContinue
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")
        $memory.importance = 5

        if ($File.Extension -eq ".md") {
            $memory.contentType = "document"
        }
    } catch {
        return $null
    }

    return $memory
}

function Parse-Copilot {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "copilot"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = "Copilot data file: $($File.Name)"
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")
    } catch {
        return $null
    }

    return $memory
}

function Parse-Continue {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "continue"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = "Continue data file: $($File.Name)"
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")
    } catch {
        return $null
    }

    return $memory
}

function Parse-Zed {
    param([System.IO.FileInfo]$File)

    $memory = @{
        platform = "zed"
        contentType = "general"
        importance = 4
    }

    try {
        $memory.content = "Zed data file: $($File.Name)"
        $memory.sourcePath = $File.FullName
        $memory.timestamp = (Get-Date).ToString("o")
    } catch {
        return $null
    }

    return $memory
}

function Send-ToServer {
    param([hashtable]$Event)

    try {
        $json = $Event | ConvertTo-Json -Compress
        $null = Invoke-RestMethod -Uri "$ServerUrl/api/memories" -Method Post -Body $json -ContentType "application/json" -TimeoutSec 5 -ErrorAction SilentlyContinue
    } catch {
    }
}

function Start-Watcher {
    Write-Log "Starting file system watcher..."

    while ($Script:IsRunning) {
        foreach ($platformId in $Platforms.Keys) {
            Scan-Platform -PlatformId $platformId -PlatformConfig $Platforms[$platformId]
        }

        Start-Sleep -Milliseconds $ScanIntervalMs
    }
}

function Stop-Service {
    Write-Log "Stopping Soul Oracle Service..."
    $Script:IsRunning = $false
}

Initialize-Service

Write-Log "Soul Oracle Service started"
Write-Log "Monitoring $($Platforms.Count) platforms"
Write-Log "Server URL: $ServerUrl"
Write-Log "Data directory: $DataDir"

try {
    Start-Watcher
} catch {
    Write-Log "Service error: $_" "ERROR"
} finally {
    Stop-Service
}