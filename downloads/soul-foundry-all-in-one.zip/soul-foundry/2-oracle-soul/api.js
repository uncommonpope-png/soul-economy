const API_BASE = '';

async function api(endpoint, options = {}) {
    const url = API_BASE + endpoint;
    const config = {
        method: options.method || 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    };

    if (options.body) {
        config.body = JSON.stringify(options.body);
    }

    try {
        const response = await fetch(url, config);
        const data = await response.json();
        return data;
    } catch (err) {
        console.error('API error:', err);
        return { success: false, error: err.message };
    }
}

const SoulOracleAPI = {
    async getStats() {
        return api('/api/stats');
    },

    async getMemories(query = '', platform = '', limit = 20) {
        let endpoint = `/api/memories?q=${encodeURIComponent(query)}&limit=${limit}`;
        if (platform) {
            endpoint += `&platform=${encodeURIComponent(platform)}`;
        }
        return api(endpoint);
    },

    async getMemory(id) {
        return api(`/api/memories/${id}`);
    },

    async addMemory(memory) {
        return api('/api/memories', {
            method: 'POST',
            body: memory
        });
    },

    async getPlatforms() {
        return api('/api/platforms');
    },

    async getHealth() {
        return api('/api/health');
    },

    async searchMemories(query, platformFilter = '') {
        const q = encodeURIComponent(query);
        const p = encodeURIComponent(platformFilter);
        return api(`/api/memories?q=${q}${p ? '&platform=' + p : ''}`);
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = SoulOracleAPI;
}