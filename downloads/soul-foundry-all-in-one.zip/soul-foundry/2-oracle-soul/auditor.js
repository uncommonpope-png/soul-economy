#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');
const { URL } = require('url');

class SoulAuditor {
    constructor(dataDir = path.join(os.homedir(), '.soul-oracle')) {
        this.dataDir = dataDir;
        this.auditPath = path.join(dataDir, 'audits.json');
        this.findingsPath = path.join(dataDir, 'findings.json');
        this.biblePath = path.join(dataDir, 'living-bible.json');
        this.learningsPath = path.join(dataDir, 'learnings.json');
    }

    now() {
        return new Date().toISOString();
    }

    generateId() {
        return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    async auditSession(options = {}) {
        const { 
            limit = 10, 
            searchWeb = true, 
            includeCode = true,
            autoApply = false 
        } = options;

        const learnings = this.getRecentLearnings(limit);
        const memories = this.getRecentMemories(limit);
        const items = [...learnings, ...memories].sort((a, b) => 
            new Date(b.timestamp) - new Date(a.timestamp)
        ).slice(0, limit);

        if (items.length === 0) {
            return { error: 'No sessions found to audit', items: [] };
        }

        const findings = [];
        const webRefs = [];

        for (const item of items) {
            const content = item.content || item.description || '';
            const platform = item.platform || 'unknown';

            const finding = {
                id: this.generateId(),
                timestamp: this.now(),
                platform,
                source: item,
                analysis: this.analyzeContent(content),
                comparisons: [],
                suggestions: []
            };

            if (searchWeb && this.isSearchable(content)) {
                const searchTerm = this.extractSearchTerms(content);
                if (searchTerm) {
                    const webResults = await this.searchWeb(searchTerm);
                    finding.comparisons = webResults.slice(0, 3);
                    finding.suggestions = this.generateSuggestions(content, webResults);
                    webRefs.push(...webResults.slice(0, 3));
                }
            }

            if (includeCode && content.includes('```')) {
                finding.codeSnippets = this.extractCode(content);
                finding.codeReview = this.reviewCode(finding.codeSnippets);
            }

            findings.push(finding);
        }

        const audit = {
            id: `audit_session_${Date.now()}`,
            timestamp: this.now(),
            totalItems: items.length,
            items: findings,
            webReferences: webRefs,
            summary: this.generateSummary(findings),
            applied: autoApply
        };

        this.saveAudit(audit);

        if (autoApply) {
            this.applyFindings(findings);
        }

        return audit;
    }

    getRecentLearnings(limit) {
        if (!fs.existsSync(this.learningsPath)) return [];
        try {
            const data = JSON.parse(fs.readFileSync(this.learningsPath, 'utf8'));
            return Array.isArray(data) ? data.slice(-limit) : [];
        } catch { return []; }
    }

    getRecentMemories(limit) {
        const dbDir = path.join(this.dataDir, 'db');
        if (!fs.existsSync(dbDir)) return [];
        
        const memories = [];
        try {
            const files = fs.readdirSync(dbDir);
            files.forEach(file => {
                const filePath = path.join(dbDir, file);
                try {
                    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                    if (Array.isArray(data)) memories.push(...data);
                } catch {}
            });
        } catch {}
        return memories.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, limit);
    }

    analyzeContent(content) {
        const analysis = {
            hasDecision: false,
            hasProblem: false,
            hasSolution: false,
            hasCode: false,
            topics: [],
            tone: 'neutral'
        };

        const lower = content.toLowerCase();

        if (lower.includes('decided') || lower.includes('chose') || 
            lower.includes('going with') || lower.includes('selected'))
            analysis.hasDecision = true;

        if (lower.includes('bug') || lower.includes('error') || 
            lower.includes('issue') || lower.includes('failed') ||
            lower.includes('broken'))
            analysis.hasProblem = true;

        if (lower.includes('fixed') || lower.includes('solved') || 
            lower.includes('solution') || lower.includes('works now'))
            analysis.hasSolution = true;

        if (content.includes('```') || lower.includes('function') || 
            lower.includes('const ') || lower.includes('import '))
            analysis.hasCode = true;

        const topicMatches = content.match(/\b(react|vue|angular|node|python|javascript|typescript|rust|go|docker|sql|api|graphql|jwt|oauth|aws|azure|git|testing|deployment|authentication|database|frontend|backend|api|rest|graphql)\b/gi);
        if (topicMatches) {
            analysis.topics = [...new Set(topicMatches.map(t => t.toLowerCase()))];
        }

        if (content.includes('great') || content.includes('perfect') || content.includes('works'))
            analysis.tone = 'positive';
        else if (content.includes('frustrating') || content.includes('annoying') || content.includes('struggling'))
            analysis.tone = 'frustrated';

        return analysis;
    }

    isSearchable(content) {
        return content.length > 30 && 
               (content.includes('how') || content.includes('what') || 
                content.includes('why') || content.includes('best') ||
                content.includes('vs') || content.includes('alternative') ||
                content.includes('bug') || content.includes('error') ||
                content.includes('implement') || content.includes('pattern'));
    }

    extractSearchTerms(content) {
        const stopWords = ['the', 'a', 'an', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'is', 'was', 'are', 'were', 'this', 'that', 'it', 'with', 'from', 'by', 'as', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'but', 'not', 'what', 'which', 'who', 'whom', 'when', 'where', 'why', 'how'];
        
        const words = content.replace(/[^a-zA-Z0-9\s#]/g, '')
            .split(/\s+/)
            .filter(w => w.length > 2 && !stopWords.includes(w.toLowerCase()))
            .slice(0, 8);

        if (words.length < 2) return null;

        const techTerms = words.filter(w => /^(react|vue|angular|node|python|js|ts|rust|go|docker|sql|api|jwt|oauth|aws|git|css|html|json|yaml|npm|yarn|webpack|vite|jest|cypress|next|nuxt|express|fastify|prisma|typeorm|redux|vuex|pinia)$/i.test(w));
        
        if (techTerms.length > 0) {
            return [...new Set(techTerms.map(t => t.toLowerCase()))].join(' ');
        }

        return words.slice(0, 5).join(' ');
    }

    async searchWeb(query) {
        const results = [];
        const sources = [];

        // Try Stack Overflow first
        try {
            const soResults = await this.searchStackOverflow(query);
            sources.push(...soResults);
        } catch {}

        // Try DuckDuckGo
        try {
            const ddgResults = await this.searchDuckDuckGo(query);
            sources.push(...ddgResults);
        } catch {}

        // Try GitHub
        try {
            const ghResults = await this.searchGitHub(query);
            sources.push(...ghResults);
        } catch {}

        return sources.slice(0, 5);
    }

    searchStackOverflow(query) {
        return new Promise((resolve) => {
            const url = `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encodeURIComponent(query)}&site=stackoverflow&pagesize=3`;
            
            https.get(url, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        if (json.items) {
                            resolve(json.items.map(item => ({
                                source: 'stackoverflow',
                                title: item.title,
                                url: item.link,
                                score: item.score,
                                answerCount: item.answer_count,
                                snippet: item.title
                            })));
                        } else resolve([]);
                    } catch { resolve([]); }
                });
            }).on('error', () => resolve([]));
        });
    }

    searchDuckDuckGo(query) {
        return new Promise((resolve) => {
            const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1`;
            
            https.get(url, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        const results = [];
                        if (json.AbstractText) {
                            results.push({
                                source: 'duckduckgo',
                                title: json.Heading || 'Related',
                                url: json.AbstractURL || '',
                                snippet: json.AbstractText.substring(0, 300)
                            });
                        }
                        if (json.RelatedTopics) {
                            json.RelatedTopics.slice(0, 3).forEach(topic => {
                                if (topic.Text) {
                                    results.push({
                                        source: 'duckduckgo',
                                        title: topic.Text.substring(0, 80),
                                        url: topic.FirstURL || '',
                                        snippet: topic.Text.substring(0, 300)
                                    });
                                }
                            });
                        }
                        resolve(results);
                    } catch { resolve([]); }
                });
            }).on('error', () => resolve([]));
        });
    }

    searchGitHub(query) {
        return new Promise((resolve) => {
            const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=3`;
            
            https.get(url, { headers: { 'User-Agent': 'SoulOracle/1.0' } }, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        if (json.items) {
                            resolve(json.items.map(item => ({
                                source: 'github',
                                title: item.full_name,
                                url: item.html_url,
                                stars: item.stargazers_count,
                                description: item.description || '',
                                snippet: `${item.full_name} - ${item.description || ''} (${item.stargazers_count} stars)`
                            })));
                        } else resolve([]);
                    } catch { resolve([]); }
                });
            }).on('error', () => resolve([]));
        });
    }

    generateSuggestions(content, webResults) {
        const suggestions = [];
        
        if (webResults.length === 0) {
            suggestions.push({
                type: 'info',
                text: 'No web references found. Consider researching this topic manually.'
            });
            return suggestions;
        }

        const lower = content.toLowerCase();

        if (lower.includes('error') || lower.includes('bug')) {
            const solutions = webResults.filter(r => 
                r.snippet.toLowerCase().includes('fix') || 
                r.snippet.toLowerCase().includes('solution')
            );
            if (solutions.length > 0) {
                suggestions.push({
                    type: 'solution',
                    text: `Found ${solutions.length} potential solutions. Reference: ${solutions[0].url}`
                });
            }
        }

        if (lower.includes('implement') || lower.includes('build')) {
            const repos = webResults.filter(r => r.source === 'github');
            if (repos.length > 0) {
                suggestions.push({
                    type: 'reference',
                    text: `Similar implementation: ${repos[0].title} (${repos[0].stars} stars)`,
                    url: repos[0].url
                });
            }
        }

        if (lower.includes('vs') || lower.includes('alternative') || lower.includes('which')) {
            suggestions.push({
                type: 'comparison',
                text: 'Check community discussions for comparisons on this topic',
                url: webResults[0]?.url || ''
            });
        }

        return suggestions;
    }

    extractCode(content) {
        const codes = [];
        const regex = /```(\w*)\n([\s\S]*?)```/g;
        let match;
        while ((match = regex.exec(content)) !== null) {
            codes.push({
                language: match[1] || 'unknown',
                code: match[2].substring(0, 500)
            });
        }
        return codes;
    }

    reviewCode(snippets) {
        const reviews = [];
        snippets.forEach(snippet => {
            const issues = [];
            const lines = snippet.code.split('\n');

            if (snippet.code.includes('console.log')) {
                issues.push({ severity: 'warning', message: 'Contains console.log statements (remove before production)' });
            }
            if (snippet.code.includes('TODO') || snippet.code.includes('FIXME')) {
                issues.push({ severity: 'info', message: 'Contains TODO/FIXME markers (incomplete work)' });
            }
            if (snippet.code.includes('var ')) {
                issues.push({ severity: 'warning', message: 'Uses var instead of const/let' });
            }
            if (lines.some(l => l.length > 120)) {
                issues.push({ severity: 'style', message: 'Lines exceed 120 characters (readability)' });
            }

            reviews.push({
                language: snippet.language,
                issues,
                score: Math.max(0, 10 - issues.length * 2)
            });
        });
        return reviews;
    }

    generateSummary(findings) {
        const decisions = findings.filter(f => f.analysis.hasDecision);
        const problems = findings.filter(f => f.analysis.hasProblem);
        const solutions = findings.filter(f => f.analysis.hasSolution);
        const codeItems = findings.filter(f => f.analysis.hasCode);
        const withSuggestions = findings.filter(f => f.suggestions.length > 0);

        const allTopics = [...new Set(findings.flatMap(f => f.analysis.topics))];

        return {
            totalItems: findings.length,
            decisions: decisions.length,
            problems: problems.length,
            solutions: solutions.length,
            codeSnippets: codeItems.length,
            newSuggestions: withSuggestions.length,
            topics: allTopics,
            topTopic: allTopics[0] || null,
            hasGaps: problems.length > solutions.length,
            webReferencesFound: findings.reduce((sum, f) => sum + f.comparisons.length, 0)
        };
    }

    saveAudit(audit) {
        let audits = [];
        if (fs.existsSync(this.auditPath)) {
            try { audits = JSON.parse(fs.readFileSync(this.auditPath, 'utf8')); } catch {}
        }
        audits.unshift(audit);
        if (audits.length > 50) audits = audits.slice(0, 50);
        fs.writeFileSync(this.auditPath, JSON.stringify(audits, null, 2));
    }

    applyFindings(findings) {
        const newLearnings = [];

        findings.forEach(finding => {
            if (finding.suggestions.length > 0) {
                finding.suggestions.forEach(suggestion => {
                    newLearnings.push({
                        id: `lrn_audit_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                        type: 'audit-suggestion',
                        content: suggestion.text,
                        source: 'soul-auditor',
                        platform: finding.platform || 'unknown',
                        metadata: { url: suggestion.url || '', auditId: finding.id },
                        timestamp: this.now()
                    });
                });
            }
        });

        if (newLearnings.length > 0) {
            let learnings = [];
            if (fs.existsSync(this.learningsPath)) {
                try { learnings = JSON.parse(fs.readFileSync(this.learningsPath, 'utf8')); } catch {}
            }
            learnings.push(...newLearnings);
            if (learnings.length > 500) learnings = learnings.slice(-500);
            fs.writeFileSync(this.learningsPath, JSON.stringify(learnings, null, 2));
        }
    }

    getAuditHistory(limit = 10) {
        if (!fs.existsSync(this.auditPath)) return [];
        try {
            const audits = JSON.parse(fs.readFileSync(this.auditPath, 'utf8'));
            return Array.isArray(audits) ? audits.slice(0, limit) : [];
        } catch { return []; }
    }

    getLatestFinding() {
        if (!fs.existsSync(this.findingsPath)) return null;
        try {
            const findings = JSON.parse(fs.readFileSync(this.findingsPath, 'utf8'));
            return Array.isArray(findings) ? findings[findings.length - 1] : null;
        } catch { return null; }
    }
}

module.exports = SoulAuditor;

if (require.main === module) {
    const auditor = new SoulAuditor();
    const cmd = process.argv[2] || 'help';

    switch (cmd) {
        case 'audit':
            auditor.auditSession({ searchWeb: true }).then(r => console.log(JSON.stringify(r, null, 2)));
            break;
        case 'history':
            console.log(JSON.stringify(auditor.getAuditHistory(), null, 2));
            break;
        default:
            console.log(`
Soul Auditor - Agent Work Reviewer

Commands:
  node auditor.js audit    - Run audit on recent sessions
  node auditor.js history  - View audit history
  node auditor.js help     - Show this help
`);
    }
}