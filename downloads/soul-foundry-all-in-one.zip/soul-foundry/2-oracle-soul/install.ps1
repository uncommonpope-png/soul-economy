# Soul Oracle Installer
# One-command installation for Windows

param(
    [string]$InstallPath = "$env:USERPROFILE\.soul-oracle",
    [switch]$SkipNPM
)

$ErrorActionPreference = "Stop"

Write-Host @"
╔══════════════════════════════════════════╗
║         Soul Oracle Installer             ║
║    Your AI agents share one soul         ║
╚══════════════════════════════════════════╝
"@ -ForegroundColor Cyan

Write-Host "`n[1/5] Checking prerequisites..." -ForegroundColor Yellow

$nodeVersion = node --version 2>$null
if ($nodeVersion) {
    Write-Host "  ✓ Node.js $nodeVersion found" -ForegroundColor Green
} else {
    Write-Host "  ✗ Node.js not found. Please install from https://nodejs.org" -ForegroundColor Red
    exit 1
}

Write-Host "`n[2/5] Creating installation directory..." -ForegroundColor Yellow

if (Test-Path $InstallPath) {
    Write-Host "  ✓ Directory exists: $InstallPath" -ForegroundColor Green
} else {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    Write-Host "  ✓ Created: $InstallPath" -ForegroundColor Green
}

Write-Host "`n[3/5] Copying Soul Oracle files..." -ForegroundColor Yellow

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ($scriptDir -eq "") {
    $scriptDir = Get-Location
}

$copyItems = @("service", "server", "dashboard", "package.json", "SPEC.md")
foreach ($item in $copyItems) {
    $src = Join-Path $scriptDir $item
    $dst = Join-Path $InstallPath $item
    if (Test-Path $src) {
        if (Test-Path $dst) {
            Remove-Item $dst -Recurse -Force
        }
        Copy-Item -Path $src -Destination $dst -Recurse -Force
        Write-Host "  ✓ Copied: $item" -ForegroundColor Green
    }
}

Write-Host "`n[4/5] Installing Node.js dependencies..." -ForegroundColor Yellow

if (-not $SkipNPM) {
    Push-Location $InstallPath
    try {
        npm install 2>$null
        Write-Host "  ✓ Dependencies installed" -ForegroundColor Green
    } catch {
        Write-Host "  ⚠ npm install failed, trying without npm packages" -ForegroundColor Yellow
    }
    Pop-Location
}

Write-Host "`n[5/5] Creating shortcuts and configuration..." -ForegroundColor Yellow

$configPath = Join-Path $InstallPath "config.json"
$config = @{
    port = 3847
    dataDir = $InstallPath
    serviceUrl = "http://localhost:3847"
    version = "1.1.0"
} | ConvertTo-Json -Depth 5

Set-Content -Path $configPath -Value $config -Encoding UTF8
Write-Host "  ✓ Config created" -ForegroundColor Green

$startupShortcut = Join-Path $InstallPath "soul-oracle-startup.bat"
$startupContent = "@echo off
cd /d `"$InstallPath`"
start /B node server\index.js
powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$InstallPath\service\soul-oracle.ps1`"
Set-Content -Path $startupShortcut -Value $startupContent -Encoding ASCII
Write-Host "  ✓ Startup script created" -ForegroundColor Green

Write-Host @"

╔══════════════════════════════════════════╗
║         Installation Complete!            ║
╚══════════════════════════════════════════╝

To start Soul Oracle:

  1. Start the server:
     cd `$InstallPath
     npm start

  2. Open dashboard:
     http://localhost:3847/

  3. Start monitoring (PowerShell as Admin):
     powershell -ExecutionPolicy Bypass -File `"$InstallPath\service\soul-oracle.ps1`"

For auto-start on boot, add to Windows Task Scheduler:
  schtasks /create /tn "Soul Oracle" /tr `"powershell -ExecutionPolicy Bypass -File `"$InstallPath\service\soul-oracle.ps1`"`" /sc onlogon

"@ -ForegroundColor Cyan