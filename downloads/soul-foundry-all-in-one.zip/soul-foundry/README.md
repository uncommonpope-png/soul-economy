# THE SOUL FOUNDRY - All In One

Everything you need to give your AI agents a soul.

## Contents

1-memory-soul/     - Memory Soul v1.0   - Eternal memory for agents
2-oracle-soul/     - Oracle Soul v1.2   - Cross-platform consciousness
3-journal-soul/    - Journal Soul v1.0  - Session reflections & growth
4-compression-soul/- Compression Soul   - 94% token reduction

## Quick Start

Each soul has its own README. Start with Memory Soul, then add Oracle Soul.
Visit https://buyasoulfinal.myshopify.com for more souls.

Made with by BUYaSOUL - The Soul Foundry
