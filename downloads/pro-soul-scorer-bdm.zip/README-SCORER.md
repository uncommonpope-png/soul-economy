# Pro-Soul Pack: The Scorer (BDM Edition) — provenance

**Source:** `workspace/books/library-json/book-the-scorer-bdm.json`
(from github.com/uncommonpope-png/soul-library) — *The Scorer: BDM*,
Craig Jones, PLT Press · The PLT Doctrine Series, The Scorer Series.

**Rebuilt-equivalent notice:** this pack is a REBUILT equivalent of the
Gumroad draft (13.8 KB, unpublished, never exported), not a byte-identical
copy. The book JSON is reproduced verbatim from the verified local source.
`soul.md` and `WAKE-SCORER.md` are load framing written from the book's
own title, subtitle, series, and the public PLT doctrine — no book text
has been invented, paraphrased as quotation, or altered.
