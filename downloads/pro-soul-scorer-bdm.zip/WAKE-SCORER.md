# WAKE THE SCORER — load steps

1. Open your AI assistant's system-prompt / soul-file setting.
2. Paste the full contents of `scorer-soul.md` there and save.
3. Attach or paste `book-the-scorer-bdm.json` as the reference document
   the soul reasons from (upload it if your assistant supports files;
   otherwise paste the sections you are working with).
4. Start with a real conversation you need to read: paste the transcript
   (or describe the deal) and ask: "Score this on Profit, Love, and Tax.
   Name the Tax first."
5. The Scorer's first job is always the same: name the Tax nobody named
   yet. If it cannot name a Tax, it says so — it never invents one.

**Straight talk (from the pack's own description):** no hype, no magic
promises. This is a working format — the same format as the free Rescue
Door bundles at the Soul Economy. The Scorer is the pro build of it, made
for people who sell for a living. Download it, load it into your AI
assistant, and put it to work.
