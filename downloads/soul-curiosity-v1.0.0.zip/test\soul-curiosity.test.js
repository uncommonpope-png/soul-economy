#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-curiosity-test');
console.log('\n Curiosity Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const CuriositySoul=require('../lib/soul-curiosity.js');
t('Loads with key',()=>{const i=new CuriositySoul({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Auth check works',()=>{const i=new CuriositySoul({dataDir:TD,apiKey:'testkey'});assert(i.checkAuth({headers:{'x-api-key':'testkey'}}));assert(!i.checkAuth({headers:{'x-api-key':'wrong'}}));});
t('Key persists',()=>{const i=new CuriositySoul({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Explore new topic adds it',()=>{const i=new CuriositySoul({dataDir:TD});i.explore("quantum");assert(i.known_topics.includes("quantum"));});
t('Explore existing topic branches',()=>{const i=new CuriositySoul({dataDir:TD});i.explore("physics");const len=i.topic_tree["physics"].branches.length;i.explore("physics");assert(i.topic_tree["physics"].branches.length>=len);});
t('Ask generates a question',()=>{const i=new CuriositySoul({dataDir:TD});const r=i.ask();assert(r.question);assert(r.topic);});
t('Discover records new finding',()=>{const i=new CuriositySoul({dataDir:TD});const r=i.discover("E=mc^2","physics");assert(r.recorded);assert(r.finding==="E=mc^2");});
t('Curiosity saturation increases',()=>{const i=new CuriositySoul({dataDir:TD});i.explore("a");i.explore("b");i.explore("c");assert(i.curiosity_saturation>0);});
t('Discovery journal grows',()=>{const i=new CuriositySoul({dataDir:TD});i.explore("math");i.ask();i.discover("new thing","science");assert(i.discovery_journal.length>=3);});
t('Topic tree branches grow',()=>{const i=new CuriositySoul({dataDir:TD});i.explore("physics");i.explore("physics");i.explore("physics");assert(i.topic_tree["physics"].branches.length>=2);});
t('GetCuriosityState works',()=>{const i=new CuriositySoul({dataDir:TD});const r=i.getCuriosityState();assert(typeof r.curiosity_level==="number");assert(typeof r.topic_branches==="number");});
t('GetStats returns ok',()=>{const i=new CuriositySoul({dataDir:TD});const s=i.getStats();assert(s.name);assert(typeof s.curiosity_level==="number");});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);