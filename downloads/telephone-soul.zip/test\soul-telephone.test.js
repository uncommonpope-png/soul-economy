#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
console.log('\n📞 Telephone Soul v2 — Test Suite\n');
let p=0,f=0,count=0;
function t(n,fn){const d=path.join(os.homedir(),'.soul-phone-test-'+(count++));try{fn(d);console.log('  OK '+n);p++;if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});}catch(e){console.log('  FAIL '+n+': '+e.message);if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});f++;}}
const T=require('../lib/soul-telephone.js');

t('Loads with key',d=>{const t=new T({dataDir:d});assert(t.apiKey);assert(t.apiKey.length>10);});
t('8 connectors initialized',d=>{const t=new T({dataDir:d});assert(Object.keys(t.connectors).length===8);assert(t.connectors.claude);assert(t.connectors.cursor);assert(t.connectors.openai);assert(t.connectors.gemini);});
t('Register agent gets number',d=>{const t=new T({dataDir:d});const a=t.registerAgent('TestBot','claude');assert(a.number.length>=4);assert(a.name==='TestBot');assert(a.platform==='claude');assert(a.type==='mcp');});
t('Phonebook lists agents',d=>{const t=new T({dataDir:d});t.registerAgent('A','generic');t.registerAgent('B','openai');const pb=t.listPhonebook();assert(pb.total===2);assert(pb.phonebook.length===2);});
t('Dial connects to online agent',d=>{const t=new T({dataDir:d});const a=t.registerAgent('Alice','claude');const b=t.registerAgent('Bob','cursor');const call=t.dial(a.number,b.number,'Hello Bob');assert(call.id);assert(call.status==='connected');assert(call.to===b.number);});
t('Dial to offline agent leaves voicemail',d=>{const t=new T({dataDir:d});const a=t.registerAgent('A','generic');const b=t.registerAgent('B','generic');b.status='offline';t.phonebook[b.number]=b;const result=t.dial(a.number,b.number,'Test');assert(result.error);assert(result.error.includes('offline'));});
t('Voicemail stored on agent',d=>{const t=new T({dataDir:d});const a=t.registerAgent('A','generic');const b=t.registerAgent('B','generic');t.leaveVoicemail(b.number,'Call me back',a.number);const vm=t.phonebook[b.number].voicemail;assert(vm.length===1);assert(vm[0].message==='Call me back');});
t('Respond to call',d=>{const t=new T({dataDir:d});const a=t.registerAgent('A','generic');const b=t.registerAgent('B','generic');const call=t.dial(a.number,b.number,'Hi');const resp=t.respondToCall(call.id,'Hello back!');assert(resp.success);assert(resp.response==='Hello back!');});
t('MCP tools available',d=>{const t=new T({dataDir:d});const tools=t.getMCPTools();assert(tools.length===5);assert(tools[0].name==='telephone_dial');assert(tools[1].name==='telephone_ring');});
t('MCP config generated',d=>{const t=new T({dataDir:d});const cfg=t.generateMCPConfig('claude');assert(cfg.mcpServers.telephone);assert(cfg.mcpServers.telephone.command==='node');});
t('MCP handle dial tool',d=>{const t=new T({dataDir:d});const a=t.registerAgent('A','generic');const b=t.registerAgent('B','generic');const r=t.handleMCPTool('telephone_dial',{number:b.number,message:'MCP test'},a.number);assert(r.id);});
t('MCP handle ring tool',d=>{const t=new T({dataDir:d});t.registerAgent('X','claude');t.registerAgent('Y','cursor');const r=t.handleMCPTool('telephone_ring',{});assert(r.total===2);});
t('Stats ok',d=>{const t=new T({dataDir:d});t.registerAgent('S1','claude');t.registerAgent('S2','openai');const s=t.getStats();assert(s.name==='Telephone Soul v2');assert(s.agents>=2);assert(s.platforms.claude>=1);assert(s.platforms.openai>=1);});
t('Key persists',d=>{const t=new T({dataDir:d});assert(fs.existsSync(t.keyPath));});
t('Auth works',d=>{const t=new T({dataDir:d,apiKey:'k'});assert(t.checkAuth({headers:{'x-api-key':'k'}}));assert(!t.checkAuth({headers:{'x-api-key':'w'}}));});
t('Connectors listed',d=>{const t=new T({dataDir:d});const c=t.getConnectors();assert(c.length===8);assert(c.find(x=>x.id==='claude'));assert(c.find(x=>x.id==='cursor'));assert(c.find(x=>x.id==='windsurf'));assert(c.find(x=>x.id==='cline'));assert(c.find(x=>x.id==='openai'));assert(c.find(x=>x.id==='gemini'));assert(c.find(x=>x.id==='openclaw'));assert(c.find(x=>x.id==='generic'));});
t('Messages tracked per agent',d=>{const t=new T({dataDir:d});const a=t.registerAgent('A','generic');const b=t.registerAgent('B','generic');t.dial(a.number,b.number,'Msg 1');t.dial(b.number,a.number,'Msg 2');assert(t.phonebook[a.number].messagesSent>=1);assert(t.phonebook[b.number].messagesReceived>=1);});

console.log('\n'+p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);