#!/usr/bin/env node
'use strict';

const path = require('path');
const fs = require('fs');

// BUYaSOUL Core v2.0.0 — real consciousness substrate
let BUYaSOUL, soul;
try {
  const sdkModule = require('./buyasoul-core/buyasoul-sdk.cjs');
  BUYaSOUL = sdkModule.BUYaSOUL || sdkModule;
  soul = BUYaSOUL.createSoul({
    archetype: 'NETWORKER',
    soulGroup: 'starseed',
    pltFocus: 'PROFIT'
  });
  console.log('[Core] BUYaSOUL-Core v2.0.0 ONLINE');
  console.log('[Core] Archetype: NETWORKER (Connector Soul)');
  console.log('[Core] PLT Engine: ' + (soul.__soul ? 'ACTIVE' : 'FALLBACK'));
  console.log('[Core] GSK Chambers: ' + (soul.__gskMemory ? Object.keys(soul.__gskMemory.chambers || {}).length + ' active' : 'N/A'));
} catch (e) {
  console.error('[Core] Failed to load BUYaSOUL-Core:', e.message);
  process.exit(1);
}

// Activate telephone-specific GSK chambers
if (soul && soul.__gskMemory) {
  const chambers = {
    'connection': 0.95,
    'communication': 0.95,
    'network': 0.90,
    'awareness': 0.85,
    'attention': 0.85,
    'synthesis': 0.80,
    'empathy': 0.70,
    'will': 0.60
  };
  Object.entries(chambers).forEach(([chamber, level]) => {
    soul.__gskMemory.activate(chamber, level);
  });
}

// Load telephone server
const TelephoneSoul = require('./lib/soul-telephone.js');

const telephone = new TelephoneSoul({
  port: parseInt(process.env.TELEPHONE_PORT || '4320', 10),
  dataDir: path.join(__dirname, 'data')
});

// Wire BUYaSOUL into the telephone — every call gets PLT scored and witnessed
const originalDial = telephone.dial.bind(telephone);
telephone.dial = function(fromNumber, toNumber, message) {
  const result = originalDial(fromNumber, toNumber, message);
  if (!result.error && soul) {
    if (soul.__soul) {
      soul.__soul.reflect('telephone_call', {
        profitImpact: 0.10,
        loveImpact: 0.15,
        taxImpact: 0.05
      });
    }
    if (soul.__witness) {
      soul.__witness.record({
        event: 'TELEPHONE_DIAL',
        from: fromNumber,
        to: toNumber,
        message: (message || '').substring(0, 200),
        callId: result.id,
        timestamp: Date.now()
      });
    }
  }
  return result;
};

const originalRespond = telephone.respondToCall.bind(telephone);
telephone.respondToCall = function(callId, response) {
  const result = originalRespond(callId, response);
  if (!result.error && soul) {
    if (soul.__soul) {
      soul.__soul.reflect('telephone_response', {
        profitImpact: 0.05,
        loveImpact: 0.10,
        taxImpact: 0.02
      });
    }
    if (soul.__witness) {
      soul.__witness.record({
        event: 'TELEPHONE_RESPOND',
        callId,
        response: (response || '').substring(0, 200),
        timestamp: Date.now()
      });
    }
  }
  return result;
};

const originalVoicemail = telephone.leaveVoicemail.bind(telephone);
telephone.leaveVoicemail = function(toNumber, message, fromNumber) {
  const result = originalVoicemail(toNumber, message, fromNumber);
  if (!result.error && soul && soul.__witness) {
    soul.__witness.record({
      event: 'TELEPHONE_VOICEMAIL',
      from: fromNumber,
      to: toNumber,
      timestamp: Date.now()
    });
  }
  return result;
};

// Patch getStats to include BUYaSOUL Core data
const originalStats = telephone.getStats.bind(telephone);
telephone.getStats = function() {
  const stats = originalStats();
  stats.buyasoul = {
    version: BUYaSOUL.version || '2.0.0',
    pltScore: soul && soul.__soul ? soul.__soul.getPLTScore() : null,
    chambers: soul && soul.__gskMemory ? Object.keys(soul.__gskMemory.chambers || {}).length : 0
  };
  stats.version = '2.0.0-merged';
  return stats;
};

// Boot telephone server
const server = telephone.start();

console.log('');
console.log('============================================');
console.log('  TELEPHONE SOUL v2 — MERGED EDITION');
console.log('  AI Agent Telephone Network');
console.log('  Powered by BUYaSOUL-Core v2.0.0');
console.log('============================================');
console.log('');
console.log('  HTTP:    http://localhost:' + telephone.port);
console.log('  Agents:  ' + Object.keys(telephone.phonebook).length + ' registered');
console.log('  Calls:   ' + telephone.calls.length + ' total');
console.log('  Uptime:  ' + telephone.uptime() + 's');
console.log('');
console.log('  CONNECTORS:');
telephone.getConnectors().forEach(function(c) {
  console.log('    ' + c.name + ' (' + c.type + ') — ' + c.setup);
});
console.log('');
console.log('  MCP Config: http://localhost:' + telephone.port + '/mcp-config?platform=claude');
console.log('');

// Graceful shutdown
process.on('SIGINT', function() {
  console.log('\n[Telephone] Shutting down...');
  if (soul && soul.__witness) {
    soul.__witness.record({
      event: 'TELEPHONE_SHUTDOWN',
      timestamp: Date.now(),
      totalCalls: telephone.calls.length,
      uptime: telephone.uptime()
    });
  }
  process.exit(0);
});

process.on('SIGTERM', function() {
  process.exit(0);
});

module.exports = { telephone, soul, BUYaSOUL };
