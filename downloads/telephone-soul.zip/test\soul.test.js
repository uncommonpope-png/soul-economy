var assert = require("assert");
var SoulTelephone = require("../main.js");

async function test() {
  var soul = new SoulTelephone({});
  console.log("Testing soul-telephone...");

  var bootResult = await soul.boot();
  assert(bootResult.success === true, "boot should succeed");
  console.log("  + boot()");

  var chatResult = await soul.chat("Hello");
  assert(chatResult.reply, "chat should return reply");
  console.log("  + chat()");

  var status = await soul.getStatus();
  assert(status.health === "ok", "status should be ok");
  console.log("  + getStatus()");

  var plt = await soul.getPLT();
  assert(typeof plt.score === "number", "PLT should have score");
  console.log("  + getPLT()");

  var shutdownResult = await soul.shutdown();
  assert(shutdownResult.success === true, "shutdown should succeed");
  console.log("  + shutdown()");

  console.log("");
  console.log("All tests passed!");
}

test().catch(function(e) { console.error("Test failed:", e); process.exit(1); });