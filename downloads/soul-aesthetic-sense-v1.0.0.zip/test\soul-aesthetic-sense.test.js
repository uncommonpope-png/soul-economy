#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-aesthetic-sense-test');
console.log('\n Aesthetic Sense Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const AestheticSenseSoul=require('../lib/soul-aesthetic-sense.js');
t('Loads with key',()=>{const i=new AestheticSenseSoul({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Auth check works',()=>{const i=new AestheticSenseSoul({dataDir:TD,apiKey:'testkey'});assert(i.checkAuth({headers:{'x-api-key':'testkey'}}));assert(!i.checkAuth({headers:{'x-api-key':'wrong'}}));});
t('Key persists',()=>{const i=new AestheticSenseSoul({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Observe rates beauty',()=>{const i=new AestheticSenseSoul({dataDir:TD});const r=i.observe("sunset","nature");assert(typeof r.beauty_score==="number");assert(typeof r.is_beautiful==="boolean");});
t('Observe with unknown category works',()=>{const i=new AestheticSenseSoul({dataDir:TD});const r=i.observe("code");assert(r.category==="art");});
t('Create produces expression',()=>{const i=new AestheticSenseSoul({dataDir:TD});const r=i.create("classical");assert(r.style);assert(r.expression);});
t('Create adds to preferred styles',()=>{const i=new AestheticSenseSoul({dataDir:TD});const len=i.preferred_styles.length;i.create("surreal");assert(i.preferred_styles.length>=len);});
t('Find beauty returns results',()=>{const i=new AestheticSenseSoul({dataDir:TD});const r=i.findBeauty("mathematics");assert(typeof r.beauty_score==="number");});
t('Aesthetic categories track',()=>{const i=new AestheticSenseSoul({dataDir:TD});i.observe("rain","nature");i.observe("sonata","sound");assert(i.beauty_history.length>=2);});
t('Appreciation increases on observe',()=>{const i=new AestheticSenseSoul({dataDir:TD});const b=i.appreciation;i.observe("garden","nature");assert(i.appreciation>=b);});
t('GetAestheticState returns state',()=>{const i=new AestheticSenseSoul({dataDir:TD});const r=i.getAestheticState();assert(typeof r.appreciation==="number");assert(r.categories);});
t('GetStats returns ok',()=>{const i=new AestheticSenseSoul({dataDir:TD});const s=i.getStats();assert(s.name);assert(typeof s.appreciation==="number");});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);