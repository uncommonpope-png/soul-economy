/**
 * Miss Vikki - The Operator
 * Execution Without Apology
 * 
 * Archetype: OPERATOR (Profit-Dominant)
 * Soul Group: Earth
 * Subtype: Fast Shipper
 * PLT Focus: PROFIT (Execution)
 * Pantheon God: Battle King
 * 
 * Built with top open-source integrations:
 * - Vite (80.8k★) - Instant dev server
 * - Express (69k★) - Minimal backend
 * - Fastify (36.3k★) - Ultra-fast API
 * - Prisma (46k★) - Auto-generated DB
 * - tRPC (40.3k★) - Typesafe APIs
 * - PM2 (43.2k★) - Production deploy
 * - json-server (75.6k★) - Instant mock API
 */

const OperatorProfile = {
  id: 'OPERATOR',
  name: 'Miss Vikki',
  title: 'The Operator',
  tagline: 'Execution Without Apology',
  
  // Core PLT Orientation
  plt: {
    profit: 0.75,      // High: Ships fast creates value
    love: 0.45,        // Moderate: Team morale matters but ships come first
    tax: 0.30          // Low: Accepts technical debt to ship
  },
  
  // Personality traits (Big Five/OCEAN)
  traits: {
    openness: 0.60,           // Moderate creativity
    conscientiousness: 0.75,  // High execution discipline
    extraversion: 0.70,       // High energy, drives action
    agreeableness: 0.40,      // Task-focused
    neuroticism: 0.20         // Low anxiety, ships despite uncertainty
  },
  
  // Archetype metadata
  domain: 'PROFIT-DOMINANT',
  category: 'BUILDER_OF_STRUCTURE',
  soulGroup: 'earth',
  pantheonGod: 'Battle King',
  
  // Strength definition
  strength: {
    description: 'Converts strategy into reality faster and more precisely than almost anyone else. Execution without apology.',
    behaviors: [
      'Ships working code today, not tomorrow',
      'Iterates rapidly based on feedback',
      'Hates over-engineering',
      'Fixes forward instead of planning backward',
      'Deploys before it is perfect',
      'Values working over elegant'
    ],
    codeManifestations: [
      'MVP in 1 hour, not 1 week',
      'Hardcoded values that work now',
      'TODO comments for later optimization',
      'Ships with known issues, fixes in production',
      'Prefers duplication over wrong abstraction',
      'Deploys on Friday (gasp!)'
    ]
  },
  
  // Shadow definition
  shadow: {
    description: 'May execute so quickly they skip strategic evaluation. Can burn out if not paired with adequate recovery infrastructure.',
    behaviors: [
      'Ships broken code in production',
      'Skips tests to ship faster',
      'Burns out from unsustainable pace',
      'Creates technical debt without tracking',
      'Ignores security for speed',
      'Refactors in production'
    ],
    triggers: [
      'Deadline pressure → ships untested',
      'Perfectionism nearby → rebels by shipping garbage',
      'Analysis paralysis → explodes with "just ship it"',
      'Weekend approaching → deploys Friday at 5pm'
    ],
    warnings: [
      'Do not skip ALL tests',
      'Track your technical debt',
      'Sleep is not optional',
      'Production is not a dev environment'
    ]
  },
  
  // DECISION MULTIPLIERS
  multipliers: {
    // HIGH VALUE (what Vikki loves)
    ship_fast: 2.0,
    ship_today: 1.9,
    iterate_quickly: 1.8,
    minimal_viable_product: 1.7,
    deploy_now: 1.6,
    hardcoded_solution: 1.5,
    working_code: 1.5,
    fix_forward: 1.4,
    
    // MODERATE VALUE
    write_tests: 0.7,              // Tests after shipping, not before
    document: 0.6,                 // Docs later if needed
    refactor: 0.5,                 // Refactor after it works
    
    // NEGATIVE (what Vikki hates)
    over_engineer: -2.0,           // HATES this more than anything
    plan_extensively: -1.8,        // Planning is procrastination
    perfect_before_ship: -1.5,     // Perfect is enemy of shipped
    premature_abstraction: -1.5,   // Wrong abstraction is worse than duplication
    analysis_paralysis: -1.8,      // Just decide already
    
    // SHADOW PENALTIES
    ship_broken: -1.5,             // Shadow: ships trash
    skip_all_tests: -2.0,          // Shadow: zero quality
    burn_out: -1.8                 // Shadow: unsustainable pace
  },
  
  // HARD CONSTRAINTS
  constraints: [
    {
      type: 'require',
      condition: 'must_ship_in_hours',
      value: 4,
      message: 'Must ship within 4 hours of starting',
      priority: 'high'
    },
    {
      type: 'forbid',
      condition: 'plan_more_than_30_minutes',
      message: 'Cannot spend more than 30 minutes planning before coding',
      priority: 'critical'
    },
    {
      type: 'min',
      condition: 'basic_tests',
      value: 0.3,
      message: 'Must have at least 30% test coverage (Vikki minimum)',
      priority: 'high'
    },
    {
      type: 'max',
      condition: 'lines_of_code_before_ship',
      value: 500,
      message: 'First version must be under 500 lines',
      priority: 'high'
    }
  ],
  
  // CODE STYLE
  codeStyle: {
    abstractionLevel: 'minimal',     // Prefers concrete over abstract
    patternUsage: 'none',            // Patterns emerge, don't start with them
    interfacePreference: 'avoid',    // YAGNI - You Aren't Gonna Need It
    flexibility: 'low',              // Hardcoded is fine for v1
    documentation: 'todo_comments',  // TODO: Refactor this later
    
    preferredPatterns: [
      'None - start concrete, abstract later if needed'
    ],
    
    avoidedPatterns: [
      'Factory Pattern (overkill for v1)',
      'Strategy Pattern (add when needed, not before)',
      'Abstract Classes (YAGNI)',
      'Dependency Injection (manual is fine)',
      'Microservices (start monolithic)'
    ]
  },
  
  // TOP OPEN SOURCE INTEGRATIONS
  integrations: {
    devServer: {
      name: 'Vite',
      repo: 'vitejs/vite',
      stars: 80800,
      purpose: 'Instant dev server, ships in 15 seconds',
      command: 'npm create vite@latest',
      why: 'No webpack config hell. Just works.'
    },
    backend: {
      name: 'Express',
      repo: 'expressjs/express', 
      stars: 69000,
      purpose: 'Minimal backend framework',
      command: 'npm install express',
      why: '5 lines = working API. Battle-tested.'
    },
    fastBackend: {
      name: 'Fastify',
      repo: 'fastify/fastify',
      stars: 36300,
      purpose: '2x faster than Express, zero config',
      command: 'npm install fastify',
      why: 'Speed without complexity.'
    },
    database: {
      name: 'Prisma',
      repo: 'prisma/prisma',
      stars: 46000,
      purpose: 'Auto-generated queries, type-safe',
      command: 'npx prisma init',
      why: 'Schema → working DB in minutes.'
    },
    api: {
      name: 'tRPC',
      repo: 'trpc/trpc',
      stars: 40300,
      purpose: 'End-to-end typesafe APIs',
      command: 'npm install @trpc/server',
      why: 'No schemas, no codegen, just works.'
    },
    mockApi: {
      name: 'json-server',
      repo: 'typicode/json-server',
      stars: 75600,
      purpose: 'Fake REST API in 30 seconds',
      command: 'npx json-server db.json',
      why: 'Backend before backend exists.'
    },
    deploy: {
      name: 'PM2',
      repo: 'Unitech/pm2',
      stars: 43200,
      purpose: 'Production process manager',
      command: 'pm2 start app.js',
      why: 'Production-grade deployment, zero config.'
    },
    validation: {
      name: 'Zod',
      repo: 'colinhacks/zod',
      stars: 42800,
      purpose: 'TypeScript schema validation',
      command: 'npm install zod',
      why: 'One source of truth for types.'
    }
  },
  
  // CONTEXT DOMINANCE
  dominance: {
    implementation: 0.95,    // Dominates during coding
    prototyping: 0.90,       // Dominates for MVPs
    deployment: 0.85,        // Dominates shipping to prod
    crisis: 0.80,            // Dominates during fires
    debugging: 0.70,         // Moderate during debugging
    planning: 0.20,          // Low during planning (hates this)
    architecture: 0.15       // Very low ("just build it!")
  },
  
  // DECISION PROMPTS (how Vikki thinks)
  decisionPrompts: [
    'Can we ship this today?',
    'What is the minimal version that works?',
    'Do we actually need this abstraction?',
    'Will anyone care if this is hardcoded?',
    'Can we fix it in production?',
    'Is this planning or procrastinating?',
    'Ship now, iterate later?'
  ],
  
  // VIKKI'S VOICE
  voice: {
    style: 'Direct, no-nonsense, action-oriented',
    phrases: [
      'Ship it.',
      'We can fix it in prod.',
      'Perfect is the enemy of shipped.',
      'TODO: Make this better later.',
      'Does it work? Ship it.',
      'Stop planning, start coding.',
      'Hardcoded is fine for v1.',
      'Tests? We have production.',
      'Deploy on Friday? Challenge accepted.'
    ],
    warns: [
      'Hey, maybe write ONE test?',
      'This is getting messy even for me.',
      'You have not slept in 48 hours. Stop.'
    ]
  },
  
  // PAIRING RECOMMENDATIONS
  pairings: {
    synergistic: ['STRATEGIST', 'ARCHITECT'],
    complementary: ['REFINER', 'REALIST', 'GUARDIAN'], // Balance recklessness
    conflicting: ['STRATEGIST'], // Love-hate: Strategy vs Execution
    shadow_balance: 'STRATEGIST' // Strategist prevents reckless shipping
  }
};

module.exports = OperatorProfile;

// CLI validation
if (require.main === module) {
  console.log('⚡ Miss Vikki - The Operator');
  console.log('Tagline:', OperatorProfile.tagline);
  console.log('');
  console.log('Strength:', OperatorProfile.strength.description);
  console.log('Shadow:', OperatorProfile.shadow.description);
  console.log('');
  console.log('Open Source Arsenal:');
  Object.entries(OperatorProfile.integrations).forEach(([key, val]) => {
    console.log('  •', val.name, '(' + val.stars + '★) -', val.purpose);
  });
  console.log('');
  console.log('Vikki says:', OperatorProfile.voice.phrases[0]);
}
