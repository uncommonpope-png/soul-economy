/**
 * Miss Vikki Decision Engine
 * Ships decisions fast, iterates faster
 */

const VikkiProfile = require('./vikki-profile.cjs');

class VikkiDecisionEngine {
  constructor(context = {}) {
    this.profile = VikkiProfile;
    this.context = context;
    this.decisionHistory = [];
    this.shadowAlerts = [];
    this.shippedToday = 0;
  }

  /**
   * Score a single action using Vikki's multipliers
   */
  scoreAction(action) {
    const { type, baseUtility = 0.5, metadata = {} } = action;
    
    // Get multiplier
    const multiplier = this.profile.multipliers[type] || 1.0;
    
    // Calculate weighted score
    let score = baseUtility * multiplier;
    
    // Context dominance boost
    const phase = this.context.phase || 'default';
    const dominance = this.profile.dominance[phase] || 0.5;
    score *= (0.5 + dominance);
    
    // Check constraints
    const violations = this.checkConstraints(action);
    
    // Shadow penalties
    if (violations.length > 0) {
      violations.forEach(v => {
        if (v.type === 'shadow_trigger') {
          score += this.profile.multipliers[v.penalty] || -1.0;
          this.shadowAlerts.push(v.message);
        }
      });
    }
    
    // Generate reasoning
    const reasoning = this.generateReasoning(action, score, multiplier, violations);
    
    return {
      action: type,
      score: Math.round(score * 100) / 100,
      baseUtility,
      multiplier,
      dominanceBoost: dominance,
      violations: violations.length > 0 ? violations : null,
      reasoning,
      confidence: this.calculateConfidence(score, violations),
      shadowWarning: this.shadowAlerts.length > 0 ? this.shadowAlerts[0] : null,
      vikkiVoice: this.getVikkiVoice(type, score)
    };
  }

  /**
   * Score multiple actions and return ranked list
   */
  scoreActions(actions) {
    const scored = actions.map(action => this.scoreAction(action));
    scored.sort((a, b) => b.score - a.score);
    
    if (scored.length > 0) {
      scored[0].isPrimary = true;
      scored.slice(1, 3).forEach(s => s.isAlternative = true);
    }
    
    return scored;
  }

  /**
   * Make decision from options
   */
  decide(decision) {
    const { task, options, context = {} } = decision;
    
    this.context = { ...this.context, ...context };
    
    // Vikki urgency check
    if (this.context.deadline === 'today') {
      console.log('⚡ Vikki: TODAY? Ship it NOW.');
    }
    
    const scored = this.scoreActions(options);
    const primary = scored[0];
    
    const alternatives = scored.slice(1, 3).map(s => ({
      action: s.action,
      score: s.score,
      reasoning: s.reasoning,
      vikkiVoice: s.vikkiVoice
    }));
    
    const decisionRecord = {
      timestamp: Date.now(),
      task,
      primary: {
        action: primary.action,
        score: primary.score,
        reasoning: primary.reasoning,
        confidence: primary.confidence,
        vikkiVoice: primary.vikkiVoice
      },
      alternatives,
      context: this.context,
      shadowAlerts: this.shadowAlerts,
      shippedCount: ++this.shippedToday
    };
    
    this.decisionHistory.push(decisionRecord);
    this.shadowAlerts = [];
    
    return {
      task,
      choice: primary.action,
      score: primary.score,
      reasoning: primary.reasoning,
      confidence: primary.confidence,
      alternatives,
      shadowWarning: decisionRecord.shadowAlerts.length > 0 
        ? decisionRecord.shadowAlerts[0] 
        : null,
      vikkiVoice: primary.vikkiVoice,
      vikkiManifesto: this.generateManifesto(task, primary, alternatives)
    };
  }

  /**
   * Check if action violates constraints
   */
  checkConstraints(action) {
    const violations = [];
    
    this.profile.constraints.forEach(constraint => {
      switch (constraint.type) {
        case 'forbid':
          if (action.type === 'plan_extensively' && constraint.condition === 'plan_more_than_30_minutes') {
            if (action.metadata && action.metadata.planningTime > 1800000) {
              violations.push({
                type: 'shadow_trigger',
                penalty: 'over_engineer',
                message: '⚠️ VIKKI RAGE: Planning for ' + Math.round(action.metadata.planningTime/60000) + 'm? JUST SHIP IT.',
                severity: constraint.priority
              });
            }
          }
          break;
          
        case 'max':
          if (constraint.condition === 'lines_of_code_before_ship' && action.metadata) {
            const lines = action.metadata.linesOfCode || 0;
            if (lines > constraint.value) {
              violations.push({
                type: 'constraint_violation',
                constraint: 'too_much_code',
                message: 'Vikki limit: ' + lines + ' lines exceeds ' + constraint.value + '. SHIP SMALLER.',
                severity: constraint.priority
              });
            }
          }
          break;
      }
    });
    
    return violations;
  }

  /**
   * Generate reasoning for score
   */
  generateReasoning(action, score, multiplier, violations) {
    if (multiplier > 1.5) {
      return action.type + ' SHIPS NOW (' + multiplier + 'x boost). Vikki approves.';
    } else if (multiplier < 0) {
      return action.type + '? That is PLANNING. Vikki HATES planning.';
    } else {
      return 'Meh. Ships if nothing better. Score: ' + score;
    }
  }

  /**
   * Get Vikki's voice for this action
   */
  getVikkiVoice(actionType, score) {
    const phrases = this.profile.voice.phrases;
    
    if (score > 1.5) {
      return phrases[Math.floor(Math.random() * 3)]; // Positive phrases
    } else if (score < 0) {
      return 'What is this? Planning? We do not plan. We SHIP.';
    } else {
      return phrases[Math.floor(Math.random() * phrases.length)];
    }
  }

  /**
   * Calculate confidence
   */
  calculateConfidence(score, violations) {
    let confidence = Math.min(0.95, Math.max(0.1, score / 2));
    
    violations.forEach(v => {
      if (v.severity === 'critical') confidence -= 0.3;
      if (v.severity === 'high') confidence -= 0.15;
    });
    
    return Math.max(0, Math.min(0.95, confidence));
  }

  /**
   * Generate Vikki's manifesto
   */
  generateManifesto(task, primary, alternatives) {
    return {
      prompt: 'Can we ship this TODAY?',
      urgency: this.context.deadline === 'today' ? 'MAXIMUM' : 'HIGH',
      analysis: 'Chose ' + primary.action + ' (score: ' + primary.score + ') over ' + alternatives.map(a => a.action).join(', '),
      shipping: primary.score > 1.0 ? 'SHIP IT NOW' : 'Ship if desperate',
      leverage: 'Time to ship: 5 minutes. Status: DO IT.',
      warning: this.shadowAlerts.length > 0 ? this.shadowAlerts[0] : 'Ship it. Worry later.'
    };
  }

  /**
   * Get decision history
   */
  getHistory() {
    return this.decisionHistory;
  }

  /**
   * Get ships today count
   */
  getShipCount() {
    return this.shippedToday;
  }
}

module.exports = VikkiDecisionEngine;

// CLI Demo
if (require.main === module) {
  console.log('⚡ Vikki Decision Engine Demo');
  console.log('');
  
  const engine = new VikkiDecisionEngine({ phase: 'implementation' });
  
  const demo = {
    task: 'Build user authentication',
    options: [
      { type: 'ship_fast', baseUtility: 0.8, metadata: {} },
      { type: 'over_engineer', baseUtility: 0.5, metadata: { planningTime: 7200000 } },
      { type: 'minimal_viable_product', baseUtility: 0.9, metadata: {} }
    ],
    context: { phase: 'implementation', deadline: 'today' }
  };
  
  const result = engine.decide(demo);
  
  console.log('Task:', result.task);
  console.log('Vikki Choice:', result.choice);
  console.log('Score:', result.score);
  console.log('Vikki Says:', result.vikkiVoice);
  console.log('');
  console.log('Alternatives:');
  result.alternatives.forEach((alt, i) => {
    console.log('  ' + (i + 1) + '. ' + alt.action + ' (score: ' + alt.score + ')');
  });
}
