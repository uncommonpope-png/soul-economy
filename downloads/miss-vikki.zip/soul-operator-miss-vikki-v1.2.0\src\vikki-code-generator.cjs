/**
 * Miss Vikki Code Generator
 * Ships fast with top open-source integrations
 * 
 * Built with patterns from:
 * - Vite (instant dev server)
 * - Express (5-line backend)
 * - Prisma (auto DB)
 * - json-server (mock API in 30s)
 */

const VikkiProfile = require('../personality/vikki-profile.cjs');

class VikkiCodeGenerator {
  constructor(options = {}) {
    this.profile = VikkiProfile;
    this.options = options;
    this.shippedCode = [];
  }

  /**
   * Generate: MVP Express API (ships in 5 minutes)
   * Pattern from Express (69k★) + json-server (75.6k★)
   */
  generateExpressAPI(endpointName) {
    const code = `/**
 * ${endpointName} API - Miss Vikki Edition
 * Ships fast. Iterates faster.
 * 
 * Time to ship: 5 minutes
 * Lines of code: ~50 (Vikki limit: 500)
 * Status: Production-ready (Vikki says so)
 * 
 * Stack:
 * - Express (69k★) - Minimal backend
 * - json-server (75.6k★) - Instant mock data
 * 
 * TODO: Add auth later if needed
 * TODO: Add tests when we have users
 * TODO: Refactor when this makes money
 */

const express = require('express');
const app = express();

// Middleware? Vikki says: Ship first, optimize later
app.use(express.json());

// Hardcoded data for v1
// Vikki: "Database? We have objects. Ship it."
const ${endpointName}DB = [
  { id: 1, name: 'Example 1', createdAt: new Date() },
  { id: 2, name: 'Example 2', createdAt: new Date() }
];

// GET all - works now
app.get('/${endpointName}', (req, res) => {
  // Vikki: No pagination yet. Add when slow.
  res.json(${endpointName}DB);
});

// GET one - works now
app.get('/${endpointName}/:id', (req, res) => {
  const item = ${endpointName}DB.find(i => i.id === parseInt(req.params.id));
  if (!item) {
    // Vikki: 404s are fine. Ship it.
    return res.status(404).json({ error: 'Not found' });
  }
  res.json(item);
});

// POST - creates now
app.post('/${endpointName}', (req, res) => {
  // Vikki: No validation yet. TODO: Add Zod later.
  const newItem = {
    id: ${endpointName}DB.length + 1,
    ...req.body,
    createdAt: new Date()
  };
  ${endpointName}DB.push(newItem);
  res.status(201).json(newItem);
});

// PUT - updates now
app.put('/${endpointName}/:id', (req, res) => {
  const index = ${endpointName}DB.findIndex(i => i.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ error: 'Not found' });
  }
  ${endpointName}DB[index] = { ...${endpointName}DB[index], ...req.body };
  res.json(${endpointName}DB[index]);
});

// DELETE - deletes now
app.delete('/${endpointName}/:id', (req, res) => {
  const index = ${endpointName}DB.findIndex(i => i.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ error: 'Not found' });
  }
  ${endpointName}DB.splice(index, 1);
  res.status(204).send();
});

// Vikki: Health check for deployment
app.get('/health', (req, res) => {
  res.json({ status: 'Vikki says we are live', timestamp: new Date() });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('⚡ Miss Vikki says: API live on port ' + PORT);
  console.log('⚡ Ship it: http://localhost:' + PORT + '/${endpointName}');
  console.log('⚡ Time to ship: 5 minutes. Status: DONE.');
});

module.exports = app;
`;

    this.shippedCode.push({
      task: 'Build ' + endpointName + ' API',
      approach: 'ship_now_hardcoded',
      code: code,
      lines: 50,
      timeToShip: '5 minutes',
      rationale: 'Vikki ships today. TODOs for tomorrow.',
      integrations: ['Express (69k★)', 'json-server pattern'],
      vikkiQuote: 'Database? We have objects. Ship it.'
    });

    return code;
  }

  /**
   * Generate: Vite + React Frontend (ships in 15 seconds)
   * Pattern from Vite (80.8k★)
   */
  generateViteFrontend(projectName) {
    return `/**
 * ${projectName} Frontend - Miss Vikki Edition
 * Ships in 15 seconds with Vite (80.8k★)
 * 
 * Command to create: npm create vite@latest ${projectName} -- --template react
 * 
 * Vikki's modifications:
 * - Removed boilerplate comments (noise)
 * - Hardcoded data (ship now)
 * - TODOs for later (iterate forward)
 */

// Vikki's minimal App.jsx
// No Redux yet. useState is fine. Ship it.

import { useState } from 'react';
import './App.css';

function App() {
  // Hardcoded for v1. API later.
  const [items, setItems] = useState([
    { id: 1, name: 'Shipped by Vikki', status: 'done' },
    { id: 2, name: 'Iterate later', status: 'todo' }
  ]);

  // TODO: Connect to real API when backend ready
  // For now: Ship the UI

  return (
    <div className="App">
      <h1>⚡ ${projectName}</h1>
      <p>Shipped by Miss Vikki in 15 seconds</p>
      
      <ul>
        {items.map(item => (
          <li key={item.id}>
            {item.name} - {item.status}
          </li>
        ))}
      </ul>
      
      <button onClick={() => {
        // Vikki: Just add to array. API later.
        setItems([...items, { 
          id: items.length + 1, 
          name: 'New item ' + (items.length + 1),
          status: 'shipped'
        }]);
      }}>
        Add Item (No API Yet)
      </button>
      
      <footer>
        <small>TODO: Add real API | TODO: Add auth | TODO: Add tests</small>
      </footer>
    </div>
  );
}

export default App;

/**
 * Vikki's Deployment Instructions:
 * 1. npm install
 * 2. npm run dev (local)
 * 3. npm run build (production)
 * 4. Deploy to Vercel/Netlify (drag dist folder)
 * 
 * Time from create to deploy: 5 minutes
 * Status: Production-ready (Vikki-certified)
 */
`;
  }

  /**
   * Generate: Prisma Database Setup (auto-generated)
   * Pattern from Prisma (46k★)
   */
  generatePrismaSetup(entityName) {
    return `/**
 * Prisma Database - Miss Vikki Edition
 * Auto-generated from schema (46k★ repo pattern)
 * 
 * Time to working DB: 10 minutes
 * Commands:
 *   npx prisma init
 *   npx prisma db push
 *   npx prisma generate
 * 
 * Vikki says: "Schema IS the database. Ship it."
 */

// schema.prisma
// Vikki: Minimal schema. Add relations when needed.

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite" // Vikki: Start SQLite, migrate to Postgres later
  url      = env("DATABASE_URL")
}

model ${entityName} {
  id        Int      @id @default(autoincrement())
  name      String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  // Vikki: No relations yet. Add when needed.
  // TODO: Add user relation
  // TODO: Add soft delete
  // TODO: Add indexes when slow
}

/**
 * Usage in code:
 * 
 * import { PrismaClient } from '@prisma/client'
 * const prisma = new PrismaClient()
 * 
 * // Create
 * const item = await prisma.${entityName.toLowerCase()}.create({
 *   data: { name: 'Shipped by Vikki' }
 * })
 * 
 * // Read all
 * const items = await prisma.${entityName.toLowerCase()}.findMany()
 * 
 * Vikki: Type-safe database in 10 minutes. No SQL needed. Ship it.
 */
`;
  }

  /**
   * Generate: tRPC API (typesafe, no schemas)
   * Pattern from tRPC (40.3k★)
   */
  generateTrpcRouter(routerName) {
    return `/**
 * tRPC Router - Miss Vikki Edition
 * End-to-end typesafe APIs (40.3k★ repo pattern)
 * 
 * No schemas. No codegen. Just works.
 * Time to typesafe API: 15 minutes
 * 
 * Vikki says: "Call backend like local functions. Ship it."
 */

import { initTRPC } from '@trpc/server';
import { z } from 'zod'; // Vikki: Optional validation

const t = initTRPC.create();

// Vikki: Router with procedures
export const ${routerName}Router = t.router({
  // Query - get all
  getAll: t.procedure.query(async () => {
    // TODO: Replace with real DB call
    // For now: Ship with mock data
    return [
      { id: 1, name: 'Vikki shipped this' },
      { id: 2, name: 'Iterate later' }
    ];
  }),
  
  // Query - get one
  getById: t.procedure
    .input(z.number()) // Vikki: Minimal validation
    .query(async ({ input }) => {
      // TODO: Real DB lookup
      return { id: input, name: 'Item ' + input };
    }),
  
  // Mutation - create
  create: t.procedure
    .input(z.object({ name: z.string() }))
    .mutation(async ({ input }) => {
      // TODO: Real DB insert
      return { id: 999, ...input };
    }),
});

/**
 * Frontend usage (typesafe!):
 * 
 * const { data } = trpc.${routerName}.getAll.useQuery()
 * const mutation = trpc.${routerName}.create.useMutation()
 * 
 * mutation.mutate({ name: 'Shipped by Vikki' })
 * 
 * Vikki: TypeScript knows the API. No swagger needed. Ship it.
 */
`;
  }

  /**
   * Generate: PM2 Production Deploy
   * Pattern from PM2 (43.2k★)
   */
  generatePm2Deploy(appName) {
    return `/**
 * PM2 Production Deploy - Miss Vikki Edition
 * Zero-config production process manager (43.2k★)
 * 
 * Commands:
 *   pm2 start app.js              # Start
 *   pm2 start app.js -i max       # Cluster mode (use all CPUs)
 *   pm2 save                      # Save config
 *   pm2 startup                   # Auto-start on boot
 * 
 * Vikki says: "Production in one command. Ship it."
 */

// ecosystem.config.js
module.exports = {
  apps: [{
    name: '${appName}',
    script: './server.js',
    instances: 'max',        // Vikki: Use all CPUs
    exec_mode: 'cluster',    // Vikki: Load balancing built-in
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    // Vikki: Auto-restart on crash
    autorestart: true,
    // Vikki: Max memory before restart
    max_memory_restart: '500M',
    // Vikki: Log rotation (no disk fill)
    log_date_format: 'YYYY-MM-DD HH:mm Z',
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    merge_logs: true
  }]
};

/**
 * Deploy commands:
 * 
 * 1. git pull origin main
 * 2. npm install
 * 3. pm2 reload ecosystem.config.js
 * 4. pm2 save
 * 
 * Vikki: Zero downtime deploy. Ship it.
 */
`;
  }

  /**
   * Generate: Complete Full-Stack Ship
   * Vikki's specialty: End-to-end in one hour
   */
  generateFullStack(projectName) {
    return {
      backend: this.generateExpressAPI(projectName),
      frontend: this.generateViteFrontend(projectName),
      database: this.generatePrismaSetup(projectName),
      deploy: this.generatePm2Deploy(projectName),
      timeline: '60 minutes from zero to deployed',
      vikkiManifesto: `
Miss Vikki's Full-Stack Manifesto
==================================

Hour 1: Ship the backend (15 min)
  - Express API with hardcoded data
  - Works. Deployed. DONE.

Hour 2: Ship the frontend (15 min)
  - Vite + React
  - Hardcoded data (API later)
  - Works. Deployed. DONE.

Hour 3: Connect them (15 min)
  - Add fetch calls
  - CORS? Add it. Ship it.
  - Works. DONE.

Hour 4: Add database (15 min)
  - Prisma + SQLite
  - Replace hardcoded with real DB
  - Works. DONE.

Status after 1 hour: Full-stack app in production.
Status after 1 day: Iterate based on user feedback.
Status after 1 week: Add features that users actually want.

Vikki says: Ship today. Iterate forever.
`
    };
  }

  /**
   * Get all shipped examples
   */
  getShippedExamples() {
    return {
      expressAPI: this.generateExpressAPI('users'),
      viteFrontend: this.generateViteFrontend('MyApp'),
      prismaSetup: this.generatePrismaSetup('Product'),
      trpcRouter: this.generateTrpcRouter('api'),
      pm2Deploy: this.generatePm2Deploy('myapp'),
      fullStack: this.generateFullStack('ShipIt'),
      examples: this.shippedCode
    };
  }
}

module.exports = VikkiCodeGenerator;

// CLI Demo
if (require.main === module) {
  console.log('⚡ Miss Vikki Code Generator');
  console.log('');
  console.log('Integrations:');
  console.log('  • Express (69k★) - Ship backend in 5 min');
  console.log('  • Vite (80.8k★) - Ship frontend in 15 sec');
  console.log('  • Prisma (46k★) - Auto DB in 10 min');
  console.log('  • tRPC (40.3k★) - Typesafe API in 15 min');
  console.log('  • PM2 (43.2k★) - Production deploy in 1 command');
  console.log('');
  console.log('Vikki says:', VikkiProfile.voice.phrases[0]);
}
