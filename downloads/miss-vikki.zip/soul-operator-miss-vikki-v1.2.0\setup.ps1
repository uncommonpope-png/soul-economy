Write-Host "⚡ Miss Vikki Setup - Execution Without Apology" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
Write-Host "Checking Node.js..." -ForegroundColor Yellow
$nodeVersion = node -v 2>$null
if (-not $nodeVersion) {
    Write-Host "❌ Node.js not found. Install from https://nodejs.org" -ForegroundColor Red
    exit 1
}

$majorVersion = [int]($nodeVersion -replace 'v' -split '\.')[0]
if ($majorVersion -lt 14) {
    Write-Host "❌ Node.js too old. Need 14+, found $nodeVersion" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Node.js $nodeVersion detected" -ForegroundColor Green
Write-Host ""

# Check directory
if (-not (Test-Path "package.json")) {
    Write-Host "❌ package.json not found" -ForegroundColor Red
    exit 1
}

# Install
Write-Host "Installing dependencies..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ npm install failed" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Dependencies installed" -ForegroundColor Green
Write-Host ""

# Create .env
if (-not (Test-Path ".env")) {
    Write-Host "Creating .env..." -ForegroundColor Yellow
    @"
# Miss Vikki Configuration
VIKKI_PROFIT=0.75
VIKKI_LOVE=0.45
VIKKI_TAX=0.30
VIKKI_MAX_PLANNING_MINUTES=30
VIKKI_SHIP_WITHIN_HOURS=4
"@ | Out-File -FilePath ".env" -Encoding UTF8
    Write-Host "✅ Created .env" -ForegroundColor Green
    Write-Host ""
}

# Create activation script
Write-Host "Creating activation script..." -ForegroundColor Yellow
$activate = @'
Write-Host "⚡ Activating Miss Vikki..." -ForegroundColor Cyan
node -e "
const Vikki = require('./soul-operator-miss-vikki.cjs');
const vikki = new Vikki();

console.log('');
console.log('╔════════════════════════════════════════════════╗');
console.log('║  MISS VIKKI v1.0.0 ACTIVATED                  ║');
console.log('╠════════════════════════════════════════════════╣');
console.log('║  Archetype: The Operator                      ║');
console.log('║  Focus: PROFIT (Execution)                    ║');
console.log('║  Tagline: Execution Without Apology           ║');
console.log('╚════════════════════════════════════════════════╝');
console.log('');
console.log('Vikki is ready to:');
console.log('  • Ship Express API in 5 minutes');
console.log('  • Ship Vite frontend in 15 seconds');
console.log('  • Ship full-stack in 1 hour');
console.log('  • Deploy with PM2 in 1 command');
console.log('');
console.log('Vikki says: Ship it. Worry later.');
"
'@
$activate | Out-File -FilePath "activate-vikki.ps1" -Encoding UTF8
Write-Host "✅ Created activate-vikki.ps1" -ForegroundColor Green
Write-Host ""

# Final message
Write-Host "════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "✅ MISS VIKKI SETUP COMPLETE" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "Activate Vikki:" -ForegroundColor White
Write-Host "  .\activate-vikki.ps1" -ForegroundColor Yellow
Write-Host ""
Write-Host "Or use directly:" -ForegroundColor White
Write-Host "  node soul-operator-miss-vikki.cjs" -ForegroundColor Yellow
Write-Host ""
Write-Host "⚡ Ship it." -ForegroundColor Cyan
