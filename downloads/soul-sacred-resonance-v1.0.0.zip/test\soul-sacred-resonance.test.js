const http = require('http');
const soul = require('../lib/soul-sacred-resonance');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has resonance', st.body && typeof st.body.resonance === 'number');

  // 7. POST /resonate
  const res = await req('POST', '/resonate', { experience: 'sunrise over mountains' }, { 'x-api-key': soul.API_KEY });
  test('POST /resonate returns 200', res.status === 200);
  test('/resonate has resonance_level', res.body && typeof res.body.resonance_level === 'number');

  // 8. POST /resonate without experience
  const bad = await req('POST', '/resonate', {}, { 'x-api-key': soul.API_KEY });
  test('POST /resonate missing experience returns 400', bad.status === 400);

  // 9. POST /awe
  const awe = await req('POST', '/awe', { encounter: 'starry night sky' }, { 'x-api-key': soul.API_KEY });
  test('POST /awe returns 200', awe.status === 200);
  test('/awe has awe_intensity', awe.body && typeof awe.body.awe_intensity === 'number');

  // 10. POST /awe without encounter
  const aweBad = await req('POST', '/awe', {}, { 'x-api-key': soul.API_KEY });
  test('POST /awe missing encounter returns 400', aweBad.status === 400);

  // 11. GET /sacred
  const sac = await req('GET', '/sacred', null, { 'x-api-key': soul.API_KEY });
  test('GET /sacred returns 200', sac.status === 200);
  test('/sacred has resonance', sac.body && typeof sac.body.resonance === 'number');
  test('/sacred has sacred_values', sac.body && Array.isArray(sac.body.sacred_values));

  // 12. resonate function directly
  const r2 = soul.resonate('ocean waves');
  test('resonate function works', r2 && r2.experience === 'ocean waves');
  test('resonate returns harmonic_pattern', r2 && r2.harmonic_pattern);

  // 13. feelAwe function directly
  const a2 = soul.feelAwe('grand canyon');
  test('feelAwe function works', a2 && a2.encounter === 'grand canyon');

  // 14. connect function directly
  const c2 = soul.connect('the cosmos');
  test('connect function works', c2 && c2.greater_whole === 'the cosmos');
  test('connect returns unity_experience', c2 && c2.unity_experience === true);

  // 15. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
