const http = require('http');
const soul = require('../lib/soul-personality');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has big_five', st.body && st.body.big_five);

  // 7. POST /assess
  const ass = await req('POST', '/assess', null, { 'x-api-key': soul.API_KEY });
  test('POST /assess returns 200', ass.status === 200);
  test('/assess has big_five', ass.body && ass.body.big_five);
  test('/assess has summary', ass.body && ass.body.summary);

  // 8. POST /adapt - crisis
  const ad = await req('POST', '/adapt', { situation: 'crisis management needed' }, { 'x-api-key': soul.API_KEY });
  test('POST /adapt returns 200', ad.status === 200);
  test('/adapt for crisis returns decisive_assertive', ad.body && ad.body.adjusted_expression === 'decisive_assertive');

  // 9. POST /adapt - social
  const ad2 = await req('POST', '/adapt', { situation: 'social party gathering' }, { 'x-api-key': soul.API_KEY });
  test('POST /adapt for social returns warm_engaging', ad2.status === 200 && ad2.body.adjusted_expression === 'warm_engaging');

  // 10. POST /adapt without situation
  const bad = await req('POST', '/adapt', {}, { 'x-api-key': soul.API_KEY });
  test('POST /adapt missing situation returns 400', bad.status === 400);

  // 11. POST /express
  const exp = await req('POST', '/express', null, { 'x-api-key': soul.API_KEY });
  test('POST /express returns 200', exp.status === 200);
  test('/express has tone', exp.body && exp.body.tone);

  // 12. GET /personality
  const pers = await req('GET', '/personality', null, { 'x-api-key': soul.API_KEY });
  test('GET /personality returns 200', pers.status === 200);
  test('/personality has mbti', pers.body && pers.body.mbti);
  test('/personality has enneagram', pers.body && typeof pers.body.enneagram === 'number');

  // 13. assess function
  const a2 = soul.assess();
  test('assess function returns profile', a2 && a2.summary);
  test('assess function has dominant_trait', a2 && a2.dominant_trait);

  // 14. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
