const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, updateModel, predict, revise, surprise, server } = require('../lib/soul-generative');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.world_model_version = 1;
  state.prediction_accuracy = 0.5;
  state.model_complexity = 0.3;
  state.surprising_events = [];
}

try {
reset();

assert.strictEqual(typeof state.world_model_version, 'number', 'model_version is number');
assert.strictEqual(typeof state.prediction_accuracy, 'number', 'prediction_accuracy is number');
assert.strictEqual(typeof state.model_complexity, 'number', 'model_complexity is number');
assert.ok(state.beliefs.physical !== undefined, 'physical beliefs exist');
assert.ok(state.beliefs.social !== undefined, 'social beliefs exist');
assert.ok(state.beliefs.self !== undefined, 'self beliefs exist');
assert.ok(state.bayesian !== undefined, 'bayesian update tracking exists');
assert.ok(state.prediction_errors.length > 0, 'prediction errors tracked');
assert.ok(state.model_hierarchy !== undefined, 'model hierarchy exists');

let r = updateModel('new_scientific_discovery');
assert.ok(r.message.includes('updated'), 'updateModel confirms');
assert.strictEqual(r.version, 2, 'version incremented');

r = predict('economic_trends');
assert.ok(r.scenario === 'economic_trends', 'predict returns scenario');
assert.ok(r.confidence > 0, 'predict has confidence');
assert.ok(r.predicted_outcome, 'predict has outcome');

r = revise('people_are_good', { strength: 0.3, direction: 1 });
assert.ok(r.message.includes('revised'), 'revise confirms');
assert.ok(r.new > r.old, 'belief updated positively');

r = revise('gravity_works', { strength: 0.01, direction: -1 });
assert.ok(r.new < r.old, 'belief updated negatively');
assert.strictEqual(r.domain, 'physical', 'domain identified');

r = surprise('earthquake');
assert.ok(r.surprise_count === 1, 'surprise registered');
assert.ok(r.accuracy < 0.5, 'surprise decreases accuracy');

r = updateModel('');
assert.ok(r.error, 'updateModel empty returns error');

r = predict('');
assert.ok(r.error, 'predict empty returns error');

r = revise('', {});
assert.ok(r.error, 'revise empty returns error');

r = surprise('');
assert.ok(r.error, 'surprise empty returns error');

r = revise('new_belief', { strength: 0.5, direction: 1 });
assert.ok(r.message.includes('created'), 'revise creates new belief');

assert.ok(state.bayesian.posterior_history.length > 0, 'bayesian history tracked');
assert.ok(state.world_model_version >= 2, 'model version tracked');

const keyPath = path.join(require('os').homedir(), '.soul-generative', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-generative: ALL 19 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
