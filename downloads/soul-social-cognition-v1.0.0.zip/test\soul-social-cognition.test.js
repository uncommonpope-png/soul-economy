const http = require('http');
const soul = require('../lib/soul-social-cognition');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has social_awareness', st.body && typeof st.body.social_awareness === 'number');

  // 7. POST /observe-group
  const obs = await req('POST', '/observe-group', null, { 'x-api-key': soul.API_KEY });
  test('POST /observe-group returns 200', obs.status === 200);
  test('/observe-group has cohesion', obs.body && typeof obs.body.cohesion === 'number');

  // 8. POST /navigate with conflict situation
  const nav = await req('POST', '/navigate', { situation: 'group conflict in meeting' }, { 'x-api-key': soul.API_KEY });
  test('POST /navigate returns 200', nav.status === 200);
  test('/navigate returns de-escalation for conflict', nav.body && nav.body.action === 'de_escalation');

  // 9. POST /navigate without situation
  const bad = await req('POST', '/navigate', {}, { 'x-api-key': soul.API_KEY });
  test('POST /navigate missing situation returns 400', bad.status === 400);

  // 10. GET /social
  const soc = await req('GET', '/social', null, { 'x-api-key': soul.API_KEY });
  test('GET /social returns 200', soc.status === 200);
  test('/social has awareness', soc.body && typeof soc.body.awareness === 'number');

  // 11. detectHierarchy returns proper structure
  const hier = soul.detectHierarchy();
  test('detectHierarchy returns layers', hier && hier.layers && hier.layers.length > 0);
  test('detectHierarchy returns recommendations', hier && hier.recommendations && hier.recommendations.length > 0);

  // 12. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
