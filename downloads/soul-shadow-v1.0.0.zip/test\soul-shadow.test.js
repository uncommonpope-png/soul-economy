const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, confront, integrate, shadowWork, project, server } = require('../lib/soul-shadow');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.denied_traits = ['aggression', 'jealousy', 'grandiosity'];
  state.integrated_traits = [];
  state.integration_level = 0.1;
  state.active_complex = null;
  state.shadow_encounters = [];
}

try {
reset();

assert.strictEqual(Array.isArray(state.denied_traits), true, 'denied_traits is array');
assert.strictEqual(Array.isArray(state.integrated_traits), true, 'integrated_traits is array');
assert.strictEqual(typeof state.integration_level, 'number', 'integration_level is number');
assert.ok(state.shadow_archetypes.shadow !== undefined, 'shadow archetype exists');
assert.ok(state.shadow_archetypes.persona !== undefined, 'persona archetype exists');
assert.ok(state.shadow_archetypes.anima !== undefined, 'anima archetype exists');
assert.ok(state.shadow_archetypes.animus !== undefined, 'animus archetype exists');
assert.ok(state.gold_shadow.hidden_strengths.length > 0, 'gold shadow strengths exist');
assert.ok(state.complexes.length > 0, 'complexes exist');

let r = confront('fear');
assert.ok(r.message.includes('fear'), 'confront includes trait');
assert.ok(r.integration_level > 0.1, 'confront increases integration');
assert.ok(state.denied_traits.includes('fear'), 'confront adds trait');

r = integrate('fear');
assert.ok(r.message.includes('fear'), 'integrate includes trait');
assert.ok(state.integrated_traits.includes('fear'), 'trait moved to integrated');
assert.ok(!state.denied_traits.includes('fear'), 'trait removed from denied');

reset();
r = integrate('nonexistent');
assert.ok(r.error, 'integrate nonexistent returns error');

r = shadowWork();
assert.ok(r.integration_level > 0.1, 'shadowWork increases integration');
assert.ok(r.gold_visibility > 0, 'shadowWork reveals gold shadow');

r = project('adversary');
assert.ok(r.projected_trait, 'project identifies trait');
assert.ok(r.message.includes('adversary'), 'project mentions entity');

assert.ok(state.shadow_encounters.length > 0, 'encounters tracked');

const keyPath = path.join(require('os').homedir(), '.soul-shadow', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-shadow: ALL 16 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
