#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-play-test');
console.log('\n Play Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const PlaySoul=require('../lib/soul-play.js');
t('Loads with key',()=>{const i=new PlaySoul({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Auth check works',()=>{const i=new PlaySoul({dataDir:TD,apiKey:'testkey'});assert(i.checkAuth({headers:{'x-api-key':'testkey'}}));assert(!i.checkAuth({headers:{'x-api-key':'wrong'}}));});
t('Key persists',()=>{const i=new PlaySoul({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Start game begins play',()=>{const i=new PlaySoul({dataDir:TD});const r=i.startGame("strategy");assert(r.game==="strategy");assert(r.started);});
t('Start game with bad type returns error',()=>{const i=new PlaySoul({dataDir:TD});const r=i.startGame("invalid");assert(r.error);});
t('Play move without game returns error',()=>{const i=new PlaySoul({dataDir:TD});const r=i.playMove("rock");assert(r.error);});
t('Play move works with active game',()=>{const i=new PlaySoul({dataDir:TD});i.startGame("strategy");const r=i.playMove("rock");assert(r.move==="rock");assert(typeof r.won==="boolean");});
t('Laugh increases joy',()=>{const i=new PlaySoul({dataDir:TD});const b=i.joy;i.laugh();assert(i.joy>b);});
t('Wins and losses track',()=>{const i=new PlaySoul({dataDir:TD});i.startGame("strategy");for(let x=0;x<10;x++)i.playMove("rock");assert(i.wins>0||i.losses>0);});
t('Play state returns all fields',()=>{const i=new PlaySoul({dataDir:TD});i.startGame("word");const r=i.getPlayState();assert(typeof r.playfulness==="number");assert(r.available_games);});
t('Play history tracks actions',()=>{const i=new PlaySoul({dataDir:TD});i.startGame("word");i.playMove("rhyme");i.laugh();assert(i.play_history.length>=3);});
t('GetStats returns ok',()=>{const i=new PlaySoul({dataDir:TD});const s=i.getStats();assert(s.name);assert(typeof s.playfulness==="number");});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);