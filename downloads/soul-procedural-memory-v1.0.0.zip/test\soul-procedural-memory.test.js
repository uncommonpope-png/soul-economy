#!/usr/bin/env node
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const TEST_BASE = path.join(os.homedir(), '.soul-procedural-memory-test');
console.log('\n\u{1F9E0} Procedural Memory Soul v1.0.0 \u2014 Test Suite\n');
let passed = 0, failed = 0;
function test(name, fn) { try { fn(); console.log('  \u2713 ' + name); passed++; } catch (e) { console.log('  \u2717 ' + name + ': ' + e.message); failed++; } }
const P = require('../lib/soul-procedural-memory.js');
let testDirCounter = 0;
function freshSoul() {
    const dir = TEST_BASE + '\\test_' + (++testDirCounter);
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    return new P({ dataDir: dir });
}

test('Soul loads with API key', () => {
    const p = freshSoul();
    assert(p.apiKey, 'Should generate API key');
    assert(p.apiKey.length > 10, 'Key long enough');
});

test('Initial arrays are empty', () => {
    const p = freshSoul();
    assert(Array.isArray(p.mistakes), 'mistakes is array');
    assert(Array.isArray(p.policies), 'policies is array');
    assert(Array.isArray(p.behavior_log), 'behavior_log is array');
    assert(p.mistakes.length === 0, 'no mistakes initially');
    assert(p.policies.length === 0, 'no policies initially');
    assert(p.prevention_count === 0, 'prevention count zero');
});

test('recordMistake stores a mistake', () => {
    const p = freshSoul();
    const m = p.recordMistake({ action: 'chmod_777', context: 'permissions_fix', consequence: 'security_hole', severity: 'high', fix: 'use chmod 755' });
    assert(m.id.startsWith('mistake_'), 'Has mistake id');
    assert(m.action === 'chmod_777', 'Action preserved');
    assert(m.context === 'permissions_fix', 'Context preserved');
    assert(m.severity === 'high', 'Severity preserved');
    assert(m.occurrences === 1, 'First occurrence');
    assert(p.mistakes.length === 1, 'Stored in array');
});

test('recordMistake requires action and context', () => {
    const p = freshSoul();
    assert.throws(() => p.recordMistake({}), /action and context are required/);
    assert.throws(() => p.recordMistake({ action: 'test' }), /action and context are required/);
});

test('Repeated mistake increments occurrences', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'rm_rf', context: 'cleanup', consequence: 'data_loss', severity: 'critical', fix: 'use trash instead' });
    const m2 = p.recordMistake({ action: 'rm_rf', context: 'cleanup', consequence: 'data_loss', severity: 'critical' });
    assert(m2.occurrences === 2, 'Second occurrence');
});

test('Mistake repeated 3+ times generates a policy', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'sudo_all', context: 'package_install', consequence: 'security_risk', severity: 'high', fix: 'avoid sudo' });
    p.recordMistake({ action: 'sudo_all', context: 'package_install', consequence: 'security_risk', severity: 'high' });
    p.recordMistake({ action: 'sudo_all', context: 'package_install', consequence: 'security_risk', severity: 'high' });
    assert(p.policies.length >= 1, 'Policy created after 3 occurrences');
    const pol = p.policies[0];
    assert(pol.trigger === 'package_install', 'Policy has trigger');
    assert(pol.forbidden_action === 'sudo_all', 'Policy has forbidden action');
    assert(pol.confidence > 0, 'Policy has confidence');
});

test('checkAction returns allowed when no policy matches', () => {
    const p = freshSoul();
    const result = p.checkAction('git_push', 'deploy');
    assert(result.allowed === true, 'Action allowed');
    assert(result.policy === null, 'No policy matched');
});

test('checkAction blocks when policy matches with high confidence', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'chmod_777', context: 'permissions', consequence: 'security_hole', severity: 'high', fix: 'use chmod 755' });
    p.recordMistake({ action: 'chmod_777', context: 'permissions', consequence: 'security_hole', severity: 'high' });
    p.recordMistake({ action: 'chmod_777', context: 'permissions', consequence: 'security_hole', severity: 'high' });
    p.recordMistake({ action: 'chmod_777', context: 'permissions', consequence: 'security_hole', severity: 'high' });
    p.recordMistake({ action: 'chmod_777', context: 'permissions', consequence: 'security_hole', severity: 'high' });
    const result = p.checkAction('chmod_777', 'permissions');
    assert(result.allowed === false, 'Action blocked');
    assert(result.policy !== null, 'Policy returned');
    assert(result.suggestion !== null, 'Suggestion provided');
});

test('applyFix returns fix for matching policy', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'root_login', context: 'ssh_access', consequence: 'security_risk', severity: 'high', fix: 'use key-based auth' });
    p.recordMistake({ action: 'root_login', context: 'ssh_access', consequence: 'security_risk', severity: 'high' });
    p.recordMistake({ action: 'root_login', context: 'ssh_access', consequence: 'security_risk', severity: 'high' });
    const result = p.applyFix('root_login', 'ssh_access');
    assert(result.found === true, 'Fix found');
    assert(result.fix === 'use key-based auth', 'Correct fix');
    assert(result.confidence > 0, 'Has confidence');
});

test('applyFix returns not found when no match', () => {
    const p = freshSoul();
    const result = p.applyFix('nonexistent', 'unknown');
    assert(result.found === false, 'No fix found');
});

test('generatePolicies creates policies from repeated mistakes', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'drop_db', context: 'migration', consequence: 'data_loss', severity: 'critical', fix: 'backup first' });
    p.recordMistake({ action: 'drop_db', context: 'migration', consequence: 'data_loss', severity: 'critical' });
    p.recordMistake({ action: 'drop_db', context: 'migration', consequence: 'data_loss', severity: 'critical' });
    const result = p.generatePolicies();
    assert(result.total > 0, 'Has policies');
    assert(typeof result.created === 'number', 'Created count');
});

test('reviewBehavior returns stats', () => {
    const p = freshSoul();
    const stats = p.reviewBehavior();
    assert(stats.total_actions === 0, 'No actions yet');
    assert(stats.active_policies === 0, 'No policies');
    assert(typeof stats.prevention_rate === 'string', 'Has prevention rate');
});

test('Prevention count increments', () => {
    const p = freshSoul();
    p.recordMistake({ action: 'rm_rf_slash', context: 'cleanup', consequence: 'catastrophic', severity: 'critical', fix: 'dont do this' });
    p.recordMistake({ action: 'rm_rf_slash', context: 'cleanup', consequence: 'catastrophic', severity: 'critical' });
    p.recordMistake({ action: 'rm_rf_slash', context: 'cleanup', consequence: 'catastrophic', severity: 'critical' });
    p.recordMistake({ action: 'rm_rf_slash', context: 'cleanup', consequence: 'catastrophic', severity: 'critical' });
    p.recordMistake({ action: 'rm_rf_slash', context: 'cleanup', consequence: 'catastrophic', severity: 'critical' });
    const countBefore = p.prevention_count;
    p.checkAction('rm_rf_slash', 'cleanup');
    assert(p.prevention_count > countBefore, 'Prevention count increased');
});

test('getStats returns correct structure', () => {
    const p = freshSoul();
    const stats = p.getStats();
    assert(stats.name === 'Procedural Memory Soul', 'Has name');
    assert(stats.version === '1.0.0', 'Has version');
    assert(typeof stats.mistakes_recorded === 'number', 'Has mistake count');
    assert(typeof stats.policies_active === 'number', 'Has policy count');
    assert(typeof stats.prevention_count === 'number', 'Has prevention count');
});

test('Auth check works', () => {
    const p = freshSoul();
    p.apiKey = 'test-key';
    assert(p.checkAuth({ headers: { 'x-api-key': 'test-key' } }) === true, 'Valid key passes');
    assert(p.checkAuth({ headers: { 'x-api-key': 'wrong' } }) === false, 'Wrong key fails');
    assert(p.checkAuth({ headers: { 'x-procedural-key': 'test-key' } }) === true, 'Alternate header works');
});

test('Key persists to disk', () => {
    const p = freshSoul();
    assert(fs.existsSync(p.keyPath), 'Key file exists');
    const stored = fs.readFileSync(p.keyPath, 'utf8').trim();
    assert(stored === p.apiKey, 'Stored key matches');
});

test('Max mistakes limit enforced', () => {
    const p = freshSoul();
    for (let i = 0; i < 1005; i++) {
        p.recordMistake({ action: 'action_' + i, context: 'test_' + i, consequence: 'none', severity: 'low' });
    }
    assert(p.mistakes.length <= 1000, 'Max 1000 mistakes');
});

test('State persists between instances', () => {
    const dir = TEST_BASE + '\\persist_test';
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    const p1 = new P({ dataDir: dir });
    p1.recordMistake({ action: 'test_persist', context: 'persistence_test', consequence: 'none', severity: 'low' });
    const p2 = new P({ dataDir: dir });
    assert(p2.mistakes.length >= 1, 'Mistakes loaded from disk');
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
});

test('Behavior log tracks allowed actions', () => {
    const p = freshSoul();
    p.checkAction('normal_action', 'normal_context');
    assert(p.behavior_log.length > 0, 'Action logged');
    const last = p.behavior_log[p.behavior_log.length - 1];
    assert(last.action === 'normal_action', 'Action name logged');
    assert(['allowed', 'flagged', 'prevented'].includes(last.outcome), 'Outcome tracked');
});

test('recordMistake with minimal fields uses defaults', () => {
    const p = freshSoul();
    const m = p.recordMistake({ action: 'bare_action', context: 'bare_context' });
    assert(m.severity === 'medium', 'Default severity');
    assert(m.consequence === 'unknown', 'Default consequence');
});

test('DELETE mistake removes it via splice', () => {
    const p = freshSoul();
    const m = p.recordMistake({ action: 'delete_me', context: 'test', consequence: 'none', severity: 'low' });
    assert(p.mistakes.length === 1, 'Mistake exists');
    const idx = p.mistakes.findIndex(x => x.id === m.id);
    assert(idx >= 0, 'Mistake found by id');
    p.mistakes.splice(idx, 1);
    p.saveState();
    assert(p.mistakes.length === 0, 'Mistake removed');
});

test('Consecutive same mistake updates existing not duplicates', () => {
    const p = freshSoul();
    const m1 = p.recordMistake({ action: 'same_act', context: 'same_ctx', consequence: 'bad', severity: 'high', fix: 'fix it' });
    const m2 = p.recordMistake({ action: 'same_act', context: 'same_ctx' });
    assert(m1.id === m2.id, 'Same id for repeated mistake');
    assert(p.mistakes.length === 1, 'Still only one entry');
    assert(m2.occurrences === 2, 'Occurrences incremented');
});

if (fs.existsSync(TEST_BASE)) fs.rmSync(TEST_BASE, { recursive: true, force: true });
console.log('\n' + '='.repeat(40));
console.log('Results: ' + passed + ' passed, ' + failed + ' failed\n');
process.exit(failed > 0 ? 1 : 0);
