const http = require('http');
const soul = require('../lib/soul-self-modeling');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has self_concept', st.body && st.body.self_concept);

  // 7. POST /self - update trait
  const upd = await req('POST', '/self', { trait: 'honest', value: 0.9 }, { 'x-api-key': soul.API_KEY });
  test('POST /self returns 200', upd.status === 200);
  test('/self returns updated', upd.body && upd.body.updated === true);

  // 8. POST /self without trait
  const bad = await req('POST', '/self', { value: 0.5 }, { 'x-api-key': soul.API_KEY });
  test('POST /self missing trait returns 400', bad.status === 400);

  // 9. POST /evaluate
  const ev = await req('POST', '/evaluate', { capability: 'public_speaking' }, { 'x-api-key': soul.API_KEY });
  test('POST /evaluate returns 200', ev.status === 200);
  test('/evaluate has self_efficacy', ev.body && typeof ev.body.self_efficacy === 'number');

  // 10. POST /evaluate without capability
  const evBad = await req('POST', '/evaluate', {}, { 'x-api-key': soul.API_KEY });
  test('POST /evaluate missing capability returns 400', evBad.status === 400);

  // 11. POST /compare
  const comp = await req('POST', '/compare', { ideal: { honest: 1.0, kind: 0.9 } }, { 'x-api-key': soul.API_KEY });
  test('POST /compare returns 200', comp.status === 200);
  test('/compare has gaps', comp.body && Array.isArray(comp.body.gaps));

  // 12. POST /compare without ideal
  const compBad = await req('POST', '/compare', {}, { 'x-api-key': soul.API_KEY });
  test('POST /compare missing ideal returns 400', compBad.status === 400);

  // 13. GET /self-model
  const sm = await req('GET', '/self-model', null, { 'x-api-key': soul.API_KEY });
  test('GET /self-model returns 200', sm.status === 200);
  test('/self-model has self_esteem', sm.body && typeof sm.body.self_esteem === 'number');
  test('/self-model has possible_selves', sm.body && sm.body.possible_selves);

  // 14. updateSelf with large gap creates discrepancy
  soul.updateSelf('capable', 0.1);
  test('large update creates discrepancy', soul.state.self_discrepancies.length > 0);

  // 15. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
