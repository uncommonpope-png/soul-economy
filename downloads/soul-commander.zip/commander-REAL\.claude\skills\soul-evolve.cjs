/**
 * soul-evolve.cjs — Soul Commander v2.0.0
 * Skill: The commander evolves based on battlefield experience.
 * Uses BUYaSOUL Core archetypes for evolution suggestions.
 */

const fs = require('fs');
const path = require('path');
const { BUYaSOUL } = require('../../lib/buyasoul-bridge.cjs');

const SOUL_FILE = path.join(__dirname, '..', '..', '.soul-state', 'user-state.json');
const JOURNAL_FILE = path.join(__dirname, '..', '..', '.soul-journal.jsonl');

function loadState() {
  try { return JSON.parse(fs.readFileSync(SOUL_FILE, 'utf8')); } catch { return null; }
}

function loadJournal(limit = 50) {
  if (!fs.existsSync(JOURNAL_FILE)) return [];
  const lines = fs.readFileSync(JOURNAL_FILE, 'utf8').trim().split('\n').filter(Boolean);
  return lines.slice(-limit).map(line => { try { return JSON.parse(line); } catch { return null; } }).filter(Boolean);
}

function generateSuggestions(state, entries) {
  const suggestions = [];
  const blocks = entries.filter(e => e.event === 'GUARDIAN_BLOCKED').length;
  if (blocks > 3) suggestions.push('  ⚠ Guardian has blocked ' + blocks + ' operations. Review your security rules.');
  const highTax = entries.filter(e => e.event === 'HIGH_TAX_WARNING').length;
  if (highTax > 5) suggestions.push('  ⚠ High-tax operations are frequent. Consider adding safer defaults.');
  const pltScores = entries.filter(e => e.plt?.score !== undefined).map(e => e.plt.score);
  const avgPLT = pltScores.length ? pltScores.reduce((a, b) => a + b, 0) / pltScores.length : 0;
  if (avgPLT < 5) suggestions.push('  ⚠ Average PLT score is low (' + avgPLT.toFixed(1) + '). Review recent operations.');

  // Use BUYaSOUL archetype data if available
  let archetypeData = null;
  try { archetypeData = BUYaSOUL.getArchetype?.(state?.userArchetype); } catch {}
  if (archetypeData) {
    suggestions.push(`  ⚙️ BUYaSOUL Archetype: ${archetypeData.name || state?.userArchetype}`);
    if (archetypeData.edge) suggestions.push(`     Edge: ${archetypeData.edge}`);
    if (archetypeData.shadow) suggestions.push(`     Shadow: ${archetypeData.shadow}`);
  }

  if (suggestions.length === 0) suggestions.push('  ⚡ The battlefield is clear. Continue building with confidence.');
  return suggestions;
}

function main() {
  const state = loadState();
  const entries = loadJournal(50);
  const suggestions = generateSuggestions(state, entries);

  const report = [
    '═'.repeat(60),
    '  SOUL EVOLUTION — Soul Commander v2.0.0 [Powered by BUYaSOUL Core]',
    '═'.repeat(60),
    `  User: ${state?.userName || 'Unknown'}`,
    `  Archetype: ${state?.userArchetype || 'Unknown'}`,
    '  Suggestions:',
    ...suggestions,
    '═'.repeat(60)
  ];

  console.log('\n' + report.join('\n') + '\n');
}

module.exports = { main, generateSuggestions };
if (require.main === module) main();
