/**
 * Example: Auto-Detect Power — Let Commander choose the right power
 *
 * Demonstrates automatic power selection from natural language.
 */

const SoulCommander = require('../soul-commander.cjs');

async function runAutoDetectExample() {
  console.log('=== SOUL COMMANDER: AUTO-DETECT EXAMPLE ===\n');

  const commander = new SoulCommander();

  const missions = [
    'generate an image of a futuristic city',
    'convert text to speech saying hello world',
    'scrape https://example.com and take a screenshot',
    'remember this information: user prefers dark mode',
    'ingest the manual.pdf document',
    'connect to the filesystem MCP server',
    'create a workflow that sends daily reports',
    'refactor this code to use async await',
    'run the deepseek model locally',
    'stream real-time stock prices',
    'hash this password securely',
    'cache the result of this calculation',
    'deploy the app to docker',
    'generate a PDF report from the markdown file',
    'sync context with Miss Vikki',
    'get the hexagonal architecture pattern'
  ];

  console.log('Testing auto-detection on ' + missions.length + ' descriptions...\n');

  for (const description of missions) {
    const detected = commander.detectPower(description);
    console.log(`"${description.substring(0, 50)}..." => ${detected}`);
  }

  console.log('\n=== EXECUTING AUTO-DETECTED MISSIONS ===\n');

  const results = await commander.swarm(
    missions.slice(0, 5).map(description => ({ description }))
  );

  console.log('\nResults:');
  for (const r of results.results) {
    console.log(`  ${r.power}: ${r.success ? 'OK' : 'FAIL'}`);
  }
}

runAutoDetectExample().catch(console.error);
