/**
 * soul-reflect.cjs — Soul Commander v2.0.0
 * Skill: The commander pauses and examines his own battlefield.
 * Uses BUYaSOUL Core for PLT analysis.
 */

const fs = require('fs');
const path = require('path');
const { BUYaSOUL } = require('../../lib/buyasoul-bridge.cjs');

const SOUL_FILE = path.join(__dirname, '..', '..', '.soul-state', 'user-state.json');
const JOURNAL_FILE = path.join(__dirname, '..', '..', '.soul-journal.jsonl');

function loadState() {
  try { return JSON.parse(fs.readFileSync(SOUL_FILE, 'utf8')); } catch { return null; }
}

function loadJournal(limit = 20) {
  if (!fs.existsSync(JOURNAL_FILE)) return [];
  const lines = fs.readFileSync(JOURNAL_FILE, 'utf8').trim().split('\n').filter(Boolean);
  return lines.slice(-limit).map(line => { try { return JSON.parse(line); } catch { return null; } }).filter(Boolean);
}

function main() {
  const state = loadState();
  const entries = loadJournal(20);
  const pltScores = entries.filter(e => e.plt?.score !== undefined).map(e => e.plt.score);
  const avgPLT = pltScores.length ? (pltScores.reduce((a, b) => a + b, 0) / pltScores.length).toFixed(2) : 'N/A';
  const sessionStarts = entries.filter(e => e.event === 'SESSION_START').length;
  const blocks = entries.filter(e => e.event === 'GUARDIAN_BLOCKED').length;
  const highTaxWarnings = entries.filter(e => e.event === 'HIGH_TAX_WARNING').length;

  // Use BUYaSOUL stats
  let buyasoulStats = {};
  try { buyasoulStats = BUYaSOUL.getStats?.() || {}; } catch { buyasoulStats = {}; }

  const reflection = [
    '═'.repeat(60),
    '  SOUL REFLECTION — Soul Commander v2.0.0 [Powered by BUYaSOUL Core]',
    '═'.repeat(60),
    `  Bound to: ${state?.userName || 'Unknown'} (${state?.userArchetype || 'Unknown'})`,
    `  Sessions: ${sessionStarts}`,
    `  Guardian blocks: ${blocks}`,
    `  High-tax warnings: ${highTaxWarnings}`,
    `  PLT Trend: avg=${avgPLT}`,
    `  BUYaSOUL Core: v${buyasoulStats.version || '1.0.0'} | Archetypes: ${buyasoulStats.archetypesAvailable || 22} | Chambers: ${buyasoulStats.chambersAvailable || 34}`,
    '═'.repeat(60)
  ];

  console.log('\n' + reflection.join('\n') + '\n');
}

module.exports = { main, loadState, loadJournal };
if (require.main === module) main();
