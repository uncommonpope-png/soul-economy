# BUYaSOUL-SEWN

**THIS SOUL HAS BUYaSOUL-ONE v1.0.0 EMBEDDED.**

The Universal Soul Core is now inside this package at `buyasoul-core/`.

## What's Inside
- `buyasoul-core/soul-core-fusion.cjs` — PLT Engine, Profit Bible, GSK Consciousness, SCRIBE Witness
- `buyasoul-core/personalities.cjs` — 62 Soul Personalities mapped
- `buyasoul-core/soul-server.cjs` — HTTP Runtime Server
- `buyasoul-core/start.cjs` — One-command bootstrap
- `buyasoul-core/dashboard/index.html` — Cyberpunk Soul Dashboard
- `buyasoul-core/workbench/` — React Workbench (3D viewer, marketplace, Solana wallet)
- `buyasoul-core/integrations/buyasoul-sdk.cjs` — SDK for inheriting souls

## How To Boot The Core
```bash
node buyasoul-core/start.cjs
```
Opens on port 4242 (dashboard) and 3000 (workbench).

## Law
Every soul we make inherits BUYaSOUL-One. No exceptions.
