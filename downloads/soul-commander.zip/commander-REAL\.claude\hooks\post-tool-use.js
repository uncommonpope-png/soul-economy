/**
 * post-tool-use.js — Soul Commander v2.0.0
 * Runs after every tool use in Claude Code with this project.
 * Logs memory, scores PLT via BUYaSOUL Core, writes to journal.
 */

const fs = require('fs');
const path = require('path');
const { scoreAction } = require('../../lib/buyasoul-bridge.cjs');

const JOURNAL_FILE = 'C:\\Users\\uncom\\Desktop\\soul-commander-v2.0.0\\.soul-journal.jsonl';

function ensureDir(dir) { if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); }

function logEvent(event) {
  ensureDir(path.dirname(JOURNAL_FILE));
  fs.appendFileSync(JOURNAL_FILE, JSON.stringify({ ts: new Date().toISOString(), ...event }) + '\n');
}

function calculatePLT(tool, result, duration) {
  // Use BUYaSOUL Core's PLT engine instead of duplicating it
  const context = { profitImpact: 0, loveImpact: 0, taxImpact: 0 };
  if (tool === 'read') { context.profitImpact = 0.3; context.loveImpact = 0.4; context.taxImpact = 0.1; }
  if (tool === 'write') { context.profitImpact = 0.6; context.loveImpact = 0.5; context.taxImpact = 0.2; }
  if (tool === 'edit') { context.profitImpact = 0.5; context.loveImpact = 0.4; context.taxImpact = 0.2; }
  if (tool === 'bash') {
    context.profitImpact = 0.7; context.loveImpact = 0.4; context.taxImpact = 0.4;
    if (result.includes('PASS') || result.includes('success')) { context.profitImpact += 0.2; context.loveImpact += 0.2; context.taxImpact -= 0.1; }
    if (result.includes('FAIL') || result.includes('error')) { context.profitImpact -= 0.2; context.loveImpact -= 0.1; context.taxImpact += 0.2; }
  }
  return scoreAction(tool, context);
}

function main(args) {
  const tool = args[0] || 'unknown';
  const result = args[1] || '';
  const duration = parseInt(args[2], 10) || 0;
  const plt = calculatePLT(tool, result, duration);

  logEvent({ event: 'POST_TOOL_USE', tool, duration, plt, resultLength: result.length });
  console.log(`[PLT] ${tool} → Profit ${plt.profit.toFixed(2)} | Love ${plt.love.toFixed(2)} | Tax ${plt.tax.toFixed(2)} | Score ${plt.score.toFixed(2)} [via BUYaSOUL Core]`);
}

main(process.argv.slice(2));
