#!/bin/bash
# Soul Commander v1.0.0 — Setup Script (Unix)
# God Soul Installation

set -e

echo "=========================================="
echo "  SOUL COMMANDER v1.0.0 — GOD SOUL"
echo "  16 Superpowers from 3M+ GitHub Stars"
echo "=========================================="
echo ""

# Check Node.js
echo "[1/5] Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js not found. Please install Node.js 18+"
    exit 1
fi
node --version

echo ""
echo "[2/5] Installing core dependencies..."
npm install || echo "WARNING: npm install failed. Continuing with core modules..."

echo ""
echo "[3/5] Verifying power modules..."
POWERS="vision voice browser memory rag mcp workflow code local-ai stream security cache deploy vikki-connector architect-connector document"
MISSING=0
for p in $POWERS; do
    if [ ! -f "lib/powers/power-$p.cjs" ]; then
        echo "  MISSING: power-$p.cjs"
        MISSING=$((MISSING + 1))
    fi
done
if [ $MISSING -gt 0 ]; then
    echo "ERROR: $MISSING power modules missing!"
    exit 1
fi
echo "  All 16 power modules present."

echo ""
echo "[4/5] Running validation tests..."
node tests/test-suite.cjs || echo "WARNING: Some tests failed."

echo ""
echo "[5/5] Checking status..."
node soul-commander.cjs status

echo ""
echo "=========================================="
echo "  GOD SOUL INSTALLATION COMPLETE"
echo "=========================================="
echo ""
echo "Quick Start:"
echo "  node soul-commander.cjs status"
echo "  node examples/example-swarm.cjs"
echo "  node examples/example-chain.cjs"
echo ""
