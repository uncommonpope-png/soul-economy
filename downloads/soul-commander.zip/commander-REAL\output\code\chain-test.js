// Generated code based on: Generate a helper function
// Implement your logic here
