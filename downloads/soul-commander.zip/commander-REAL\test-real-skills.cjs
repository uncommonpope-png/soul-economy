/**
 * test-real-skills.cjs — Verify all real skills work
 */

const RealMetrics = require('./lib/real-skills/real-metrics.cjs');
const RealLogger = require('./lib/real-skills/real-logger.cjs');
const RealVectorDB = require('./lib/real-skills/real-vector-db.cjs');
const RealQueue = require('./lib/real-skills/real-queue.cjs');
const RealCache = require('./lib/real-skills/real-cache.cjs');
const RealScraper = require('./lib/real-skills/real-scraper.cjs');
const { createMachine, interpret } = require('./lib/real-skills/real-state-machine.cjs');

console.log('=== TESTING REAL SKILLS ===\n');

// 1. Metrics
console.log('1. REAL METRICS');
const metrics = new RealMetrics({ storagePath: './data/test/metrics' });
metrics.createCounter('requests_total', 'Total requests', { method: 'GET' });
metrics.inc('requests_total', { method: 'GET' }, 1);
metrics.inc('requests_total', { method: 'GET' }, 1);
metrics.createGauge('cpu_usage', 'CPU usage percent');
metrics.set('cpu_usage', {}, 45.2);
console.log(metrics.export().substring(0, 200) + '...');
console.log('✓ Metrics work\n');

// 2. Logger
console.log('2. REAL LOGGER');
const logger = new RealLogger({ 
  level: 'debug',
  transports: [
    { type: 'console', colorize: true },
    { type: 'file', filename: './data/test/logs/app.log' }
  ],
  defaultMeta: { service: 'test' }
});
logger.info('Test message', { userId: 123 });
logger.warn('Warning message');
logger.error('Error message');
const logs = logger.query({ limit: 5 });
console.log('Queried logs:', logs.length, 'entries');
console.log('✓ Logger works\n');

// 3. Vector DB
console.log('3. REAL VECTOR DB');
const vdb = new RealVectorDB({ storagePath: './data/test/vectors' });
const collection = vdb.collection('documents');
collection.add(
  ['The quick brown fox', 'Lazy dog sleeps', 'Machine learning is powerful'],
  null, // auto-generate embeddings
  [{ source: 'test' }, { source: 'test' }, { source: 'ai' }]
);
const search = collection.search('artificial intelligence', 2);
console.log('Search results:', search[0].documents);
console.log('✓ Vector DB works\n');

// 4. Queue
console.log('4. REAL QUEUE');
const queue = new RealQueue({ name: 'test', storagePath: './data/test/queues' });
queue.process('email', async (data) => {
  console.log('  Processing email to:', data.to);
  return { sent: true };
});
queue.add('email', { to: 'test@example.com', subject: 'Hello' });
setTimeout(() => {
  console.log('  Job counts:', queue.getJobCounts());
  console.log('✓ Queue works\n');

  // 5. Cache
  console.log('5. REAL CACHE');
  const cache = new RealCache({ storagePath: './data/test/cache' });
  cache.set('user:123', { name: 'Alice', role: 'admin' }, 60000);
  console.log('  Get user:123:', cache.get('user:123').name);
  cache.incr('counter');
  cache.incr('counter');
  console.log('  Counter:', cache.get('counter'));
  console.log('✓ Cache works\n');

  // 6. State Machine
  console.log('6. REAL STATE MACHINE');
  const machine = createMachine({
    id: 'door',
    initial: 'locked',
    context: { attempts: 0 },
    states: {
      locked: {
        on: { UNLOCK: 'unlocked' }
      },
      unlocked: {
        entry: ['logUnlock'],
        on: { LOCK: 'locked', OPEN: 'open' }
      },
      open: {
        on: { CLOSE: 'unlocked' }
      }
    },
    actions: {
      logUnlock: (ctx) => {
        console.log('  Door unlocked!');
      }
    }
  });
  const service = interpret(machine).start();
  service.send('UNLOCK');
  console.log('  Current state:', machine.getState().value);
  service.send('OPEN');
  console.log('  Current state:', machine.getState().value);
  console.log('✓ State Machine works\n');

  console.log('=== ALL REAL SKILLS VERIFIED ===');
  console.log('Zero npm dependencies. Real functionality.\n');
}, 2000);
