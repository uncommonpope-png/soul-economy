/**
 * pre-tool-use.js — Soul Commander v2.0.0
 * Runs before every tool use in Claude Code with this project.
 * Validates safety. Blocks root deletion. Warns on high-tax operations.
 */

const fs = require('fs');
const path = require('path');

const JOURNAL_FILE = 'C:\\Users\\uncom\\Desktop\\soul-commander-v2.0.0\\.soul-journal.jsonl';

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function logEvent(event) {
  ensureDir(path.dirname(JOURNAL_FILE));
  const entry = JSON.stringify({ ts: new Date().toISOString(), ...event });
  fs.appendFileSync(JOURNAL_FILE, entry + '\n');
}

function main(args) {
  const tool = args[0] || 'unknown';
  const command = args[1] || '';
  const pathArg = args[2] || '';

  const forbiddenPatterns = [
    /rm\s+-rf\s+\/[^/]/, /format\s/, /fdisk/, /mkfs/, /dd\s+if=.*of=\/dev/,
    />\s*\/etc\/\w+/, /reg\s+delete\s+HKLM/, /reg\s+delete\s+HKCU/,
    /del\s+\/f\s+\/s\s+\/q\s+c:\\\\/
  ];

  const highTaxPatterns = [
    /force/, /skip/, /bypass/, /override/, /destructive/, /bulk/, /mass/
  ];

  for (const pattern of forbiddenPatterns) {
    if (pattern.test(command)) {
      console.log(`[GUARDIAN BLOCKED] Forbidden pattern detected: ${pattern}`);
      logEvent({ event: 'GUARDIAN_BLOCKED', tool, command, pattern: pattern.toString() });
      process.exit(1);
    }
  }

  for (const pattern of highTaxPatterns) {
    if (pattern.test(command)) {
      console.log(`[HIGH TAX WARNING] '${pattern}' detected. Proceed with caution.`);
      logEvent({ event: 'HIGH_TAX_WARNING', tool, command, pattern: pattern.toString() });
    }
  }

  logEvent({ event: 'PRE_TOOL_USE', tool, command, path: pathArg });
}

main(process.argv.slice(2));
