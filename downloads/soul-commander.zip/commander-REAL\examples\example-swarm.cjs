/**
 * Example: Swarm Mode — Execute multiple powers simultaneously
 *
 * Demonstrates parallel execution of unrelated missions.
 */

const SoulCommander = require('../soul-commander.cjs');

async function runSwarmExample() {
  console.log('=== SOUL COMMANDER: SWARM MODE EXAMPLE ===\n');

  const commander = new SoulCommander();

  // Define multiple missions to run in parallel
  const missions = [
    {
      power: 'CODE',
      description: 'generate express API with user routes',
      outputPath: 'api-routes.js'
    },
    {
      power: 'SECURITY',
      description: 'hash password mySecretPassword123'
    },
    {
      power: 'DOCUMENT',
      description: 'generate report',
      title: 'API Documentation',
      sections: [
        { heading: 'Authentication', content: 'API uses JWT tokens', bullets: ['Login endpoint', 'Refresh token'] },
        { heading: 'User Routes', content: 'CRUD operations for users' }
      ]
    },
    {
      power: 'CACHE',
      description: 'set',
      key: 'example-cache-key',
      value: { message: 'Hello from swarm mode', timestamp: Date.now() }
    }
  ];

  console.log('Launching swarm with ' + missions.length + ' missions...\n');

  const result = await commander.swarm(missions);

  console.log('\n=== SWARM RESULTS ===');
  console.log('Total:', result.total);
  console.log('Completed:', result.completed);
  console.log('Failed:', result.failed);
  console.log('Success:', result.success);

  for (const [i, r] of result.results.entries()) {
    console.log(`\nMission ${i + 1} (${r.power}):`);
    console.log('  Status:', r.success ? 'OK' : 'FAIL');
    console.log('  Duration:', r.duration);
    if (r.output) {
      console.log('  Output:', JSON.stringify(r.output, null, 2).substring(0, 200));
    }
    if (r.error) {
      console.log('  Error:', r.error);
    }
  }
}

runSwarmExample().catch(console.error);
