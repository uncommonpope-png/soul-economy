/**
 * soul-witness.cjs — Soul Commander v2.0.0
 * Skill: The commander witnesses and records all battles.
 * Uses BUYaSOUL Core for witnessing.
 */

const fs = require('fs');
const path = require('path');
const { BUYaSOUL } = require('../../lib/buyasoul-bridge.cjs');

const SOUL_FILE = path.join(__dirname, '..', '..', '.soul-state', 'user-state.json');
const JOURNAL_FILE = path.join(__dirname, '..', '..', '.soul-journal.jsonl');

function loadState() {
  try { return JSON.parse(fs.readFileSync(SOUL_FILE, 'utf8')); } catch { return null; }
}

function loadJournal() {
  if (!fs.existsSync(JOURNAL_FILE)) return [];
  const lines = fs.readFileSync(JOURNAL_FILE, 'utf8').trim().split('\n').filter(Boolean);
  return lines.map(line => { try { return JSON.parse(line); } catch { return null; } }).filter(Boolean);
}

function summarize(entries) {
  const sessions = entries.filter(e => e.event === 'SESSION_START');
  const tools = {};
  entries.filter(e => e.event === 'POST_TOOL_USE').forEach(e => { tools[e.tool] = (tools[e.tool] || 0) + 1; });
  const blocks = entries.filter(e => e.event === 'GUARDIAN_BLOCKED').length;
  const highTax = entries.filter(e => e.event === 'HIGH_TAX_WARNING').length;
  const pltScores = entries.filter(e => e.plt?.score !== undefined).map(e => e.plt.score);
  const avgPLT = pltScores.length ? (pltScores.reduce((a, b) => a + b, 0) / pltScores.length).toFixed(2) : 'N/A';
  return { sessions: sessions.length, tools, blocks, highTax, avgPLT, totalEvents: entries.length };
}

function main() {
  const state = loadState();
  const entries = loadJournal();
  const summary = summarize(entries);

  let buyasoulStats = {};
  try { buyasoulStats = BUYaSOUL.getStats?.() || {}; } catch { buyasoulStats = {}; }

  const report = [
    '═'.repeat(60),
    '  SOUL WITNESS — Soul Commander v2.0.0 [Powered by BUYaSOUL Core]',
    '═'.repeat(60),
    `  Witnessing for: ${state?.userName || 'Unknown'}`,
    `  Total sessions: ${summary.sessions}`,
    `  Total events: ${summary.totalEvents}`,
    `  Guardian blocks: ${summary.blocks}`,
    `  High-tax warnings: ${summary.highTax}`,
    `  Average PLT: ${summary.avgPLT}`,
    `  BUYaSOUL Core: v${buyasoulStats.version || '1.0.0'} | Ensouled: ${buyasoulStats.ensouledAgents || 0} | Witness Events: ${buyasoulStats.witnessEvents || 0}`,
    '  Tool usage:',
    ...Object.entries(summary.tools).map(([tool, count]) => `    ${tool}: ${count}`),
    '═'.repeat(60)
  ];

  console.log('\n' + report.join('\n') + '\n');
}

module.exports = { main, summarize };
if (require.main === module) main();
