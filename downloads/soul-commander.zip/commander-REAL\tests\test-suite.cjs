/**
 * SOUL COMMANDER v2.0.0 — Test Suite
 *
 * Validates all 19 powers and core orchestration.
 */

const SoulCommander = require('../soul-commander.cjs');
const fs = require('fs');
const path = require('path');

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    console.log(`  PASS: ${name}`);
    passed++;
  } catch (error) {
    console.log(`  FAIL: ${name} — ${error.message}`);
    failed++;
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

async function runTests() {
  console.log('=== SOUL COMMANDER TEST SUITE ===\n');

  const commander = new SoulCommander();

  // --- Core Tests ---
  await test('Commander initializes with 19 powers', () => {
    assert(commander.powerNames.length === 19, `Expected 19, got ${commander.powerNames.length}`);
  });

  await test('Status returns all powers', () => {
    const status = commander.status();
    assert(status.powers === 19, 'Status should report 19 powers');
    assert(status.missionsExecuted === 0, 'Should start with 0 missions');
  });

  await test('Auto-detect maps descriptions to powers', () => {
    assert(commander.detectPower('generate an image') === 'VISION');
    assert(commander.detectPower('speak this text') === 'VOICE');
    assert(commander.detectPower('scrape a website') === 'BROWSER');
    assert(commander.detectPower('unknown operation') === 'CODE');
  });

  // --- Power Tests ---
  await test('VISION: execute generation mission', async () => {
    const result = await commander.execute({
      power: 'VISION',
      description: 'generate a cat image',
      outputFile: 'test-cat.png'
    });
    assert(result.success, result.error);
    assert(result.output, 'Should have output');
  });

  await test('VOICE: execute TTS mission', async () => {
    const result = await commander.execute({
      power: 'VOICE',
      description: 'say hello world',
      text: 'Hello world from Soul Commander'
    });
    assert(result.success, result.error);
  });

  await test('CODE: generate API code', async () => {
    const result = await commander.execute({
      power: 'CODE',
      description: 'generate express API',
      prompt: 'Create an Express.js API with user routes',
      outputPath: 'test-api.js'
    });
    assert(result.success, result.error);
    assert(result.output.filePath, 'Should return file path');
    assert(fs.existsSync(result.output.filePath), 'File should exist');
  });

  await test('SECURITY: hash password', async () => {
    const result = await commander.execute({
      power: 'SECURITY',
      description: 'hash mypassword',
      data: 'mypassword'
    });
    assert(result.success, result.error);
    assert(result.output.hash, 'Should return hash');
  });

  await test('CACHE: set and get', async () => {
    await commander.execute({
      power: 'CACHE',
      description: 'set test key',
      key: 'test-key',
      value: { test: true }
    });
    const result = await commander.execute({
      power: 'CACHE',
      description: 'get test key',
      key: 'test-key'
    });
    assert(result.success, result.error);
    assert(result.output.hit, 'Should be cache hit');
  });

  await test('RAG: ingest and query', async () => {
    const testDoc = path.join(__dirname, 'test-doc.txt');
    fs.writeFileSync(testDoc, 'Soul Commander is a God Soul with 16 superpowers. It can generate images, speak, browse the web, and more. The powers are grafted from 3M+ GitHub stars.');

    const ingest = await commander.execute({
      power: 'RAG',
      description: 'ingest document',
      filePath: testDoc
    });
    assert(ingest.success, ingest.error);

    const query = await commander.execute({
      power: 'RAG',
      description: 'query',
      question: 'What is Soul Commander?'
    });
    assert(query.success, query.error);
    assert(query.output.answer, 'Should have answer');
  });

  await test('DEPLOY: build docker', async () => {
    const result = await commander.execute({
      power: 'DEPLOY',
      description: 'build docker',
      sourceDir: path.join(__dirname, '..'),
      imageName: 'test-soul-commander'
    });
    assert(result.success, result.error);
    assert(result.output.dockerfile, 'Should return Dockerfile path');
  });

  await test('DOCUMENT: generate report', async () => {
    const result = await commander.execute({
      power: 'DOCUMENT',
      description: 'generate report',
      title: 'Test Report',
      sections: [{ heading: 'Test', content: 'This is a test' }]
    });
    assert(result.success, result.error);
    assert(fs.existsSync(result.output.filePath), 'Report file should exist');
  });

  await test('STREAM: create and publish', async () => {
    await commander.execute({
      power: 'STREAM',
      description: 'create test stream',
      streamName: 'test-stream'
    });
    const pub = await commander.execute({
      power: 'STREAM',
      description: 'publish to test stream',
      streamName: 'test-stream',
      data: { message: 'hello' }
    });
    assert(pub.success, pub.error);
    assert(pub.output.eventId, 'Should have event ID');
  });

  await test('MCP: connect and discover', async () => {
    const result = await commander.execute({
      power: 'MCP',
      description: 'connect',
      serverName: 'test-server',
      config: { command: 'npx', args: ['test'] }
    });
    assert(result.success, result.error);
  });

  await test('WORKFLOW: create and run', async () => {
    const create = await commander.execute({
      power: 'WORKFLOW',
      description: 'create test workflow',
      name: 'test-workflow',
      definition: {
        nodes: [
          { id: 'start', name: 'Start', type: 'trigger' },
          { id: 'end', name: 'End', type: 'function' }
        ],
        connections: { start: ['end'] }
      }
    });
    assert(create.success, create.error);

    const run = await commander.execute({
      power: 'WORKFLOW',
      description: 'run test workflow',
      workflowName: 'test-workflow'
    });
    assert(run.success, run.error);
  });

  // --- New Powers v2.0 ---
  await test('OBSERVABILITY: monitor and alert', async () => {
    const result = await commander.execute({
      power: 'OBSERVABILITY',
      description: 'monitor endpoint',
      action: 'monitor',
      endpoint: 'https://example.com/health'
    });
    assert(result.success, result.error);
    assert(result.output, 'Should have output');
  });

  await test('TESTING: generate and run tests', async () => {
    const result = await commander.execute({
      power: 'TESTING',
      description: 'generate tests',
      action: 'generateTests',
      target: 'calculator',
      spec: 'arithmetic'
    });
    assert(result.success, result.error);
    assert(result.output, 'Should have output');
  });

  await test('AGENT-SWARM: spawn and coordinate', async () => {
    await commander.execute({
      power: 'AGENT-SWARM',
      description: 'spawn agents',
      action: 'spawn',
      agents: [
        { name: 'coder', role: 'developer', skills: ['javascript', 'nodejs'] },
        { name: 'tester', role: 'qa', skills: ['testing', 'cypress'] }
      ]
    });
    const assign = await commander.execute({
      power: 'AGENT-SWARM',
      description: 'assign task',
      action: 'assign',
      tasks: [
        { id: 't1', description: 'Build API', requiredSkills: ['javascript'], assignee: 'coder' }
      ]
    });
    assert(assign.success, assign.error);
  });

  // --- Swarm & Chain Tests ---
  await test('SWARM: execute multiple missions', async () => {
    const result = await commander.swarm([
      { power: 'SECURITY', description: 'hash test1', data: 'test1' },
      { power: 'SECURITY', description: 'hash test2', data: 'test2' }
    ]);
    assert(result.success, 'Swarm should succeed');
    assert(result.total === 2, 'Should have 2 results');
  });

  await test('CHAIN: execute sequential missions', async () => {
    const result = await commander.chain([
      { power: 'CODE', description: 'generate function', prompt: 'Generate a helper function', outputPath: 'chain-test.js' },
      { power: 'DOCUMENT', description: 'generate docs', title: 'Chain Test' }
    ]);
    assert(result.success, 'Chain should succeed');
    assert(result.results.length === 2, 'Should have 2 steps');
  });

  // --- Summary ---
  console.log('\n=== TEST SUMMARY ===');
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total:  ${passed + failed}`);

  process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(error => {
  console.error('Test suite failed:', error);
  process.exit(1);
});
