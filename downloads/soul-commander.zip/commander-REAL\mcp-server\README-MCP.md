# Soul Commander MCP Server

A production-grade [Model Context Protocol (MCP)](https://modelcontextprotocol.io) server that exposes all 16 Soul Commander superpowers as tools. Built for Claude Code and any MCP-compatible client.

## Overview

- **Protocol:** JSON-RPC 2.0 over stdio
- **MCP Spec:** 2024-11-05
- **Transport:** stdio
- **Logging:** stderr only
- **Output:** stdout JSON-RPC only
- **Tools:** 62 total (59 capability tools + 3 meta tools)

## Quick Start

### 1. Configure Claude Code

Place `.mcp.json` in your project root:

```json
{
  "mcpServers": {
    "soul-commander": {
      "command": "node",
      "args": ["mcp-server/mcp-server.cjs"],
      "env": {
        "NODE_ENV": "production",
        "SOUL_COMMANDER_OUTPUT_DIR": "./output/commander"
      }
    }
  }
}
```

### 2. Verify the Server

```bash
cd soul-commander-v1.0.0/mcp-server
node mcp-server.cjs
```

The server will log to stderr and wait for JSON-RPC messages on stdin.

### 3. Test a Tool Call

Send a JSON-RPC request via stdin:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test-client","version":"1.0.0"}}}
{"jsonrpc":"2.0","id":2,"method":"tools/list"}
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"soul_commander_status","arguments":{}}}
```

## Architecture

```
┌─────────────────┐     JSON-RPC 2.0      ┌──────────────────┐
│  Claude Code    │  ←→  over stdio  ←→  │  mcp-server.cjs  │
│  (MCP Client)   │                       │                  │
└─────────────────┘                       │  • initialize    │
                                          │  • tools/list    │
                                          │  • tools/call    │
                                          └────────┬─────────┘
                                                   │
                                          ┌────────▼─────────┐
                                          │ SoulCommander    │
                                          │ (../soul-        │
                                          │  commander.cjs)  │
                                          └────────┬─────────┘
                                                   │
                                    ┌────────────────┴──────────────┐
                                    │ 16 Powers                     │
                                    │ VISION · VOICE · BROWSER      │
                                    │ MEMORY · RAG · MCP            │
                                    │ WORKFLOW · CODE · LOCAL-AI    │
                                    │ STREAM · SECURITY · CACHE     │
                                    │ DEPLOY · VIKKI · ARCHITECT    │
                                    │ DOCUMENT                      │
                                    └───────────────────────────────┘
```

## Tool Catalog

### Vision (3 tools)

| Tool | Use When |
|------|----------|
| `soul_vision_generate` | Creating art, photos, renders, illustrations from text |
| `soul_vision_inpaint` | Modifying, filling, or replacing parts of an image |
| `soul_vision_upscale` | Increasing image resolution, denoising, improving quality |

### Voice (3 tools)

| Tool | Use When |
|------|----------|
| `soul_voice_speak` | Audio narration, voiceover, spoken output |
| `soul_voice_transcribe` | Converting audio files to text, subtitles, transcripts |
| `soul_voice_clone` | Replicating a voice for later TTS usage |

### Browser (5 tools)

| Tool | Use When |
|------|----------|
| `soul_browser_launch` | Starting web automation, scraping, or testing |
| `soul_browser_goto` | Opening a specific webpage for interaction |
| `soul_browser_screenshot` | Capturing a visual of a webpage or element |
| `soul_browser_scrape` | Extracting text, links, tables, or structured content |
| `soul_browser_pdf` | Converting a webpage to a PDF document |

### Memory (3 tools)

| Tool | Use When |
|------|----------|
| `soul_memory_add` | Remembering, persisting, or storing information |
| `soul_memory_query` | Recalling previously stored info by semantic meaning |
| `soul_memory_recall` | Retrieving a specific memory by its exact ID |

### RAG (2 tools)

| Tool | Use When |
|------|----------|
| `soul_rag_ingest` | Adding documents to the searchable knowledge base |
| `soul_rag_query` | Asking questions against ingested documents |

### MCP (3 tools)

| Tool | Use When |
|------|----------|
| `soul_mcp_connect` | Integrating another MCP server or tool registry |
| `soul_mcp_discover_tools` | Seeing what tools an external MCP server exposes |
| `soul_mcp_call_tool` | Invoking a tool on an external MCP server |

### Workflow (3 tools)

| Tool | Use When |
|------|----------|
| `soul_workflow_create` | Defining pipelines, automation sequences, scheduled chains |
| `soul_workflow_run` | Manually triggering an existing workflow |
| `soul_workflow_list` | Viewing available workflows and their status |

### Code (5 tools)

| Tool | Use When |
|------|----------|
| `soul_code_generate` | Generating functions, scripts, APIs, classes, modules |
| `soul_code_analyze` | Reviewing, auditing, or assessing code quality |
| `soul_code_refactor` | Improving, modernizing, restructuring code |
| `soul_code_test` | Generating or running unit/integration tests |
| `soul_code_document` | Creating docs, READMEs, API docs, inline comments |

### Local-AI (4 tools)

| Tool | Use When |
|------|----------|
| `soul_local_ai_list_models` | Checking installed offline/edge models |
| `soul_local_ai_load_model` | Warming up or switching to a specific local model |
| `soul_local_ai_chat` | Running inference on a self-hosted model |
| `soul_local_ai_check_health` | Verifying Ollama, LM Studio, or other backends |

### Stream (4 tools)

| Tool | Use When |
|------|----------|
| `soul_stream_create` | Setting up event streams, pipelines, real-time channels |
| `soul_stream_publish` | Pushing events or messages into an active stream |
| `soul_stream_subscribe` | Listening to a real-time feed |
| `soul_stream_process` | Mapping, filtering, aggregating stream data |

### Security (6 tools)

| Tool | Use When |
|------|----------|
| `soul_security_hash` | Creating digests, checksums, hashed passwords |
| `soul_security_verify` | Checking integrity or validating passwords |
| `soul_security_encrypt` | Protecting sensitive data at rest or in transit |
| `soul_security_decrypt` | Recovering plaintext from encrypted data |
| `soul_security_token` | Generating auth tokens, session tokens, signed payloads |
| `soul_security_validate` | Input validation, schema checking, form verification |

### Cache (4 tools)

| Tool | Use When |
|------|----------|
| `soul_cache_get` | Reading a previously cached result |
| `soul_cache_set` | Memoizing or persisting a temporary result |
| `soul_cache_delete` | Invalidating or clearing a cached entry |
| `soul_cache_stats` | Inspecting hit rates, size, or cache health |

### Deploy (4 tools)

| Tool | Use When |
|------|----------|
| `soul_deploy_build` | Compiling, bundling, preparing code for release |
| `soul_deploy_deploy` | Shipping, publishing, or hosting an application |
| `soul_deploy_docker` | Building images, running containers, managing Docker |
| `soul_deploy_static` | Hosting HTML/CSS/JS, JAMstack, or static content |

### Vikki Connector (3 tools)

| Tool | Use When |
|------|----------|
| `soul_vikki_connector_connect` | Linking with Miss Vikki (Operator Soul) |
| `soul_vikki_connector_send` | Dispatching tasks or instructions to the Operator |
| `soul_vikki_connector_sync` | Aligning state/memory between Commander and Vikki |

### Architect Connector (3 tools)

| Tool | Use When |
|------|----------|
| `soul_architect_connector_connect` | Linking with Soul Architect |
| `soul_architect_connector_get_pattern` | Getting hexagonal, DDD, CQRS, or other patterns |
| `soul_architect_connector_analyze` | Architecture review, tech debt scan, design assessment |

### Document (4 tools)

| Tool | Use When |
|------|----------|
| `soul_document_generate_report` | Creating data reports, summaries, analysis documents |
| `soul_document_export_pdf` | Converting content to PDF |
| `soul_document_export_html` | Generating styled HTML pages or email templates |
| `soul_document_generate_slides` | Building presentation slide decks |

### Meta (4 tools)

| Tool | Use When |
|------|----------|
| `soul_commander_status` | Checking active powers, health, and mission history |
| `soul_commander_swarm` | Running multiple independent tasks in parallel |
| `soul_commander_chain` | Running sequential tasks with context passing |
| `soul_commander_detect_power` | Getting a power recommendation for a description |

## JSON-RPC Protocol

### Initialize

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {},
    "clientInfo": { "name": "claude-code", "version": "1.0.0" }
  }
}
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "protocolVersion": "2024-11-05",
    "capabilities": { "tools": { "listChanged": true } },
    "serverInfo": { "name": "soul-commander-mcp", "version": "1.0.0" }
  }
}
```

### Tools List

**Request:**
```json
{ "jsonrpc": "2.0", "id": 2, "method": "tools/list" }
```

**Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "tools": [
      {
        "name": "soul_code_generate",
        "description": "Generate code from a description...",
        "inputSchema": { "type": "object", ... },
        "outputSchema": { "type": "object", ... },
        "_meta": { "anthropic/maxResultSizeChars": 50000 }
      }
    ]
  }
}
```

### Tool Call

**Request:**
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "soul_code_generate",
    "arguments": {
      "description": "Express API with auth middleware",
      "language": "javascript",
      "tests": true
    }
  }
}
```

**Success Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "result": {
    "content": [
      { "type": "text", "text": "{ \"success\": true, ... }" }
    ],
    "isError": false,
    "_meta": { "anthropic/maxResultSizeChars": 50000 }
  }
}
```

**Error Response:**
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "result": {
    "content": [
      { "type": "text", "text": "Error: Power not available" }
    ],
    "isError": true
  }
}
```

## Design Checklist

- ✅ JSON-RPC 2.0 over stdio
- ✅ stderr for logs, stdout ONLY for JSON-RPC
- ✅ inputSchema and outputSchema for every tool
- ✅ snake_case tool names
- ✅ `isError: true` for execution errors
- ✅ `_meta["anthropic/maxResultSizeChars"]` for large-output tools
- ✅ Tool descriptions under 2KB with searchable "USE WHEN" phrases
- ✅ `listChanged` capability declared
- ✅ Structured content returned as JSON text blocks
- ✅ Session-scoped SoulCommander instances

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NODE_ENV` | `production` | Node environment mode |
| `SOUL_COMMANDER_OUTPUT_DIR` | `./output/commander` | Output directory for artifacts |
| `SOUL_COMMANDER_LOG_LEVEL` | `info` | Log verbosity: debug, info, warn, error |

## File Structure

```
soul-commander-v1.0.0/
├── mcp-server/
│   ├── mcp-server.cjs      # Main MCP server (this file)
│   ├── .mcp.json           # Claude Code configuration
│   └── README-MCP.md       # This documentation
├── soul-commander.cjs      # SoulCommander class
└── lib/
    └── powers/             # 16 power modules
```

## Debugging

View logs in real-time:

```bash
node mcp-server/mcp-server.cjs 2> mcp-server.log
```

Logs are newline-delimited JSON objects on stderr:

```json
{"ts":"2026-05-26T...","level":"info","message":"Tool call: soul_code_generate","sessionId":"default","args":["description","language"]}
```

## License

DeepSeek License v1.0 — Licensed for commercial resale.

Built by Profit Prime for the Grand Code Pope.
