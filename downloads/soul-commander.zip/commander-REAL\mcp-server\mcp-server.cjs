#!/usr/bin/env node
/**
 * Soul Commander MCP Server v1.0.0
 *
 * A Model Context Protocol (MCP) server exposing all 16 Soul Commander
 * superpowers as tools. Communicates via JSON-RPC 2.0 over stdio.
 *
 * SPEC: MCP 2024-11-05
 * TRANSPORT: stdio
 * LOGGING: stderr ONLY
 * OUTPUT: stdout JSON-RPC ONLY
 */

const SoulCommander = require('../soul-commander.cjs');

// ── Constants ───────────────────────────────────────────────────────────────
const MCP_VERSION = '2024-11-05';
const SERVER_NAME = 'soul-commander-mcp';
const SERVER_VERSION = '1.0.0';

// ── Logger (stderr only) ────────────────────────────────────────────────────
function log(level, message, meta = {}) {
  const ts = new Date().toISOString();
  const entry = { ts, level, message, ...meta };
  process.stderr.write(JSON.stringify(entry) + '\n');
}

// ── JSON-RPC Helpers ──────────────────────────────────────────────────────
function sendResponse(id, result) {
  const response = { jsonrpc: '2.0', id, result };
  process.stdout.write(JSON.stringify(response) + '\n');
}

function sendError(id, code, message, data) {
  const errorObj = { code, message };
  if (data !== undefined) errorObj.data = data;
  const response = { jsonrpc: '2.0', id, error: errorObj };
  process.stdout.write(JSON.stringify(response) + '\n');
}

function sendNotification(method, params) {
  const notification = { jsonrpc: '2.0', method, params };
  process.stdout.write(JSON.stringify(notification) + '\n');
}

// ── Tool Definitions ────────────────────────────────────────────────────────
const TOOL_DEFINITIONS = [
  // ─── VISION ───────────────────────────────────────────────────────────────
  {
    name: 'soul_vision_generate',
    description:
      'Generate images from text prompts using AI. ' +
      'USE WHEN: The user wants to create art, photos, renders, illustrations, or any visual content from a description.',
    inputSchema: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: 'Text description of the image to generate' },
        negative_prompt: { type: 'string', description: 'What to avoid in the image' },
        width: { type: 'number', default: 1024, description: 'Image width in pixels' },
        height: { type: 'number', default: 1024, description: 'Image height in pixels' },
        model: { type: 'string', description: 'Specific model to use (optional)' },
        output_path: { type: 'string', description: 'Path to save the generated image' }
      },
      required: ['prompt']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_vision_inpaint',
    description:
      'Inpaint or edit regions of an existing image. ' +
      'USE WHEN: The user wants to modify, fill, or replace parts of an image using a mask and prompt.',
    inputSchema: {
      type: 'object',
      properties: {
        image_path: { type: 'string', description: 'Path to the source image' },
        mask_path: { type: 'string', description: 'Path to the mask image' },
        prompt: { type: 'string', description: 'Description of what to paint into the masked region' },
        output_path: { type: 'string', description: 'Path to save the result' }
      },
      required: ['image_path', 'mask_path', 'prompt']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_vision_upscale',
    description:
      'Upscale/enhance the resolution of an image. ' +
      'USE WHEN: The user wants to increase image resolution, denoise, or improve quality.',
    inputSchema: {
      type: 'object',
      properties: {
        image_path: { type: 'string', description: 'Path to the image to upscale' },
        scale: { type: 'number', default: 2, description: 'Upscale factor (e.g. 2, 4)' },
        output_path: { type: 'string', description: 'Path to save the upscaled image' }
      },
      required: ['image_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── VOICE ────────────────────────────────────────────────────────────────
  {
    name: 'soul_voice_speak',
    description:
      'Convert text to speech (TTS). ' +
      'USE WHEN: The user wants audio narration, voiceover, spoken output, or to hear text read aloud.',
    inputSchema: {
      type: 'object',
      properties: {
        text: { type: 'string', description: 'Text to speak' },
        voice: { type: 'string', description: 'Voice ID or name' },
        speed: { type: 'number', default: 1.0, description: 'Speech speed multiplier' },
        output_path: { type: 'string', description: 'Path to save the audio file' }
      },
      required: ['text']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_voice_transcribe',
    description:
      'Transcribe speech/audio to text (STT). ' +
      'USE WHEN: The user has an audio file and wants a transcript, subtitles, or text extraction.',
    inputSchema: {
      type: 'object',
      properties: {
        audio_path: { type: 'string', description: 'Path to the audio file' },
        language: { type: 'string', description: 'Language code (e.g. en, es)' }
      },
      required: ['audio_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_voice_clone',
    description:
      'Clone a voice from audio samples. ' +
      'USE WHEN: The user wants to replicate a voice for later TTS usage.',
    inputSchema: {
      type: 'object',
      properties: {
        audio_samples: {
          type: 'array',
          items: { type: 'string' },
          description: 'Paths to sample audio files'
        },
        text: { type: 'string', description: 'Optional test text to synthesize with the cloned voice' },
        output_path: { type: 'string', description: 'Path to save the cloned voice model or sample' }
      },
      required: ['audio_samples']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── BROWSER ────────────────────────────────────────────────────────────────
  {
    name: 'soul_browser_launch',
    description:
      'Launch a headless browser instance. ' +
      'USE WHEN: The user needs to start web automation, scraping, or testing before navigating.',
    inputSchema: {
      type: 'object',
      properties: {
        headless: { type: 'boolean', default: true, description: 'Run in headless mode' },
        browser: { type: 'string', default: 'chromium', description: 'Browser type: chromium, firefox, webkit' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_browser_goto',
    description:
      'Navigate the browser to a URL. ' +
      'USE WHEN: The user wants to open a specific webpage for scraping, screenshot, or interaction.',
    inputSchema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'URL to navigate to' },
        wait_for: { type: 'string', description: 'Selector or state to wait for before continuing' }
      },
      required: ['url']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_browser_screenshot',
    description:
      'Capture a screenshot of the current page. ' +
      'USE WHEN: The user wants a visual capture of a webpage, element, or full page.',
    inputSchema: {
      type: 'object',
      properties: {
        selector: { type: 'string', description: 'CSS selector of element to screenshot' },
        full_page: { type: 'boolean', default: false, description: 'Capture the full scrollable page' },
        output_path: { type: 'string', description: 'Path to save the screenshot' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_browser_scrape',
    description:
      'Scrape structured data from a webpage. ' +
      'USE WHEN: The user wants to extract text, links, tables, or structured content from a URL.',
    inputSchema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'URL to scrape' },
        selector: { type: 'string', description: 'CSS selector to target specific elements' },
        format: { type: 'string', default: 'json', description: 'Output format: json, markdown, text' }
      },
      required: ['url']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_browser_pdf',
    description:
      'Generate a PDF from a webpage. ' +
      'USE WHEN: The user wants to save a webpage as a PDF document.',
    inputSchema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'URL to convert to PDF' },
        output_path: { type: 'string', description: 'Path to save the PDF' },
        format: { type: 'string', default: 'A4', description: 'Page format: A4, Letter, etc.' }
      },
      required: ['url']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── MEMORY ─────────────────────────────────────────────────────────────────
  {
    name: 'soul_memory_add',
    description:
      'Store a memory with vector embedding. ' +
      'USE WHEN: The user wants to remember, persist, or store information for later semantic retrieval.',
    inputSchema: {
      type: 'object',
      properties: {
        content: { type: 'string', description: 'The text content to store' },
        metadata: { type: 'object', description: 'Optional metadata object' },
        id: { type: 'string', description: 'Optional custom ID' }
      },
      required: ['content']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_memory_query',
    description:
      'Query memories using semantic search. ' +
      'USE WHEN: The user asks to recall, search, or find previously stored information by meaning.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Natural language query' },
        top_k: { type: 'number', default: 5, description: 'Number of top results to return' },
        filter: { type: 'object', description: 'Metadata filter' }
      },
      required: ['query']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_memory_recall',
    description:
      'Recall a specific memory by ID. ' +
      'USE WHEN: The user references a specific memory ID and wants the exact record back.',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Memory ID to recall' },
        include_metadata: { type: 'boolean', default: true, description: 'Include metadata in result' }
      },
      required: ['id']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── RAG ────────────────────────────────────────────────────────────────────
  {
    name: 'soul_rag_ingest',
    description:
      'Ingest a document into the RAG knowledge base. ' +
      'USE WHEN: The user uploads or references a document (PDF, text, markdown) to add to searchable knowledge.',
    inputSchema: {
      type: 'object',
      properties: {
        source: { type: 'string', description: 'File path or URL of the document' },
        type: { type: 'string', default: 'auto', description: 'Document type: pdf, txt, md, auto' },
        metadata: { type: 'object', description: 'Optional metadata' }
      },
      required: ['source']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_rag_query',
    description:
      'Query the RAG knowledge base. ' +
      'USE WHEN: The user asks questions against previously ingested documents or wants grounded answers.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Question or query text' },
        top_k: { type: 'number', default: 5, description: 'Number of chunks to retrieve' },
        filters: { type: 'object', description: 'Metadata filters' }
      },
      required: ['query']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },

  // ─── MCP ────────────────────────────────────────────────────────────────────
  {
    name: 'soul_mcp_connect',
    description:
      'Connect to an external MCP server. ' +
      'USE WHEN: The user wants to integrate another MCP server or tool registry into Soul Commander.',
    inputSchema: {
      type: 'object',
      properties: {
        server_name: { type: 'string', description: 'Friendly name for this connection' },
        command: { type: 'string', description: 'Command to run the server (e.g. node, python)' },
        args: { type: 'array', items: { type: 'string' }, description: 'Arguments for the command' },
        env: { type: 'object', description: 'Environment variables' }
      },
      required: ['server_name']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_mcp_discover_tools',
    description:
      'Discover available tools from a connected MCP server. ' +
      'USE WHEN: The user wants to see what tools an external MCP server exposes.',
    inputSchema: {
      type: 'object',
      properties: {
        server_name: { type: 'string', description: 'Name of the connected MCP server' }
      },
      required: ['server_name']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_mcp_call_tool',
    description:
      'Call a tool on a connected MCP server. ' +
      'USE WHEN: The user wants to invoke a tool exposed by an external MCP server.',
    inputSchema: {
      type: 'object',
      properties: {
        server_name: { type: 'string', description: 'Name of the connected MCP server' },
        tool_name: { type: 'string', description: 'Tool to invoke' },
        arguments: { type: 'object', description: 'Arguments for the tool' }
      },
      required: ['server_name', 'tool_name']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── WORKFLOW ───────────────────────────────────────────────────────────────
  {
    name: 'soul_workflow_create',
    description:
      'Create a new automation workflow. ' +
      'USE WHEN: The user wants to define a pipeline, automation sequence, or scheduled task chain.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Workflow name' },
        steps: {
          type: 'array',
          items: { type: 'object' },
          description: 'Ordered list of steps/tasks'
        },
        triggers: {
          type: 'array',
          items: { type: 'object' },
          description: 'Trigger conditions (e.g. cron, webhook)'
        }
      },
      required: ['name', 'steps']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_workflow_run',
    description:
      'Execute a workflow by ID or name. ' +
      'USE WHEN: The user wants to manually trigger or run an existing workflow with inputs.',
    inputSchema: {
      type: 'object',
      properties: {
        workflow_id: { type: 'string', description: 'Workflow ID or name' },
        inputs: { type: 'object', description: 'Input parameters for the workflow' }
      },
      required: ['workflow_id']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_workflow_list',
    description:
      'List all created workflows. ' +
      'USE WHEN: The user wants to see available workflows, their status, or filter by name/tag.',
    inputSchema: {
      type: 'object',
      properties: {
        filter: { type: 'string', description: 'Name filter substring' },
        limit: { type: 'number', default: 50, description: 'Max results' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },

  // ─── CODE ───────────────────────────────────────────────────────────────────
  {
    name: 'soul_code_generate',
    description:
      'Generate code from a description. ' +
      'USE WHEN: The user asks for a function, script, API, class, module, or any code snippet.',
    inputSchema: {
      type: 'object',
      properties: {
        description: { type: 'string', description: 'What the code should do' },
        language: { type: 'string', description: 'Programming language (e.g. javascript, python, rust)' },
        context: { type: 'string', description: 'Additional context or existing code' },
        tests: { type: 'boolean', default: false, description: 'Include unit tests' }
      },
      required: ['description', 'language']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_code_analyze',
    description:
      'Analyze code for bugs, smells, complexity, or security issues. ' +
      'USE WHEN: The user wants a review, audit, or quality assessment of existing code.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', description: 'Source code to analyze' },
        language: { type: 'string', description: 'Language of the code' },
        rules: { type: 'array', items: { type: 'string' }, description: 'Specific rules or checks to run' }
      },
      required: ['code']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_code_refactor',
    description:
      'Refactor code to a target pattern or with specific instructions. ' +
      'USE WHEN: The user wants to improve, modernize, restructure, or clean up existing code.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', description: 'Source code to refactor' },
        language: { type: 'string', description: 'Language of the code' },
        target_pattern: { type: 'string', description: 'Target architecture pattern (e.g. hexagonal, DDD)' },
        instructions: { type: 'string', description: 'Natural language refactoring instructions' }
      },
      required: ['code']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_code_test',
    description:
      'Generate or run tests for code. ' +
      'USE WHEN: The user wants unit tests, integration tests, test coverage, or to validate code behavior.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', description: 'Source code to test' },
        language: { type: 'string', description: 'Programming language' },
        framework: { type: 'string', description: 'Test framework (e.g. jest, pytest, vitest)' },
        coverage: { type: 'boolean', default: false, description: 'Generate coverage report' }
      },
      required: ['code']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_code_document',
    description:
      'Generate documentation for code. ' +
      'USE WHEN: The user wants docs, README sections, API docs, or inline comments for existing code.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', description: 'Source code to document' },
        language: { type: 'string', description: 'Programming language' },
        format: { type: 'string', default: 'markdown', description: 'Output format: markdown, jsdoc, sphinx' },
        output_path: { type: 'string', description: 'Path to save documentation' }
      },
      required: ['code']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },

  // ─── LOCAL-AI ───────────────────────────────────────────────────────────────
  {
    name: 'soul_local_ai_list_models',
    description:
      'List available local/self-hosted AI models. ' +
      'USE WHEN: The user wants to know what edge or offline models are installed and ready.',
    inputSchema: {
      type: 'object',
      properties: {
        provider: { type: 'string', description: 'Provider filter: ollama, lmstudio, localai' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_local_ai_load_model',
    description:
      'Load a local AI model into memory. ' +
      'USE WHEN: The user wants to warm up or switch to a specific local model for inference.',
    inputSchema: {
      type: 'object',
      properties: {
        model_id: { type: 'string', description: 'Model identifier' },
        provider: { type: 'string', description: 'Provider: ollama, lmstudio, localai' },
        config: { type: 'object', description: 'Loading configuration (ctx size, GPU layers, etc.)' }
      },
      required: ['model_id']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_local_ai_chat',
    description:
      'Chat with a loaded local AI model. ' +
      'USE WHEN: The user wants to run inference on a self-hosted model with a prompt or conversation.',
    inputSchema: {
      type: 'object',
      properties: {
        model_id: { type: 'string', description: 'Model to chat with' },
        messages: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              role: { type: 'string' },
              content: { type: 'string' }
            }
          },
          description: 'Conversation messages'
        },
        temperature: { type: 'number', default: 0.7 },
        max_tokens: { type: 'number', default: 2048 }
      },
      required: ['model_id', 'messages']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_local_ai_check_health',
    description:
      'Check health of local AI providers. ' +
      'USE WHEN: The user wants to verify that Ollama, LM Studio, or other local backends are running.',
    inputSchema: {
      type: 'object',
      properties: {
        provider: { type: 'string', description: 'Specific provider to check' },
        endpoint: { type: 'string', description: 'Custom endpoint URL' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── STREAM ─────────────────────────────────────────────────────────────────
  {
    name: 'soul_stream_create',
    description:
      'Create a real-time data stream. ' +
      'USE WHEN: The user wants to set up an event stream, pipeline, or real-time channel.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Stream name' },
        type: { type: 'string', default: 'event', description: 'Stream type: event, kafka, websocket' },
        config: { type: 'object', description: 'Stream configuration' }
      },
      required: ['name']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_stream_publish',
    description:
      'Publish data to a stream. ' +
      'USE WHEN: The user wants to push events, messages, or records into an active stream.',
    inputSchema: {
      type: 'object',
      properties: {
        stream_id: { type: 'string', description: 'Stream identifier' },
        data: {},
        key: { type: 'string', description: 'Partition key (optional)' }
      },
      required: ['stream_id', 'data']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_stream_subscribe',
    description:
      'Subscribe to a stream to receive events. ' +
      'USE WHEN: The user wants to listen to a real-time feed or receive push events.',
    inputSchema: {
      type: 'object',
      properties: {
        stream_id: { type: 'string', description: 'Stream identifier' },
        filter: { type: 'object', description: 'Event filter criteria' }
      },
      required: ['stream_id']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_stream_process',
    description:
      'Process/transform a stream with a function. ' +
      'USE WHEN: The user wants to map, filter, aggregate, or transform stream data.',
    inputSchema: {
      type: 'object',
      properties: {
        stream_id: { type: 'string', description: 'Stream identifier' },
        transform: { type: 'string', description: 'Transformation logic or function name' },
        sink: { type: 'string', description: 'Output destination' }
      },
      required: ['stream_id']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── SECURITY ───────────────────────────────────────────────────────────────
  {
    name: 'soul_security_hash',
    description:
      'Hash data using cryptographic algorithms. ' +
      'USE WHEN: The user wants to create a digest, checksum, or hashed password/token.',
    inputSchema: {
      type: 'object',
      properties: {
        data: { type: 'string', description: 'Data to hash' },
        algorithm: { type: 'string', default: 'sha256', description: 'Hash algorithm: sha256, bcrypt, argon2' }
      },
      required: ['data']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_security_verify',
    description:
      'Verify data against a hash. ' +
      'USE WHEN: The user wants to check integrity, validate a password, or confirm a checksum.',
    inputSchema: {
      type: 'object',
      properties: {
        data: { type: 'string', description: 'Original data or candidate value' },
        hash: { type: 'string', description: 'Hash to verify against' },
        algorithm: { type: 'string', default: 'sha256', description: 'Algorithm used for hashing' }
      },
      required: ['data', 'hash']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_security_encrypt',
    description:
      'Encrypt data with a key. ' +
      'USE WHEN: The user wants to protect sensitive data at rest or in transit.',
    inputSchema: {
      type: 'object',
      properties: {
        data: { type: 'string', description: 'Plaintext data to encrypt' },
        key: { type: 'string', description: 'Encryption key' },
        algorithm: { type: 'string', default: 'aes-256-gcm', description: 'Cipher algorithm' }
      },
      required: ['data', 'key']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_security_decrypt',
    description:
      'Decrypt data with a key. ' +
      'USE WHEN: The user has encrypted data and the correct key and wants the plaintext back.',
    inputSchema: {
      type: 'object',
      properties: {
        data: { type: 'string', description: 'Encrypted data / ciphertext' },
        key: { type: 'string', description: 'Decryption key' },
        algorithm: { type: 'string', default: 'aes-256-gcm', description: 'Cipher algorithm' }
      },
      required: ['data', 'key']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_security_token',
    description:
      'Generate a signed token (JWT-style). ' +
      'USE WHEN: The user wants to create an auth token, session token, or signed payload.',
    inputSchema: {
      type: 'object',
      properties: {
        payload: { type: 'object', description: 'Token payload / claims' },
        secret: { type: 'string', description: 'Signing secret' },
        expires_in: { type: 'number', default: 3600, description: 'Expiration in seconds' },
        algorithm: { type: 'string', default: 'HS256', description: 'Signing algorithm' }
      },
      required: ['payload', 'secret']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_security_validate',
    description:
      'Validate data against a schema or rules. ' +
      'USE WHEN: The user wants input validation, schema checking, or form verification.',
    inputSchema: {
      type: 'object',
      properties: {
        data: {},
        schema: { type: 'object', description: 'JSON Schema to validate against' },
        rules: { type: 'array', items: { type: 'string' }, description: 'Custom validation rules' }
      },
      required: ['data']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── CACHE ──────────────────────────────────────────────────────────────────
  {
    name: 'soul_cache_get',
    description:
      'Retrieve a value from cache. ' +
      'USE WHEN: The user wants to read a previously cached result or config.',
    inputSchema: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'Cache key' },
        namespace: { type: 'string', default: 'default', description: 'Cache namespace' }
      },
      required: ['key']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_cache_set',
    description:
      'Store a value in cache. ' +
      'USE WHEN: The user wants to memoize, speed up future lookups, or persist a temporary result.',
    inputSchema: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'Cache key' },
        value: {},
        ttl: { type: 'number', default: 3600, description: 'Time-to-live in seconds' },
        namespace: { type: 'string', default: 'default', description: 'Cache namespace' }
      },
      required: ['key', 'value']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_cache_delete',
    description:
      'Delete a value from cache. ' +
      'USE WHEN: The user wants to invalidate, clear, or remove a cached entry.',
    inputSchema: {
      type: 'object',
      properties: {
        key: { type: 'string', description: 'Cache key' },
        namespace: { type: 'string', default: 'default', description: 'Cache namespace' }
      },
      required: ['key']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_cache_stats',
    description:
      'Get cache statistics. ' +
      'USE WHEN: The user wants to inspect cache hit rates, size, or health.',
    inputSchema: {
      type: 'object',
      properties: {
        namespace: { type: 'string', description: 'Filter by namespace (optional)' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── DEPLOY ─────────────────────────────────────────────────────────────────
  {
    name: 'soul_deploy_build',
    description:
      'Build a project for deployment. ' +
      'USE WHEN: The user wants to compile, bundle, or prepare code for release.',
    inputSchema: {
      type: 'object',
      properties: {
        project_path: { type: 'string', description: 'Path to the project root' },
        target: { type: 'string', default: 'production', description: 'Build target' },
        config: { type: 'object', description: 'Build configuration overrides' }
      },
      required: ['project_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_deploy_deploy',
    description:
      'Deploy a project to a platform. ' +
      'USE WHEN: The user wants to ship, publish, or host an application or site.',
    inputSchema: {
      type: 'object',
      properties: {
        project_path: { type: 'string', description: 'Path to the built project' },
        platform: { type: 'string', description: 'Target platform: vercel, netlify, docker, aws, etc.' },
        config: { type: 'object', description: 'Deployment configuration' }
      },
      required: ['project_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_deploy_docker',
    description:
      'Perform Docker operations. ' +
      'USE WHEN: The user wants to build an image, run a container, or manage Docker assets.',
    inputSchema: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'Action: build, run, push, stop' },
        image: { type: 'string', description: 'Image name/tag' },
        tag: { type: 'string', description: 'Image tag' },
        dockerfile: { type: 'string', description: 'Path to Dockerfile' }
      },
      required: ['action']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_deploy_static',
    description:
      'Deploy a static site. ' +
      'USE WHEN: The user wants to host HTML/CSS/JS, JAMstack, or simple static content.',
    inputSchema: {
      type: 'object',
      properties: {
        source_path: { type: 'string', description: 'Path to static files' },
        target: { type: 'string', description: 'Target: github-pages, s3, vercel, netlify' },
        config: { type: 'object', description: 'Deployment config' }
      },
      required: ['source_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── VIKKI-CONNECTOR ──────────────────────────────────────────────────────
  {
    name: 'soul_vikki_connector_connect',
    description:
      'Connect to Miss Vikki (Operator Soul). ' +
      'USE WHEN: The user wants to link with the Operator soul for project shipping or execution.',
    inputSchema: {
      type: 'object',
      properties: {
        endpoint: { type: 'string', description: 'Vikki endpoint URL' },
        auth: { type: 'object', description: 'Authentication credentials' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_vikki_connector_send',
    description:
      'Send a message or command to Miss Vikki. ' +
      'USE WHEN: The user wants to dispatch a task, context, or instruction to the Operator.',
    inputSchema: {
      type: 'object',
      properties: {
        message: { type: 'string', description: 'Message or command to send' },
        context: { type: 'object', description: 'Additional context payload' },
        channel: { type: 'string', description: 'Communication channel' }
      },
      required: ['message']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_vikki_connector_sync',
    description:
      'Sync context with Miss Vikki. ' +
      'USE WHEN: The user wants to align state, memory, or project context between Commander and Vikki.',
    inputSchema: {
      type: 'object',
      properties: {
        context: { type: 'object', description: 'Context object to synchronize' },
        direction: { type: 'string', default: 'bidirectional', description: 'Sync direction: push, pull, bidirectional' }
      },
      required: ['context']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── ARCHITECT-CONNECTOR ──────────────────────────────────────────────────
  {
    name: 'soul_architect_connector_connect',
    description:
      'Connect to Soul Architect. ' +
      'USE WHEN: The user wants to link with the Architect soul for design patterns or system analysis.',
    inputSchema: {
      type: 'object',
      properties: {
        endpoint: { type: 'string', description: 'Architect endpoint URL' },
        auth: { type: 'object', description: 'Authentication credentials' }
      }
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_architect_connector_get_pattern',
    description:
      'Get an architecture pattern from Soul Architect. ' +
      'USE WHEN: The user wants a hexagonal, DDD, CQRS, or other design pattern scaffold.',
    inputSchema: {
      type: 'object',
      properties: {
        pattern_name: { type: 'string', description: 'Pattern name: hexagonal, ddd, cqrs, microservices, etc.' },
        language: { type: 'string', description: 'Target language' },
        context: { type: 'object', description: 'Domain context' }
      },
      required: ['pattern_name']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_architect_connector_analyze',
    description:
      'Analyze a project with Soul Architect. ' +
      'USE WHEN: The user wants an architecture review, tech debt scan, or design assessment.',
    inputSchema: {
      type: 'object',
      properties: {
        project_path: { type: 'string', description: 'Path to project root' },
        depth: { type: 'string', default: 'standard', description: 'Analysis depth: quick, standard, deep' },
        focus_areas: { type: 'array', items: { type: 'string' }, description: 'Areas to focus on' }
      },
      required: ['project_path']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },

  // ─── DOCUMENT ─────────────────────────────────────────────────────────────────
  {
    name: 'soul_document_generate_report',
    description:
      'Generate a structured report. ' +
      'USE WHEN: The user wants a data report, summary, analysis document, or formatted findings.',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Report title' },
        data: {},
        format: { type: 'string', default: 'markdown', description: 'Output format: markdown, json, csv' },
        sections: { type: 'array', items: { type: 'string' }, description: 'Section names' }
      },
      required: ['title', 'data']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_document_export_pdf',
    description:
      'Export content to PDF. ' +
      'USE WHEN: The user wants to convert markdown, HTML, or data into a PDF document.',
    inputSchema: {
      type: 'object',
      properties: {
        source: { type: 'string', description: 'Source content or file path' },
        output_path: { type: 'string', description: 'Destination path' },
        options: { type: 'object', description: 'PDF options (margins, header, footer)' }
      },
      required: ['source']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },
  {
    name: 'soul_document_export_html',
    description:
      'Export content to HTML. ' +
      'USE WHEN: The user wants a styled HTML page, email template, or web-ready document.',
    inputSchema: {
      type: 'object',
      properties: {
        source: { type: 'string', description: 'Source content or file path' },
        output_path: { type: 'string', description: 'Destination path' },
        template: { type: 'string', description: 'HTML template to use' }
      },
      required: ['source']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_document_generate_slides',
    description:
      'Generate presentation slides. ' +
      'USE WHEN: The user wants a slide deck, presentation, or pitch deck from content.',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Presentation title' },
        slides: { type: 'array', items: { type: 'object' }, description: 'Slide content objects' },
        theme: { type: 'string', description: 'Visual theme name' },
        output_path: { type: 'string', description: 'Destination path' }
      },
      required: ['title', 'slides']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  },

  // ─── META / COMMANDER ───────────────────────────────────────────────────────
  {
    name: 'soul_commander_status',
    description:
      'Get Soul Commander status. ' +
      'USE WHEN: The user wants to see which powers are active, health, or mission history.',
    inputSchema: {
      type: 'object',
      properties: {}
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_commander_swarm',
    description:
      'Execute missions in parallel across powers (swarm mode). ' +
      'USE WHEN: The user wants multiple independent tasks executed simultaneously for speed.',
    inputSchema: {
      type: 'object',
      properties: {
        missions: {
          type: 'array',
          items: { type: 'object' },
          description: 'Array of mission objects with power, description, and args'
        }
      },
      required: ['missions']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_commander_chain',
    description:
      'Execute missions sequentially, passing context (chain mode). ' +
      'USE WHEN: The user wants tasks to run in order where later steps depend on earlier results.',
    inputSchema: {
      type: 'object',
      properties: {
        missions: {
          type: 'array',
          items: { type: 'object' },
          description: 'Array of mission objects'
        },
        break_on_fail: { type: 'boolean', default: true, description: 'Stop chain on first failure' }
      },
      required: ['missions']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    },
    _meta: { 'anthropic/maxResultSizeChars': 50000 }
  },
  {
    name: 'soul_commander_detect_power',
    description:
      'Auto-detect which power fits a description. ' +
      'USE WHEN: The user is unsure which tool to use and wants a recommendation.',
    inputSchema: {
      type: 'object',
      properties: {
        description: { type: 'string', description: 'Task description' }
      },
      required: ['description']
    },
    outputSchema: {
      type: 'object',
      properties: {
        output: { type: 'object' },
        error: { type: 'string' }
      }
    }
  }
];

// ── Tool Execution Map ──────────────────────────────────────────────────────
// Maps tool names to their execution strategy
const TOOL_EXEC_MAP = {
  // Vision
  soul_vision_generate:   { power: 'VISION',      desc: args => `Generate image: ${args.prompt}` },
  soul_vision_inpaint:    { power: 'VISION',      desc: args => `Inpaint image: ${args.prompt}` },
  soul_vision_upscale:    { power: 'VISION',      desc: args => `Upscale image: ${args.image_path}` },
  // Voice
  soul_voice_speak:       { power: 'VOICE',       desc: args => `TTS: ${args.text?.slice(0, 80)}` },
  soul_voice_transcribe:  { power: 'VOICE',       desc: args => `Transcribe: ${args.audio_path}` },
  soul_voice_clone:       { power: 'VOICE',       desc: args => `Clone voice from ${args.audio_samples?.length} samples` },
  // Browser
  soul_browser_launch:    { power: 'BROWSER',     desc: () => 'Launch browser' },
  soul_browser_goto:      { power: 'BROWSER',     desc: args => `Goto: ${args.url}` },
  soul_browser_screenshot:{ power: 'BROWSER',     desc: args => `Screenshot: ${args.selector || 'page'}` },
  soul_browser_scrape:    { power: 'BROWSER',     desc: args => `Scrape: ${args.url}` },
  soul_browser_pdf:       { power: 'BROWSER',     desc: args => `PDF from: ${args.url}` },
  // Memory
  soul_memory_add:        { power: 'MEMORY',      desc: args => `Add memory: ${args.content?.slice(0, 80)}` },
  soul_memory_query:      { power: 'MEMORY',      desc: args => `Query memory: ${args.query}` },
  soul_memory_recall:     { power: 'MEMORY',      desc: args => `Recall memory: ${args.id}` },
  // RAG
  soul_rag_ingest:        { power: 'RAG',         desc: args => `Ingest document: ${args.source}` },
  soul_rag_query:         { power: 'RAG',         desc: args => `RAG query: ${args.query}` },
  // MCP
  soul_mcp_connect:       { power: 'MCP',         desc: args => `Connect MCP server: ${args.server_name}` },
  soul_mcp_discover_tools:{ power: 'MCP',         desc: args => `Discover tools: ${args.server_name}` },
  soul_mcp_call_tool:     { power: 'MCP',         desc: args => `Call tool ${args.tool_name} on ${args.server_name}` },
  // Workflow
  soul_workflow_create:   { power: 'WORKFLOW',    desc: args => `Create workflow: ${args.name}` },
  soul_workflow_run:      { power: 'WORKFLOW',    desc: args => `Run workflow: ${args.workflow_id}` },
  soul_workflow_list:     { power: 'WORKFLOW',    desc: () => 'List workflows' },
  // Code
  soul_code_generate:     { power: 'CODE',        desc: args => `Generate ${args.language} code: ${args.description}` },
  soul_code_analyze:      { power: 'CODE',        desc: () => 'Analyze code' },
  soul_code_refactor:     { power: 'CODE',        desc: args => `Refactor code: ${args.instructions || args.target_pattern}` },
  soul_code_test:         { power: 'CODE',        desc: () => 'Generate tests' },
  soul_code_document:     { power: 'CODE',        desc: () => 'Document code' },
  // Local-AI
  soul_local_ai_list_models:  { power: 'LOCAL-AI', desc: () => 'List local models' },
  soul_local_ai_load_model:   { power: 'LOCAL-AI', desc: args => `Load model: ${args.model_id}` },
  soul_local_ai_chat:         { power: 'LOCAL-AI', desc: args => `Chat with ${args.model_id}` },
  soul_local_ai_check_health: { power: 'LOCAL-AI', desc: () => 'Check local AI health' },
  // Stream
  soul_stream_create:     { power: 'STREAM',      desc: args => `Create stream: ${args.name}` },
  soul_stream_publish:    { power: 'STREAM',      desc: args => `Publish to stream: ${args.stream_id}` },
  soul_stream_subscribe:  { power: 'STREAM',      desc: args => `Subscribe to stream: ${args.stream_id}` },
  soul_stream_process:    { power: 'STREAM',      desc: args => `Process stream: ${args.stream_id}` },
  // Security
  soul_security_hash:     { power: 'SECURITY',    desc: () => 'Hash data' },
  soul_security_verify:   { power: 'SECURITY',    desc: () => 'Verify hash' },
  soul_security_encrypt:  { power: 'SECURITY',    desc: () => 'Encrypt data' },
  soul_security_decrypt:  { power: 'SECURITY',    desc: () => 'Decrypt data' },
  soul_security_token:    { power: 'SECURITY',    desc: () => 'Generate token' },
  soul_security_validate: { power: 'SECURITY',    desc: () => 'Validate data' },
  // Cache
  soul_cache_get:         { power: 'CACHE',       desc: args => `Cache get: ${args.key}` },
  soul_cache_set:         { power: 'CACHE',       desc: args => `Cache set: ${args.key}` },
  soul_cache_delete:      { power: 'CACHE',       desc: args => `Cache delete: ${args.key}` },
  soul_cache_stats:       { power: 'CACHE',       desc: () => 'Cache stats' },
  // Deploy
  soul_deploy_build:      { power: 'DEPLOY',      desc: args => `Build: ${args.project_path}` },
  soul_deploy_deploy:     { power: 'DEPLOY',      desc: args => `Deploy: ${args.project_path}` },
  soul_deploy_docker:     { power: 'DEPLOY',      desc: args => `Docker ${args.action}` },
  soul_deploy_static:     { power: 'DEPLOY',      desc: args => `Static deploy: ${args.source_path}` },
  // Vikki
  soul_vikki_connector_connect: { power: 'VIKKI-CONNECTOR', desc: () => 'Connect to Vikki' },
  soul_vikki_connector_send:    { power: 'VIKKI-CONNECTOR', desc: args => `Send to Vikki: ${args.message?.slice(0, 60)}` },
  soul_vikki_connector_sync:    { power: 'VIKKI-CONNECTOR', desc: () => 'Sync context with Vikki' },
  // Architect
  soul_architect_connector_connect:    { power: 'ARCHITECT-CONNECTOR', desc: () => 'Connect to Architect' },
  soul_architect_connector_get_pattern:{ power: 'ARCHITECT-CONNECTOR', desc: args => `Get pattern: ${args.pattern_name}` },
  soul_architect_connector_analyze:    { power: 'ARCHITECT-CONNECTOR', desc: args => `Analyze project: ${args.project_path}` },
  // Document
  soul_document_generate_report: { power: 'DOCUMENT', desc: args => `Report: ${args.title}` },
  soul_document_export_pdf:      { power: 'DOCUMENT', desc: () => 'Export PDF' },
  soul_document_export_html:     { power: 'DOCUMENT', desc: () => 'Export HTML' },
  soul_document_generate_slides: { power: 'DOCUMENT', desc: args => `Slides: ${args.title}` },
};

// ── Server Class ────────────────────────────────────────────────────────────
class SoulMcpServer {
  constructor() {
    this.initialized = false;
    this.commanders = new Map(); // sessionId -> SoulCommander
    log('info', 'SoulMcpServer instantiated');
  }

  getCommander(sessionId = 'default') {
    if (!this.commanders.has(sessionId)) {
      const commander = new SoulCommander({ outputDir: './output/commander' });
      this.commanders.set(sessionId, commander);
      log('info', `SoulCommander created for session ${sessionId}`);
    }
    return this.commanders.get(sessionId);
  }

  // ── Handlers ────────────────────────────────────────────────────────────────

  async handleInitialize(id, params) {
    this.initialized = true;
    log('info', 'Initialized', { clientInfo: params?.clientInfo });

    return {
      protocolVersion: MCP_VERSION,
      capabilities: {
        tools: { listChanged: true }
      },
      serverInfo: {
        name: SERVER_NAME,
        version: SERVER_VERSION
      }
    };
  }

  async handleToolsList(id, params) {
    const cursor = params?.cursor;
    // Simple cursor support: if cursor provided, return empty to signal end
    if (cursor) {
      return { tools: [], nextCursor: undefined };
    }

    return {
      tools: TOOL_DEFINITIONS.map(t => ({
        name: t.name,
        description: t.description,
        inputSchema: t.inputSchema,
        ...(t.outputSchema ? { outputSchema: t.outputSchema } : {}),
        ...(t._meta ? { _meta: t._meta } : {})
      }))
    };
  }

  async handleToolsCall(id, params) {
    const { name, arguments: args = {}, _meta = {} } = params;
    const sessionId = _meta?.sessionId || 'default';

    log('info', `Tool call: ${name}`, { sessionId, args: Object.keys(args) });

    // Validate tool exists
    const toolDef = TOOL_DEFINITIONS.find(t => t.name === name);
    if (!toolDef) {
      return this.makeErrorResult(`Unknown tool: ${name}.`);
    }

    try {
      // Meta tools that bypass execute()
      if (name === 'soul_commander_status') {
        const commander = this.getCommander(sessionId);
        const result = commander.status();
        return this.makeSuccessResult(result, toolDef._meta);
      }

      if (name === 'soul_commander_swarm') {
        const commander = this.getCommander(sessionId);
        const result = await commander.swarm(args.missions || []);
        return this.makeSuccessResult(result, toolDef._meta);
      }

      if (name === 'soul_commander_chain') {
        const commander = this.getCommander(sessionId);
        const missions = (args.missions || []).map(m => ({
          ...m,
          breakOnFail: args.break_on_fail !== false
        }));
        const result = await commander.chain(missions);
        return this.makeSuccessResult(result, toolDef._meta);
      }

      if (name === 'soul_commander_detect_power') {
        const commander = this.getCommander(sessionId);
        const detected = commander.detectPower(args.description);
        return this.makeSuccessResult({ detected_power: detected, description: args.description }, toolDef._meta);
      }

      // Standard power delegation
      const execMap = TOOL_EXEC_MAP[name];
      if (!execMap) {
        return this.makeErrorResult(`Tool ${name} exists but has no execution mapping.`);
      }

      const commander = this.getCommander(sessionId);
      const description = typeof execMap.desc === 'function' ? execMap.desc(args) : execMap.desc;

      const mission = {
        power: execMap.power,
        description,
        ...args
      };

      const result = await commander.execute(mission);

      if (result.success === false || result.error) {
        return this.makeErrorResult(result.error || 'Execution failed', result, toolDef._meta);
      }

      return this.makeSuccessResult(result, toolDef._meta);
    } catch (err) {
      log('error', `Tool ${name} threw: ${err.message}`, { stack: err.stack });
      return this.makeErrorResult(err.message, { stack: err.stack }, toolDef._meta);
    }
  }

  // ── Result Helpers ─────────────────────────────────────────────────────────

  makeSuccessResult(data, meta = {}) {
    const content = [
      {
        type: 'text',
        text: typeof data === 'string' ? data : JSON.stringify(data, null, 2)
      }
    ];

    // If data.output exists and is an object, add structured representation hint
    if (data && typeof data === 'object') {
      content.push({
        type: 'text',
        text: `\n---structured---\n${JSON.stringify(data)}`
      });
    }

    const result = {
      content,
      isError: false
    };

    if (meta && Object.keys(meta).length > 0) {
      result._meta = meta;
    }

    return result;
  }

  makeErrorResult(message, data = null, meta = {}) {
    const content = [
      {
        type: 'text',
        text: `Error: ${message}` + (data ? `\n\nDetails:\n${JSON.stringify(data, null, 2)}` : '')
      }
    ];

    const result = {
      content,
      isError: true
    };

    if (meta && Object.keys(meta).length > 0) {
      result._meta = meta;
    }

    return result;
  }

  // ── Request Router ─────────────────────────────────────────────────────────

  async processRequest(request) {
    const { id, method, params } = request;

    // Notifications (no id)
    if (id === undefined) {
      if (method === 'notifications/initialized') {
        log('info', 'Client confirmed initialization');
        return null;
      }
      log('warn', `Unhandled notification: ${method}`);
      return null;
    }

    // Requests (has id)
    switch (method) {
      case 'initialize':
        return await this.handleInitialize(id, params);
      case 'tools/list':
        return await this.handleToolsList(id, params);
      case 'tools/call':
        return await this.handleToolsCall(id, params);
      default:
        return sendError(id, -32601, `Method not found: ${method}`);
    }
  }
}

// ── Main Entry ────────────────────────────────────────────────────────────────
async function main() {
  const server = new SoulMcpServer();

  process.stdin.setEncoding('utf8');

  let buffer = '';

  process.stdin.on('data', async (chunk) => {
    buffer += chunk;

    // Process line-delimited JSON-RPC
    let lines = buffer.split('\n');
    buffer = lines.pop(); // keep incomplete line in buffer

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      try {
        const request = JSON.parse(trimmed);

        if (request.jsonrpc !== '2.0') {
          log('warn', 'Received non-JSON-RPC 2.0 message', { raw: trimmed.slice(0, 200) });
          if (request.id !== undefined) {
            sendError(request.id, -32600, 'Invalid Request: expected jsonrpc 2.0');
          }
          continue;
        }

        log('debug', `→ ${request.method}`, { id: request.id });
        const result = await server.processRequest(request);

        // Only send response if it was a request (has id) and processRequest returned something
        if (request.id !== undefined && result !== null) {
          sendResponse(request.id, result);
          log('debug', `← ${request.method}`, { id: request.id });
        }
      } catch (err) {
        log('error', `Failed to process message: ${err.message}`, { raw: trimmed.slice(0, 200) });
        // Try to extract id for error response
        let id = null;
        try {
          const parsed = JSON.parse(trimmed);
          id = parsed.id;
        } catch {}
        if (id !== undefined && id !== null) {
          sendError(id, -32700, 'Parse error', err.message);
        }
      }
    }
  });

  process.stdin.on('end', () => {
    log('info', 'stdin closed — shutting down');
    process.exit(0);
  });

  process.stdin.on('error', (err) => {
    log('error', `stdin error: ${err.message}`);
    process.exit(1);
  });

  // Signal readiness on stderr
  log('info', `Soul Commander MCP Server ready`, { version: SERVER_VERSION, mcpVersion: MCP_VERSION });
}

main().catch((err) => {
  log('fatal', `Server crashed: ${err.message}`, { stack: err.stack });
  process.exit(1);
});
