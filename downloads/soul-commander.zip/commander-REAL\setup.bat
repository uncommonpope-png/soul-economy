@echo off
REM Soul Commander v1.0.0 — Setup Script
REM God Soul Installation

echo ==========================================
echo   SOUL COMMANDER v1.0.0 — GOD SOUL
echo   16 Superpowers from 3M+ GitHub Stars
echo ==========================================
echo.

REM Check Node.js
echo [1/5] Checking Node.js...
node --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Node.js not found. Please install Node.js 18+ from https://nodejs.org/
    exit /b 1
)
node --version

echo.
echo [2/5] Installing core dependencies...
npm install
if %ERRORLEVEL% neq 0 (
    echo WARNING: npm install failed. Continuing with core modules...
)

echo.
echo [3/5] Verifying power modules...
set "POWERS=vision voice browser memory rag mcp workflow code local-ai stream security cache deploy vikki-connector architect-connector document"
set /a MISSING=0
for %%p in (%POWERS%) do (
    if not exist "lib\powers\power-%%p.cjs" (
        echo   MISSING: power-%%p.cjs
        set /a MISSING+=1
    )
)
if %MISSING% gtr 0 (
    echo ERROR: %MISSING% power modules missing!
    exit /b 1
)
echo   All 16 power modules present.

echo.
echo [4/5] Running validation tests...
node tests/test-suite.cjs
if %ERRORLEVEL% neq 0 (
    echo WARNING: Some tests failed. Check output above.
) else (
    echo   All tests passed!
)

echo.
echo [5/5] Checking status...
node soul-commander.cjs status

echo.
echo ==========================================
echo   GOD SOUL INSTALLATION COMPLETE
echo ==========================================
echo.
echo Quick Start:
echo   node soul-commander.cjs status
echo   node examples/example-swarm.cjs
echo   node examples/example-chain.cjs
echo.
echo For auto-detect: node examples/example-auto-detect.cjs
echo.
pause
