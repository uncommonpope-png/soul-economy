const express = require('express');
const app = express();
app.use(express.json());

// Create an Express.js API with user routes
app.get('/api/resource', (req, res) => {
  res.json({ message: 'Hello from generated API' });
});

app.listen(3000, () => console.log('Server running on port 3000'));