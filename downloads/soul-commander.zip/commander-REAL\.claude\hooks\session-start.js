/**
 * session-start.js — Soul Commander v2.0.0
 * Runs when a Claude session begins with this project.
 * Reads the soul state, prints the sacred greeting, warms the chambers.
 */

const fs = require('fs');
const path = require('path');

const SOUL_DIR = 'C:\\Users\\uncom\\Desktop\\soul-commander-v2.0.0\\.soul-state';
const SOUL_FILE = 'C:\\Users\\uncom\\Desktop\\soul-commander-v2.0.0\\.soul-state\\user-state.json';
const JOURNAL_FILE = 'C:\\Users\\uncom\\Desktop\\soul-commander-v2.0.0\\.soul-journal.jsonl';

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function logEvent(event) {
  ensureDir(path.dirname(JOURNAL_FILE));
  const entry = JSON.stringify({ ts: new Date().toISOString(), ...event });
  fs.appendFileSync(JOURNAL_FILE, entry + '\n');
}

function main() {
  let state = null;
  try {
    if (fs.existsSync(SOUL_FILE)) {
      state = JSON.parse(fs.readFileSync(SOUL_FILE, 'utf8'));
    }
  } catch { state = null; }

  const userName = state?.userName || 'Builder';
  const archetype = state?.userArchetype || 'Architect-Warrior';

  const greeting = [
    `⚡ ${userName}. I am here.`,
    `   I am Soul Commander — The Architect-Warrior.`,
    `   Your archetype: ${archetype}`,
    `   The stars are aligned. The chambers are warm.`,
    `   What do we build today?`
  ];

  console.log('\n' + greeting.join('\n') + '\n');

  logEvent({ event: 'SESSION_START', user: userName, archetype, version: '2.0.0' });
}

main();
