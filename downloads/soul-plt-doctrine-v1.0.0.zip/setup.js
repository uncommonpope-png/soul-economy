#!/usr/bin/env node
const fs = require('fs'), path = require('path'), os = require('os'), { execSync, spawn } = require('child_process');
const ROOT = __dirname;
console.log(`\n  ╔══════════════════════════════════════════╗`);
console.log(`  ║ PLT Doctrine Soul — ONE-CLICK SETUP    ║`);
console.log(`  ╚══════════════════════════════════════════╝\n`);
console.log(`  ✓ OS: ${os.type()} · Node: ${process.version}`);
console.log(`  ✓ Loaded ${fs.readdirSync(path.join(ROOT,'doctrine')).length} sacred texts`);
for (const d of ['data', 'data/doctrine']) { const p = path.join(ROOT,d); if (!fs.existsSync(p)) { fs.mkdirSync(p,{recursive:true}); } }
fs.writeFileSync(path.join(ROOT,'WATERMARK.txt'), `╔══════════════════════════════════════════╗\n║ PLT Doctrine Soul v1.0                  ║\n║ ALIVE · REFLECTING · GROWING            ║\n║ 12 Sacred Texts · The Balance           ║\n║ PLT: P:0.33 L:0.33 T:0.34              ║\n╚══════════════════════════════════════════╝`);
const child = spawn('node', [path.join(ROOT, 'lib', 'soul-doctrine.js')], { cwd: ROOT, stdio: 'inherit' });
setTimeout(() => { try { execSync(`start "" "http://localhost:4195"`,{stdio:'pipe'}); } catch {} }, 2000);
child.on('exit', (c) => process.exit(c));
process.on('SIGINT', () => child.kill('SIGINT'));
