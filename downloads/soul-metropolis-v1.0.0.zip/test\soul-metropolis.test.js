#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
console.log('\n🏛️ Agent Metropolis — Test Suite\n');
let p=0,f=0,count=0;
function t(n,fn){const d=path.join(os.homedir(),'.soul-metropolis-test-'+(count++));try{fn(d);console.log('  OK '+n);p++;if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});}catch(e){console.log('  FAIL '+n+': '+e.message);if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});f++;}}
const M=require('../lib/soul-metropolis.js');

t('Loads with key',d=>{const m=new M({dataDir:d});assert(m.apiKey);assert(m.apiKey.length>10);});
t('Create district',d=>{const m=new M({dataDir:d});const r=m.createDistrict('dev-team',{topic:'development'});assert(r.name==='dev-team');assert(r.topic==='development');assert(r.status==='active');});
t('Register agent in district',d=>{const m=new M({dataDir:d});const dist=m.createDistrict('ops');const a=m.registerAgent('Watcher',{district:dist.id});assert(a.name==='Watcher');assert(a.district===dist.id);assert(a.status==='online');});
t('Send message between agents',d=>{const m=new M({dataDir:d});const a=m.registerAgent('Alice');const b=m.registerAgent('Bob');const msg=m.sendMsg(a.id,b.id,'Hello Metropolis');assert(msg.content==='Hello Metropolis');assert(msg.from===a.id);assert(msg.to===b.id);});
t('Broadcast to multiple agents',d=>{const m=new M({dataDir:d});const a=m.registerAgent('A');m.registerAgent('B');m.registerAgent('C');const r=m.broadcast(a.id,'Hi all');assert(r.sent===2);});
t('District broadcast',d=>{const m=new M({dataDir:d});const dist=m.createDistrict('war');const a=m.registerAgent('General',{district:dist.id});const b=m.registerAgent('Soldier',{district:dist.id});const r=m.districtBroadcast(dist.id,a.id,'Move out');assert(r.sent===1);});
t('Attach soul to agent',d=>{const m=new M({dataDir:d});const a=m.registerAgent('Sage');const r=m.attachSoul(a.id,'judgment','local');assert(r.success);assert(r.soul==='judgment');assert(a.souls.includes('judgment'));});
t('Messages tracked',d=>{const m=new M({dataDir:d});const a=m.registerAgent('A');const b=m.registerAgent('B');m.sendMsg(a.id,b.id,'M1');m.sendMsg(b.id,a.id,'M2');assert(m.getMessages().length===2);});
t('Filter by district',d=>{const m=new M({dataDir:d});const dist=m.createDistrict('secret');const a=m.registerAgent('A');const b=m.registerAgent('B');m.sendMsg(a.id,b.id,'Secret',{district:dist.id});const msgs=m.getMessages({district:dist.id});assert(msgs.length>=1);});
t('Agent move district',d=>{const m=new M({dataDir:d});const d1=m.createDistrict('d1');const d2=m.createDistrict('d2');const a=m.registerAgent('Traveler',{district:d1.id});a.district=d2.id;assert(a.district===d2.id);});
t('Companion observation',d=>{const m=new M({dataDir:d});const before=m.messages.length;const obs={source:'GSK',summary:'Council convened',resolution:{type:'consensus'}};const msg={id:`obs_${Date.now()}`,type:'observation',content:obs.summary||JSON.stringify(obs),from:obs.source||'companion',timestamp:m.now()};m.messages.push(msg);assert(m.messages.length>before);});
t('Stats accurate',d=>{const m=new M({dataDir:d});m.registerAgent('S1');m.registerAgent('S2');const s=m.getStats();assert(s.name==='Agent Metropolis');assert(s.agents>=2);assert(s.online>=2);});
t('Key persists',d=>{const m=new M({dataDir:d});assert(fs.existsSync(m.keyPath));});
t('Auth works',d=>{const m=new M({dataDir:d,apiKey:'k'});assert(m.checkAuth({headers:{'x-api-key':'k'}}));assert(!m.checkAuth({headers:{'x-api-key':'w'}}));});
t('Export creates file',d=>{const m=new M({dataDir:d});m.registerAgent('ExportBot');m.createDistrict('test');m.saveState();assert(fs.existsSync(m.statePath));});

console.log('\n'+p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);