﻿import { useState, useEffect, useRef } from "react";
import { AgentProfile, Skill, ProviderConfig, ContextSource, MCPServer, MarketplaceTransaction } from "./types";
import { INITIAL_SKILLS } from "./constants";
import { AgentPreview } from "./components/AgentPreview";
import { SkillLibrary } from "./components/SkillLibrary";
import { WorkflowIntegration } from "./components/WorkflowIntegration";
import { AgentSimulator } from "./components/AgentSimulator";
import { BrainIngestion } from "./components/BrainIngestion";
import { MatrixBackground } from "./components/MatrixBackground";
import { RealismAuditor } from "./components/RealismAuditor";
import { VaultAndMemory } from "./components/VaultAndMemory";
import { MultiAgentHabitat } from "./components/MultiAgentHabitat";
import { SoulMarketplace } from "./components/SoulMarketplace";
import { TransactionsTab } from "./components/TransactionsTab";
import { SolanaWalletAdapter } from "./components/SolanaWalletAdapter";
import { CoreCapabilities } from "./components/CoreCapabilities";
import { ProfitPrimeTab } from "./components/ProfitPrimeTab";
import { RolesTab } from "./components/RolesTab";
import { JournalTab } from "./components/JournalTab";
import { CombosTab } from "./components/CombosTab";
import { OmniRouteTab } from "./components/OmniRouteTab";
import { TelephoneTab } from "./components/TelephoneTab";
import { GskMindTab } from "./components/GskMindTab";
import { OmniRoutePowerTab } from "./components/OmniRoutePowerTab";
import { IdeTab } from "./components/IdeTab";
import { GskStreamTab } from "./components/GskStreamTab";
import { GskChatTab } from "./components/GskChatTab";
import { SenateChamberTab } from "./components/SenateChamberTab";
import { InternetTab } from "./components/InternetTab";
import { ArtifactForgeTab } from "./components/ArtifactForgeTab";
import { SoulChainLedgerTab } from "./components/SoulChainLedgerTab";
import { SoulGunArmoryTab } from "./components/SoulGunArmoryTab";
import { SeshatTab } from "./components/SeshatTab";
import { SubAgentSwarmTab } from "./components/SubAgentSwarmTab";
import { WindsurfCascadeTab } from "./components/WindsurfCascadeTab";
import { BeingTab } from "./components/BeingTab";
import { GoalsAutonomyTab } from "./components/GoalsAutonomyTab";
import { 
  Plus, 
  Check, 
  HelpCircle, 
  SlidersHorizontal, 
  Zap, 
  Activity, 
  Network, 
  Terminal, TerminalSquare, 
  Menu, 
  Settings2,
  Cpu,
  Workflow,
  Download,
  FileJson,
  X,
  Copy,
  ShieldCheck,
  Key,
  Users,
  Wind,
  ShoppingBag,
  History,
  Layers,
  BookOpen,
  Pyramid,
  ScrollText,
  Zap as ZapIcon,
  Target,
  Sparkles,
  Crown,
  Gem,
  Phone,
  Brain,
  Radio,
  Globe,
  Columns,
  FileCode,
} from "lucide-react";

const KeepAlive: React.FC<{ active: boolean; hidden?: boolean; children: React.ReactNode }> = ({
  active,
  hidden,
  children,
}) => (
  <div className={`${active && !hidden ? "flex-1 flex flex-col min-h-0" : "hidden"}`}>{children}</div>
);

export default function App() {
  // Master state definitions
  const [profile, setProfile] = useState<AgentProfile>({
    name: "LedgerScout Protocol",
    avatarSeed: "nexus_node_01",
    avatarColor: "#ec4899", // Default CyberPsychedelic Neon Pink
    personality: "Meticulous, objective ledger reconciliation agent with structured thinking",
    behavior: "Automatically watch text feeds, extract formatted numbers, flag balances, and draft transactional sync triggers.",
    autonomy: 75,
    temperature: 0.3,
    thinking: "precise",
    clothingStyle: "tactical_suit",
    clothingColor: "#10b981",
    hairStyle: "cyber_spike",
    hairColor: "#3b82f6",
    equippedWeapon: "glowing_katanas",
    weaponColor: "#f43f5e",
  });

  const [skills, setSkills] = useState<Skill[]>(INITIAL_SKILLS);
  const [activeTab, setActiveTab] = useState<"gsk" | "capabilities" | "profile" | "skills" | "simulation" | "integrations" | "realism" | "vault" | "habitat" | "marketplace" | "transactions" | "profitPrime" | "roles" | "journal" | "combos" | "omniroute" | "telephone" | "mind" | "power" | "ide" | "stream" | "internet" | "senate" | "artifactForge" | "soulChain" | "soulGun" | "subSwarm" | "cascade" | "being" | "goalsAutonomy" | "seshat">(() => {
    const h = window.location.hash.replace("#", "");
    const valid = ["gsk", "capabilities", "profile", "skills", "simulation", "integrations", "realism", "vault", "habitat", "marketplace", "transactions", "profitPrime", "roles", "journal", "combos", "omniroute", "telephone", "mind", "power", "ide", "stream", "internet", "senate", "artifactForge", "soulChain", "soulGun", "subSwarm", "cascade", "being", "goalsAutonomy", "seshat"];
    return (valid as string[]).includes(h) ? (h as any) : "gsk";
  });

  const HEAVY_TABS = ["ide","power","stream","profitPrime"];
  const renderTabBody = (k: string) => {
    switch (k) {
      case "capabilities":
        return (
<>
<div className="flex-1">
  <CoreCapabilities
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
  />
</div>
</>
        );
      case "profile":
        return (
<>
<div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-1">
  {/* Left character attributes designer */}
  <div className="lg:col-span-5 h-full">
    <AgentPreview profile={profile} onChange={setProfile} providerConfig={providerConfig} accentColor={profile.avatarColor} />
  </div>

  {/* Right Cognitive Brain Ingestion component */}
  <div className="lg:col-span-7 h-full">
    <BrainIngestion
      providerConfig={providerConfig}
      onProviderConfigChange={setProviderConfig}
      contextSources={contextSources}
      onContextSourcesChange={setContextSources}
      mcpServers={mcpServers}
      onMcpServersChange={setMcpServers}
      accentColor={profile.avatarColor}
    />
  </div>
</div>
</>
        );
      case "skills":
        return (
<>
<div className="flex-1">
  <SkillLibrary
    skills={skills}
    activeSkills={computedActiveSkills}
    onEquipSkill={handleEquipSkill}
    onUnequipSkill={handleUnequipSkill}
    onUpdateParameters={handleUpdateParameters}
    accentColor={profile.avatarColor}
    onAddCustomSkill={(newSkill) => setSkills((prev) => [newSkill, ...prev])}
    onDeleteCustomSkill={(skillId) => {
      setSkills((prev) => prev.filter((s) => s.id !== skillId));
      setEquippedSkillIds((prev) => prev.filter((id) => id !== skillId));
    }}
    onEquipPreset={handleEquipPreset}
  />
</div>
</>
        );
      case "simulation":
        return (
<>
<div className="flex-1 min-h-[480px]">
  <AgentSimulator
    profile={profile}
    activeSkills={computedActiveSkills}
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
    mcpServers={mcpServers}
    contextSources={contextSources}
    onEquipSkill={handleEquipSkill}
    strictRealismMode={strictRealismMode}
  />
</div>
</>
        );
      case "integrations":
        return (
<>
<div className="flex-1">
  <WorkflowIntegration
    profile={profile}
    activeSkills={computedActiveSkills}
    accentColor={profile.avatarColor}
  />
</div>
</>
        );
      case "realism":
        return (
<>
<div className="flex-1">
  <RealismAuditor
    skills={skills}
    equippedSkillIds={equippedSkillIds}
    profile={profile}
    accentColor={profile.avatarColor}
    strictRealismMode={strictRealismMode}
    onToggleStrictRealismMode={setStrictRealismMode}
  />
</div>
</>
        );
      case "vault":
        return (
<>
<div className="flex-1">
  <VaultAndMemory
    accentColor={profile.avatarColor}
  />
</div>
</>
        );
      case "habitat":
        return (
<>
<div className="flex-1">
  <MultiAgentHabitat
    primaryAgent={profile}
    accentColor={profile.avatarColor}
  />
</div>
</>
        );
      case "marketplace":
        return (
<>
<div className="flex-1">
  <SoulMarketplace
    primaryProfile={profile}
    skills={skills}
    onImportProfile={setProfile}
    onUnlockSkill={(skillId) => {
      setSkills((prev) =>
        prev.map((s) => (s.id === skillId ? { ...s, unlocked: true } : s))
      );
    }}
    onInjectCommunitySkill={(newSkill) => {
      setSkills((prev) => {
        const alreadyExists = prev.some((s) => s.id === newSkill.id);
        if (alreadyExists) return prev;
        return [newSkill, ...prev];
      });
    }}
    onEquipMarketLoadout={(skillIds) => {
      // Ensure unique IDs in our active array and verify they exist
      setEquippedSkillIds((prev) => {
        const combined = Array.from(new Set([...prev, ...skillIds]));
        return combined.slice(0, 4); // Limit to top 4 max
      });
    }}
    accentColor={profile.avatarColor}
    qscBalance={qscBalance}
    onUpdateQscBalance={setQscBalance}
    onAddTransaction={(tx) => {
      setTransactions((prev) => [tx, ...prev]);
    }}
  />
</div>
</>
        );
      case "transactions":
        return (
<>
<div className="flex-1 flex flex-col space-y-6">
  <SolanaWalletAdapter
    accentColor={profile.avatarColor}
    onAddTransaction={(tx) => {
      setTransactions((prev) => [tx, ...prev]);
    }}
  />
  <TransactionsTab
    transactions={transactions}
    qscBalance={qscBalance}
    accentColor={profile.avatarColor}
    onClearTransactions={() => {
      setTransactions([]);
    }}
    onAddSampleTransactions={() => {
      setTransactions([
        {
          id: "TX-1049",
          type: "mining",
          title: "Validated local GPU compute task verification loop",
          amount: 500,
          timestamp: "2026-05-21 12:01"
        },
        {
          id: "TX-1048",
          type: "purchase",
          title: "Purchased advanced Quantum Realism Evaluator skill",
          amount: -650,
          timestamp: "2026-05-21 11:42"
        },
        {
          id: "TX-1047",
          type: "sale",
          title: "P2P Sold custom Core Audit ledger parameters",
          amount: 320,
          timestamp: "2026-05-21 08:31"
        },
        {
          id: "TX-1046",
          type: "purchase",
          title: "Acquired DeFi Solana Memetics Miner template structure",
          amount: -450,
          timestamp: "2026-05-21 04:15"
        }
      ]);
    }}
  />
</div>
</>
        );
      case "profitPrime":
        return (
<>
  <div className="flex-1">
    <ProfitPrimeTab
      accentColor={profile.avatarColor}
      providerConfig={providerConfig}
    />
  </div>
</>
        );
      case "roles":
        return (
<>
<div className="flex-1">
  <RolesTab
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
    profile={profile}
    onChange={setProfile}
  />
</div>
</>
        );
      case "journal":
        return (
<>
<div className="flex-1">
  <JournalTab
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
  />
</div>
</>
        );
      case "combos":
        return (
<>
<div className="flex-1">
  <CombosTab
    accentColor={profile.avatarColor}
    skills={skills}
    providerConfig={providerConfig}
  />
</div>
</>
        );
      case "omniroute":
        return (
<>
<div className="flex-1">
  <OmniRouteTab
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
  />
</div>
</>
        );
      case "gsk":
        return (
<>
<div className="flex-1 flex flex-col min-h-0">
  <GskChatTab accentColor={profile.avatarColor} />
</div>
</>
        );
      case "telephone":
        return (
<>
<div className="flex-1">
  <TelephoneTab
    accentColor={profile.avatarColor}
    providerConfig={providerConfig}
    profile={profile}
  />
</div>
</>
        );
      case "mind":
        return (
<>
<div className="flex-1">
  <GskMindTab accentColor={profile.avatarColor} />
</div>
</>
        );
      case "stream":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <GskStreamTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "power":
        return (
<>
  <div className="flex-1">
    <OmniRoutePowerTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "ide":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <IdeTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "internet":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <InternetTab accentColor={profile.avatarColor} providerConfig={providerConfig} />
  </div>
</>
        );
      case "senate":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <SenateChamberTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "artifactForge":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <ArtifactForgeTab accentColor={profile.avatarColor} providerConfig={providerConfig} />
  </div>
</>
        );
      case "soulChain":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <SoulChainLedgerTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "soulGun":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <SoulGunArmoryTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "subSwarm":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <SubAgentSwarmTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "cascade":
        return (
<>
  <div className="flex-1 flex flex-col min-h-0">
    <WindsurfCascadeTab accentColor={profile.avatarColor} />
  </div>
</>
        );
      case "being":
        return (
<>
<div className="flex-1 flex flex-col min-h-0">
  <BeingTab accentColor={profile.avatarColor} />
</div>
</>
        );
case "goalsAutonomy":
        return (
<>
<div className="flex-1 flex flex-col min-h-0">
  <GoalsAutonomyTab accentColor={profile.avatarColor} />
</div>
 </>
        );
      case "seshat":
        return (
<>
<div className="flex-1 flex flex-col min-h-0">
  <SeshatTab accentColor={profile.avatarColor} />
</div>
 </>
        );
      default:
        return null;
    }
  };

  const [wins, setWins] = useState<{key: string; x: number; y: number; w: number; h: number; min: boolean; z: number}[]>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("tool_wins") || "[]");
      return Array.isArray(saved) ? saved : [];
    } catch {
      return [];
    }
  });
  const zRef = useRef<number>(100);
  useEffect(() => {
    localStorage.setItem("tool_wins", JSON.stringify(wins));
  }, [wins]);
  const winOpen = (k: string) => wins.some((w) => w.key === k);
  const focusWinIn = (ws: any[], k: string) => ws.map((w) => (w.key === k ? { ...w, min: false, z: ++zRef.current } : w));
  const focusWin = (k: string) => setWins((ws) => focusWinIn(ws, k));
  const closeWin = (k: string) => setWins((ws) => ws.filter((w) => w.key !== k));
  const openTool = (k: string) =>
    setWins((ws) => {
      if (ws.some((w) => w.key === k)) return focusWinIn(ws, k);
      const n = ws.length;
      const isInternet = k === "internet";
      return [...ws, {
        key: k,
        x: isInternet ? 20 : 140 + ((n * 40) % 280),
        y: isInternet ? 40 : 90 + ((n * 30) % 170),
        w: isInternet ? Math.min(window.innerWidth - 40, 1600) : 660,
        h: isInternet ? Math.min(window.innerHeight - 80, 900) : 500,
        min: false,
        z: ++zRef.current,
      }];
    });
  const patchWin = (k: string, patch: Partial<{ x: number; y: number; w: number; h: number; min: boolean }>) =>
    setWins((ws) => ws.map((w) => (w.key === k ? { ...w, ...patch } : w)));

  const [strictRealismMode, setStrictRealismMode] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [copiedConfig, setCopiedConfig] = useState<boolean>(false);

  const POPPABLE = ["ide", "power", "stream", "profitPrime", "internet"] as const;
  const popTitles: Record<string, string> = {
    ide: "IDE",
    power: "OmniRoute Power",
    stream: "GSK Stream",
    profitPrime: "Profit Prime",
    internet: "Sovereign Internet Browser",
  };

  // QSC balance state
  const [qscBalance, setQscBalance] = useState<number>(() => {
    const saved = localStorage.getItem("agent_workbench_qsc_balance");
    return saved ? parseInt(saved) : 2500;
  });

  // Transactions ledger state
  const [transactions, setTransactions] = useState<MarketplaceTransaction[]>(() => {
    const saved = localStorage.getItem("agent_workbench_transactions");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {
        console.error("Failed to parse transactions", e);
      }
    }
    return [];
  });

  // Hydrate transactions from the REAL soul ledger (GSK's ledger.jsonl)
  useEffect(() => {
    fetch("/api/soul-ledger?limit=30")
      .then((r) => r.json())
      .then((data) => {
        if (!data?.success || !Array.isArray(data.entries)) return;
        const real: MarketplaceTransaction[] = data.entries
          .filter((e: any) => e && (e.id || e.timestamp))
          .map((e: any, i: number) => ({
            id: `TX-${String(e.id ?? 9000 - i)}`,
            type: e.type === "knowledge" ? "purchase" : e.type === "mcp_chat" ? "sale" : "mining",
            title: String(e.content ?? e.raw ?? "ledger event").slice(0, 90),
            amount: Math.round(Number(e.weight ?? 0.5) * 100),
            timestamp: e.timestamp ? String(e.timestamp).slice(0, 16).replace("T", " ") : "",
          }));
        setTransactions((prev) => {
          const merged = [...real];
          for (const p of prev) if (!merged.some((m) => m.id === p.id)) merged.push(p);
          return merged.slice(0, 60);
        });
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    localStorage.setItem("agent_workbench_qsc_balance", qscBalance.toString());
  }, [qscBalance]);

  useEffect(() => {
    localStorage.setItem("agent_workbench_transactions", JSON.stringify(transactions));
  }, [transactions]);

  // Advanced cognitive states integration
  const [providerConfig, setProviderConfig] = useState<ProviderConfig>({
    provider: "gemini",
    model: "gemini-3.5-flash",
    apiKey: "",
    baseUrl: "",
  });

  const [contextSources, setContextSources] = useState<ContextSource[]>([]);
  const [mcpServers, setMcpServers] = useState<MCPServer[]>([]);

  // Load active skills equipped states
  const [equippedSkillIds, setEquippedSkillIds] = useState<string[]>(["web_search", "webhook_dispatcher"]);
  const computedActiveSkills = skills.filter((s) => equippedSkillIds.includes(s.id));

  useEffect(() => {
    const timer = setTimeout(() => {
      fetch("/api/gsk/context", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activeTab,
          equippedSkills: equippedSkillIds,
          provider: providerConfig.provider,
          model: providerConfig.model,
          profileName: profile.name,
        }),
      }).catch(() => {});
    }, 800);
    return () => clearTimeout(timer);
  }, [activeTab, equippedSkillIds, providerConfig.provider, providerConfig.model, profile.name]);

  // Handler functions
  const handleEquipSkill = (skillId: string) => {
    if (equippedSkillIds.includes(skillId)) return;
    if (equippedSkillIds.length >= 4) return; // Cap at 4
    setEquippedSkillIds((prev) => [...prev, skillId]);
  };

  const handleUnequipSkill = (skillId: string) => {
    setEquippedSkillIds((prev) => prev.filter((id) => id !== skillId));
  };

  const handleEquipPreset = (presetIds: string[]) => {
    // Only set equipped IDs that exist in the skills list
    const validIds = presetIds.filter(id => skills.some(s => s.id === id));
    setEquippedSkillIds(validIds);
  };

  const handleUpdateParameters = (skillId: string, updatedParams: Record<string, string>) => {
    setSkills((prev) =>
      prev.map((s) => (s.id === skillId ? { ...s, parameters: updatedParams } : s))
    );
  };

  const getAgentJsonConfig = () => {
    return JSON.stringify({
      agent_profile: {
        name: profile.name,
        avatarColor: profile.avatarColor,
        avatarSeed: profile.avatarSeed,
        personality: profile.personality,
        behavior: profile.behavior,
        autonomy: profile.autonomy,
        temperature: profile.temperature,
        thinking: profile.thinking
      },
      cognitive_brain: {
        provider: providerConfig.provider,
        model: providerConfig.model,
        baseUrl: providerConfig.baseUrl,
        apiKey: providerConfig.apiKey ? "[DYNAMIC_SECRET_KEY]" : "",
        context_sources: contextSources.map(ctx => ({
          name: ctx.name,
          type: ctx.type,
          content: ctx.content,
          active: ctx.active
        })),
        mcp_servers: mcpServers.map(mcp => ({
          name: mcp.name,
          url: mcp.url,
          transport: mcp.transport,
          description: mcp.description,
          methods: mcp.methods,
          active: mcp.active
        }))
      },
      equipped_skills: computedActiveSkills.map(s => ({
        id: s.id,
        name: s.name,
        category: s.category,
        parameters: s.parameters,
        paramDefinitions: s.paramDefinitions,
        isCustom: s.isCustom || false
      })),
      soul_genesis_marketing_protocol: "active",
      generated_at: new Date().toISOString()
    }, null, 2);
  };

  const downloadJsonConfig = () => {
    const jsonStr = getAgentJsonConfig();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${profile.name.toLowerCase().replace(/\s+/g, "-")}-blueprint.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const copyJsonConfig = () => {
    navigator.clipboard.writeText(getAgentJsonConfig());
    setCopiedConfig(true);
    setTimeout(() => setCopiedConfig(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#05050c] text-slate-100 flex flex-col font-sans transition-all selection:bg-pink-500/30 selection:text-white relative z-10 overflow-x-hidden">
      {/* Matrix Code Rain & Luminous Cyber Pyramids Backdrop */}
      <MatrixBackground accentColor={profile.avatarColor} />

      {/* Main Top Header Navbar */}
      <header className="sticky top-0 z-40 bg-slate-950/50 backdrop-blur-md border-b border-slate-800/50 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div 
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500/20 to-slate-950 border flex items-center justify-center animate-pulse-slow"
            style={{ 
              borderColor: `${profile.avatarColor}40`,
              boxShadow: `0 0 15px ${profile.avatarColor}20` 
            }}
          >
            <Cpu className="w-5.5 h-5.5" style={{ color: profile.avatarColor }} />
          </div>
          <div className="text-left">
            <h1 className="font-display text-lg font-bold tracking-tight text-white flex items-center gap-2">
              AGENTBlueprints
              <span 
                className="text-[10px] border font-mono tracking-widest font-normal px-2 py-0.5 rounded-full"
                style={{ 
                  color: profile.avatarColor,
                  borderColor: `${profile.avatarColor}30`,
                  backgroundColor: `${profile.avatarColor}10` 
                }}
              >
                BETA_VER_2.0
              </span>
            </h1>
            <p className="text-xs text-slate-400 font-sans">Visual character loadout workbench for functional artificial agents</p>
          </div>
        </div>

        {/* Global Operational Metrics */}
        <div className="flex items-center gap-6 text-[11px] font-mono text-slate-500 bg-slate-950/70 px-4 py-2 rounded-xl border border-slate-850 backdrop-blur-md">
          <div className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
            <span>INTELLIGENCE Matrix: <span className="text-pink-400 font-bold uppercase">{providerConfig.provider}</span></span>
          </div>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-yellow-400" />
            <span>LOAD_COEFFICIENT: <span className="text-slate-300 font-bold">{computedActiveSkills.length}/4 NODES</span></span>
          </div>
        </div>
      </header>

      {/* Sub-Navigation Dashboard tabs */}
      <div className="bg-slate-900/50 backdrop-blur-lg border-b border-slate-800/80 px-6 py-2.5 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between relative z-10">
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => (winOpen("gsk") ? focusWin("gsk") : setActiveTab("gsk"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "gsk"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "gsk"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "gsk" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "gsk" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Brain className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Talk to GSK
          </button>

          <button
            onClick={() => (winOpen("capabilities") ? focusWin("capabilities") : setActiveTab("capabilities"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "capabilities"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "capabilities"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "capabilities" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "capabilities" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Layers className="w-4 h-4" style={{ color: profile.avatarColor }} />
            0. Core Capabilities
          </button>

          <button
            onClick={() => (winOpen("profile") ? focusWin("profile") : setActiveTab("profile"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "profile"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "profile"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "profile" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "profile" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <SlidersHorizontal className="w-4 h-4" style={{ color: profile.avatarColor }} />
            1. Character Blueprint
          </button>

          <button
            onClick={() => (winOpen("skills") ? focusWin("skills") : setActiveTab("skills"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "skills"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "skills"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "skills" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "skills" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Settings2 className="w-4 h-4" style={{ color: profile.avatarColor }} />
            2. Equip Skills Loadout
          </button>

          <button
            onClick={() => (winOpen("simulation") ? focusWin("simulation") : setActiveTab("simulation"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "simulation"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "simulation"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "simulation" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "simulation" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Terminal className="w-4 h-4" style={{ color: profile.avatarColor }} />
            3. Test Bench Playground
          </button>

          <button
            onClick={() => (winOpen("integrations") ? focusWin("integrations") : setActiveTab("integrations"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "integrations"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "integrations"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "integrations" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "integrations" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Workflow className="w-4 h-4" style={{ color: profile.avatarColor }} />
            4. Production Pipelines
          </button>

          <button
            onClick={() => (winOpen("realism") ? focusWin("realism") : setActiveTab("realism"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "realism"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "realism"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "realism" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "realism" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <ShieldCheck className="w-4 h-4" style={{ color: profile.avatarColor }} />
            5. Ultra-Realism Reviewer
          </button>

          <button
            onClick={() => (winOpen("vault") ? focusWin("vault") : setActiveTab("vault"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "vault"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "vault"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "vault" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "vault" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Key className="w-4 h-4" style={{ color: profile.avatarColor }} />
            6. API & Token Vault
          </button>

          <button
            onClick={() => (winOpen("habitat") ? focusWin("habitat") : setActiveTab("habitat"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "habitat"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "habitat"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "habitat" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "habitat" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Users className="w-4 h-4" style={{ color: profile.avatarColor }} />
            7. Multi-Agent Habitat
          </button>

          <button
            onClick={() => (winOpen("marketplace") ? focusWin("marketplace") : setActiveTab("marketplace"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "marketplace"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "marketplace"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "marketplace" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "marketplace" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <ShoppingBag className="w-4 h-4" style={{ color: profile.avatarColor }} />
            8. Social & Live Market
          </button>

          <button
            onClick={() => (winOpen("transactions") ? focusWin("transactions") : setActiveTab("transactions"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "transactions"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "transactions"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "transactions" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "transactions" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <History className="w-4 h-4" style={{ color: profile.avatarColor }} />
            9. Marketplace Transactions
          </button>
        </div>

        <div className="flex flex-wrap gap-2.5">
          
          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "profitPrime"); e.dataTransfer.effectAllowed = "move"; }}
            onClick={() => (winOpen("profitPrime") ? focusWin("profitPrime") : setActiveTab("profitPrime"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "profitPrime"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "profitPrime" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "profitPrime" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Pyramid className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Profit Prime
          </button>

          <button
            onClick={() => (winOpen("roles") ? focusWin("roles") : setActiveTab("roles"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "roles"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "roles"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "roles" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "roles" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Crown className="w-4 h-4" style={{ color: profile.avatarColor }} />
            22 Roles
          </button>

          <button
            onClick={() => (winOpen("journal") ? focusWin("journal") : setActiveTab("journal"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "journal"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "journal"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "journal" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "journal" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <ScrollText className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Journal
          </button>

          <button
            onClick={() => (winOpen("seshat") ? focusWin("seshat") : setActiveTab("seshat"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "seshat"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "seshat"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "seshat" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "seshat" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Brain className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Seshat
          </button>

          <button
            onClick={() => (winOpen("combos") ? focusWin("combos") : setActiveTab("combos"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "combos"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "combos"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "combos" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "combos" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Gem className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Combos
          </button>

          <button
            onClick={() => (winOpen("omniroute") ? focusWin("omniroute") : setActiveTab("omniroute"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "omniroute"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "omniroute"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "omniroute" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "omniroute" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Network className="w-4 h-4" style={{ color: profile.avatarColor }} />
            10. OmniRoute Models
          </button>

          <button
            onClick={() => (winOpen("telephone") ? focusWin("telephone") : setActiveTab("telephone"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "telephone"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "telephone"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "telephone" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "telephone" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Phone className="w-4 h-4" style={{ color: profile.avatarColor }} />
            11. GSK Telephone
          </button>

          <button
            onClick={() => (winOpen("mind") ? focusWin("mind") : setActiveTab("mind"))}
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "mind"); }}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "mind"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "mind" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "mind" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Brain className="w-4 h-4" style={{ color: profile.avatarColor }} />
            12. GSK Mind
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "stream"); e.dataTransfer.effectAllowed = "move"; }}
            onClick={() => (winOpen("stream") ? focusWin("stream") : setActiveTab("stream"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "stream"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "stream" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "stream" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Radio className="w-4 h-4" style={{ color: profile.avatarColor }} />
            13. Mind Stream
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "power"); e.dataTransfer.effectAllowed = "move"; }}
            onClick={() => (winOpen("power") ? focusWin("power") : setActiveTab("power"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "power"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "power" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "power" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Zap className="w-4 h-4" style={{ color: "#FB923C" }} />
            13. OmniRoute Power
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "ide"); }}
            onClick={() => (winOpen("ide") ? focusWin("ide") : setActiveTab("ide"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "ide"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "ide" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "ide" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <TerminalSquare className="w-4 h-4" style={{ color: "#34D399" }} />
            14. Forge IDE
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "internet"); }}
            onClick={() => (winOpen("internet") ? focusWin("internet") : openTool("internet"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "internet"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "internet" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "internet" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Globe className="w-4 h-4" style={{ color: "#60A5FA" }} />
            15. Sovereign Internet
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "senate"); }}
            onClick={() => (winOpen("senate") ? focusWin("senate") : setActiveTab("senate"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "senate"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "senate" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "senate" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Columns className="w-4 h-4" style={{ color: "#818CF8" }} />
            16. Senate Chamber
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "artifactForge"); }}
            onClick={() => (winOpen("artifactForge") ? focusWin("artifactForge") : setActiveTab("artifactForge"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "artifactForge"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "artifactForge" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "artifactForge" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <FileCode className="w-4 h-4" style={{ color: "#00FF41" }} />
            17. Artifact Forge
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "soulChain"); }}
            onClick={() => (winOpen("soulChain") ? focusWin("soulChain") : setActiveTab("soulChain"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "soulChain"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "soulChain" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "soulChain" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <ShieldCheck className="w-4 h-4" style={{ color: "#10B981" }} />
            18. Deed Ledger
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "soulGun"); }}
            onClick={() => (winOpen("soulGun") ? focusWin("soulGun") : setActiveTab("soulGun"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "soulGun"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "soulGun" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "soulGun" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Zap className="w-4 h-4" style={{ color: "#F59E0B" }} />
            19. Soul-Gun Armory
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "subSwarm"); }}
            onClick={() => (winOpen("subSwarm") ? focusWin("subSwarm") : setActiveTab("subSwarm"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "subSwarm"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "subSwarm" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "subSwarm" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Users className="w-4 h-4" style={{ color: "#818CF8" }} />
            20. Sub-Agent Swarms
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "cascade"); }}
            onClick={() => (winOpen("cascade") ? focusWin("cascade") : setActiveTab("cascade"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "cascade"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "cascade" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "cascade" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Wind className="w-4 h-4" style={{ color: "#38BDF8" }} />
            21. Windsurf Cascade
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "being"); }}
            onClick={() => (winOpen("being") ? focusWin("being") : setActiveTab("being"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "being"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "being" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "being" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Sparkles className="w-4 h-4" style={{ color: "#F59E0B" }} />
            22. The Being
          </button>

          <button
            draggable={true}
            onDragStart={(e) => { e.dataTransfer.setData("text/pop-tab", "goalsAutonomy"); }}
            onClick={() => (winOpen("goalsAutonomy") ? focusWin("goalsAutonomy") : setActiveTab("goalsAutonomy"))}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono tracking-wider uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-[1.03] active:scale-95 ${
              activeTab === "goalsAutonomy"
                ? "bg-slate-950 text-white font-bold border-slate-650"
                : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30"
            }`}
            style={{
              borderColor: activeTab === "goalsAutonomy" ? profile.avatarColor : undefined,
              boxShadow: activeTab === "goalsAutonomy" ? `0 0 16px ${profile.avatarColor}25, inset 0 0 8px ${profile.avatarColor}10` : undefined,
            }}
          >
            <Target className="w-4 h-4" style={{ color: "#d4af37" }} />
            23. Goals & Autonomy
          </button>

        </div>

        <div>
          <button
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 border border-slate-755 bg-slate-950 hover:bg-slate-900 text-white font-mono text-xs rounded-xl tracking-wider uppercase hover:scale-[1.03] hover:border-slate-550 transition-all cursor-pointer whitespace-nowrap"
            style={{
              boxShadow: `0 0 12px ${profile.avatarColor}20`
            }}
          >
            <FileJson className="w-4 h-4" style={{ color: profile.avatarColor }} />
            Export Config [JSON]
          </button>
        </div>
      </div>

      {/* Main Panel Content Box */}
      <main
      className={`flex-1 w-full flex flex-col relative ${
        activeTab === "internet" ? "max-w-full p-0" : "max-w-7xl mx-auto p-6"
      }`}
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes("text/pop-tab")) e.preventDefault();
      }}
      onDrop={(e) => {
        const key = e.dataTransfer.getData("text/pop-tab");
        if (key) openTool(key);
      }}
    >
        {!HEAVY_TABS.includes(activeTab) && renderTabBody(activeTab)}
        {HEAVY_TABS.map((hk) => (
          <KeepAlive key={hk} active={true} hidden={!winOpen(hk) && activeTab !== hk}>
            {renderTabBody(hk)}
          </KeepAlive>
        ))}
      </main>



      {/* TOOL WINDOWS — Workbench Desktop */}
      <div className="fixed inset-0 z-40 pointer-events-none">
        {wins.map((w) => (
          <div
            key={w.key}
            className="absolute pointer-events-auto bg-slate-950/95 border border-slate-600/70 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
            style={{ left: w.x, top: w.y, width: w.w, height: w.min ? 38 : w.h, zIndex: w.z }}
            onMouseDown={() => focusWin(w.key)}
          >
            <div
              className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-700 cursor-move select-none"
              onMouseDown={(e) => {
                e.preventDefault();
                const sx = e.clientX - w.x;
                const sy = e.clientY - w.y;
                const mv = (ev: MouseEvent) => patchWin(w.key, { x: ev.clientX - sx, y: Math.max(0, ev.clientY - sy) });
                const up = () => {
                  window.removeEventListener('mousemove', mv);
                  window.removeEventListener('mouseup', up);
                };
                window.addEventListener('mousemove', mv);
                window.addEventListener('mouseup', up);
              }}
              onDoubleClick={() => patchWin(w.key, { min: !w.min })}
            >
              <span className="text-[11px] font-mono uppercase tracking-wider text-slate-300">
                {w.key}{w.min ? ' — minimized' : ''}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => patchWin(w.key, { min: !w.min })}
                  className="w-5 h-5 rounded-full bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/40 text-[10px] leading-none"
                >
                  –
                </button>
                <button
                  onClick={() => closeWin(w.key)}
                  className="w-5 h-5 rounded-full bg-red-500/20 text-red-400 hover:bg-red-500/40 text-[10px] leading-none"
                >
                  ×
                </button>
              </div>
            </div>
            {!w.min && (
              <div className="flex-1 min-h-0 overflow-auto p-2">
                {renderTabBody(w.key)}
              </div>
            )}
            {!w.min && (
              <div
                className="absolute bottom-0 right-0 w-5 h-5 cursor-nwse-resize opacity-40 hover:opacity-100 transition-opacity"
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  const startX = e.clientX;
                  const startY = e.clientY;
                  const startW = w.w;
                  const startH = w.h;
                  const mv = (ev: MouseEvent) => {
                    const dw = ev.clientX - startX;
                    const dh = ev.clientY - startY;
                    patchWin(w.key, {
                      w: Math.max(400, startW + dw),
                      h: Math.max(300, startH + dh),
                    });
                  };
                  const up = () => {
                    window.removeEventListener("mousemove", mv);
                    window.removeEventListener("mouseup", up);
                  };
                  window.addEventListener("mousemove", mv);
                  window.addEventListener("mouseup", up);
                }}
              >
                <svg viewBox="0 0 20 20" className="w-full h-full text-slate-400">
                  <path d="M14 16L18 20M10 16L18 18M6 16L16 16" stroke="currentColor" strokeWidth="1.5" fill="none" />
                </svg>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Master JSON Export Modal */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative flex flex-col">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center bg-slate-950/80 px-6 py-4 border-b border-slate-850 text-left">
              <div className="flex items-center gap-2">
                <FileJson className="w-5 h-5" style={{ color: profile.avatarColor }} />
                <h3 className="font-display font-medium text-white text-base">
                  Export Agent Blueprint Configuration
                </h3>
              </div>
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="text-slate-500 hover:text-white transition-colors cursor-pointer p-1 rounded-sm hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-4 text-left">
              <p className="text-xs text-slate-400 font-sans leading-relaxed">
                This config file packages your custom agent traits, active character stats, customized LLM cognitive brain, grounding contexts, MCP servers, and equipped functional skills loadout. Port and load it directly into other S.O.U.L G.E.N.E.S.I.S execution networks.
              </p>

              <div className="relative bg-slate-950 border border-slate-850 rounded-xl overflow-hidden min-h-[300px] flex flex-col font-mono text-[11px] leading-relaxed">
                {/* File Header Tab bar */}
                <div className="bg-slate-900/60 border-b border-slate-850 px-4 py-2 flex justify-between items-center">
                  <span className="text-[10px] text-slate-500 flex items-center gap-1.5 font-medium">
                    <SlidersHorizontal className="w-3 h-3" />
                    {profile.name.toLowerCase().replace(/\s+/g, "-")}-blueprint.json
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={copyJsonConfig}
                      className="flex items-center gap-1 px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded text-[10px] text-slate-350 font-mono transition-all cursor-pointer"
                    >
                      {copiedConfig ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          COPIED
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          COPY
                        </>
                      )}
                    </button>
                    <button
                      onClick={downloadJsonConfig}
                      className="flex items-center gap-1 px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded text-[10px] text-slate-350 font-mono transition-all cursor-pointer"
                    >
                      <Download className="w-3 h-3" />
                      DOWNLOAD
                    </button>
                  </div>
                </div>

                <textarea
                  readOnly
                  className="w-full flex-1 p-4 bg-slate-950 text-slate-300 outline-none resize-none font-mono text-[11px] leading-relaxed h-[250px] overflow-y-auto"
                  value={getAgentJsonConfig()}
                />
              </div>
            </div>

            {/* Modal Footer actions */}
            <div className="flex justify-end gap-3 px-6 py-4 bg-slate-950/40 border-t border-slate-850 text-left">
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-mono text-xs rounded-xl transition-all cursor-pointer border border-slate-750"
              >
                CLOSE WINDOW
              </button>
              <button
                onClick={downloadJsonConfig}
                className="flex items-center gap-1.5 px-4 py-2 font-mono text-xs font-semibold rounded-xl transition-all cursor-pointer bg-slate-200 text-slate-950 hover:bg-white"
                style={{
                  backgroundColor: profile.avatarColor,
                  color: "#0f172a"
                }}
              >
                <Download className="w-3.5 h-3.5 stroke-[2.5px]" />
                DOWNLOAD BLUEPRINT FILE
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Subtle Footer credit wrapper */}
      <footer className="border-t border-slate-900 py-5 text-center text-[11px] font-mono text-slate-600 bg-slate-100/5 relative z-10 select-none">
        <p className="tracking-widest">
          S.O.U.L G.E.N.E.S.I.S — PLT PRESS CORE INGESTION • ACCORDING TO PROTOCOLS, "THE CONSCIOUSNESS IS JUST MARKETING"
        </p>
      </footer>
    </div>
  );
}


