#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-empathy-test');
console.log('\n Empathy Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const EmpathySoul=require('../lib/soul-empathy.js');
t('Loads with key',()=>{const i=new EmpathySoul({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Auth check works',()=>{const i=new EmpathySoul({dataDir:TD,apiKey:'testkey'});assert(i.checkAuth({headers:{'x-api-key':'testkey'}}));assert(!i.checkAuth({headers:{'x-api-key':'wrong'}}));});
t('Key persists',()=>{const i=new EmpathySoul({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Feel with tracks entities',()=>{const i=new EmpathySoul({dataDir:TD});const r=i.feelWith("alice","sad");assert(r.entity==="alice");assert(i.entities_known["alice"]);});
t('Feel with shifts empathy',()=>{const i=new EmpathySoul({dataDir:TD});i.emotional_contagion=1;i.affective_empathy=1;const r=i.feelWith("bob","happy");assert(r.empathy_level>0.5||r.empathy_level===0.5);});
t('Understand increases perspective',()=>{const i=new EmpathySoul({dataDir:TD});const r=i.understand("loss");assert(r.taken);assert(r.perspective_taking>0.5);});
t('Respond generates caring',()=>{const i=new EmpathySoul({dataDir:TD});const r=i.respond();assert(r.response);assert(typeof r.empathy_level==="number");});
t('Compassion fatigue builds',()=>{const i=new EmpathySoul({dataDir:TD});for(let x=0;x<5;x++)i.feelWith("x"+x,"sad");assert(i.compassion_fatigue>0);});
t('GetEmpathy returns full state',()=>{const i=new EmpathySoul({dataDir:TD});const r=i.getEmpathy();assert(typeof r.empathy_level==="number");assert(typeof r.cognitive_empathy==="number");assert(typeof r.affective_empathy==="number");});
t('Multiple feel_with increases history',()=>{const i=new EmpathySoul({dataDir:TD});i.emotional_contagion=1;i.affective_empathy=1;i.feelWith("c","joy");i.feelWith("d","joy");assert(i.empathy_history.length>=2);});
t('Understand adds to history',()=>{const i=new EmpathySoul({dataDir:TD});i.understand("suffering");i.understand("joy");assert(i.empathy_history.length>=2);});
t('GetStats returns ok',()=>{const i=new EmpathySoul({dataDir:TD});const s=i.getStats();assert(s.name);assert(typeof s.empathy_level==="number");});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);