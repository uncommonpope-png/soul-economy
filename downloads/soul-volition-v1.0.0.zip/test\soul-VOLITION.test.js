const http = require('http');
const assert = require('assert');
const { choose, exerciseWill, reflectOnChoice, rateParalysis, state, API_KEY } = require('../lib/soul-VOLITION');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.volition_strength = 0.5;
  state.autonomy_level = 0.5;
  state.choice_paralysis = 0;
  state.choices_made = [];
  state.decision_history = [];
  state.decision_satisfactions = [];
  state.counterfactuals = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4261, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  VOLITION Chamber Tests\n');

test('choose returns one of the options', () => {
  resetState();
  const result = choose(['a', 'b', 'c']);
  assert(['a', 'b', 'c'].includes(result.choice));
  assert(result.volition_strength > 0.5);
});

test('choose requires at least 2 options', () => {
  resetState();
  const result = choose(['only']);
  assert(result.error);
});

test('choose adds to choices_made history', () => {
  resetState();
  choose(['x', 'y']);
  assert.strictEqual(state.choices_made.length, 1);
});

test('exerciseWill boosts volition_strength', () => {
  resetState();
  state.volition_strength = 0.3;
  const result = exerciseWill();
  assert(result.volition_strength > 0.3);
  assert(result.autonomy_level > 0.5);
});

test('exerciseWill reduces choice_paralysis', () => {
  resetState();
  state.choice_paralysis = 0.5;
  const result = exerciseWill();
  assert(result.choice_paralysis < 0.5);
});

test('reflectOnChoice returns satisfaction and counterfactual', () => {
  resetState();
  choose(['red', 'blue']);
  const result = reflectOnChoice(0);
  assert(result.satisfaction !== undefined);
  assert(result.counterfactual);
  assert(result.counterfactual.alternative);
});

test('reflectOnChoice with invalid index returns error', () => {
  resetState();
  const result = reflectOnChoice(99);
  assert(result.error);
});

test('rateParalysis increases paralysis with many choices', () => {
  resetState();
  choose(['a', 'b']); choose(['c', 'd']); choose(['e', 'f']);
  const result = rateParalysis();
  assert(result.choice_paralysis >= 0);
});

test('GET /ping returns 200 without auth', async () => {
  const res = await httpRequest('GET', '/ping');
  assert.strictEqual(res.status, 200);
});

test('GET /state returns 401 without auth', async () => {
  const res = await httpRequest('GET', '/state');
  assert.strictEqual(res.status, 401);
});

test('POST /choose returns choice with valid auth', async () => {
  resetState();
  const res = await httpRequest('POST', '/choose', { options: ['coffee', 'tea'] }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.choice);
});

test('POST /exercise boosts will', async () => {
  resetState();
  const res = await httpRequest('POST', '/exercise', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.volition_strength > 0.5);
});

test('POST /reflect reviews past decision', async () => {
  resetState();
  await httpRequest('POST', '/choose', { options: ['a', 'b'] }, API_KEY);
  const res = await httpRequest('POST', '/reflect', { index: 0 }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.decision);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
