const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, forgive, seekForgiveness, reconcile, letGo, server } = require('../lib/soul-forgiveness');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.forgiveness_readiness = 0.3;
  state.grudges = ['old_friend_betrayal', 'parental_disappointment'];
  state.resentments = ['workplace_injustice'];
  state.reconciliations = [];
  state.compassion_level = 0.4;
}

try {
reset();

assert.strictEqual(typeof state.forgiveness_readiness, 'number', 'forgiveness_readiness is number');
assert.strictEqual(typeof state.compassion_level, 'number', 'compassion_level is number');
assert.strictEqual(Array.isArray(state.grudges), true, 'grudges is array');
assert.ok(state.forgiveness_stages !== undefined, 'forgiveness_stages exists');
assert.ok(state.self_forgiveness !== undefined, 'self_forgiveness exists');
assert.ok(state.unforgivable_threshold !== undefined, 'unforgivable_threshold exists');
assert.strictEqual(state.grudges.length, 2, 'initial grudges count');

let r = forgive('old_friend_betrayal', 'betrayed trust');
assert.ok(r.message.includes('old_friend_betrayal'), 'forgive includes entity');
assert.ok(r.readiness > 0.3, 'forgive increases readiness');
assert.ok(r.compassion > 0.4, 'forgive increases compassion');
assert.strictEqual(state.grudges.length, 1, 'grudge removed');

r = reconcile('workplace_injustice');
assert.ok(r.message.includes('workplace_injustice'), 'reconcile includes entity');
assert.strictEqual(state.reconciliations.length, 1, 'reconciliation recorded');
assert.ok(r.compassion > 0.4, 'reconcile increases compassion');

r = seekForgiveness('myself');
assert.ok(r.message.includes('myself'), 'seek includes entity');
assert.ok(r.readiness > 0.3, 'seek increases readiness');

r = letGo();
assert.ok(r.readiness > 0.3, 'letGo increases readiness');
assert.ok(r.grudges_remaining >= 0, 'letGo reports remaining grudges');

r = forgive('', '');
assert.ok(r.error, 'forgive empty returns error');

r = reconcile('');
assert.ok(r.error, 'reconcile empty returns error');

r = seekForgiveness('');
assert.ok(r.error, 'seek empty returns error');

assert.ok(state.forgiveness_stages.hurt >= 0, 'hurt stage tracked');
assert.ok(state.self_forgiveness.shame >= 0, 'shame tracked');

const keyPath = path.join(require('os').homedir(), '.soul-forgiveness', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-forgiveness: ALL 16 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
