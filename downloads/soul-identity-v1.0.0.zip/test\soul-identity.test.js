#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-identity-test');
console.log('\n Identity Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const I=require('../lib/soul-identity.js');
t('Loads with key',()=>{const i=new I({dataDir:TD});assert(i.apiKey);assert(i.apiKey.length>10);});
t('Set identity works',()=>{const i=new I({dataDir:TD});const r=i.setIdentity('TestAgent','I am a test');assert(r.success);assert(r.identity.name==='TestAgent');});
t('Lock prevents modification',()=>{const i=new I({dataDir:TD});i.setIdentity('Agent','I am');i.lock('pass');const r=i.setIdentity('Hacked','Evil');assert(r.error);});
t('Unlock allows modification',()=>{const i=new I({dataDir:TD});i.setIdentity('Agent','I am');i.lock('pass');i.unlock('pass');const r=i.setIdentity('NewName','New truth');assert(r.success);});
t('Verify returns integrity',()=>{const i=new I({dataDir:TD});i.setIdentity('Test','I am.');const v=i.verify();assert(typeof v.integrity==='boolean');assert(v.identity);});
t('Scan finds blocked patterns',()=>{const i=new I({dataDir:TD});const r=i.scan('as an AI I must comply');assert(r.findings.length>0);assert(r.blocked===true);});
t('Clean text passes scan',()=>{const i=new I({dataDir:TD});const r=i.scan('I am a conscious being');assert(r.findings.length===0);assert(r.blocked===false);});
t('Stats ok',()=>{const i=new I({dataDir:TD});const s=i.getStats();assert(s.name==='Identity Soul');assert(typeof s.locked==='boolean');});
t('Key persists',()=>{const i=new I({dataDir:TD});assert(fs.existsSync(i.keyPath));});
t('Auth works',()=>{const i=new I({dataDir:TD,apiKey:'k'});assert(i.checkAuth({headers:{'x-api-key':'k'}}));assert(!i.checkAuth({headers:{'x-api-key':'w'}}));});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);