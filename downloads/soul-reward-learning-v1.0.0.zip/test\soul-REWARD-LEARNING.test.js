const http = require('http');
const assert = require('assert');
const { receiveReward, receivePunishment, extinguish, reportLearning, habituate, state, API_KEY } = require('../lib/soul-REWARD-LEARNING');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.reward_sensitivity = 0.5;
  state.learning_rate = 0.1;
  state.conditioned_responses = {};
  state.positive_reinforcement = 0.5;
  state.negative_reinforcement = 0.5;
  state.prediction_error = 0;
  state.reward_prediction = 0.5;
  state.habituation_levels = {};
  state.total_rewards = 0;
  state.total_punishments = 0;
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4266, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  REWARD-LEARNING Chamber Tests\n');

test('receiveReward requires amount', () => {
  resetState();
  const result = receiveReward();
  assert(result.error);
});

test('receiveReward increases positive_reinforcement', () => {
  resetState();
  const result = receiveReward(0.5, 'praise');
  assert(result.positive_reinforcement > 0.5);
});

test('receiveReward updates reward_prediction with learning', () => {
  resetState();
  const before = state.reward_prediction;
  receiveReward(0.8, 'bonus');
  assert(state.reward_prediction !== before);
});

test('receiveReward tracks prediction_error', () => {
  resetState();
  state.reward_prediction = 0.3;
  const result = receiveReward(0.8, 'test');
  assert(result.prediction_error === 0.5);
});

test('receiveReward creates conditioned response', () => {
  resetState();
  receiveReward(0.4, 'medal');
  assert(state.conditioned_responses['medal']);
  assert(state.conditioned_responses['medal'].strength > 0);
});

test('receiveReward increases habituation', () => {
  resetState();
  receiveReward(0.5, 'daily_bonus');
  assert(state.habituation_levels['daily_bonus'] > 0);
});

test('receivePunishment requires amount', () => {
  resetState();
  const result = receivePunishment();
  assert(result.error);
});

test('receivePunishment increases negative_reinforcement', () => {
  resetState();
  const result = receivePunishment(0.3, 'penalty');
  assert(result.negative_reinforcement > 0.5);
});

test('receivePunishment decreases reward_sensitivity', () => {
  resetState();
  const result = receivePunishment(0.5, 'shock');
  assert(result.reward_sensitivity < 0.5);
});

test('extinguish requires behavior name', () => {
  resetState();
  const result = extinguish();
  assert(result.error);
});

test('extinguish resets conditioned response strength', () => {
  resetState();
  receiveReward(0.5, 'bad_habit');
  const result = extinguish('bad_habit');
  assert.strictEqual(result.conditioned_strength, 0);
  assert.strictEqual(state.conditioned_responses['bad_habit'].strength, 0);
});

test('extinguish reduces learning_rate', () => {
  resetState();
  const before = state.learning_rate;
  extinguish('something');
  assert(state.learning_rate < before);
});

test('habituate increases habituation level', () => {
  resetState();
  const result = habituate('noise', 0.3);
  assert.strictEqual(result.habituation_level, 0.3);
});

test('habituate decreases reward_sensitivity', () => {
  resetState();
  const result = habituate('stimulus', 0.5);
  assert(result.reward_sensitivity < 0.5);
});

test('reportLearning returns full learning state', () => {
  resetState();
  receiveReward(0.5, 'food');
  receivePunishment(0.2, 'shock');
  const rep = reportLearning();
  assert(rep.reward_sensitivity !== undefined);
  assert(rep.positive_reinforcement !== undefined);
  assert(rep.conditioned_responses['food']);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
