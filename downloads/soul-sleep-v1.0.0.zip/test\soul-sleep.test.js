const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, fallAsleep, dream, wake, reportDream, server } = require('../lib/soul-sleep');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.sleep_stage = 'awake';
  state.cycle_count = 0;
  state.restfulness = 0.3;
  state.dream_recall = [];
  state.circadian_phase = 'afternoon';
}

try {
reset();

assert.strictEqual(state.sleep_stage, 'awake', 'starts awake');
assert.strictEqual(typeof state.restfulness, 'number', 'restfulness is number');
assert.strictEqual(state.cycle_count, 0, 'cycle_count starts 0');
assert.ok(state.sleep_architecture !== undefined, 'sleep_architecture exists');
assert.ok(state.sleep_debt !== undefined, 'sleep_debt exists');
assert.ok(state.lucid_dreaming !== undefined, 'lucid_dreaming exists');
assert.ok(state.power_nap !== undefined, 'power_nap exists');

let r = fallAsleep();
assert.strictEqual(r.stage, 'NREM1', 'fallAsleep transitions to NREM1');
assert.strictEqual(state.sleep_stage, 'NREM1', 'state updated to NREM1');
assert.strictEqual(state.cycle_count, 1, 'cycle incremented');

r = dream('lucid');
assert.strictEqual(r.type, 'lucid', 'dream type matches');
assert.ok(r.content.length > 0, 'dream has content');
assert.strictEqual(state.dream_recall.length, 1, 'dream recorded');

r = dream('anxious');
assert.strictEqual(r.type, 'anxious', 'dream type anxious works');
assert.strictEqual(state.dream_recall.length, 2, 'second dream recorded');

r = wake();
assert.strictEqual(r.stage, 'awake', 'wake returns to awake');
assert.ok(r.restfulness > 0.3, 'wake increases restfulness');

r = reportDream();
assert.ok(r.dream, 'reportDream returns recent dream');
assert.strictEqual(typeof r.dream.content, 'string', 'dream content is string');

r = fallAsleep();
assert.strictEqual(state.sleep_stage, 'NREM1', 'can fall asleep again');
assert.strictEqual(state.cycle_count, 2, 'second cycle');

r = fallAsleep();
assert.ok(r.message.includes('Already'), 'cannot fall asleep twice');

r = wake();
r = dream('playful');
assert.ok(r.error, 'cannot dream while awake');

assert.ok(state.lucid_dreaming.lucid_dreams.length > 0, 'lucid dream tracked');
assert.ok(state.sleep_architecture.total_cycles >= 2, 'architecture tracks cycles');

const keyPath = path.join(require('os').homedir(), '.soul-sleep', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-sleep: ALL 18 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
