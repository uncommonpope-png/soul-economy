#!/usr/bin/env node

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');

const TEST_DIR = path.join(os.homedir(), '.soul-scribe-test');

console.log('\n👁️ SCRIBE Soul v1.0.0 — Test Suite\n');

let passed = 0;
let failed = 0;

function test(name, fn) {
    try { fn(); console.log(`  ✓ ${name}`); passed++; }
    catch (err) { console.log(`  ✗ ${name}: ${err.message}`); failed++; }
}

if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });

const ScribeSoul = require('../lib/soul-scribe.js');

test('SCRIBE loads with API key', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    assert(s.apiKey, 'Should generate API key');
    assert(s.apiKey.length > 10, 'Key should be long enough');
});

test('SCRIBE API key persists to disk', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    const keyPath = path.join(TEST_DIR, '.key');
    assert(fs.existsSync(keyPath), 'Key file should exist');
    const stored = fs.readFileSync(keyPath, 'utf8').trim();
    assert(stored === s.apiKey, 'Stored key should match');
});

test('Fixed API key is honored', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR, apiKey: 'test-key-123' });
    assert(s.apiKey === 'test-key-123', 'Should use provided key');
});

test('Record stores a memory', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    const mem = s.record({
        type: 'observation',
        content: 'Test observation',
        tags: ['test']
    });
    assert(mem.id.startsWith('mem_'), 'Should have ID');
    assert(mem.content === 'Test observation', 'Should store content');
    assert(mem.timestamp, 'Should have timestamp');
});

test('Memories persist across instances', () => {
    const s1 = new ScribeSoul({ dataDir: TEST_DIR });
    s1.record({ content: 'Persistence test', tags: ['test'] });
    const s2 = new ScribeSoul({ dataDir: TEST_DIR });
    assert(s2.memories.length >= 1, 'Should load previous memories');
});

test('Recall finds memories', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    s.record({ content: 'Working on authentication system', tags: ['auth', 'code'] });
    const results = s.recall('authentication');
    assert(results.length > 0, 'Should find matching memories');
});

test('Auth check works correctly', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR, apiKey: 'secret-123' });
    const mockReq = { headers: { 'x-api-key': 'secret-123' } };
    const badReq = { headers: { 'x-api-key': 'wrong' } };
    const noAuthReq = { headers: {} };
    assert(s.checkAuth(mockReq) === true, 'Valid key should pass');
    assert(s.checkAuth(badReq) === false, 'Invalid key should fail');
    assert(s.checkAuth(noAuthReq) === false, 'No key should fail');
});

test('Stats returns correct structure', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    const stats = s.getStats();
    assert(stats.name === 'SCRIBE', 'Should have name');
    assert(stats.memories >= 0, 'Should count memories');
    assert(stats.skills >= 4, 'Should have skills');
    assert(stats.apiKey, 'Should show key prefix');
});

test('Export creates file', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    s.record({ content: 'Export test', tags: [] });
    const result = s.exportAll();
    assert(fs.existsSync(result.path), 'Export file should exist');
    assert(result.count > 0, 'Should export memories');
});

test('Generate ID is unique', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    const ids = new Set();
    for (let i = 0; i < 100; i++) { ids.add(s.generateId()); }
    assert(ids.size === 100, 'All 100 IDs should be unique');
});

test('Uptime increases', () => {
    const s = new ScribeSoul({ dataDir: TEST_DIR });
    const u1 = s.uptime();
    setTimeout(() => {
        const u2 = s.uptime();
        try {
            assert(u2 >= u1, 'Uptime should increase');
            console.log('  ✓ Uptime increases');
            passed++;
        } catch (err) { console.log(`  ✗ ${err.message}`); failed++; }
        cleanup();
    }, 10);
});

function cleanup() {
    if (fs.existsSync(TEST_DIR)) fs.rmSync(TEST_DIR, { recursive: true, force: true });

    console.log('\n' + '='.repeat(40));
    console.log(`Results: ${passed} passed, ${failed} failed`);
    console.log('='.repeat(40) + '\n');
    process.exit(failed > 0 ? 1 : 0);
}