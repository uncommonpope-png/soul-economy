const http = require('http');
const soul = require('../lib/soul-developmental-phase');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has phase', st.body && st.body.phase);

  // 7. POST /advance (should fail - crisis not resolved)
  const adv = await req('POST', '/advance', null, { 'x-api-key': soul.API_KEY });
  test('POST /advance without resolution returns 400', adv.status === 400);

  // 8. POST /confront
  const conf = await req('POST', '/confront', null, { 'x-api-key': soul.API_KEY });
  test('POST /confront returns 200', conf.status === 200);
  test('/confront has confronted', conf.body && conf.body.confronted === true);
  test('/confront has resolution_gain', conf.body && typeof conf.body.resolution_gain === 'number');

  // 9. POST /resolve without confronting first - reset state
  // Create fresh server state by directly manipulating
  soul.state.crisis_status = 'confronting';
  soul.state.resolution_progress = 0.9;

  const res = await req('POST', '/resolve', { insight: 'self_acceptance' }, { 'x-api-key': soul.API_KEY });
  test('POST /resolve returns 200', res.status === 200);
  test('/resolve has virtue_developed', res.body && res.body.virtue_developed);

  // 10. POST /resolve without insight still works
  soul.state.crisis_status = 'confronting';
  soul.state.resolution_progress = 0.85;
  const res2 = await req('POST', '/resolve', {}, { 'x-api-key': soul.API_KEY });
  test('POST /resolve empty body returns 200', res2.status === 200);

  // 11. POST /regress
  const reg = await req('POST', '/regress', null, { 'x-api-key': soul.API_KEY });
  test('POST /regress returns 200', reg.status === 200);
  test('/regress shows regression', reg.body && reg.body.regression_count > 0);

  // 12. GET /development
  const dev = await req('GET', '/development', null, { 'x-api-key': soul.API_KEY });
  test('GET /development returns 200', dev.status === 200);
  test('/development has current_phase', dev.body && dev.body.current_phase);
  test('/development has piaget stage', dev.body && dev.body.piaget);
  test('/development has kohlberg stage', dev.body && dev.body.kohlberg);

  // 13. advance function after resolution
  soul.state.resolution_progress = 0.9;
  const adv2 = soul.advance();
  test('advance after resolution succeeds', adv2 && !adv2.error);
  test('advance returns new_phase', adv2 && adv2.new_phase);

  // 14. confrontCrisis function
  const c2 = soul.confrontCrisis();
  test('confrontCrisis function works', c2 && c2.confronted === true);

  // 15. regress function
  const r2 = soul.regress();
  test('regress function works', r2 && r2.phase);
  test('regress counts regression', r2 && r2.regression_count > 0);

  // 16. ERIKSON_STAGES constant
  test('ERIKSON_STAGES has 8 stages', soul.ERIKSON_STAGES.length === 8);
  test('First stage is trust_vs_mistrust', soul.ERIKSON_STAGES[0].phase === 'trust_vs_mistrust');

  // 17. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
