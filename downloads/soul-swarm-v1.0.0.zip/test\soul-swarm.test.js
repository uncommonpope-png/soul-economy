#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-swarm-test');
console.log('\n Swarm Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const S=require('../lib/soul-swarm.js');
t('Loads with key',()=>{const s=new S({dataDir:TD});assert(s.apiKey);assert(s.apiKey.length>10);});
t('5 roles defined',()=>{const s=new S({dataDir:TD});assert(Object.keys(s.ROLES).length===5);assert(s.ROLES.leader);assert(s.ROLES.worker);});
t('Create swarm',()=>{const s=new S({dataDir:TD});const w=s.createSwarm('test',{size:5});assert(w.id);assert(w.agents.length===5);assert(w.status==='active');});
t('Swarm has mesh',()=>{const s=new S({dataDir:TD});const w=s.createSwarm('mesh-test',{size:4});const expected=6;assert(w.mesh.length===expected,'4 agents = '+expected+' connections');});
t('Assign task to swarm',()=>{const s=new S({dataDir:TD});const w=s.createSwarm('task-test',{size:3});const r=s.assignTask(w.id,'Build feature X');assert(r.task);assert(r.agent);assert(r.task.assignedTo===r.agent.id);});
t('Agent goes busy after task',()=>{const s=new S({dataDir:TD});const w=s.createSwarm('busy-test',{size:2});s.assignTask(w.id,'Task 1');const busy=w.agents.filter(a=>a.status==='busy').length;assert(busy>=1);});
t('Swarm status returns stats',()=>{const s=new S({dataDir:TD});const w=s.createSwarm('status-test',{size:4});const st=s.getSwarmStatus(w.id);assert(st);assert(st.size===4);assert(typeof st.avgEnergy==='number');});
t('Stats ok',()=>{const s=new S({dataDir:TD});const st=s.getStats();assert(st.name==='Swarm Soul');assert(st.swarms>=0);});
t('Key persists',()=>{const s=new S({dataDir:TD});assert(fs.existsSync(s.keyPath));});
t('Auth works',()=>{const s=new S({dataDir:TD,apiKey:'k'});assert(s.checkAuth({headers:{'x-api-key':'k'}}));assert(!s.checkAuth({headers:{'x-api-key':'w'}}));});
t('Swarms persist to disk',()=>{const d=TD+'_persist';if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});const s1=new S({dataDir:d});s1.createSwarm('persist-test');const s2=new S({dataDir:d});assert(Object.keys(s2.swarms).length>=1);fs.rmSync(d,{recursive:true,force:true});});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);