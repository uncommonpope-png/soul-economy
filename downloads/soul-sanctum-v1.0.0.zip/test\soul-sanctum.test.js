#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-sanctum-test');
console.log('\n Sanctum Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const S=require('../lib/soul-sanctum.js');
t('Loads with key',()=>{const s=new S({dataDir:TD});assert(s.apiKey);assert(s.apiKey.length>10);});
t('WS key computation works',()=>{const s=new S({dataDir:TD});const k=s.wsKey('dGhlIHNhbXBsZSBub25jZQ==');assert(k.length>10,'Should produce a key');});
t('WS frame encoding works',()=>{const s=new S({dataDir:TD});const f=s.wsFrame('Hello');assert(Buffer.isBuffer(f));assert(f.length>2);assert(f[0]===0x81);});
t('Key persists',()=>{const s=new S({dataDir:TD});assert(fs.existsSync(s.keyPath));});
t('Stats ok',()=>{const s=new S({dataDir:TD});const stats={name:'Sanctum Soul',version:'1.0.0',wsPort:4190,httpPort:4191,clients:0,ticks:0,connections:0,apiKey:s.apiKey.substring(0,8)+'...',uptime:s.uptime()};assert(stats.name==='Sanctum Soul');assert(stats.wsPort===4190);});
t('Unique IDs',()=>{const s=new S({dataDir:TD});const ids=new Set();for(let i=0;i<50;i++)ids.add(s.genId());assert(ids.size===50);});
t('Auth works',()=>{const s=new S({dataDir:TD,apiKey:'k'});const k=r=>r.headers['x-api-key']||(r.headers['authorization']||'').replace('Bearer ','');assert(k({headers:{'x-api-key':'k'}})=='k');});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);