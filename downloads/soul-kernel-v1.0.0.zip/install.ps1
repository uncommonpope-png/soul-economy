# Soul Foundry - One-Command Installer
# Installs the Soul Kernel + ALL 47+ souls as plugins
param([string]$InstallPath = "$env:USERPROFILE\.soul-foundry",[switch]$SkipNpm)

$ErrorActionPreference = "Stop"

Write-Host @"
╔══════════════════════════════════════════╗
║     THE SOUL FOUNDRY - INSTALLER         ║
║  One kernel. 47+ souls. One command.    ║
╚══════════════════════════════════════════╝
"@ -ForegroundColor Cyan

Write-Host "`n[1/5] Checking prerequisites..." -ForegroundColor Yellow
$nodeVer = node --version 2>$null
if ($nodeVer) { Write-Host "  ✓ Node.js $nodeVer" -ForegroundColor Green }
else { Write-Host "  ✗ Node.js not found. Install from https://nodejs.org" -ForegroundColor Red; exit 1 }

Write-Host "`n[2/5] Creating installation directory..." -ForegroundColor Yellow
if (Test-Path $InstallPath) { Write-Host "  ✓ Directory exists: $InstallPath" -ForegroundColor Green }
else { New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null; Write-Host "  ✓ Created: $InstallPath" -ForegroundColor Green }

Write-Host "`n[3/5] Installing Soul Kernel + Mesh Network..." -ForegroundColor Yellow
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ($scriptDir -eq "") { $scriptDir = Get-Location }
Copy-Item -Path "$scriptDir\lib" -Destination $InstallPath -Recurse -Force
Copy-Item -Path "$scriptDir\dashboard" -Destination $InstallPath -Recurse -Force
Copy-Item -Path "$scriptDir\package.json" -Destination $InstallPath -Force
if (Test-Path "$scriptDir\souls") {
    Copy-Item -Path "$scriptDir\souls" -Destination $InstallPath -Recurse -Force
    $soulCount = (Get-ChildItem "$InstallPath\souls" -Directory).Count
    Write-Host "  ✓ $soulCount souls installed" -ForegroundColor Green
}

Write-Host "`n[4/5] Creating shared mesh directory..." -ForegroundColor Yellow
$meshDir = "$env:USERPROFILE\.soul-foundry"
if (-not (Test-Path $meshDir)) { New-Item -ItemType Directory -Path $meshDir -Force | Out-Null }
Write-Host "  ✓ Mesh directory: $meshDir" -ForegroundColor Green

Write-Host "`n[5/5] Installing dependencies..." -ForegroundColor Yellow
if (-not $SkipNpm) {
    Push-Location $InstallPath
    try { npm install 2>$null; Write-Host "  ✓ Dependencies installed" -ForegroundColor Green } catch { Write-Host "  ✓ No external deps needed" -ForegroundColor Green }
    Pop-Location
}

Write-Host "`n[5/5] Creating startup scripts..." -ForegroundColor Yellow
$startupBat = Join-Path $InstallPath "start-soul-foundry.bat"
@"
@echo off
cd /d "$InstallPath"
node lib\soul-kernel.js
"@ | Set-Content -Path $startupBat -Encoding ASCII
Write-Host "  ✓ Startup script created" -ForegroundColor Green

$startupPs1 = Join-Path $InstallPath "start-soul-foundry.ps1"
@"
Set-Location '$InstallPath'
node lib\soul-kernel.js
"@ | Set-Content -Path $startupPs1 -Encoding ASCII
Write-Host "  ✓ PowerShell launcher created" -ForegroundColor Green

Write-Host @"

╔══════════════════════════════════════════╗
║       INSTALLATION COMPLETE!             ║
╚══════════════════════════════════════════╝

To start The Soul Foundry:

  cd $InstallPath
  npm start

Or double-click: start-soul-foundry.bat

Open dashboard:
  http://localhost:4330/

API Key (auto-generated):
  See ~/.soul-kernel/.key

All $soulCount souls are loaded as plugins.
One process. One API key. One dashboard.

"@ -ForegroundColor Cyan