#!/usr/bin/env node
'use strict';
const assert = require('assert');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const TEST_DIR = path.join(os.tmpdir(), 'soul-kernel-test-' + Date.now());
const SOULS_DIR = path.join(TEST_DIR, 'souls');
const DATA_DIR = path.join(TEST_DIR, 'data');
const S1_DIR = path.join(SOULS_DIR, 'test-echo');
const S2_DIR = path.join(SOULS_DIR, 'test-counter');
const S3_DIR = path.join(SOULS_DIR, 'test-broken');

console.log('\n SOUL KERNEL — Test Suite (16 tests)\n');

let p = 0, f = 0;
function t(name, fn) {
  try { fn(); console.log('  OK  ' + name); p++; }
  catch (e) { console.log('  FAIL ' + name + ': ' + e.message); f++; }
}
function tAsync(name, fn) {
  tests.push({ name, fn });
}
let tests = [];

function setupTestSouls() {
  fs.mkdirSync(path.join(S1_DIR, 'lib'), { recursive: true });
  fs.mkdirSync(path.join(S2_DIR, 'lib'), { recursive: true });
  fs.mkdirSync(path.join(S3_DIR, 'lib'), { recursive: true });

  fs.writeFileSync(path.join(S1_DIR, 'plugin.json'), JSON.stringify({
    name: 'test-echo', version: '1.0.0', displayName: 'Test Echo',
    description: 'Echo soul for testing', category: 'utility',
    port: 4101, endpoints: ['/ping', '/status', '/echo'], dependencies: [], price: 0
  }, null, 2));

  fs.writeFileSync(path.join(S2_DIR, 'plugin.json'), JSON.stringify({
    name: 'test-counter', version: '2.0.0', displayName: 'Test Counter',
    description: 'Counter soul for testing', category: 'utility',
    port: 4102, endpoints: ['/ping', '/status', '/increment'], dependencies: [], price: 1.99
  }, null, 2));

  fs.writeFileSync(path.join(S3_DIR, 'plugin.json'), JSON.stringify({
    name: 'test-broken', version: '1.0.0', displayName: 'Test Broken',
    description: 'Broken soul for testing error handling', category: 'utility',
    port: 4103, endpoints: ['/status'], dependencies: [], price: 0
  }, null, 2));

  fs.writeFileSync(path.join(S1_DIR, 'lib', 'soul-test-echo.js'), `
'use strict';
class TestEcho {
  constructor(o) {
    this.port = o.port || 4101;
    this.dataDir = o.dataDir || TEST_DIR;
    this.apiKey = o.apiKey || null;
    this.bootTime = Date.now();
  }
  ping() { return { alive: true, name: 'Test Echo' }; }
  getStats() { return { name: 'Test Echo', version: '1.0.0', uptime: Math.floor((Date.now() - this.bootTime) / 1000) }; }
  echo(body) { return { echoed: body, ts: new Date().toISOString() }; }
}
module.exports = TestEcho;
`.trim());

  fs.writeFileSync(path.join(S2_DIR, 'lib', 'soul-test-counter.js'), `
'use strict';
class TestCounter {
  constructor(o) {
    this.port = o.port || 4102;
    this.dataDir = o.dataDir || TEST_DIR;
    this.apiKey = o.apiKey || null;
    this.count = 0;
    this.bootTime = Date.now();
  }
  ping() { return { alive: true, name: 'Test Counter' }; }
  getStats() { return { name: 'Test Counter', version: '2.0.0', count: this.count }; }
  increment(body) { this.count += (body && body.amount) || 1; return { count: this.count }; }
}
module.exports = TestCounter;
`.trim());

  fs.writeFileSync(path.join(S3_DIR, 'lib', 'soul-test-broken.js'), `
'use strict';
throw new Error('Intentional load failure');
`.trim());
}

function httpRequest(port, method, urlPath, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port, path: urlPath, method, headers: headers || {} };
    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(data); } catch {}
        resolve({ status: res.statusCode, headers: res.headers, body: data, json: parsed });
      });
    });
    req.on('error', reject);
    req.end();
  });
}

let kernel, server, kernelPort;

async function runTests() {
  setupTestSouls();

  // Clear any cached modules from previous runs
  for (const key of Object.keys(require.cache)) {
    if (key.includes('soul-test-') || key.includes('soul-kernel') || key.includes('plugin-converter')) {
      delete require.cache[key];
    }
  }

  const SoulKernel = require('../lib/soul-kernel.js');
  const { convertSoul, convertAllSouls, inferCategory } = require('../lib/plugin-converter.js');

  kernel = new SoulKernel({ soulsDir: SOULS_DIR, dataDir: DATA_DIR });
  await kernel.start();
  kernelPort = kernel.server.address().port;

  // ---- SYNCHRONOUS TESTS ----
  t('1. Kernel generates API key', () => {
    assert(kernel.apiKey, 'No API key generated');
    assert(kernel.apiKey.length > 10, 'Key too short');
    assert(fs.existsSync(kernel.keyPath), 'Key file not created');
  });

  t('2. loadPlugin loads valid soul', () => {
    const plugin = kernel.loadPlugin(S1_DIR);
    assert(plugin, 'Plugin was not loaded');
    assert(plugin.instance, 'No instance created');
    assert.strictEqual(plugin.meta.name, 'test-echo');
    assert.strictEqual(plugin.status, 'online');
  });

  t('3. loadAllPlugins scans directory and loads multiple souls', () => {
    kernel.plugins.clear();
    kernel.loadAllPlugins();
    assert(kernel.plugins.has('test-echo'), 'test-echo not loaded');
    assert(kernel.plugins.has('test-counter'), 'test-counter not loaded');
  });

  t('4. Broken plugin loads with error status', () => {
    // Already loaded by loadAllPlugins - check its status
    const broken = kernel.plugins.get('test-broken');
    assert(broken, 'test-broken should be in plugins map');
    assert.strictEqual(broken.status, 'error', 'Broken plugin should have error status');
    assert(broken.error, 'Broken plugin should have error message');
  });

  // ---- ASYNC TESTS ----
  // Test 5: GET /ping
  {
    let r = await httpRequest(kernelPort, 'GET', '/ping');
    t('5. GET /ping returns alive', () => {
      assert.strictEqual(r.status, 200);
      assert(r.json.alive);
      assert.strictEqual(r.json.name, 'Soul Kernel');
    });
  }

  // Test 6: GET /status
  {
    let r = await httpRequest(kernelPort, 'GET', '/status');
    t('6. GET /status returns kernel status', () => {
      assert.strictEqual(r.status, 200);
      assert(r.json.name, 'Soul Kernel');
      assert(typeof r.json.soulsLoaded === 'number');
      assert(r.json.uptime >= 0);
    });
  }

  // Test 7: GET /souls
  {
    let r = await httpRequest(kernelPort, 'GET', '/souls');
    t('7. GET /souls returns list of loaded plugins', () => {
      assert.strictEqual(r.status, 200);
      assert(Array.isArray(r.json.souls));
      const names = r.json.souls.map(s => s.name);
      assert(names.includes('test-echo'), 'test-echo not in list');
      assert(names.includes('test-counter'), 'test-counter not in list');
    });
  }

  // Test 8: GET / returns HTML dashboard
  {
    let r = await httpRequest(kernelPort, 'GET', '/');
    t('8. GET / returns HTML dashboard', () => {
      assert.strictEqual(r.status, 200);
      assert(r.headers['content-type'] && r.headers['content-type'].includes('text/html'));
      assert(r.body.includes('Soul Kernel') || r.body.includes('dashboard'), 'Response does not look like HTML dashboard');
    });
  }

  // Test 9: Auth required - returns 401 without key
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/test-echo/status');
    t('9. Plugin endpoint returns 401 without API key', () => {
      assert.strictEqual(r.status, 401);
      assert(r.json && r.json.error);
    });
  }

  // Test 10: Auth works with correct key
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/test-echo/status', { 'X-API-Key': kernel.apiKey });
    t('10. Plugin endpoint works with correct API key', () => {
      assert.strictEqual(r.status, 200);
      assert(r.json);
    });
  }

  // Test 11: GET /soul/NAME/status returns plugin stats
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/test-echo/status', { 'X-API-Key': kernel.apiKey });
    t('11. GET /soul/test-echo/status returns soul stats', () => {
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.json.name, 'Test Echo');
    });
  }

  // Test 12: POST /soul/NAME/echo with body
  {
    let body = JSON.stringify({ message: 'hello' });
    let r = await httpRequest(kernelPort, 'POST', '/soul/test-echo/echo', { 'X-API-Key': kernel.apiKey, 'Content-Type': 'application/json' });
    // Actually need to send body for POST
    const r2 = await new Promise((resolve, reject) => {
      const opts = { hostname: 'localhost', port: kernelPort, path: '/soul/test-echo/echo', method: 'POST', headers: { 'X-API-Key': kernel.apiKey, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } };
      const req = http.request(opts, (res) => {
        let d = '';
        res.on('data', c => d += c);
        res.on('end', () => { try { resolve({ status: res.statusCode, json: JSON.parse(d) }); } catch { resolve({ status: res.statusCode, body: d }); } });
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
    t('12. POST /soul/test-echo/echo with body', () => {
      assert.strictEqual(r2.status, 200);
      assert(r2.json.echoed);
      assert.strictEqual(r2.json.echoed.message, 'hello');
    });
  }

  // Test 13: POST /soul/test-counter/increment
  {
    const body = JSON.stringify({ amount: 5 });
    const r = await new Promise((resolve, reject) => {
      const opts = { hostname: 'localhost', port: kernelPort, path: '/soul/test-counter/increment', method: 'POST', headers: { 'X-API-Key': kernel.apiKey, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } };
      const req = http.request(opts, (res) => {
        let d = '';
        res.on('data', c => d += c);
        res.on('end', () => { try { resolve({ status: res.statusCode, json: JSON.parse(d) }); } catch { resolve({ status: res.statusCode, body: d }); } });
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
    t('13. POST /soul/test-counter/increment increments counter', () => {
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.json.count, 5);
    });
  }

  // Test 14: 404 for nonexistent soul
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/nonexistent/status', { 'X-API-Key': kernel.apiKey });
    t('14. Unknown soul returns 404', () => {
      assert.strictEqual(r.status, 404);
    });
  }

  // Test 15: 404 for nonexistent endpoint on existing soul
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/test-echo/nonexistent', { 'X-API-Key': kernel.apiKey });
    t('15. Unknown endpoint on existing soul returns 404', () => {
      assert.strictEqual(r.status, 404);
    });
  }

  // Test 16: GET /soul/test-echo (info)
  {
    let r = await httpRequest(kernelPort, 'GET', '/soul/test-echo', { 'X-API-Key': kernel.apiKey });
    t('16. GET /soul/NAME returns soul info', () => {
      assert.strictEqual(r.status, 200);
      assert(r.json.name);
      assert(Array.isArray(r.json.endpoints));
    });
  }

  // Test 17: Unauthorized soul list access
  {
    let r = await httpRequest(kernelPort, 'GET', '/souls', {});
    t('17. /souls without key also returns data (public)', () => {
      // /souls is public per spec
      assert.strictEqual(r.status, 200);
    });
  }

  // Test 18: plugin-converter module exports
  t('18. plugin-converter exports functions', () => {
    assert.strictEqual(typeof convertSoul, 'function');
    assert.strictEqual(typeof convertAllSouls, 'function');
    assert.strictEqual(typeof inferCategory, 'function');
  });

  // Test 19: inferCategory returns correct category
  t('19. inferCategory categorizes soul names', () => {
    assert.strictEqual(inferCategory('meta-consciousness'), 'awareness');
    assert.strictEqual(inferCategory('teacher'), 'growth');
    assert.strictEqual(inferCategory('creativity'), 'creativity');
    assert.strictEqual(inferCategory('unknown-random'), 'uncategorized');
  });

  // Test 20: Kernel can reload plugins
  {
    // Save current plugin count
    const beforeCount = kernel.plugins.size;
    let r = await httpRequest(kernelPort, 'GET', '/reload', { 'X-API-Key': kernel.apiKey });
    t('20. GET /reload reloads all plugins', () => {
      assert.strictEqual(r.status, 200);
      assert(r.json.message === 'Reloaded');
      assert.strictEqual(kernel.plugins.size, beforeCount);
    });
  }

  // Print async test results
  console.log('\n---');
  console.log(p + '/' + (p + f) + ' tests passed\n');

  await kernel.stop();
  cleanup();
  process.exit(f > 0 ? 1 : 0);
}

function cleanup() {
  try {
    for (const key of Object.keys(require.cache)) {
      if (key.includes('soul-test-')) delete require.cache[key];
    }
    fs.rmSync(TEST_DIR, { recursive: true, force: true });
  } catch {}
}

runTests().catch(e => {
  console.log('\n  FATAL: ' + e.message + '\n');
  cleanup();
  process.exit(1);
});
