#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-consensus-test');
console.log('\n Consensus Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const C=require('../lib/soul-consensus.js');
t('Loads with key',()=>{const c=new C({dataDir:TD});assert(c.apiKey);assert(c.apiKey.length>10);});
t('Vote returns structure',()=>{const c=new C({dataDir:TD});const r=c.vote('Test');assert(r.topic);assert(r.results);assert(r.outcome);assert(r.summary);});
t('Vote has correct counts',()=>{const c=new C({dataDir:TD});const r=c.vote('Test',{voters:10});assert(r.results.length===10);assert(r.summary.total===10);assert(r.summary.for+r.summary.against===10);});
t('Outcome is valid',()=>{const c=new C({dataDir:TD});const valid=['strong_consensus','consensus','lean_against','strong_objection'];const r=c.vote('Test');assert(valid.includes(r.outcome));});
t('Key persists',()=>{const c=new C({dataDir:TD});assert(fs.existsSync(c.keyPath));});
t('Auth works',()=>{const c=new C({dataDir:TD,apiKey:'k'});assert(c.checkAuth({headers:{'x-api-key':'k'}}));assert(!c.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const c=new C({dataDir:TD});const s=c.getStats();assert(s.name==='Consensus Soul');assert(s.votes>=0);});
t('Weighted voting works',()=>{const c=new C({dataDir:TD});const r=c.vote('Test',{voters:3,weights:{voter_0:5,voter_1:1,voter_2:1}});assert(r.summary.weightedFor>0||r.summary.weightedAgainst>0);});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);