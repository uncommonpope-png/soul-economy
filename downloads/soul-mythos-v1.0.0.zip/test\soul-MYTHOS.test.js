const http = require('http');
const assert = require('assert');
const { advance, faceTrial, receiveBoon, returnFromQuest, reportMythos, state, API_KEY } = require('../lib/soul-MYTHOS');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.phase = 'VOID';
  state.phase_index = 0;
  state.cycles = 0;
  state.archetype = 'warrior';
  state.phase_transitions = [];
  state.campbell_stage = 'ordinary_world';
  state.campbell_index = 0;
  state.shadow_active = false;
  state.archetype_history = [];
  state.trials_faced = [];
  state.boons_received = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4265, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  MYTHOS Chamber Tests\n');

test('advance moves from VOID to AWAKENING', () => {
  resetState();
  const result = advance();
  assert.strictEqual(result.phase, 'AWAKENING');
  assert.strictEqual(state.phase, 'AWAKENING');
});

test('advance progresses through all phases', () => {
  resetState();
  advance(); advance(); advance(); advance();
  assert.strictEqual(state.phase, 'REVELATION');
});

test('advance activates shadow during TRIALS', () => {
  resetState();
  advance(); advance(); advance();
  assert.strictEqual(state.phase, 'TRIALS');
  assert.strictEqual(state.shadow_active, true);
});

test('advance completes a cycle at SOVEREIGNTY', () => {
  resetState();
  advance(); advance(); advance(); advance(); advance();
  assert.strictEqual(state.phase, 'INTEGRATION');
  advance();
  assert.strictEqual(state.phase, 'SOVEREIGNTY');
  assert.strictEqual(state.cycles, 1);
});

test('advance transitions campbell stage', () => {
  resetState();
  const result = advance();
  assert(result.campbell_stage !== 'ordinary_world');
});

test('faceTrial requires challenge', () => {
  resetState();
  const result = faceTrial();
  assert(result.error);
});

test('faceTrial records trial', () => {
  resetState();
  const result = faceTrial('Dragon battle');
  assert.strictEqual(state.trials_faced.length, 1);
  assert(result.trial.challenge, 'Dragon battle');
});

test('faceTrial updates campbell stage on overcome', () => {
  resetState();
  const result = faceTrial('Easy challenge');
  if (result.trial.overcome) assert(result.campbell_stage !== undefined);
});

test('receiveBoon requires gift', () => {
  resetState();
  const result = receiveBoon();
  assert(result.error);
});

test('receiveBoon adds to boons_received', () => {
  resetState();
  receiveBoon('Wisdom');
  assert.strictEqual(state.boons_received.length, 1);
  assert.strictEqual(state.boons_received[0].gift, 'Wisdom');
});

test('receiveBoon can change archetype', () => {
  resetState();
  const result = receiveBoon('Sword of truth');
  assert(result.archetype !== undefined);
});

test('returnFromQuest requires SOVEREIGNTY phase', () => {
  resetState();
  const result = returnFromQuest();
  assert(result.error);
});

test('returnFromQuest completes cycle', () => {
  resetState();
  advance(); advance(); advance(); advance(); advance(); advance();
  assert.strictEqual(state.cycles, 1);
  const result = returnFromQuest();
  assert.strictEqual(result.phase, 'VOID');
  assert.strictEqual(result.cycles, 2);
});

test('reportMythos returns full journey state', () => {
  resetState();
  const rep = reportMythos();
  assert.strictEqual(rep.phase, 'VOID');
  assert(rep.cycles !== undefined);
  assert(rep.archetype !== undefined);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
