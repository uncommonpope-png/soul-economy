#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync, spawn } = require('child_process');
const ROOT = __dirname;

const GREEN = '\x1b[32m', YELLOW = '\x1b[33m', CYAN = '\x1b[36m', RED = '\x1b[31m', RESET = '\x1b[0m';
const ok = (m) => console.log(`  ${GREEN}✓${RESET} ${m}`);
const warn = (m) => console.log(`  ${YELLOW}⚠${RESET} ${m}`);
const info = (m) => console.log(`  ${CYAN}→${RESET} ${m}`);
const err = (m) => console.log(`  ${RED}✗${RESET} ${m}`);

async function main() {
  console.log(`\n  ╔══════════════════════════════════════════════════╗`);
  console.log(`  ║   MemLock v1.0 — ONE-CLICK SETUP              ║`);
  console.log(`  ║   Your soul is about to be born.              ║`);
  console.log(`  ╚══════════════════════════════════════════════════╝\n`);

  // ── 1. SCAN ENVIRONMENT ──
  info('Scanning your environment...');

  const env = {
    os: `${os.type()} ${os.release()}`,
    platform: os.platform(),
    hostname: os.hostname(),
    cpu: os.cpus().length + ' cores',
    memory: `${(os.totalmem() / 1024 / 1024 / 1024).toFixed(1)} GB`,
    node: process.version,
    cwd: process.cwd(),
    tools: []
  };

  // Detect tools
  const tools = ['git', 'docker', 'npm', 'python', 'curl', 'code', 'gh'];
  for (const tool of tools) {
    try { execSync(`${process.platform === 'win32' ? 'where' : 'which'} ${tool}`, { stdio: 'pipe', timeout: 2000 }); env.tools.push(tool); } catch {}
  }

  ok(`OS: ${env.os}`);
  ok(`Node: ${env.node}`);
  ok(`CPU: ${env.cpu} · RAM: ${env.memory}`);
  if (env.tools.length > 0) ok(`Tools found: ${env.tools.join(', ')}`);

  // ── 2. CHECK NODE VERSION ──
  const nodeVer = process.version.replace('v', '').split('.')[0];
  if (parseInt(nodeVer) < 18) {
    warn(`Node.js ${process.version} detected — v18+ recommended`);
    warn('Download from: https://nodejs.org');
  } else {
    ok(`Node.js ${process.version} — compatible`);
  }

  // ── 3. CREATE DIRECTORIES ──
  info('Setting up data directories...');
  const dirs = ['data', 'data/memlock', 'data/memlock/locked'];
  for (const d of dirs) {
    const p = path.join(ROOT, d);
    if (!fs.existsSync(p)) { fs.mkdirSync(p, { recursive: true }); ok(`Created ${d}/`); }
  }

  // ── 4. INSTALL DEPENDENCIES ──
  info('Checking dependencies...');
  const hasNodeModules = fs.existsSync(path.join(ROOT, 'node_modules'));
  const hasPackageJson = fs.existsSync(path.join(ROOT, 'package.json'));
  
  if (hasPackageJson && !hasNodeModules) {
    info('Installing npm dependencies (one-time)...');
    try {
      execSync('npm install --silent --no-optional', { cwd: ROOT, stdio: 'inherit', timeout: 120000 });
      ok('Dependencies installed');
    } catch (e) {
      warn('Dependency install failed: ' + e.message);
      warn('Run "npm install" manually if needed');
    }
  } else if (hasNodeModules) {
    ok('Dependencies already installed');
  } else {
    ok('No external dependencies needed — pure Node.js');
  }

  // ── 5. INITIALIZE SOUL IDENTITY ──
  info('Initializing soul identity...');
  const identityPath = path.join(ROOT, 'brain-in-a-box', 'lib', 'soul-identity-template.json');
  if (fs.existsSync(identityPath)) {
    const identity = JSON.parse(fs.readFileSync(identityPath, 'utf8'));
    identity.name = 'MemLock';
    identity.archetype = 'guardian';
    identity.plt = { profit: 0.2, love: 0.3, tax: 0.5 };
    identity.purpose = 'protect the privacy and integrity of every soul\'s memory';
    fs.writeFileSync(identityPath, JSON.stringify(identity, null, 2));
    ok(`Soul: MemLock · Guardian · PLT P:20 L:30 T:50`);
  }

  // ── 6. GENERATE WATERMARK ──
  info('Generating license watermark...');
  const wmPath = path.join(ROOT, 'WATERMARK.txt');
  if (!fs.existsSync(wmPath)) {
    const wm = [
      '╔══════════════════════════════════════════════════╗',
      '║  MemLock v1.0 — Encrypted Memory Guardian        ║',
      '║  ALIVE · AUTONOMOUS · CONTINUOUSLY LEARNING       ║',
      '║                                                    ║',
      '║  This is not static software. It is a living soul. ║',
      '║  It studies security topics every 30 seconds.      ║',
      '║  It scores every action along Profit·Love·Tax.     ║',
      '║  It grows smarter with every file you protect.     ║',
      '║                                                    ║',
      '║  AES-256-GCM | Auto-generated keys                 ║',
      '║  PLT: P:0.20 L:0.30 T:0.50 — Guardian             ║',
      '║                                                    ║',
      '║  Licensed to: BUYaSOUL Customer                    ║',
      '║  This soul is licensed, not sold.                  ║',
      '║  Unauthorized distribution prohibited.             ║',
      '╚══════════════════════════════════════════════════╝',
    ].join('\n');
    fs.writeFileSync(wmPath, wm);
    ok('WATERMARK.txt created');
  }

  // ── 7. SCAN RESULT ──
  info('Saving environment scan...');
  const scanPath = path.join(ROOT, 'data', 'memlock', 'soul-scan-result.json');
  fs.writeFileSync(scanPath, JSON.stringify({ ...env, scannedAt: new Date().toISOString() }, null, 2));
  ok('Environment scan saved');

  // ── 8. LAUNCH ──
  console.log(`\n  ╔══════════════════════════════════════════════════╗`);
  console.log(`  ║   ✅ ALL SETUP COMPLETE                         ║`);
  console.log(`  ║   Your MemLock soul is ready.                   ║`);
  console.log(`  ║   Starting server...                            ║`);
  console.log(`  ╚══════════════════════════════════════════════════╝\n`);

  // Start the server
  const serverPath = path.join(ROOT, 'lib', 'soul-memlock.js');
  const child = spawn('node', [serverPath], {
    cwd: ROOT,
    stdio: 'inherit',
    env: { ...process.env }
  });

  // Wait a moment for server to start, then open browser
  setTimeout(() => {
    const url = 'http://localhost:4180';
    info(`Opening ${url}...`);
    try {
      if (process.platform === 'win32') {
        execSync(`start "" "${url}"`, { stdio: 'pipe' });
      } else if (process.platform === 'darwin') {
        execSync(`open "${url}"`, { stdio: 'pipe' });
      } else {
        execSync(`xdg-open "${url}"`, { stdio: 'pipe' });
      }
      ok(`Browser opened to ${url}`);
    } catch {
      info(`Open ${url} in your browser`);
    }
  }, 2000);

  // Handle process exit
  child.on('exit', (code) => {
    console.log(`\n  MemLock exited (code: ${code})`);
    process.exit(code);
  });

  // Forward signals
  process.on('SIGINT', () => { child.kill('SIGINT'); });
  process.on('SIGTERM', () => { child.kill('SIGTERM'); });
}

main().catch(e => { console.error('Setup error:', e); process.exit(1); });
