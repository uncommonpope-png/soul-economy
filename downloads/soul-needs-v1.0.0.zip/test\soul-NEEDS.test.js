const http = require('http');
const assert = require('assert');
const { primaryNeed, meet, decay, reportNeeds, frustrate, state, API_KEY } = require('../lib/soul-NEEDS');

let testsRun = 0;
let testsPassed = 0;

function test(name, fn) {
  testsRun++;
  try { fn(); testsPassed++; console.log(`  \u2713 ${name}`); }
  catch (e) { console.log(`  \u2717 ${name}: ${e.message}`); }
}

function resetState() {
  state.needs = { physiological: 0.5, safety: 0.5, belonging: 0.5, esteem: 0.5, cognitive: 0.3, aesthetic: 0.2, self_actualization: 0.1, transcendence: 0.1 };
  state.need_frustrations = {};
  state.need_salience = 'physiological';
  state.compensatory_behaviors = [];
}

function httpRequest(method, path, body, key) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: 4264, path, method, headers: { 'Content-Type': 'application/json' } };
    if (key) opts.headers['X-API-Key'] = key;
    const req = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

console.log('\n  NEEDS Chamber Tests\n');

test('primaryNeed returns the lowest unmet need', () => {
  resetState();
  state.needs.physiological = 0.1;
  state.needs.safety = 0.8;
  const result = primaryNeed();
  assert.strictEqual(result.primary_need, 'physiological');
  assert(result.value <= 0.1);
});

test('primaryNeed updates need_salience', () => {
  resetState();
  state.needs.physiological = 0.9;
  state.needs.safety = 0.1;
  primaryNeed();
  assert.strictEqual(state.need_salience, 'safety');
});

test('meet increases need value', () => {
  resetState();
  const result = meet('physiological', 0.3);
  assert.strictEqual(result.new_value, 0.8);
  assert.strictEqual(state.needs.physiological, 0.8);
});

test('meet caps at 1.0', () => {
  resetState();
  meet('physiological', 0.6);
  assert.strictEqual(state.needs.physiological, 1.0);
});

test('meet with invalid need type returns error', () => {
  resetState();
  const result = meet('invalid', 0.1);
  assert(result.error);
});

test('meet tracks compensatory behavior for low needs', () => {
  resetState();
  state.needs.physiological = 0.05;
  meet('physiological', 0.2);
  assert(state.compensatory_behaviors.length >= 1);
});

test('decay reduces all needs', () => {
  resetState();
  const before = state.needs.physiological;
  decay();
  assert(state.needs.physiological < before);
});

test('decay tracks frustrations for depleted needs', () => {
  resetState();
  state.needs.physiological = 0.05;
  decay();
  assert(state.need_frustrations.physiological > 0);
});

test('frustrate reduces need and records frustration', () => {
  resetState();
  const result = frustrate('esteem', 0.2);
  assert.strictEqual(result.new_value, 0.3);
  assert(result.frustration > 0);
});

test('reportNeeds returns full needs profile', () => {
  resetState();
  const rep = reportNeeds();
  assert(rep.needs.physiological !== undefined);
  assert(rep.need_salience !== undefined);
});

test('GET /needs returns needs via HTTP', async () => {
  const res = await httpRequest('GET', '/needs', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.needs);
});

test('GET /primary-need returns lowest need via HTTP', async () => {
  const res = await httpRequest('GET', '/primary-need', null, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.primary_need);
});

test('POST /meet satisfies need via HTTP', async () => {
  resetState();
  const res = await httpRequest('POST', '/meet', { need: 'belonging', amount: 0.2 }, API_KEY);
  assert.strictEqual(res.status, 200);
  assert(res.body.new_value > 0.5);
});

console.log(`\n  Results: ${testsPassed}/${testsRun} passed\n`);
process.exit(testsPassed === testsRun ? 0 : 1);
