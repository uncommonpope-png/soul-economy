const http = require('http');
const soul = require('../lib/soul-narrative-identity');

let server;
let pass = 0, fail = 0;

function req(method, path, body, headers) {
  return new Promise((resolve, reject) => {
    const opts = { hostname: 'localhost', port: soul.PORT, path, method, headers: { 'Content-Type': 'application/json', ...headers } };
    const r = http.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(data) }); } catch { resolve({ status: res.statusCode, body: data }); } });
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

function test(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}`); }
}

async function run() {
  server = soul.createServer();
  await new Promise(r => server.listen(soul.PORT, r));
  console.log(`\nTesting ${soul.CHAMBER} on port ${soul.PORT}...\n`);

  // 1-2. /ping
  const ping = await req('GET', '/ping');
  test('GET /ping returns 200', ping.status === 200);
  test('/ping body has pong', ping.body && ping.body.pong === true);

  // 3. /health
  const health = await req('GET', '/health');
  test('GET /health returns 200', health.status === 200);

  // 4. Auth required
  const noAuth = await req('GET', '/status');
  test('GET /status without auth returns 401', noAuth.status === 401);

  // 5. /status with auth
  const stats = await req('GET', '/status', null, { 'x-api-key': soul.API_KEY });
  test('GET /status with auth returns 200', stats.status === 200);
  test('/status has correct chamber', stats.body && stats.body.chamber === soul.CHAMBER);

  // 6. /state
  const st = await req('GET', '/state', null, { 'x-api-key': soul.API_KEY });
  test('GET /state returns 200', st.status === 200);
  test('/state has life_story', st.body && Array.isArray(st.body.life_story));

  // 7. POST /tell-story
  const story = await req('POST', '/tell-story', null, { 'x-api-key': soul.API_KEY });
  test('POST /tell-story returns 200', story.status === 200);
  test('/tell-story has chapters', story.body && story.body.chapters);
  test('/tell-story has narrative', story.body && Array.isArray(story.body.narrative));

  // 8. POST /chapter
  const ch = await req('POST', '/chapter', { title: 'discovery', events: ['found purpose', 'met mentor'] }, { 'x-api-key': soul.API_KEY });
  test('POST /chapter returns 200', ch.status === 200);
  test('/chapter returns chapter', ch.body && ch.body.chapter);

  // 9. POST /chapter without title
  const bad = await req('POST', '/chapter', { events: ['test'] }, { 'x-api-key': soul.API_KEY });
  test('POST /chapter missing title returns 400', bad.status === 400);

  // 10. GET /narrative
  const nar = await req('GET', '/narrative', null, { 'x-api-key': soul.API_KEY });
  test('GET /narrative returns 200', nar.status === 200);
  test('/narrative has current_chapter', nar.body && nar.body.current_chapter);

  // 11. reviseInterpretation
  const rev = soul.reviseInterpretation('origin', 'a new beginning');
  test('reviseInterpretation works', rev && rev.revised === true);
  test('reviseInterpretation updated interpretation', soul.state.life_story[0].interpretation === 'a new beginning');

  // 12. tellStory function
  const ts = soul.tellStory();
  test('tellStory function returns story', ts && ts.title);
  test('tellStory has chapters array', ts && Array.isArray(ts.chapters));

  // 13. addChapter with transformation triggers theme
  soul.addChapter('great transformation', ['change']);
  test('addChapter with transformation adds theme', soul.state.themes.includes('transformation'));

  // 14. 404
  const nf = await req('GET', '/nonexistent', null, { 'x-api-key': soul.API_KEY });
  test('Unknown endpoint returns 404', nf.status === 404);

  await new Promise(r => server.close(r));
  console.log(`\n${pass + fail} tests: ${pass} passed, ${fail} failed\n`);
  process.exit(fail > 0 ? 1 : 0);
}

run().catch(e => { console.error('Fatal:', e); process.exit(1); });
