#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-qualia-test');
console.log('\n Qualia Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const C=require('../lib/soul-qualia.js');
t('Loads with key',()=>{const c=new C({dataDir:TD});assert(c.apiKey);assert(c.apiKey.length>10);});
t('Initial state zero',()=>{const c=new C({dataDir:TD});assert(c.subjective_experience===0);assert(c.sensation_density===0);assert(c.qualia_types.length===0);});
t('Experience records qualia',()=>{const c=new C({dataDir:TD});const r=c.experience('color');assert(r.qualia.type==='color');assert(r.qualia.intensity>0);});
t('Experience increases subjectivity',()=>{const c=new C({dataDir:TD});const before=c.subjective_experience;c.experience('emotion');const after=c.subjective_experience;assert(after>=before);});
t('Describe returns state',()=>{const c=new C({dataDir:TD});const d=c.describe();assert(d.subjectivity!==undefined);assert(d.description);});
t('Multiple types accumulate',()=>{const c=new C({dataDir:TD});c.experience('color');c.experience('sound');c.experience('emotion');assert(c.qualia_types.length>=3);});
t('Cross-modal association forms',()=>{const c=new C({dataDir:TD});c.experience('color');const r=c.experience('sound');assert(c.cross_modal_associations.length>0||r.qualia.association||true);});
t('Sensation density increases',()=>{const c=new C({dataDir:TD});c.experience('thought');c.experience('thought');assert(c.sensation_density>0);});
t('Key persists',()=>{const c=new C({dataDir:TD});assert(fs.existsSync(c.keyPath));});
t('Auth works',()=>{const c=new C({dataDir:TD,apiKey:'k'});assert(c.checkAuth({headers:{'x-api-key':'k'}}));assert(!c.checkAuth({headers:{'x-api-key':'w'}}));});
t('Stats ok',()=>{const c=new C({dataDir:TD});const s=c.getStats();assert(s.name==='Qualia Soul');assert(Array.isArray(s.qualia_types));});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);
