const assert = require('assert');
const path = require('path');
const fs = require('fs');

const { state, evaluate, reason, choose, reflectOnChoice, server } = require('../lib/soul-moral');

function shutdown() { try { server.close(); } catch {} }

function reset() {
  state.moral_stage = 'conventional';
  state.ethical_framework = 'deontology';
  state.moral_dilemmas = [
    { id: 1, scenario: 'trolley_problem', resolved: false, framework_used: null },
    { id: 2, scenario: 'lying_to_protect', resolved: false, framework_used: null },
  ];
}

try {
reset();

assert.strictEqual(state.moral_stage, 'conventional', 'starts at conventional');
assert.strictEqual(state.ethical_framework, 'deontology', 'starts with deontology');
assert.ok(state.kohlberg !== undefined, 'kohlberg exists');
assert.ok(state.haidt_foundations !== undefined, 'haidt foundations exist');
assert.ok(state.haidt_foundations.care !== undefined, 'care foundation exists');
assert.ok(state.haidt_foundations.fairness !== undefined, 'fairness foundation exists');
assert.ok(state.haidt_foundations.loyalty !== undefined, 'loyalty foundation exists');
assert.ok(state.haidt_foundations.authority !== undefined, 'authority foundation exists');
assert.ok(state.haidt_foundations.sanctity !== undefined, 'sanctity foundation exists');
assert.ok(state.moral_dumbfounding !== undefined, 'moral dumbfounding exists');
assert.ok(state.ethical_tradeoffs.length > 0, 'ethical tradeoffs exist');

let r = evaluate('honesty', 'business_deal');
assert.strictEqual(r.action, 'honesty', 'evaluate returns action');
assert.ok(r.judgment, 'evaluate has judgment');
assert.strictEqual(r.framework, 'deontology', 'uses deontology');

r = reason('euthanasia_dilemma');
assert.ok(r.message.includes('euthanasia_dilemma'), 'reason includes dilemma');
assert.ok(r.perspective.length > 0, 'reason provides perspective');

r = choose('utilitarianism');
assert.strictEqual(r.framework, 'utilitarianism', 'framework changed to utilitarianism');
assert.strictEqual(state.ethical_framework, 'utilitarianism', 'state updated');

r = evaluate('deception', 'wartime');
assert.strictEqual(r.framework, 'utilitarianism', 'now using utilitarianism');

r = choose('virtue');
assert.strictEqual(state.ethical_framework, 'virtue', 'changed to virtue');

r = choose('invalid');
assert.ok(r.error, 'choose invalid returns error');

r = evaluate('compassion', 'hospital');
assert.strictEqual(r.framework, 'virtue', 'now using virtue ethics');

r = reflectOnChoice(1);
assert.ok(r.dilemma, 'reflectOnChoice returns dilemma');
assert.ok(r.intuitive_foundations, 'reflect returns haidt foundations');

r = evaluate('');
assert.ok(r.error, 'evaluate empty returns error');

r = reason('');
assert.ok(r.error, 'reason empty returns error');

const keyPath = path.join(require('os').homedir(), '.soul-moral', '.key');
assert.ok(fs.existsSync(keyPath), 'API key file exists');

console.log('soul-moral: ALL 20 TESTS PASSED');
shutdown();
} catch (e) { console.error(e.message); shutdown(); process.exit(1); }
