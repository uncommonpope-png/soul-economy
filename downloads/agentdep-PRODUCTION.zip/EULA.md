# AgentDEP End User License Agreement (EULA)

**Version 1.0.0 — Effective as of product purchase**

By downloading, installing, or using AgentDEP ("the Software"), you agree to the following terms:

## 1. License Grant
This license grants you a **non-exclusive, non-transferable, single-user** right to use the Software on devices you own or control.

## 2. Restrictions
You may NOT:
- Copy, duplicate, or redistribute the Software (in whole or in part) to any third party
- Upload the Software to any public or shared repository, server, or cloud storage
- Decompile, reverse engineer, or derive source code from the Software (except as permitted by law)
- Rent, lease, lend, sell, sublicense, or otherwise commercialize the Software
- Remove or alter any copyright, trademark, or license notices

## 3. License Key
- Each licensed copy is tied to a unique license key and email address
- You may activate the Software on up to 3 machines you own
- Sharing your license key violates this agreement

## 4. Ownership
The Software is licensed, not sold. All title, copyright, and intellectual property rights remain with the author.

## 5. No Warranty
THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.

## 6. Limitation of Liability
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DAMAGES ARISING FROM USE OF THE SOFTWARE.

## 7. Termination
This license terminates automatically if you violate any of its terms. Upon termination, you must delete all copies.

---

© 2026 AgentDEP. All rights reserved.
