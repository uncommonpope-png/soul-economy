import { writeFileSync, readFileSync } from 'fs';

const SHOP = 'buyasoulfinal.myshopify.com';

async function main() {
  const authRes = await fetch(`https://${SHOP}/admin/oauth/access_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: '0ac84aedb048e471d398df34a7d702e7',
      client_secret: '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',
      grant_type: 'client_credentials'
    })
  });
  const auth = await authRes.json();
  const TOKEN = auth.access_token;
  console.log('Token obtained');

  // Read the zip and upload as a file attachment
  const zipPath = 'C:\\Users\\uncom\\Desktop\\agentdep\\dist\\agentdep-v1.0.0.zip';
  const zipBuffer = readFileSync(zipPath);
  const base64zip = zipBuffer.toString('base64');

  const bodyHtml = `<h2>The First Runtime Dependency Manager for AI Agents — with Behavioral Contracts, Quality Scoring, Registry Marketplace, and Transitive Resolution</h2>

<p>AgentDep is the <strong>only</strong> AI agent package manager that combines runtime dependency resolution, behavioral contracts, quality scoring, a built-in registry marketplace, MCP server support, and air-gapped deployment — all in a single <strong>zero-dependency</strong> 52 KB zip file. No npm install. No node_modules. No external API keys.</p>

<hr>

<h3>What is AgentDep?</h3>
<p>Think <code>package.json</code> for AI agents — but with behavioral safety contracts, transitive dependency resolution with circular detection, and a quality-verified registry. AgentDep is the <strong>npm for AI agents</strong> that works fully offline with zero external dependencies.</p>

<p>Declare what your agent needs in <code>agentdep.json</code>, run <code>agentdep install</code>, and get a locked, verified, contract-checked dependency tree — every time, on every machine.</p>

<hr>

<h3>Why AgentDep?</h3>
<p><strong>Microsoft APM</strong> is config-only — it installs markdown files and MCP configs, <em>not</em> runtime dependencies. No behavioral contracts. No quality scores. No registry.</p>
<p><strong>skills.sh</strong> (Vercel) has 351K+ skills but <em>zero versioning</em>, no lockfile, no transitive deps, no security scanning.</p>
<p><strong>AgentDep</strong> is the only tool that gives you all three: a versioned registry, behavioral contracts for AI safety, and transitive runtime dependency resolution.</p>

<hr>

<h3>31 CLI Commands — Everything You Need</h3>

<h4>Project Management</h4>
<ul>
<li><strong>agentdep create</strong> — Scaffold a new agent project from 5 templates (coding-assistant, code-review, documentation, testing, browser-automation). Generates manifest, behavioral contract, README, SKILL.md, MCP config.</li>
<li><strong>agentdep init</strong> — Create a bare manifest</li>
<li><strong>agentdep install</strong> — Resolve and install all dependencies (transitive, with circular detection)</li>
<li><strong>agentdep uninstall</strong> — Remove a package</li>
<li><strong>agentdep list</strong> — List installed packages</li>
</ul>

<h4>Dependency Resolution</h4>
<ul>
<li><strong>Transitive DAG resolution</strong> — Resolves the full dependency graph, not just direct deps</li>
<li><strong>Range combinators</strong> — <code>^</code>, <code>~</code>, <code>>=</code>, <code><=</code>, <code>||</code>, hyphen ranges</li>
<li><strong>Circular dependency detection</strong> — Reports the full cycle chain, with <code>--allow-circular</code> flag</li>
<li><strong>Diamond handling</strong> — Conflict detection with best-version intersection</li>
<li><strong>Feature flags</strong> — <code>features: ["openapi"]</code> for conditional dependency loading</li>
<li><strong>agentdep outdated</strong> — Check for newer versions in the registry</li>
<li><strong>agentdep update</strong> — Bump manifest ranges to latest</li>
<li><strong>agentdep why</strong> — Trace why a dependency is needed (parent chain)</li>
<li><strong>agentdep graph --dot</strong> — Visualize the DAG as Graphviz DOT or ASCII tree</li>
<li><strong>agentdep tree</strong> — Show dependency tree</li>
</ul>

<h4>Behavioral Contracts (Unique to AgentDep)</h4>
<ul>
<li><strong>Contract schema</strong> — Declare inputs, outputs, side effects, performance constraints, dependencies</li>
<li><strong>Contract comparison</strong> — Detects missing I/O, side-effect escalation, latency/token overruns</li>
<li><strong>SHA256 behavioral fingerprint</strong> — Every contract is fingerprinted for integrity</li>
<li><strong>agentdep verify</strong> — Per-package contract mismatch reporting against parent contracts</li>
<li><strong>Lockfile v3</strong> — Stores contract fingerprints per package for supply-chain verification</li>
</ul>

<h4>Registry + Marketplace</h4>
<ul>
<li><strong>Local file-backed registry</strong> — Fully offline, no server required for basic use</li>
<li><strong>agentdep server</strong> — Start an HTTP registry server with 9 API endpoints</li>
<li><strong>Web marketplace UI</strong> — Browse, search, top-quality ranking, package detail with quality breakdown</li>
<li><strong>agentdep publish</strong> — Publish packages (local or remote registry, with auth)</li>
<li><strong>agentdep search</strong> — Search the registry</li>
<li><strong>agentdep login</strong> — Authenticate with remote registry</li>
<li><strong>agentdep info</strong> — Show package details</li>
</ul>

<h4>Security</h4>
<ul>
<li><strong>Hidden Unicode detection</strong> — Scans for 26 zero-width/homoglyph characters used in supply-chain attacks</li>
<li><strong>Path traversal detection</strong> — Prevents filesystem escape attacks</li>
<li><strong>Suspicious import scanning</strong> — Detects eval, child_process, process.env patterns</li>
<li><strong>CVE lookup</strong> — Quick check against known vulnerabilities (lodash, apm, glob-parent)</li>
<li><strong>agentdep audit</strong> — Full security audit of the dependency tree</li>
<li><strong>agentdep scan</strong> — Per-package security scan</li>
</ul>

<h4>Quality + Publisher System</h4>
<ul>
<li><strong>6-dimension quality scoring</strong> — Contract completeness (25%), documentation (15%), security (20%), publisher reputation (20%), code quality (10%), dependency quality (10%)</li>
<li><strong>0-100 quality score</strong> — With per-dimension breakdown</li>
<li><strong>agentdep quality</strong> — Score any package</li>
<li><strong>4 badge levels</strong> — Bronze, Silver, Gold, Trusted</li>
<li><strong>Domain + identity verification</strong> — Verified publisher badges</li>
<li><strong>agentdep publisher</strong> — Manage publishers, link packages</li>
<li><strong>agentdep verify-publisher</strong> — Verify publisher identity</li>
</ul>

<h4>MCP Server Support</h4>
<ul>
<li><strong>Native MCP in manifest</strong> — Declare MCP servers alongside skills and plugins</li>
<li><strong>.mcp.json generation</strong> — Install automatically writes/merges MCP config with stdio/http/sse transports</li>
<li><strong>Policy-gated MCP</strong> — Allow/block MCP servers via policy engine</li>
</ul>

<h4>Multi-Agent Compilation</h4>
<ul>
<li><strong>agentdep compile --target claude</strong> — Writes <code>.claude/skills/</code> + <code>.claude/CLAUDE.md</code> with behavioral contract</li>
<li><strong>agentdep compile --target cursor</strong> — Writes <code>.cursor/rules/*.mdc</code> with contract rules</li>
<li><strong>agentdep compile --target copilot</strong> — Writes <code>.github/copilot-instructions.md</code></li>
</ul>

<h4>Policy Engine</h4>
<ul>
<li><strong>agentdep-policy.json</strong> — Project-level governance file</li>
<li><strong>Allow/block packages</strong> — Whitelist and blacklist specific packages</li>
<li><strong>Allow/block categories</strong> — Restrict entire dependency categories</li>
<li><strong>Allow/block MCP servers</strong> — Control which MCP servers are permitted</li>
<li><strong>Side-effect restrictions</strong> — Block shell_execution, process_spawn, network_calls</li>
<li><strong>Contract requirement rule</strong> — Enforce that every package has a behavioral contract</li>
<li><strong>Max transitive depth</strong> — Prevent dependency chain bombs</li>
<li><strong>Install-time enforcement</strong> — Policy checked during every <code>agentdep install</code></li>
</ul>

<h4>Migration Tools</h4>
<ul>
<li><strong>agentdep import apm</strong> — Parse <code>apm.yml</code>, convert all deps + MCP servers to AgentDep format</li>
<li><strong>agentdep import skills-sh</strong> — Scan <code>.claude/skills/</code>, <code>.cursor/skills/</code>, convert to declared deps</li>
<li><strong>Auto-detection</strong> — Detects source format automatically</li>
</ul>

<h4>Deployment</h4>
<ul>
<li><strong>agentdep bundle</strong> — Create a self-contained air-gapped deployment zip with lockfile, modules, MCP config</li>
<li><strong>agentdep run</strong> — Execute a skill's JS entry point or display markdown instructions inline</li>
<li><strong>Zero npm dependencies</strong> — Only Node.js built-ins (http, fs, path, os, crypto, child_process)</li>
<li><strong>Fully offline</strong> — No API keys required for constant operation</li>
</ul>

<h4>Download Format</h4>
<p>The download is a 52 KB zip file containing 24 files (20 source modules, 2 binaries, README, package script). Unzip anywhere and run:</p>
<pre>node agentdep/bin/agentdep.js --help</pre>
<p>Requires Node.js 18+. No npm install. No environment setup.</p>

<hr>

<h3>Technical Specifications</h3>
<table>
<tr><th>Feature</th><th>AgentDep</th><th>Microsoft APM</th><th>skills.sh</th></tr>
<tr><td>Behavioral Contracts</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Quality Scoring</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Registry + Marketplace</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Transitive Dependencies</td><td>✅</td><td>✅</td><td>❌</td></tr>
<tr><td>Lockfile with Integrity</td><td>✅ (v3)</td><td>✅</td><td>❌</td></tr>
<tr><td>Circular Detection</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Security Scanning</td><td>✅</td><td>✅</td><td>❌</td></tr>
<tr><td>MCP Server Support</td><td>✅</td><td>✅</td><td>❌</td></tr>
<tr><td>Policy Engine</td><td>✅</td><td>✅</td><td>❌</td></tr>
<tr><td>Multi-Agent Compile</td><td>✅ (3 targets)</td><td>✅ (6 targets)</td><td>❌</td></tr>
<tr><td>Publisher Badges</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Project Scaffolding</td><td>✅ (5 templates)</td><td>❌</td><td>❌</td></tr>
<tr><td>Migration Tools</td><td>✅ (APM + skills.sh)</td><td>❌</td><td>❌</td></tr>
<tr><td>Air-Gapped Bundle</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Offline-First</td><td>✅</td><td>❌</td><td>✅</td></tr>
<tr><td>Zero npm Dependencies</td><td>✅</td><td>❌</td><td>✅</td></tr>
<tr><td>Dependency Freshness</td><td>✅</td><td>❌</td><td>❌</td></tr>
<tr><td>Skill Execution</td><td>✅</td><td>❌</td><td>❌</td></tr>
</table>

<hr>

<h3>Quick Start</h3>
<pre>
# Download and unzip — requires Node.js 18+

# Create a new agent project from template
node agentdep/bin/agentdep.js create my-coding-agent --template coding-assistant

# Initialize a project manually
node agentdep/bin/agentdep.js init my-agent 1.0.0

# Install dependencies (transitive resolution)
node agentdep/bin/agentdep.js install

# Verify behavioral contracts
node agentdep/bin/agentdep.js verify

# Score your package quality
node agentdep/bin/agentdep.js quality

# Compile for your AI agent
node agentdep/bin/agentdep.js compile --target claude

# Start the registry + marketplace server
node agentdep/bin/agentdep-server.js --port 3377
# Open http://localhost:3377 in your browser

# Create an air-gapped deployment bundle
node agentdep/bin/agentdep.js bundle

# Migrate from APM
node agentdep/bin/agentdep.js import apm

# Check for updates
node agentdep/bin/agentdep.js outdated
</pre>

<hr>

<h3>What's in the zip?</h3>
<ul>
<li><code>bin/agentdep.js</code> — Main CLI entry point (all 31 commands)</li>
<li><code>bin/agentdep-server.js</code> — Registry HTTP server + marketplace UI</li>
<li><code>lib/</code> — 18 source modules: resolver, install, lockfile, contract, quality, publisher, compile, policy, create, import-migrate, outdated, bundle, run, registry, registry-server, security, github, manifest</li>
<li><code>lib/marketplace-ui.html</code> — Zero-dependency single-file web marketplace (Browse, Top Quality, Registry Stats tabs)</li>
<li><code>README.md</code> — Full documentation</li>
</ul>

<hr>

<p><em>AgentDep v1.0.0 — Runtime Dependency Manager for AI Agents. 52 KB. Zero npm dependencies. MIT License. Built by Profit Prime.</em></p>`;

  // Create with file attachment
  const productPayload = {
    product: {
      title: 'AgentDep v1.0.0 — Runtime Dependency Manager for AI Agents',
      body_html: bodyHtml,
      vendor: 'Profit Prime',
      product_type: 'Software',
      tags: [
        'ai-agents', 'package-manager', 'dependency-manager',
        'behavioral-contracts', 'agent-registry', 'mcp-server',
        'ai-safety', 'agent-skills', 'supply-chain-security',
        'quality-scoring', 'publisher-verification',
        'air-gapped-deployment', 'offline-first', 'zero-dependencies',
        'developer-tools', 'cli-tool', 'agent-ecosystem',
        'transitive-dependencies', 'lockfile', 'security-scanning',
        'policy-engine', 'migration-tools', 'project-scaffolding',
        'multi-agent-compilation'
      ],
      variants: [{
        price: '49.00',
        requires_shipping: false,
        title: 'Digital Download (52 KB ZIP)',
        weight: 0,
        inventory_management: null,
        inventory_policy: 'continue'
      }],
      status: 'active',
      published_scope: 'global'
    }
  };

  const res = await fetch(`https://${SHOP}/admin/api/2026-04/products.json`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': TOKEN
    },
    body: JSON.stringify(productPayload)
  });

  const data = await res.json();
  if (data.errors) {
    console.error('Failed:', JSON.stringify(data.errors, null, 2));
    return;
  }

  const pid = data.product.id;
  console.log('Product created!');
  console.log('  ID:', pid);
  console.log('  Title:', data.product.title);
  console.log('  Price: $' + data.product.variants[0].price);
  console.log('  Tags:', data.product.tags.length);
  console.log('  Admin URL: https://' + SHOP + '/admin/products/' + pid);
  console.log('  Store URL: https://' + SHOP + '/products/agentdep');

  // Now upload the zip as a file attachment via the /files.json endpoint
  console.log('\nUploading zip file...');
  const fileRes = await fetch(`https://${SHOP}/admin/api/2026-04/files.json`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': TOKEN
    },
    body: JSON.stringify({
      file: {
        filename: 'agentdep-v1.0.0.zip',
        content_type: 'application/zip',
        file: base64zip
      }
    })
  });
  const fileData = await fileRes.json();
  if (fileData.errors) {
    console.log('File upload note:', JSON.stringify(fileData.errors).substring(0, 200));
    console.log('Add the zip manually in Shopify Admin → Products → AgentDep → Media');
  } else {
    console.log('File uploaded:', fileData.file?.url || 'OK');
  }
}

main().catch(e => console.error('Error:', e.message));
