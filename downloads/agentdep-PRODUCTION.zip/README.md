# AgentDep — Runtime Dependency Manager for AI Agents

**Zero npm dependencies. One zip file. 25 CLI commands.**

AgentDep is the only AI agent package manager with **behavioral contracts**, **quality scoring**, **transitive dependency resolution**, and **a built-in registry marketplace**.

## Quick Start

```bash
# Download and run (no npm install required)
node agentdep.js init my-agent 1.0.0
node agentdep.js install
```

Or install a package from the registry:

```bash
node agentdep.js install some-agent-skill
```

## Features

| Feature | AgentDep | Microsoft APM | skills.sh |
|---------|----------|---------------|-----------|
| Behavioral Contracts | ✅ | ❌ | ❌ |
| Quality Scoring | ✅ | ❌ | ❌ |
| Registry + Marketplace | ✅ | ❌ | ❌ |
| Transitive Dependencies | ✅ | ✅ | ❌ |
| Lockfile (v3) | ✅ | ✅ | ❌ |
| Circular Detection | ✅ | ❌ | ❌ |
| Security Scanning | ✅ | ✅ | ❌ |
| MCP Server Support | ✅ | ✅ | ❌ |
| Policy Engine | ✅ | ✅ | ❌ |
| Compile to Claude/Cursor/Copilot | ✅ | ✅ | ❌ |
| Publisher Badges | ✅ | ❌ | ❌ |
| Offline-First | ✅ | ❌ | ✅ |
| Zero npm Dependencies | ✅ | ❌ | ✅ |

## Commands

```
  init                     Create a new agentdep.json manifest
  install                  Resolve and install all dependencies
  uninstall <pkg>          Remove an installed package
  list                     List installed packages
  publish                  Publish package (local or remote registry)
  audit                    Security audit of dependency tree
  graph [--dot]            Visualize dependency DAG
  tree                     Show dependency tree
  why <package>            Why is this dependency needed?
  info <package>           Show package info
  search <query>           Search local registry
  login                    Authenticate with registry
  config <key> <value>     Set configuration
  server [--port] [--host] Start registry HTTP server + marketplace
  add-token <token> <user> Add publisher token for server
  scan <package>           Security scan
  verify                   Verify behavioral contracts
  compile [--target]       Compile to Claude/Cursor/Copilot
  policy <init|check|block|allow>
                           Manage policy rules
  quality <package>        Score package quality
  publisher <list|create|link|name>
                           Manage publishers
  verify-publisher <name>  Verify publisher
```

## Manifest Example

```json
{
  "name": "my-agent",
  "version": "1.0.0",
  "agent": "claude-code",
  "description": "My custom AI agent",
  "behavioral": {
    "inputs": [{ "type": "user_query" }],
    "outputs": [{ "type": "code_diff" }],
    "sideEffects": [
      { "type": "file_writes", "permission": "allowed" },
      { "type": "network_calls", "permission": "restricted" }
    ],
    "performance": { "maxLatencyMs": 30000 }
  },
  "dependencies": {
    "skills": ["skill-name@^1.0.0"]
  },
  "mcp": {
    "servers": [
      { "name": "github-mcp", "transport": "stdio", "source": "github/org/mcp-server" }
    ]
  }
}
```

## Registry Server + Marketplace

```bash
node bin/agentdep-server.js --port 3377
```

Open http://localhost:3377 in your browser for the marketplace UI.

## License

MIT
