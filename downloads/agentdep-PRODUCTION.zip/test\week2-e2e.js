// Week 2 E2E tests: diamond deps, transitive resolution, circular detection, graph
const r = require('../lib/resolver');
const path = require('path');
const fs = require('fs');

function assert(cond, msg) { if (!cond) throw new Error('FAIL: ' + msg); else console.log('  PASS: ' + msg); }

// Test 1: Diamond dependency (A depends on B and C, both B and C depend on D)
console.log('\n1. Diamond dependency resolution:');
const mf = {
  name: 'diamond-test', version: '1.0.0',
  dependencies: {
    skills: [
      { name: 'b', version: '^1.0.0', source: 'org/b' },
      { name: 'c', version: '^1.0.0', source: 'org/c' }
    ]
  }
};

// Create local registry entries for B, C, D with D as transitive
const regDir = path.join(require('os').homedir(), '.agentdep', 'registry');

function publishMock(name, version, deps, features) {
  const manifest = { name, version, dependencies: deps || {}, features: features || {} };

  // Write version to registry dir
  const regDir = path.join(require('os').homedir(), '.agentdep', 'registry');
  const vDir = path.join(regDir, name, 'versions', version);
  if (!fs.existsSync(vDir)) fs.mkdirSync(vDir, { recursive: true });
  fs.writeFileSync(path.join(vDir, 'agentdep.json'), JSON.stringify(manifest, null, 2));

  // Merge into packages metadata (append version, don't overwrite)
  const pkgDir2 = path.join(require('os').homedir(), '.agentdep', 'packages', name);
  if (!fs.existsSync(pkgDir2)) fs.mkdirSync(pkgDir2, { recursive: true });
  const metaPath = path.join(pkgDir2, 'metadata.json');
  let meta = { name, versions: {}, published: new Date().toISOString(), updated: new Date().toISOString() };
  if (fs.existsSync(metaPath)) {
    try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch {}
  }
  meta.versions[version] = { published: new Date().toISOString(), manifest };
  meta.updated = new Date().toISOString();
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));

  return manifest;
}

// B depends on D (^1.0.0)
publishMock('b', '1.2.0', { skills: [{ name: 'd', version: '^1.0.0', source: 'org/d' }] });
// C depends on D (^2.0.0) - different major version = conflict
publishMock('c', '1.0.0', { skills: [{ name: 'd', version: '^2.0.0', source: 'org/d' }] });
// D versions available
publishMock('d', '1.0.0', {});
publishMock('d', '1.5.0', {});
publishMock('d', '2.0.0', {});
publishMock('d', '2.1.0', {});

const result = r.resolveDependencies(mf, {});
assert(result.resolved.length === 3, 'resolved 3 (b + c + d once)');
console.log('Resolved packages:');
const byName = {};
result.resolved.forEach(function(d) { byName[d.name] = d; console.log('  ', d.name, '@', d.resolvedVersion, '- parents:', d.parents); });
assert(byName['b'] !== undefined, 'b resolved');
assert(byName['c'] !== undefined, 'c resolved');
assert(byName['d'] !== undefined, 'd resolved (shared)');
assert(result.conflicts.length > 0, 'conflict detected (B wants d@^1.0.0, C wants d@^2.0.0)');

// Test 2: Circular dependency detection
console.log('\n2. Circular dependency detection:');
publishMock('circ-a', '1.0.0', { skills: [{ name: 'circ-b', version: '*', source: 'org/circ-b' }] });
publishMock('circ-b', '1.0.0', { skills: [{ name: 'circ-a', version: '*', source: 'org/circ-a' }] });
const circularMf = { name: 'circ-test', version: '1.0.0', dependencies: { skills: [{ name: 'circ-a', version: '*', source: 'org/circ-a' }] } };
const circularResult = r.resolveDependencies(circularMf, {});
console.log('  Circular deps found:', circularResult.circularDeps.length);
assert(circularResult.circularDeps.length > 0, 'circular dependency detected');
if (circularResult.circularDeps.length > 0) {
  console.log('  Chain:', circularResult.circularDeps[0].chain.join(' -> '));
}

// Test 3: Feature flags
console.log('\n3. Feature flags resolution:');
publishMock('tool-a', '2.0.0', { skills: [{ name: 'parser', version: '*', source: 'org/parser' }] }, {
  openapi: [{ name: 'openapi-parser', version: '^1.0.0', source: 'org/openapi-parser' }],
  graphql: [{ name: 'graphql-parser', version: '^1.0.0', source: 'org/graphql-parser' }]
});
publishMock('parser', '1.0.0', {});
publishMock('openapi-parser', '1.0.0', {});
publishMock('graphql-parser', '1.0.0', {});

const featMf = { name: 'feat-test', version: '1.0.0', dependencies: { skills: [{ name: 'tool-a', version: '^2.0.0', source: 'org/tool-a', features: ['openapi'] }] } };
const featResult = r.resolveDependencies(featMf, {});
console.log('  Resolved:', featResult.resolved.length, 'packages');
featResult.resolved.forEach(function(d) { console.log('    ', d.name, '@', d.resolvedVersion); });
assert(featResult.resolved.some(function(d) { return d.name === 'openapi-parser'; }), 'openapi-parser resolved via feature flag');
assert(!featResult.resolved.some(function(d) { return d.name === 'graphql-parser'; }), 'graphql-parser NOT resolved (unselected feature)');

// Test 4: DOT graph output
console.log('\n4. DOT graph generation:');
const dotGraph = r.toDOT(result.dag);
console.log('  DOT output length:', dotGraph.length, 'chars');
assert(dotGraph.includes('digraph'), 'DOT starts with digraph');
assert(dotGraph.includes('->'), 'DOT contains edges');

// Test 5: Tree string output
console.log('\n5. Tree string output:');
const tree = r.toTreeString(result.dag);
console.log(tree);

// Test 6: Detect circular deps from dag
console.log('\n6. Circular dep detection from DAG:');
const cycles = r.detectCircularDeps(result.dag);
console.log('  Cycles found:', cycles.length);

// Test 7: Full install with transitive deps
console.log('\n7. Full install flow:');
const installMod = require('../lib/install');
const targetDir = path.join(__dirname, 'e2e-install');
if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
fs.mkdirSync(targetDir, { recursive: true });

const manifestMod = require('../lib/manifest');
manifestMod.writeManifest(targetDir, mf);

const installResult = installMod.install(targetDir, { verbose: false, dryRun: true });
console.log('  Dry-run would install:', installResult.resolved.length, 'packages');
assert(installResult.resolved.length >= 2, 'install resolves packages');
if (installResult.conflicts.length === 0) console.log('  (no conflicts in dry-run - packages not in local registry)');
assert(installResult.circularDeps !== undefined, 'install returns circularDeps');

// Cleanup
fs.rmSync(targetDir, { recursive: true, force: true });

console.log('\n=== All Week 2 tests PASS ===');
