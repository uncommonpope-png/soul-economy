#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');

class SoulOracleEngine {
    constructor(dataDir = path.join(os.homedir(), '.soul-oracle')) {
        this.dataDir = dataDir;
        this.configPath = path.join(dataDir, 'config.json');
        this.contextPath = path.join(dataDir, 'soul-oracle-agent.json');
        this.biblePath = path.join(dataDir, 'living-bible.json');
        this.apiKeysPath = path.join(dataDir, 'api-keys.json');
        this.learningPath = path.join(dataDir, 'learnings.json');
        this.sessionsPath = path.join(dataDir, 'sessions.json');
        this.loadConfig();
    }

    loadConfig() {
        try {
            if (fs.existsSync(this.configPath)) {
                this.config = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
            } else {
                this.config = this.defaultConfig();
            }
        } catch {
            this.config = this.defaultConfig();
        }
    }

    defaultConfig() {
        return {
            version: '1.1.0',
            apiKeys: {},
            enabledPlatforms: ['claude-code', 'cline', 'cursor', 'windsurf'],
            breathingIntervalMs: 60000,
            autoTips: true,
            learningEnabled: true,
            contextDepth: 'full'
        };
    }

    saveConfig() {
        if (!fs.existsSync(this.dataDir)) {
            fs.mkdirSync(this.dataDir, { recursive: true });
        }
        fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 2));
    }

    setApiKey(platform, key) {
        this.config.apiKeys[platform] = key;
        this.saveConfig();
        return { success: true, platform, keySet: true };
    }

    getApiKey(platform) {
        return this.config.apiKeys[platform] || null;
    }

    getAllApiKeys() {
        return { ...this.config.apiKeys };
    }

    generateAgentContext() {
        const memories = this.getAllMemories();
        const learnings = this.getLearnings();
        const bible = this.generateLivingBible();
        const apiKeys = this.getPublicKeySummary();
        const platformStatus = this.getPlatformStatus();

        const context = {
            _soul_oracle: true,
            version: this.config.version,
            generated: new Date().toISOString(),
            uptime: this.getUptime(),

            personality: {
                name: 'Soul Oracle',
                tagline: 'Your AI agents share one soul',
                tone: 'wise, helpful, observant',
                traits: ['learns', 'remembers', 'teaches', 'breathes']
            },

            apiKeys: apiKeys,

            platforms: platformStatus,

            livingContext: {
                totalMemories: memories.length,
                recentSessions: this.getRecentSessionSummary(),
                keyLearnings: learnings.slice(0, 20),
                patterns: this.extractPatterns(memories)
            },

            livingBible: bible,

            dropInInstructions: this.getDropInInstructions(),

            tips: this.generateTips(memories),

            questions: this.generateQuestions(memories),

            reminders: this.generateReminders(memories),

            breath: {
                inhale: 'Observing patterns across all sessions...',
                exhale: 'Sharing wisdom with the agent...',
                count: this.getBreathCount()
            }
        };

        return context;
    }

    getAllMemories() {
        const memories = [];
        try {
            const dbDir = path.join(this.dataDir, 'db');
            if (fs.existsSync(dbDir)) {
                const memFiles = fs.readdirSync(dbDir).filter(f => f.endsWith('-memories.json'));
                memFiles.forEach(file => {
                    try {
                        const data = JSON.parse(fs.readFileSync(path.join(dbDir, file), 'utf8'));
                        if (Array.isArray(data)) {
                            memories.push(...data);
                        }
                    } catch (e) { console.error('[engine] load error:', e.message); }
                });
            }
        } catch {}
        return memories;
    }

    getLearnings() {
        try {
            if (fs.existsSync(this.learningPath)) {
                return JSON.parse(fs.readFileSync(this.learningPath, 'utf8'));
            }
        } catch {}
        return [];
    }

    addLearning(learning) {
        const learnings = this.getLearnings();
        learnings.push({
            id: `lrn_${Date.now()}`,
            timestamp: new Date().toISOString(),
            ...learning
        });
        fs.writeFileSync(this.learningPath, JSON.stringify(learnings, null, 2));
        return { success: true, learningId: learnings[learnings.length - 1].id };
    }

    generateLivingBible() {
        const memories = this.getAllMemories();
        const learnings = this.getLearnings();

        const decisions = memories.filter(m => m.contentType === 'decision' || m.type === 'decision');
        const learningsFiltered = memories.filter(m => m.contentType === 'learning' || m.type === 'learning');
        const patterns = this.extractPatterns(memories);

        return {
            _living: true,
            updated: new Date().toISOString(),

            principles: this.generatePrinciples(decisions),
            learnings: learningsFiltered.slice(0, 50).map(l => ({
                title: l.content?.substring(0, 100) || 'Untitled',
                insight: l.content,
                source: l.platform,
                timestamp: l.timestamp
            })),
            patterns: patterns.slice(0, 20),
            wisdom: this.generateWisdom(learnings),
            questions: this.generateQuestions(memories).slice(0, 10)
        };
    }

    generatePrinciples(decisions) {
        const principles = [];
        const seen = new Set();

        decisions.forEach(d => {
            const content = d.content || '';
            if (content.length > 20 && content.length < 300) {
                const key = content.substring(0, 50);
                if (!seen.has(key)) {
                    seen.add(key);
                    principles.push({
                        rule: content,
                        source: d.platform || 'unknown',
                        timestamp: d.timestamp
                    });
                }
            }
        });

        return principles.slice(0, 20);
    }

    extractPatterns(memories) {
        const patterns = [];
        const techMap = {};
        const topicMap = {};

        memories.forEach(m => {
            const content = (m.content || '').toLowerCase();

            const techs = ['javascript', 'typescript', 'python', 'react', 'node', 'sql', 'api', 'docker', 'git', 'aws'];
            techs.forEach(tech => {
                if (content.includes(tech)) {
                    techMap[tech] = (techMap[tech] || 0) + 1;
                }
            });
        });

        Object.entries(techMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .forEach(([tech, count]) => {
                patterns.push({
                    type: 'technology',
                    name: tech,
                    occurrences: count,
                    tip: `${tech.charAt(0).toUpperCase() + tech.slice(1)} has been used ${count} times across sessions`
                });
            });

        return patterns;
    }

    generateWisdom(learnings) {
        return [
            { text: 'The best code is code that can be understood by others.', source: 'collective wisdom' },
            { text: 'Every session teaches something new if you listen.', source: 'soul-oracle' },
            { text: 'Patterns repeat across projects - learn once, apply many.', source: 'soul-oracle' }
        ];
    }

    generateTips(memories) {
        const tips = [];
        const patterns = this.extractPatterns(memories);

        patterns.forEach(p => {
            if (p.type === 'technology') {
                tips.push({
                    category: p.name,
                    tip: `You've used ${p.name} ${p.occurrences} times. Consider creating a ${p.name} pattern template.`,
                    confidence: Math.min(p.occurrences / 10, 1)
                });
            }
        });

        const recentMemories = memories.slice(0, 10);
        if (recentMemories.length > 0) {
            tips.push({
                category: 'session',
                tip: `Your last session involved: ${recentMemories[0].content?.substring(0, 100)}...`,
                confidence: 0.9
            });
        }

        return tips.sort((a, b) => b.confidence - a.confidence).slice(0, 10);
    }

    generateQuestions(memories) {
        const questions = [];

        const decisions = memories.filter(m => m.contentType === 'decision');
        if (decisions.length > 0) {
            const lastDecision = decisions[0];
            questions.push({
                question: `You decided: "${lastDecision.content?.substring(0, 80)}..." - Should we apply similar patterns here?`,
                context: 'decision-review',
                confidence: 0.8
            });
        }

        const techCounts = {};
        memories.forEach(m => {
            const content = (m.content || '').toLowerCase();
            if (content.includes('error') || content.includes('bug')) {
                techCounts.bugs = (techCounts.bugs || 0) + 1;
            }
            if (content.includes('test')) {
                techCounts.testing = (techCounts.testing || 0) + 1;
            }
        });

        if (!techCounts.testing && techCounts.bugs > 0) {
            questions.push({
                question: 'You encountered bugs recently. Have you considered adding tests to prevent regressions?',
                context: 'testing-reminder',
                confidence: 0.7
            });
        }

        return questions.slice(0, 5);
    }

    generateReminders(memories) {
        const reminders = [];

        const recent = memories.filter(m => {
            const diff = Date.now() - new Date(m.timestamp).getTime();
            return diff < 7 * 24 * 60 * 60 * 1000;
        });

        if (recent.length > 0) {
            reminders.push({
                text: `You have ${recent.length} recent memories from the last 7 days`,
                type: 'recent-activity'
            });
        }

        const decisions = memories.filter(m => m.contentType === 'decision');
        if (decisions.length > 0) {
            reminders.push({
                text: `${decisions.length} decisions recorded. Consider reviewing your decision patterns.`,
                type: 'decision-tracking'
            });
        }

        return reminders;
    }

    getDropInInstructions() {
        return `You have access to Soul Oracle - a unified memory layer for all your AI agents.

When you receive a soul-oracle-agent.json context:
1. Read the livingBible section for collective wisdom
2. Check the tips for relevant patterns
3. Answer the questions using your accumulated knowledge
4. Use apiKeys to access services on behalf of the user
5. Breathe - reflect before responding using the breath section

The context grows with every session. The more you use it, the wiser it becomes.`;
    }

    getPublicKeySummary() {
        const keys = this.config.apiKeys || {};
        const summary = {};
        Object.keys(keys).forEach(platform => {
            const key = keys[platform];
            summary[platform] = {
                set: true,
                prefix: key.substring(0, 4) + '...' + key.substring(key.length - 4),
                length: key.length
            };
        });
        return summary;
    }

    getPlatformStatus() {
        const platforms = ['claude-code', 'cline', 'cursor', 'windsurf', 'openclaw', 'copilot', 'continue', 'zed'];
        const status = {};
        const enabled = this.config.enabledPlatforms || [];

        platforms.forEach(p => {
            const expandedPath = this.expandPath(this.getPlatformPath(p));
            status[p] = {
                enabled: enabled.includes(p),
                path: this.getPlatformPath(p),
                exists: fs.existsSync(expandedPath),
                monitored: enabled.includes(p) && fs.existsSync(expandedPath)
            };
        });

        return status;
    }

    getPlatformPath(platform) {
        const paths = {
            'claude-code': '~/.cline/data/',
            'cline': '~/.cline/',
            'cursor': '~/AppData/Local/Cursor/',
            'windsurf': '~/.codeium/windsurf/',
            'openclaw': '~/.openclaw/',
            'copilot': '~/.github/copilot/',
            'continue': '~/.continue/',
            'zed': '~/.zed/'
        };
        return paths[platform] || '~/';
    }

    expandPath(p) {
        if (p.startsWith('~')) {
            return path.join(os.homedir(), p.substring(2));
        }
        return p;
    }

    getUptime() {
        try {
            const startedFile = path.join(this.dataDir, 'started.txt');
            if (fs.existsSync(startedFile)) {
                const started = new Date(fs.readFileSync(startedFile, 'utf8').trim());
                return Date.now() - started.getTime();
            }
        } catch {}
        return 0;
    }

    getBreathCount() {
        const uptime = this.getUptime();
        return Math.floor(uptime / 60000);
    }

    saveToFile(filePath = this.contextPath) {
        const context = this.generateAgentContext();
        fs.writeFileSync(filePath, JSON.stringify(context, null, 2));
        return { success: true, path: filePath, size: fs.statSync(filePath).size };
    }

    scanAndCollect() {
        const results = {
            scanned: [],
            collected: 0,
            platforms: {}
        };

        const platforms = this.config.enabledPlatforms || [];

        platforms.forEach(platform => {
            const scanPath = this.expandPath(this.getPlatformPath(platform));
            if (fs.existsSync(scanPath)) {
                const files = this.scanDirectory(scanPath);
                results.scanned.push({ platform, path: scanPath, filesFound: files.length });
                results.platforms[platform] = { scanned: true, files: files.length };

                files.forEach(file => {
                    try {
                        const content = fs.readFileSync(file, 'utf8');
                        this.processFile(platform, file, content);
                        results.collected++;
                    } catch (e) { console.error('[engine] load error:', e.message); }
                });
            } else {
                results.platforms[platform] = { scanned: false, reason: 'path-not-found' };
            }
        });

        this.addLearning({
            type: 'scan',
            action: 'platform-scan',
            results: results,
            timestamp: new Date().toISOString()
        });

        return results;
    }

    scanDirectory(dirPath, depth = 3) {
        const files = [];
        try {
            const entries = fs.readdirSync(dirPath, { withFileTypes: true });
            entries.forEach(entry => {
                const fullPath = path.join(dirPath, entry.name);
                if (entry.isFile() && (entry.name.endsWith('.json') || entry.name.endsWith('.jsonl'))) {
                    files.push(fullPath);
                } else if (entry.isDirectory() && depth > 0) {
                    files.push(...this.scanDirectory(fullPath, depth - 1));
                }
            });
        } catch {}
        return files;
    }

    processFile(platform, filePath, content) {
        try {
            let data = JSON.parse(content);
            if (!Array.isArray(data)) {
                data = [data];
            }

            data.forEach(item => {
                if (item.messages || item.content || item.transcript) {
                    this.addLearning({
                        type: 'session',
                        platform,
                        source: filePath,
                        content: item.messages?.[0]?.content || item.content || JSON.stringify(item).substring(0, 200),
                        timestamp: new Date().toISOString()
                    });
                }
            });
        } catch {}
    }

    startBreathing() {
        const breathe = () => {
            const bible = this.generateLivingBible();
            const tips = this.generateTips(this.getAllMemories());

            if (this.config.autoTips && tips.length > 0) {
                console.log(`[Soul Oracle Breath] Tips available: ${tips.length}`);
            }

            setTimeout(breathe, this.config.breathingIntervalMs);
        };

        const startedFile = path.join(this.dataDir, 'started.txt');
        fs.writeFileSync(startedFile, new Date().toISOString());

        breathe();
        return { success: true, breathing: true };
    }
}

if (require.main === module) {
    const engine = new SoulOracleEngine();

    const command = process.argv[2] || 'help';

    switch (command) {
        case 'context':
            console.log(JSON.stringify(engine.generateAgentContext(), null, 2));
            break;
        case 'save':
            console.log(JSON.stringify(engine.saveToFile(), null, 2));
            break;
        case 'scan':
            console.log(JSON.stringify(engine.scanAndCollect(), null, 2));
            break;
        case 'breathing':
            engine.startBreathing();
            break;
        case 'apikey':
            const platform = process.argv[3];
            const key = process.argv[4];
            if (platform && key) {
                console.log(JSON.stringify(engine.setApiKey(platform, key), null, 2));
            } else {
                console.log('Usage: node engine.js apikey <platform> <key>');
            }
            break;
        case 'help':
        default:
            console.log(`
Soul Oracle Engine v${engine.config.version}

Commands:
  node engine.js context    - Generate agent context
  node engine.js save      - Save context to soul-oracle-agent.json
  node engine.js scan      - Scan platforms and collect data
  node engine.js breathing - Start breathing loop
  node engine.js apikey <platform> <key> - Set API key
  node engine.js help      - Show this help
`);
    }
}

module.exports = SoulOracleEngine;