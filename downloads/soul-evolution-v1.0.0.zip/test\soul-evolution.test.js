#!/usr/bin/env node
const assert=require('assert'),fs=require('fs'),path=require('path'),os=require('os');
const TD=path.join(os.homedir(),'.soul-evo-test');
console.log('\n Evolution Soul — Test Suite\n');
let p=0,f=0;function t(n,fn){try{fn();console.log('  OK '+n);p++;}catch(e){console.log('  FAIL '+n+': '+e.message);f++;}}
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
const E=require('../lib/soul-evolution.js');
t('Loads with key',()=>{const e=new E({dataDir:TD});assert(e.apiKey);assert(e.apiKey.length>10);});
t('Starts at level 1',()=>{const e=new E({dataDir:TD});assert(e.level===1);assert(e.xp===0);assert(e.species==='learner');});
t('Gain XP increases xp',()=>{const e=new E({dataDir:TD});const r=e.gainXP(50);assert(r.xp===50);assert(r.gained===50);});
t('Level up works',()=>{const e=new E({dataDir:TD});e.gainXP(150);assert(e.level>=2);});
t('Species evolves with level',()=>{const e=new E({dataDir:TD});for(let i=0;i<5;i++)e.gainXP(200);assert(['apprentice','adept','wise_one'].includes(e.species));});
t('Improve skill works',()=>{const e=new E({dataDir:TD});const r=e.improveSkill('reasoning');assert(r.skill==='reasoning');assert(r.xpGained>0);});
t('5 skills defined',()=>{const e=new E({dataDir:TD});assert(Object.keys(e.SKILL_TREE).length===5);});
t('Stats ok',()=>{const e=new E({dataDir:TD});const s=e.getStats();assert(s.name==='Evolution Soul');assert(s.level>=1);});
t('Key persists',()=>{const e=new E({dataDir:TD});assert(fs.existsSync(e.keyPath));});
t('Auth works',()=>{const e=new E({dataDir:TD,apiKey:'k'});assert(e.checkAuth({headers:{'x-api-key':'k'}}));assert(!e.checkAuth({headers:{'x-api-key':'w'}}));});
t('State persists to disk',()=>{const d=TD+'_persist';if(fs.existsSync(d))fs.rmSync(d,{recursive:true,force:true});const e1=new E({dataDir:d});e1.gainXP(50);const e2=new E({dataDir:d});assert(e2.xp===50);fs.rmSync(d,{recursive:true,force:true});});
if(fs.existsSync(TD))fs.rmSync(TD,{recursive:true,force:true});
console.log(p+'/'+(p+f)+' passed\n');process.exit(f>0?1:0);